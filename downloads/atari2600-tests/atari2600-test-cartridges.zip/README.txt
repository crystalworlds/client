Atari 2600 test cartridges, from the CrystalWorlds.Media project
================================================================

There is no public test suite for the Atari 2600, so we wrote these: one
self-checking test cartridge for each of 15 bank-switching schemes, the
ways a 2600 cartridge larger than 4 KB swaps its banks into view (and, for
the RAM schemes, adds extra memory).

Every bank of each cartridge carries a marker byte that names it. The test
visits every switching address of its scheme, by a read and by a write, as
games do, and after each switch reads the marker to check that the right
bank is in view. The RAM schemes also write a pattern through the RAM's
write addresses and read it back through its read addresses, across bank
switches.

How to read the result: within a second the screen turns green if every
check was as the scheme must behave, and red if one was not (these are the
colours on an NTSC console). The verdict is also in the console's RAM:
address 80 holds 1 for a pass and 2 for a fail, and address 81 counts the
checks, so after a fail it names the check that failed.

What the real console shows: green, on every cartridge. The expected
results come from how each scheme is built, not from photographs of a
console.

How to run them on a console: copy a .bin file to a 2600 flash cartridge
as you would a game, and start it. A flash cartridge or emulator that
does not recognise the scheme from the file can usually be told it by the
file's extension: rename the file to end in the scheme's name, for example
test_F8SC.F8SC, or see your cartridge's manual for the names it accepts.

How three emulators did on them (measured 7 Oct 2026) is on the site's home
page, on the Atari 2600 card under "How we compare".

Files
-----
test_2K      2K, 2 KB (no switching)
test_4K      4K, 4 KB (no switching)
test_4KSC    4K with Superchip RAM (128 bytes)
test_F8      F8, 8 KB, two banks (Atari)
test_F8SC    F8 with Superchip RAM
test_F6      F6, 16 KB, four banks (Atari)
test_F6SC    F6 with Superchip RAM
test_F4      F4, 32 KB, eight banks (Atari)
test_F4SC    F4 with Superchip RAM
test_FA      FA, 12 KB with 256 bytes of RAM (CBS RAM Plus)
test_FE      FE, 8 KB, switched by the stack (Activision)
test_E0      E0, 8 KB in 1 KB slices (Parker Brothers)
test_E7      E7, 16 KB with 2 KB of RAM (M-Network)
test_3F      3F, 32 KB in 2 KB banks (Tigervision)
test_3E      3E, 3F with RAM banks added

Source
------
The source folder holds each cartridge's assembly source and the hardware
names they share (hw.inc). They assemble with dasm, for example:
  dasm test_F8.asm -f3 -I. -otest_F8.bin
which gives the file here byte for byte.

Licence: this zip is MIT-licensed (see LICENSE), unlike the rest of the site.
