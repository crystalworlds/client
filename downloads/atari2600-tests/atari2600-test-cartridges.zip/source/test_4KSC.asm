        processor 6502
        include "hw.inc"
        SEG code
        ORG $0000
        RORG $F000
        ds.b 256, 0
        ORG $0200
        RORG $F200
        MAC CHECK0
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail0
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail0  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show0
Pass0  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show0  sta COLUBK+$00
F0     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V0     sta WSYNC+$00
        dex
        bne V0
        lda #0
        sta VBLANK+$00
        ldx #192
P0     sta WSYNC+$00
        dex
        bne P0
        lda #2
        sta VBLANK+$00
        ldx #30
O0     sta WSYNC+$00
        dex
        bne O0
        jmp F0
Start0   CLEAN_START
        lda $FE00
        CHECK0 75
        ldx #0
W0      txa
        eor #$A5
        sta $F000,x
        inx
        cpx #128
        bne W0
        ldx #0
R0      txa
        eor #$A5
        cmp $F080,x
        beq K0
        jmp Fail0
K0      inx
        cpx #128
        bne R0
        jmp Pass0
        ORG $0E00
        RORG $FE00
        .byte $4B
        ORG $0FFA
        RORG $FFFA
        .byte "SC"
        ORG $0FFC
        RORG $FFFC
        .word Start0
        .word Start0
