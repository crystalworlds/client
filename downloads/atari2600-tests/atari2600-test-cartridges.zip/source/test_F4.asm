        processor 6502
        include "hw.inc"
        SEG bank0
        ORG $0000
        RORG $F000
        .byte 1, 8, 15, 22, 29, 36, 43, 50, 57, 64, 71, 78, 85, 92, 99, 106
        .byte 113, 120, 127, 134, 141, 148, 155, 162, 169, 176, 183, 190, 197, 204, 211, 218
        .byte 225, 232, 239, 246, 253, 4, 11, 18, 25, 32, 39, 46, 53, 60, 67, 74
        .byte 81, 88, 95, 102, 109, 116, 123, 130, 137, 144, 151, 158, 165, 172, 179, 186
        .byte 193, 200, 207, 214, 221, 228, 235, 242, 249, 0, 7, 14, 21, 28, 35, 42
        .byte 49, 56, 63, 70, 77, 84, 91, 98, 105, 112, 119, 126, 133, 140, 147, 154
        .byte 161, 168, 175, 182, 189, 196, 203, 210, 217, 224, 231, 238, 245, 252, 3, 10
        .byte 17, 24, 31, 38, 45, 52, 59, 66, 73, 80, 87, 94, 101, 108, 115, 122
        .byte 129, 136, 143, 150, 157, 164, 171, 178, 185, 192, 199, 206, 213, 220, 227, 234
        .byte 241, 248, 255, 6, 13, 20, 27, 34, 41, 48, 55, 62, 69, 76, 83, 90
        .byte 97, 104, 111, 118, 125, 132, 139, 146, 153, 160, 167, 174, 181, 188, 195, 202
        .byte 209, 216, 223, 230, 237, 244, 251, 2, 9, 16, 23, 30, 37, 44, 51, 58
        .byte 65, 72, 79, 86, 93, 100, 107, 114, 121, 128, 135, 142, 149, 156, 163, 170
        .byte 177, 184, 191, 198, 205, 212, 219, 226, 233, 240, 247, 254, 5, 12, 19, 26
        .byte 33, 40, 47, 54, 61, 68, 75, 82, 89, 96, 103, 110, 117, 124, 131, 138
        .byte 145, 152, 159, 166, 173, 180, 187, 194, 201, 208, 215, 222, 229, 236, 243, 250
        ORG $0200
        RORG $F200
        MAC CHECK0
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail0
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail0  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show0
Pass0  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show0  sta COLUBK+$00
F0     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V0     sta WSYNC+$00
        dex
        bne V0
        lda #0
        sta VBLANK+$00
        ldx #192
P0     sta WSYNC+$00
        dex
        bne P0
        lda #2
        sta VBLANK+$00
        ldx #30
O0     sta WSYNC+$00
        dex
        bne O0
        jmp F0
Start0   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK0 0
        lda $FFF5
        lda $FE00
        CHECK0 1
        lda $FFF6
        lda $FE00
        CHECK0 2
        lda $FFF7
        lda $FE00
        CHECK0 3
        lda $FFF8
        lda $FE00
        CHECK0 4
        lda $FFF9
        lda $FE00
        CHECK0 5
        lda $FFFA
        lda $FE00
        CHECK0 6
        lda $FFFB
        lda $FE00
        CHECK0 7
        sta $FFFB
        lda $FE00
        CHECK0 7
        sta $FFFA
        lda $FE00
        CHECK0 6
        sta $FFF9
        lda $FE00
        CHECK0 5
        sta $FFF8
        lda $FE00
        CHECK0 4
        sta $FFF7
        lda $FE00
        CHECK0 3
        sta $FFF6
        lda $FE00
        CHECK0 2
        sta $FFF5
        lda $FE00
        CHECK0 1
        sta $FFF4
        lda $FE00
        CHECK0 0
        jmp Pass0
        ORG $0E00
        RORG $FE00
        .byte 0
        ORG $0FFC
        RORG $FFFC
        .word Start0
        .word Start0
        SEG bank1
        ORG $1000
        RORG $F000
        .byte 14, 21, 28, 35, 42, 49, 56, 63, 70, 77, 84, 91, 98, 105, 112, 119
        .byte 126, 133, 140, 147, 154, 161, 168, 175, 182, 189, 196, 203, 210, 217, 224, 231
        .byte 238, 245, 252, 3, 10, 17, 24, 31, 38, 45, 52, 59, 66, 73, 80, 87
        .byte 94, 101, 108, 115, 122, 129, 136, 143, 150, 157, 164, 171, 178, 185, 192, 199
        .byte 206, 213, 220, 227, 234, 241, 248, 255, 6, 13, 20, 27, 34, 41, 48, 55
        .byte 62, 69, 76, 83, 90, 97, 104, 111, 118, 125, 132, 139, 146, 153, 160, 167
        .byte 174, 181, 188, 195, 202, 209, 216, 223, 230, 237, 244, 251, 2, 9, 16, 23
        .byte 30, 37, 44, 51, 58, 65, 72, 79, 86, 93, 100, 107, 114, 121, 128, 135
        .byte 142, 149, 156, 163, 170, 177, 184, 191, 198, 205, 212, 219, 226, 233, 240, 247
        .byte 254, 5, 12, 19, 26, 33, 40, 47, 54, 61, 68, 75, 82, 89, 96, 103
        .byte 110, 117, 124, 131, 138, 145, 152, 159, 166, 173, 180, 187, 194, 201, 208, 215
        .byte 222, 229, 236, 243, 250, 1, 8, 15, 22, 29, 36, 43, 50, 57, 64, 71
        .byte 78, 85, 92, 99, 106, 113, 120, 127, 134, 141, 148, 155, 162, 169, 176, 183
        .byte 190, 197, 204, 211, 218, 225, 232, 239, 246, 253, 4, 11, 18, 25, 32, 39
        .byte 46, 53, 60, 67, 74, 81, 88, 95, 102, 109, 116, 123, 130, 137, 144, 151
        .byte 158, 165, 172, 179, 186, 193, 200, 207, 214, 221, 228, 235, 242, 249, 0, 7
        ORG $1200
        RORG $F200
        MAC CHECK1
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail1
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail1  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show1
Pass1  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show1  sta COLUBK+$00
F1     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V1     sta WSYNC+$00
        dex
        bne V1
        lda #0
        sta VBLANK+$00
        ldx #192
P1     sta WSYNC+$00
        dex
        bne P1
        lda #2
        sta VBLANK+$00
        ldx #30
O1     sta WSYNC+$00
        dex
        bne O1
        jmp F1
Start1   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK1 0
        lda $FFF5
        lda $FE00
        CHECK1 1
        lda $FFF6
        lda $FE00
        CHECK1 2
        lda $FFF7
        lda $FE00
        CHECK1 3
        lda $FFF8
        lda $FE00
        CHECK1 4
        lda $FFF9
        lda $FE00
        CHECK1 5
        lda $FFFA
        lda $FE00
        CHECK1 6
        lda $FFFB
        lda $FE00
        CHECK1 7
        sta $FFFB
        lda $FE00
        CHECK1 7
        sta $FFFA
        lda $FE00
        CHECK1 6
        sta $FFF9
        lda $FE00
        CHECK1 5
        sta $FFF8
        lda $FE00
        CHECK1 4
        sta $FFF7
        lda $FE00
        CHECK1 3
        sta $FFF6
        lda $FE00
        CHECK1 2
        sta $FFF5
        lda $FE00
        CHECK1 1
        sta $FFF4
        lda $FE00
        CHECK1 0
        jmp Pass1
        ORG $1E00
        RORG $FE00
        .byte 1
        ORG $1FFC
        RORG $FFFC
        .word Start1
        .word Start1
        SEG bank2
        ORG $2000
        RORG $F000
        .byte 27, 34, 41, 48, 55, 62, 69, 76, 83, 90, 97, 104, 111, 118, 125, 132
        .byte 139, 146, 153, 160, 167, 174, 181, 188, 195, 202, 209, 216, 223, 230, 237, 244
        .byte 251, 2, 9, 16, 23, 30, 37, 44, 51, 58, 65, 72, 79, 86, 93, 100
        .byte 107, 114, 121, 128, 135, 142, 149, 156, 163, 170, 177, 184, 191, 198, 205, 212
        .byte 219, 226, 233, 240, 247, 254, 5, 12, 19, 26, 33, 40, 47, 54, 61, 68
        .byte 75, 82, 89, 96, 103, 110, 117, 124, 131, 138, 145, 152, 159, 166, 173, 180
        .byte 187, 194, 201, 208, 215, 222, 229, 236, 243, 250, 1, 8, 15, 22, 29, 36
        .byte 43, 50, 57, 64, 71, 78, 85, 92, 99, 106, 113, 120, 127, 134, 141, 148
        .byte 155, 162, 169, 176, 183, 190, 197, 204, 211, 218, 225, 232, 239, 246, 253, 4
        .byte 11, 18, 25, 32, 39, 46, 53, 60, 67, 74, 81, 88, 95, 102, 109, 116
        .byte 123, 130, 137, 144, 151, 158, 165, 172, 179, 186, 193, 200, 207, 214, 221, 228
        .byte 235, 242, 249, 0, 7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77, 84
        .byte 91, 98, 105, 112, 119, 126, 133, 140, 147, 154, 161, 168, 175, 182, 189, 196
        .byte 203, 210, 217, 224, 231, 238, 245, 252, 3, 10, 17, 24, 31, 38, 45, 52
        .byte 59, 66, 73, 80, 87, 94, 101, 108, 115, 122, 129, 136, 143, 150, 157, 164
        .byte 171, 178, 185, 192, 199, 206, 213, 220, 227, 234, 241, 248, 255, 6, 13, 20
        ORG $2200
        RORG $F200
        MAC CHECK2
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail2
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail2  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show2
Pass2  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show2  sta COLUBK+$00
F2     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V2     sta WSYNC+$00
        dex
        bne V2
        lda #0
        sta VBLANK+$00
        ldx #192
P2     sta WSYNC+$00
        dex
        bne P2
        lda #2
        sta VBLANK+$00
        ldx #30
O2     sta WSYNC+$00
        dex
        bne O2
        jmp F2
Start2   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK2 0
        lda $FFF5
        lda $FE00
        CHECK2 1
        lda $FFF6
        lda $FE00
        CHECK2 2
        lda $FFF7
        lda $FE00
        CHECK2 3
        lda $FFF8
        lda $FE00
        CHECK2 4
        lda $FFF9
        lda $FE00
        CHECK2 5
        lda $FFFA
        lda $FE00
        CHECK2 6
        lda $FFFB
        lda $FE00
        CHECK2 7
        sta $FFFB
        lda $FE00
        CHECK2 7
        sta $FFFA
        lda $FE00
        CHECK2 6
        sta $FFF9
        lda $FE00
        CHECK2 5
        sta $FFF8
        lda $FE00
        CHECK2 4
        sta $FFF7
        lda $FE00
        CHECK2 3
        sta $FFF6
        lda $FE00
        CHECK2 2
        sta $FFF5
        lda $FE00
        CHECK2 1
        sta $FFF4
        lda $FE00
        CHECK2 0
        jmp Pass2
        ORG $2E00
        RORG $FE00
        .byte 2
        ORG $2FFC
        RORG $FFFC
        .word Start2
        .word Start2
        SEG bank3
        ORG $3000
        RORG $F000
        .byte 40, 47, 54, 61, 68, 75, 82, 89, 96, 103, 110, 117, 124, 131, 138, 145
        .byte 152, 159, 166, 173, 180, 187, 194, 201, 208, 215, 222, 229, 236, 243, 250, 1
        .byte 8, 15, 22, 29, 36, 43, 50, 57, 64, 71, 78, 85, 92, 99, 106, 113
        .byte 120, 127, 134, 141, 148, 155, 162, 169, 176, 183, 190, 197, 204, 211, 218, 225
        .byte 232, 239, 246, 253, 4, 11, 18, 25, 32, 39, 46, 53, 60, 67, 74, 81
        .byte 88, 95, 102, 109, 116, 123, 130, 137, 144, 151, 158, 165, 172, 179, 186, 193
        .byte 200, 207, 214, 221, 228, 235, 242, 249, 0, 7, 14, 21, 28, 35, 42, 49
        .byte 56, 63, 70, 77, 84, 91, 98, 105, 112, 119, 126, 133, 140, 147, 154, 161
        .byte 168, 175, 182, 189, 196, 203, 210, 217, 224, 231, 238, 245, 252, 3, 10, 17
        .byte 24, 31, 38, 45, 52, 59, 66, 73, 80, 87, 94, 101, 108, 115, 122, 129
        .byte 136, 143, 150, 157, 164, 171, 178, 185, 192, 199, 206, 213, 220, 227, 234, 241
        .byte 248, 255, 6, 13, 20, 27, 34, 41, 48, 55, 62, 69, 76, 83, 90, 97
        .byte 104, 111, 118, 125, 132, 139, 146, 153, 160, 167, 174, 181, 188, 195, 202, 209
        .byte 216, 223, 230, 237, 244, 251, 2, 9, 16, 23, 30, 37, 44, 51, 58, 65
        .byte 72, 79, 86, 93, 100, 107, 114, 121, 128, 135, 142, 149, 156, 163, 170, 177
        .byte 184, 191, 198, 205, 212, 219, 226, 233, 240, 247, 254, 5, 12, 19, 26, 33
        ORG $3200
        RORG $F200
        MAC CHECK3
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail3
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail3  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show3
Pass3  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show3  sta COLUBK+$00
F3     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V3     sta WSYNC+$00
        dex
        bne V3
        lda #0
        sta VBLANK+$00
        ldx #192
P3     sta WSYNC+$00
        dex
        bne P3
        lda #2
        sta VBLANK+$00
        ldx #30
O3     sta WSYNC+$00
        dex
        bne O3
        jmp F3
Start3   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK3 0
        lda $FFF5
        lda $FE00
        CHECK3 1
        lda $FFF6
        lda $FE00
        CHECK3 2
        lda $FFF7
        lda $FE00
        CHECK3 3
        lda $FFF8
        lda $FE00
        CHECK3 4
        lda $FFF9
        lda $FE00
        CHECK3 5
        lda $FFFA
        lda $FE00
        CHECK3 6
        lda $FFFB
        lda $FE00
        CHECK3 7
        sta $FFFB
        lda $FE00
        CHECK3 7
        sta $FFFA
        lda $FE00
        CHECK3 6
        sta $FFF9
        lda $FE00
        CHECK3 5
        sta $FFF8
        lda $FE00
        CHECK3 4
        sta $FFF7
        lda $FE00
        CHECK3 3
        sta $FFF6
        lda $FE00
        CHECK3 2
        sta $FFF5
        lda $FE00
        CHECK3 1
        sta $FFF4
        lda $FE00
        CHECK3 0
        jmp Pass3
        ORG $3E00
        RORG $FE00
        .byte 3
        ORG $3FFC
        RORG $FFFC
        .word Start3
        .word Start3
        SEG bank4
        ORG $4000
        RORG $F000
        .byte 53, 60, 67, 74, 81, 88, 95, 102, 109, 116, 123, 130, 137, 144, 151, 158
        .byte 165, 172, 179, 186, 193, 200, 207, 214, 221, 228, 235, 242, 249, 0, 7, 14
        .byte 21, 28, 35, 42, 49, 56, 63, 70, 77, 84, 91, 98, 105, 112, 119, 126
        .byte 133, 140, 147, 154, 161, 168, 175, 182, 189, 196, 203, 210, 217, 224, 231, 238
        .byte 245, 252, 3, 10, 17, 24, 31, 38, 45, 52, 59, 66, 73, 80, 87, 94
        .byte 101, 108, 115, 122, 129, 136, 143, 150, 157, 164, 171, 178, 185, 192, 199, 206
        .byte 213, 220, 227, 234, 241, 248, 255, 6, 13, 20, 27, 34, 41, 48, 55, 62
        .byte 69, 76, 83, 90, 97, 104, 111, 118, 125, 132, 139, 146, 153, 160, 167, 174
        .byte 181, 188, 195, 202, 209, 216, 223, 230, 237, 244, 251, 2, 9, 16, 23, 30
        .byte 37, 44, 51, 58, 65, 72, 79, 86, 93, 100, 107, 114, 121, 128, 135, 142
        .byte 149, 156, 163, 170, 177, 184, 191, 198, 205, 212, 219, 226, 233, 240, 247, 254
        .byte 5, 12, 19, 26, 33, 40, 47, 54, 61, 68, 75, 82, 89, 96, 103, 110
        .byte 117, 124, 131, 138, 145, 152, 159, 166, 173, 180, 187, 194, 201, 208, 215, 222
        .byte 229, 236, 243, 250, 1, 8, 15, 22, 29, 36, 43, 50, 57, 64, 71, 78
        .byte 85, 92, 99, 106, 113, 120, 127, 134, 141, 148, 155, 162, 169, 176, 183, 190
        .byte 197, 204, 211, 218, 225, 232, 239, 246, 253, 4, 11, 18, 25, 32, 39, 46
        ORG $4200
        RORG $F200
        MAC CHECK4
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail4
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail4  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show4
Pass4  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show4  sta COLUBK+$00
F4     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V4     sta WSYNC+$00
        dex
        bne V4
        lda #0
        sta VBLANK+$00
        ldx #192
P4     sta WSYNC+$00
        dex
        bne P4
        lda #2
        sta VBLANK+$00
        ldx #30
O4     sta WSYNC+$00
        dex
        bne O4
        jmp F4
Start4   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK4 0
        lda $FFF5
        lda $FE00
        CHECK4 1
        lda $FFF6
        lda $FE00
        CHECK4 2
        lda $FFF7
        lda $FE00
        CHECK4 3
        lda $FFF8
        lda $FE00
        CHECK4 4
        lda $FFF9
        lda $FE00
        CHECK4 5
        lda $FFFA
        lda $FE00
        CHECK4 6
        lda $FFFB
        lda $FE00
        CHECK4 7
        sta $FFFB
        lda $FE00
        CHECK4 7
        sta $FFFA
        lda $FE00
        CHECK4 6
        sta $FFF9
        lda $FE00
        CHECK4 5
        sta $FFF8
        lda $FE00
        CHECK4 4
        sta $FFF7
        lda $FE00
        CHECK4 3
        sta $FFF6
        lda $FE00
        CHECK4 2
        sta $FFF5
        lda $FE00
        CHECK4 1
        sta $FFF4
        lda $FE00
        CHECK4 0
        jmp Pass4
        ORG $4E00
        RORG $FE00
        .byte 4
        ORG $4FFC
        RORG $FFFC
        .word Start4
        .word Start4
        SEG bank5
        ORG $5000
        RORG $F000
        .byte 66, 73, 80, 87, 94, 101, 108, 115, 122, 129, 136, 143, 150, 157, 164, 171
        .byte 178, 185, 192, 199, 206, 213, 220, 227, 234, 241, 248, 255, 6, 13, 20, 27
        .byte 34, 41, 48, 55, 62, 69, 76, 83, 90, 97, 104, 111, 118, 125, 132, 139
        .byte 146, 153, 160, 167, 174, 181, 188, 195, 202, 209, 216, 223, 230, 237, 244, 251
        .byte 2, 9, 16, 23, 30, 37, 44, 51, 58, 65, 72, 79, 86, 93, 100, 107
        .byte 114, 121, 128, 135, 142, 149, 156, 163, 170, 177, 184, 191, 198, 205, 212, 219
        .byte 226, 233, 240, 247, 254, 5, 12, 19, 26, 33, 40, 47, 54, 61, 68, 75
        .byte 82, 89, 96, 103, 110, 117, 124, 131, 138, 145, 152, 159, 166, 173, 180, 187
        .byte 194, 201, 208, 215, 222, 229, 236, 243, 250, 1, 8, 15, 22, 29, 36, 43
        .byte 50, 57, 64, 71, 78, 85, 92, 99, 106, 113, 120, 127, 134, 141, 148, 155
        .byte 162, 169, 176, 183, 190, 197, 204, 211, 218, 225, 232, 239, 246, 253, 4, 11
        .byte 18, 25, 32, 39, 46, 53, 60, 67, 74, 81, 88, 95, 102, 109, 116, 123
        .byte 130, 137, 144, 151, 158, 165, 172, 179, 186, 193, 200, 207, 214, 221, 228, 235
        .byte 242, 249, 0, 7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77, 84, 91
        .byte 98, 105, 112, 119, 126, 133, 140, 147, 154, 161, 168, 175, 182, 189, 196, 203
        .byte 210, 217, 224, 231, 238, 245, 252, 3, 10, 17, 24, 31, 38, 45, 52, 59
        ORG $5200
        RORG $F200
        MAC CHECK5
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail5
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail5  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show5
Pass5  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show5  sta COLUBK+$00
F5     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V5     sta WSYNC+$00
        dex
        bne V5
        lda #0
        sta VBLANK+$00
        ldx #192
P5     sta WSYNC+$00
        dex
        bne P5
        lda #2
        sta VBLANK+$00
        ldx #30
O5     sta WSYNC+$00
        dex
        bne O5
        jmp F5
Start5   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK5 0
        lda $FFF5
        lda $FE00
        CHECK5 1
        lda $FFF6
        lda $FE00
        CHECK5 2
        lda $FFF7
        lda $FE00
        CHECK5 3
        lda $FFF8
        lda $FE00
        CHECK5 4
        lda $FFF9
        lda $FE00
        CHECK5 5
        lda $FFFA
        lda $FE00
        CHECK5 6
        lda $FFFB
        lda $FE00
        CHECK5 7
        sta $FFFB
        lda $FE00
        CHECK5 7
        sta $FFFA
        lda $FE00
        CHECK5 6
        sta $FFF9
        lda $FE00
        CHECK5 5
        sta $FFF8
        lda $FE00
        CHECK5 4
        sta $FFF7
        lda $FE00
        CHECK5 3
        sta $FFF6
        lda $FE00
        CHECK5 2
        sta $FFF5
        lda $FE00
        CHECK5 1
        sta $FFF4
        lda $FE00
        CHECK5 0
        jmp Pass5
        ORG $5E00
        RORG $FE00
        .byte 5
        ORG $5FFC
        RORG $FFFC
        .word Start5
        .word Start5
        SEG bank6
        ORG $6000
        RORG $F000
        .byte 79, 86, 93, 100, 107, 114, 121, 128, 135, 142, 149, 156, 163, 170, 177, 184
        .byte 191, 198, 205, 212, 219, 226, 233, 240, 247, 254, 5, 12, 19, 26, 33, 40
        .byte 47, 54, 61, 68, 75, 82, 89, 96, 103, 110, 117, 124, 131, 138, 145, 152
        .byte 159, 166, 173, 180, 187, 194, 201, 208, 215, 222, 229, 236, 243, 250, 1, 8
        .byte 15, 22, 29, 36, 43, 50, 57, 64, 71, 78, 85, 92, 99, 106, 113, 120
        .byte 127, 134, 141, 148, 155, 162, 169, 176, 183, 190, 197, 204, 211, 218, 225, 232
        .byte 239, 246, 253, 4, 11, 18, 25, 32, 39, 46, 53, 60, 67, 74, 81, 88
        .byte 95, 102, 109, 116, 123, 130, 137, 144, 151, 158, 165, 172, 179, 186, 193, 200
        .byte 207, 214, 221, 228, 235, 242, 249, 0, 7, 14, 21, 28, 35, 42, 49, 56
        .byte 63, 70, 77, 84, 91, 98, 105, 112, 119, 126, 133, 140, 147, 154, 161, 168
        .byte 175, 182, 189, 196, 203, 210, 217, 224, 231, 238, 245, 252, 3, 10, 17, 24
        .byte 31, 38, 45, 52, 59, 66, 73, 80, 87, 94, 101, 108, 115, 122, 129, 136
        .byte 143, 150, 157, 164, 171, 178, 185, 192, 199, 206, 213, 220, 227, 234, 241, 248
        .byte 255, 6, 13, 20, 27, 34, 41, 48, 55, 62, 69, 76, 83, 90, 97, 104
        .byte 111, 118, 125, 132, 139, 146, 153, 160, 167, 174, 181, 188, 195, 202, 209, 216
        .byte 223, 230, 237, 244, 251, 2, 9, 16, 23, 30, 37, 44, 51, 58, 65, 72
        ORG $6200
        RORG $F200
        MAC CHECK6
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail6
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail6  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show6
Pass6  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show6  sta COLUBK+$00
F6     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V6     sta WSYNC+$00
        dex
        bne V6
        lda #0
        sta VBLANK+$00
        ldx #192
P6     sta WSYNC+$00
        dex
        bne P6
        lda #2
        sta VBLANK+$00
        ldx #30
O6     sta WSYNC+$00
        dex
        bne O6
        jmp F6
Start6   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK6 0
        lda $FFF5
        lda $FE00
        CHECK6 1
        lda $FFF6
        lda $FE00
        CHECK6 2
        lda $FFF7
        lda $FE00
        CHECK6 3
        lda $FFF8
        lda $FE00
        CHECK6 4
        lda $FFF9
        lda $FE00
        CHECK6 5
        lda $FFFA
        lda $FE00
        CHECK6 6
        lda $FFFB
        lda $FE00
        CHECK6 7
        sta $FFFB
        lda $FE00
        CHECK6 7
        sta $FFFA
        lda $FE00
        CHECK6 6
        sta $FFF9
        lda $FE00
        CHECK6 5
        sta $FFF8
        lda $FE00
        CHECK6 4
        sta $FFF7
        lda $FE00
        CHECK6 3
        sta $FFF6
        lda $FE00
        CHECK6 2
        sta $FFF5
        lda $FE00
        CHECK6 1
        sta $FFF4
        lda $FE00
        CHECK6 0
        jmp Pass6
        ORG $6E00
        RORG $FE00
        .byte 6
        ORG $6FFC
        RORG $FFFC
        .word Start6
        .word Start6
        SEG bank7
        ORG $7000
        RORG $F000
        .byte 92, 99, 106, 113, 120, 127, 134, 141, 148, 155, 162, 169, 176, 183, 190, 197
        .byte 204, 211, 218, 225, 232, 239, 246, 253, 4, 11, 18, 25, 32, 39, 46, 53
        .byte 60, 67, 74, 81, 88, 95, 102, 109, 116, 123, 130, 137, 144, 151, 158, 165
        .byte 172, 179, 186, 193, 200, 207, 214, 221, 228, 235, 242, 249, 0, 7, 14, 21
        .byte 28, 35, 42, 49, 56, 63, 70, 77, 84, 91, 98, 105, 112, 119, 126, 133
        .byte 140, 147, 154, 161, 168, 175, 182, 189, 196, 203, 210, 217, 224, 231, 238, 245
        .byte 252, 3, 10, 17, 24, 31, 38, 45, 52, 59, 66, 73, 80, 87, 94, 101
        .byte 108, 115, 122, 129, 136, 143, 150, 157, 164, 171, 178, 185, 192, 199, 206, 213
        .byte 220, 227, 234, 241, 248, 255, 6, 13, 20, 27, 34, 41, 48, 55, 62, 69
        .byte 76, 83, 90, 97, 104, 111, 118, 125, 132, 139, 146, 153, 160, 167, 174, 181
        .byte 188, 195, 202, 209, 216, 223, 230, 237, 244, 251, 2, 9, 16, 23, 30, 37
        .byte 44, 51, 58, 65, 72, 79, 86, 93, 100, 107, 114, 121, 128, 135, 142, 149
        .byte 156, 163, 170, 177, 184, 191, 198, 205, 212, 219, 226, 233, 240, 247, 254, 5
        .byte 12, 19, 26, 33, 40, 47, 54, 61, 68, 75, 82, 89, 96, 103, 110, 117
        .byte 124, 131, 138, 145, 152, 159, 166, 173, 180, 187, 194, 201, 208, 215, 222, 229
        .byte 236, 243, 250, 1, 8, 15, 22, 29, 36, 43, 50, 57, 64, 71, 78, 85
        ORG $7200
        RORG $F200
        MAC CHECK7
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail7
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail7  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show7
Pass7  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show7  sta COLUBK+$00
F7     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V7     sta WSYNC+$00
        dex
        bne V7
        lda #0
        sta VBLANK+$00
        ldx #192
P7     sta WSYNC+$00
        dex
        bne P7
        lda #2
        sta VBLANK+$00
        ldx #30
O7     sta WSYNC+$00
        dex
        bne O7
        jmp F7
Start7   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK7 0
        lda $FFF5
        lda $FE00
        CHECK7 1
        lda $FFF6
        lda $FE00
        CHECK7 2
        lda $FFF7
        lda $FE00
        CHECK7 3
        lda $FFF8
        lda $FE00
        CHECK7 4
        lda $FFF9
        lda $FE00
        CHECK7 5
        lda $FFFA
        lda $FE00
        CHECK7 6
        lda $FFFB
        lda $FE00
        CHECK7 7
        sta $FFFB
        lda $FE00
        CHECK7 7
        sta $FFFA
        lda $FE00
        CHECK7 6
        sta $FFF9
        lda $FE00
        CHECK7 5
        sta $FFF8
        lda $FE00
        CHECK7 4
        sta $FFF7
        lda $FE00
        CHECK7 3
        sta $FFF6
        lda $FE00
        CHECK7 2
        sta $FFF5
        lda $FE00
        CHECK7 1
        sta $FFF4
        lda $FE00
        CHECK7 0
        jmp Pass7
        ORG $7E00
        RORG $FE00
        .byte 7
        ORG $7FFC
        RORG $FFFC
        .word Start7
        .word Start7
