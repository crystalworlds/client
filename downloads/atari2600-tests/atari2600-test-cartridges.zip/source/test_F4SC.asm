        processor 6502
        include "hw.inc"
        SEG bank0
        ORG $0000
        RORG $F000
        ds.b 256, 0
        ORG $0200
        RORG $F200
        MAC CHECK0
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail0
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail0  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show0
Pass0  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show0  sta COLUBK+$00
F0     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V0     sta WSYNC+$00
        dex
        bne V0
        lda #0
        sta VBLANK+$00
        ldx #192
P0     sta WSYNC+$00
        dex
        bne P0
        lda #2
        sta VBLANK+$00
        ldx #30
O0     sta WSYNC+$00
        dex
        bne O0
        jmp F0
Start0   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK0 0
        lda $FFF5
        lda $FE00
        CHECK0 1
        lda $FFF6
        lda $FE00
        CHECK0 2
        lda $FFF7
        lda $FE00
        CHECK0 3
        lda $FFF8
        lda $FE00
        CHECK0 4
        lda $FFF9
        lda $FE00
        CHECK0 5
        lda $FFFA
        lda $FE00
        CHECK0 6
        lda $FFFB
        lda $FE00
        CHECK0 7
        sta $FFFB
        lda $FE00
        CHECK0 7
        sta $FFFA
        lda $FE00
        CHECK0 6
        sta $FFF9
        lda $FE00
        CHECK0 5
        sta $FFF8
        lda $FE00
        CHECK0 4
        sta $FFF7
        lda $FE00
        CHECK0 3
        sta $FFF6
        lda $FE00
        CHECK0 2
        sta $FFF5
        lda $FE00
        CHECK0 1
        sta $FFF4
        lda $FE00
        CHECK0 0
        sta $FFF4
        ldx #0
W0      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W0
        sta $FFFB
        ldx #0
R0      txa
        eor #$5A
        cmp $F080,x
        beq K0
        jmp Fail0
K0      inx
        cpx #128
        bne R0
        jmp Pass0
        ORG $0E00
        RORG $FE00
        .byte 0
        ORG $0FFC
        RORG $FFFC
        .word Start0
        .word Start0
        SEG bank1
        ORG $1000
        RORG $F000
        ds.b 256, 0
        ORG $1200
        RORG $F200
        MAC CHECK1
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail1
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail1  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show1
Pass1  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show1  sta COLUBK+$00
F1     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V1     sta WSYNC+$00
        dex
        bne V1
        lda #0
        sta VBLANK+$00
        ldx #192
P1     sta WSYNC+$00
        dex
        bne P1
        lda #2
        sta VBLANK+$00
        ldx #30
O1     sta WSYNC+$00
        dex
        bne O1
        jmp F1
Start1   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK1 0
        lda $FFF5
        lda $FE00
        CHECK1 1
        lda $FFF6
        lda $FE00
        CHECK1 2
        lda $FFF7
        lda $FE00
        CHECK1 3
        lda $FFF8
        lda $FE00
        CHECK1 4
        lda $FFF9
        lda $FE00
        CHECK1 5
        lda $FFFA
        lda $FE00
        CHECK1 6
        lda $FFFB
        lda $FE00
        CHECK1 7
        sta $FFFB
        lda $FE00
        CHECK1 7
        sta $FFFA
        lda $FE00
        CHECK1 6
        sta $FFF9
        lda $FE00
        CHECK1 5
        sta $FFF8
        lda $FE00
        CHECK1 4
        sta $FFF7
        lda $FE00
        CHECK1 3
        sta $FFF6
        lda $FE00
        CHECK1 2
        sta $FFF5
        lda $FE00
        CHECK1 1
        sta $FFF4
        lda $FE00
        CHECK1 0
        sta $FFF4
        ldx #0
W1      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W1
        sta $FFFB
        ldx #0
R1      txa
        eor #$5A
        cmp $F080,x
        beq K1
        jmp Fail1
K1      inx
        cpx #128
        bne R1
        jmp Pass1
        ORG $1E00
        RORG $FE00
        .byte 1
        ORG $1FFC
        RORG $FFFC
        .word Start1
        .word Start1
        SEG bank2
        ORG $2000
        RORG $F000
        ds.b 256, 0
        ORG $2200
        RORG $F200
        MAC CHECK2
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail2
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail2  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show2
Pass2  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show2  sta COLUBK+$00
F2     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V2     sta WSYNC+$00
        dex
        bne V2
        lda #0
        sta VBLANK+$00
        ldx #192
P2     sta WSYNC+$00
        dex
        bne P2
        lda #2
        sta VBLANK+$00
        ldx #30
O2     sta WSYNC+$00
        dex
        bne O2
        jmp F2
Start2   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK2 0
        lda $FFF5
        lda $FE00
        CHECK2 1
        lda $FFF6
        lda $FE00
        CHECK2 2
        lda $FFF7
        lda $FE00
        CHECK2 3
        lda $FFF8
        lda $FE00
        CHECK2 4
        lda $FFF9
        lda $FE00
        CHECK2 5
        lda $FFFA
        lda $FE00
        CHECK2 6
        lda $FFFB
        lda $FE00
        CHECK2 7
        sta $FFFB
        lda $FE00
        CHECK2 7
        sta $FFFA
        lda $FE00
        CHECK2 6
        sta $FFF9
        lda $FE00
        CHECK2 5
        sta $FFF8
        lda $FE00
        CHECK2 4
        sta $FFF7
        lda $FE00
        CHECK2 3
        sta $FFF6
        lda $FE00
        CHECK2 2
        sta $FFF5
        lda $FE00
        CHECK2 1
        sta $FFF4
        lda $FE00
        CHECK2 0
        sta $FFF4
        ldx #0
W2      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W2
        sta $FFFB
        ldx #0
R2      txa
        eor #$5A
        cmp $F080,x
        beq K2
        jmp Fail2
K2      inx
        cpx #128
        bne R2
        jmp Pass2
        ORG $2E00
        RORG $FE00
        .byte 2
        ORG $2FFC
        RORG $FFFC
        .word Start2
        .word Start2
        SEG bank3
        ORG $3000
        RORG $F000
        ds.b 256, 0
        ORG $3200
        RORG $F200
        MAC CHECK3
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail3
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail3  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show3
Pass3  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show3  sta COLUBK+$00
F3     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V3     sta WSYNC+$00
        dex
        bne V3
        lda #0
        sta VBLANK+$00
        ldx #192
P3     sta WSYNC+$00
        dex
        bne P3
        lda #2
        sta VBLANK+$00
        ldx #30
O3     sta WSYNC+$00
        dex
        bne O3
        jmp F3
Start3   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK3 0
        lda $FFF5
        lda $FE00
        CHECK3 1
        lda $FFF6
        lda $FE00
        CHECK3 2
        lda $FFF7
        lda $FE00
        CHECK3 3
        lda $FFF8
        lda $FE00
        CHECK3 4
        lda $FFF9
        lda $FE00
        CHECK3 5
        lda $FFFA
        lda $FE00
        CHECK3 6
        lda $FFFB
        lda $FE00
        CHECK3 7
        sta $FFFB
        lda $FE00
        CHECK3 7
        sta $FFFA
        lda $FE00
        CHECK3 6
        sta $FFF9
        lda $FE00
        CHECK3 5
        sta $FFF8
        lda $FE00
        CHECK3 4
        sta $FFF7
        lda $FE00
        CHECK3 3
        sta $FFF6
        lda $FE00
        CHECK3 2
        sta $FFF5
        lda $FE00
        CHECK3 1
        sta $FFF4
        lda $FE00
        CHECK3 0
        sta $FFF4
        ldx #0
W3      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W3
        sta $FFFB
        ldx #0
R3      txa
        eor #$5A
        cmp $F080,x
        beq K3
        jmp Fail3
K3      inx
        cpx #128
        bne R3
        jmp Pass3
        ORG $3E00
        RORG $FE00
        .byte 3
        ORG $3FFC
        RORG $FFFC
        .word Start3
        .word Start3
        SEG bank4
        ORG $4000
        RORG $F000
        ds.b 256, 0
        ORG $4200
        RORG $F200
        MAC CHECK4
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail4
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail4  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show4
Pass4  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show4  sta COLUBK+$00
F4     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V4     sta WSYNC+$00
        dex
        bne V4
        lda #0
        sta VBLANK+$00
        ldx #192
P4     sta WSYNC+$00
        dex
        bne P4
        lda #2
        sta VBLANK+$00
        ldx #30
O4     sta WSYNC+$00
        dex
        bne O4
        jmp F4
Start4   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK4 0
        lda $FFF5
        lda $FE00
        CHECK4 1
        lda $FFF6
        lda $FE00
        CHECK4 2
        lda $FFF7
        lda $FE00
        CHECK4 3
        lda $FFF8
        lda $FE00
        CHECK4 4
        lda $FFF9
        lda $FE00
        CHECK4 5
        lda $FFFA
        lda $FE00
        CHECK4 6
        lda $FFFB
        lda $FE00
        CHECK4 7
        sta $FFFB
        lda $FE00
        CHECK4 7
        sta $FFFA
        lda $FE00
        CHECK4 6
        sta $FFF9
        lda $FE00
        CHECK4 5
        sta $FFF8
        lda $FE00
        CHECK4 4
        sta $FFF7
        lda $FE00
        CHECK4 3
        sta $FFF6
        lda $FE00
        CHECK4 2
        sta $FFF5
        lda $FE00
        CHECK4 1
        sta $FFF4
        lda $FE00
        CHECK4 0
        sta $FFF4
        ldx #0
W4      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W4
        sta $FFFB
        ldx #0
R4      txa
        eor #$5A
        cmp $F080,x
        beq K4
        jmp Fail4
K4      inx
        cpx #128
        bne R4
        jmp Pass4
        ORG $4E00
        RORG $FE00
        .byte 4
        ORG $4FFC
        RORG $FFFC
        .word Start4
        .word Start4
        SEG bank5
        ORG $5000
        RORG $F000
        ds.b 256, 0
        ORG $5200
        RORG $F200
        MAC CHECK5
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail5
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail5  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show5
Pass5  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show5  sta COLUBK+$00
F5     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V5     sta WSYNC+$00
        dex
        bne V5
        lda #0
        sta VBLANK+$00
        ldx #192
P5     sta WSYNC+$00
        dex
        bne P5
        lda #2
        sta VBLANK+$00
        ldx #30
O5     sta WSYNC+$00
        dex
        bne O5
        jmp F5
Start5   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK5 0
        lda $FFF5
        lda $FE00
        CHECK5 1
        lda $FFF6
        lda $FE00
        CHECK5 2
        lda $FFF7
        lda $FE00
        CHECK5 3
        lda $FFF8
        lda $FE00
        CHECK5 4
        lda $FFF9
        lda $FE00
        CHECK5 5
        lda $FFFA
        lda $FE00
        CHECK5 6
        lda $FFFB
        lda $FE00
        CHECK5 7
        sta $FFFB
        lda $FE00
        CHECK5 7
        sta $FFFA
        lda $FE00
        CHECK5 6
        sta $FFF9
        lda $FE00
        CHECK5 5
        sta $FFF8
        lda $FE00
        CHECK5 4
        sta $FFF7
        lda $FE00
        CHECK5 3
        sta $FFF6
        lda $FE00
        CHECK5 2
        sta $FFF5
        lda $FE00
        CHECK5 1
        sta $FFF4
        lda $FE00
        CHECK5 0
        sta $FFF4
        ldx #0
W5      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W5
        sta $FFFB
        ldx #0
R5      txa
        eor #$5A
        cmp $F080,x
        beq K5
        jmp Fail5
K5      inx
        cpx #128
        bne R5
        jmp Pass5
        ORG $5E00
        RORG $FE00
        .byte 5
        ORG $5FFC
        RORG $FFFC
        .word Start5
        .word Start5
        SEG bank6
        ORG $6000
        RORG $F000
        ds.b 256, 0
        ORG $6200
        RORG $F200
        MAC CHECK6
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail6
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail6  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show6
Pass6  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show6  sta COLUBK+$00
F6     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V6     sta WSYNC+$00
        dex
        bne V6
        lda #0
        sta VBLANK+$00
        ldx #192
P6     sta WSYNC+$00
        dex
        bne P6
        lda #2
        sta VBLANK+$00
        ldx #30
O6     sta WSYNC+$00
        dex
        bne O6
        jmp F6
Start6   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK6 0
        lda $FFF5
        lda $FE00
        CHECK6 1
        lda $FFF6
        lda $FE00
        CHECK6 2
        lda $FFF7
        lda $FE00
        CHECK6 3
        lda $FFF8
        lda $FE00
        CHECK6 4
        lda $FFF9
        lda $FE00
        CHECK6 5
        lda $FFFA
        lda $FE00
        CHECK6 6
        lda $FFFB
        lda $FE00
        CHECK6 7
        sta $FFFB
        lda $FE00
        CHECK6 7
        sta $FFFA
        lda $FE00
        CHECK6 6
        sta $FFF9
        lda $FE00
        CHECK6 5
        sta $FFF8
        lda $FE00
        CHECK6 4
        sta $FFF7
        lda $FE00
        CHECK6 3
        sta $FFF6
        lda $FE00
        CHECK6 2
        sta $FFF5
        lda $FE00
        CHECK6 1
        sta $FFF4
        lda $FE00
        CHECK6 0
        sta $FFF4
        ldx #0
W6      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W6
        sta $FFFB
        ldx #0
R6      txa
        eor #$5A
        cmp $F080,x
        beq K6
        jmp Fail6
K6      inx
        cpx #128
        bne R6
        jmp Pass6
        ORG $6E00
        RORG $FE00
        .byte 6
        ORG $6FFC
        RORG $FFFC
        .word Start6
        .word Start6
        SEG bank7
        ORG $7000
        RORG $F000
        ds.b 256, 0
        ORG $7200
        RORG $F200
        MAC CHECK7
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail7
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail7  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show7
Pass7  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show7  sta COLUBK+$00
F7     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V7     sta WSYNC+$00
        dex
        bne V7
        lda #0
        sta VBLANK+$00
        ldx #192
P7     sta WSYNC+$00
        dex
        bne P7
        lda #2
        sta VBLANK+$00
        ldx #30
O7     sta WSYNC+$00
        dex
        bne O7
        jmp F7
Start7   CLEAN_START
        lda $FFF4
        lda $FE00
        CHECK7 0
        lda $FFF5
        lda $FE00
        CHECK7 1
        lda $FFF6
        lda $FE00
        CHECK7 2
        lda $FFF7
        lda $FE00
        CHECK7 3
        lda $FFF8
        lda $FE00
        CHECK7 4
        lda $FFF9
        lda $FE00
        CHECK7 5
        lda $FFFA
        lda $FE00
        CHECK7 6
        lda $FFFB
        lda $FE00
        CHECK7 7
        sta $FFFB
        lda $FE00
        CHECK7 7
        sta $FFFA
        lda $FE00
        CHECK7 6
        sta $FFF9
        lda $FE00
        CHECK7 5
        sta $FFF8
        lda $FE00
        CHECK7 4
        sta $FFF7
        lda $FE00
        CHECK7 3
        sta $FFF6
        lda $FE00
        CHECK7 2
        sta $FFF5
        lda $FE00
        CHECK7 1
        sta $FFF4
        lda $FE00
        CHECK7 0
        sta $FFF4
        ldx #0
W7      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W7
        sta $FFFB
        ldx #0
R7      txa
        eor #$5A
        cmp $F080,x
        beq K7
        jmp Fail7
K7      inx
        cpx #128
        bne R7
        jmp Pass7
        ORG $7E00
        RORG $FE00
        .byte 7
        ORG $7FFC
        RORG $FFFC
        .word Start7
        .word Start7
