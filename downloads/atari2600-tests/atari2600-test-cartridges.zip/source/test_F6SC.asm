        processor 6502
        include "hw.inc"
        SEG bank0
        ORG $0000
        RORG $F000
        ds.b 256, 0
        ORG $0200
        RORG $F200
        MAC CHECK0
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail0
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail0  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show0
Pass0  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show0  sta COLUBK+$00
F0     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V0     sta WSYNC+$00
        dex
        bne V0
        lda #0
        sta VBLANK+$00
        ldx #192
P0     sta WSYNC+$00
        dex
        bne P0
        lda #2
        sta VBLANK+$00
        ldx #30
O0     sta WSYNC+$00
        dex
        bne O0
        jmp F0
Start0   CLEAN_START
        lda $FFF6
        lda $FE00
        CHECK0 0
        lda $FFF7
        lda $FE00
        CHECK0 1
        lda $FFF8
        lda $FE00
        CHECK0 2
        lda $FFF9
        lda $FE00
        CHECK0 3
        sta $FFF9
        lda $FE00
        CHECK0 3
        sta $FFF8
        lda $FE00
        CHECK0 2
        sta $FFF7
        lda $FE00
        CHECK0 1
        sta $FFF6
        lda $FE00
        CHECK0 0
        sta $FFF6
        ldx #0
W0      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W0
        sta $FFF9
        ldx #0
R0      txa
        eor #$5A
        cmp $F080,x
        beq K0
        jmp Fail0
K0      inx
        cpx #128
        bne R0
        jmp Pass0
        ORG $0E00
        RORG $FE00
        .byte 0
        ORG $0FFC
        RORG $FFFC
        .word Start0
        .word Start0
        SEG bank1
        ORG $1000
        RORG $F000
        ds.b 256, 0
        ORG $1200
        RORG $F200
        MAC CHECK1
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail1
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail1  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show1
Pass1  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show1  sta COLUBK+$00
F1     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V1     sta WSYNC+$00
        dex
        bne V1
        lda #0
        sta VBLANK+$00
        ldx #192
P1     sta WSYNC+$00
        dex
        bne P1
        lda #2
        sta VBLANK+$00
        ldx #30
O1     sta WSYNC+$00
        dex
        bne O1
        jmp F1
Start1   CLEAN_START
        lda $FFF6
        lda $FE00
        CHECK1 0
        lda $FFF7
        lda $FE00
        CHECK1 1
        lda $FFF8
        lda $FE00
        CHECK1 2
        lda $FFF9
        lda $FE00
        CHECK1 3
        sta $FFF9
        lda $FE00
        CHECK1 3
        sta $FFF8
        lda $FE00
        CHECK1 2
        sta $FFF7
        lda $FE00
        CHECK1 1
        sta $FFF6
        lda $FE00
        CHECK1 0
        sta $FFF6
        ldx #0
W1      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W1
        sta $FFF9
        ldx #0
R1      txa
        eor #$5A
        cmp $F080,x
        beq K1
        jmp Fail1
K1      inx
        cpx #128
        bne R1
        jmp Pass1
        ORG $1E00
        RORG $FE00
        .byte 1
        ORG $1FFC
        RORG $FFFC
        .word Start1
        .word Start1
        SEG bank2
        ORG $2000
        RORG $F000
        ds.b 256, 0
        ORG $2200
        RORG $F200
        MAC CHECK2
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail2
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail2  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show2
Pass2  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show2  sta COLUBK+$00
F2     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V2     sta WSYNC+$00
        dex
        bne V2
        lda #0
        sta VBLANK+$00
        ldx #192
P2     sta WSYNC+$00
        dex
        bne P2
        lda #2
        sta VBLANK+$00
        ldx #30
O2     sta WSYNC+$00
        dex
        bne O2
        jmp F2
Start2   CLEAN_START
        lda $FFF6
        lda $FE00
        CHECK2 0
        lda $FFF7
        lda $FE00
        CHECK2 1
        lda $FFF8
        lda $FE00
        CHECK2 2
        lda $FFF9
        lda $FE00
        CHECK2 3
        sta $FFF9
        lda $FE00
        CHECK2 3
        sta $FFF8
        lda $FE00
        CHECK2 2
        sta $FFF7
        lda $FE00
        CHECK2 1
        sta $FFF6
        lda $FE00
        CHECK2 0
        sta $FFF6
        ldx #0
W2      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W2
        sta $FFF9
        ldx #0
R2      txa
        eor #$5A
        cmp $F080,x
        beq K2
        jmp Fail2
K2      inx
        cpx #128
        bne R2
        jmp Pass2
        ORG $2E00
        RORG $FE00
        .byte 2
        ORG $2FFC
        RORG $FFFC
        .word Start2
        .word Start2
        SEG bank3
        ORG $3000
        RORG $F000
        ds.b 256, 0
        ORG $3200
        RORG $F200
        MAC CHECK3
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail3
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail3  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show3
Pass3  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show3  sta COLUBK+$00
F3     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V3     sta WSYNC+$00
        dex
        bne V3
        lda #0
        sta VBLANK+$00
        ldx #192
P3     sta WSYNC+$00
        dex
        bne P3
        lda #2
        sta VBLANK+$00
        ldx #30
O3     sta WSYNC+$00
        dex
        bne O3
        jmp F3
Start3   CLEAN_START
        lda $FFF6
        lda $FE00
        CHECK3 0
        lda $FFF7
        lda $FE00
        CHECK3 1
        lda $FFF8
        lda $FE00
        CHECK3 2
        lda $FFF9
        lda $FE00
        CHECK3 3
        sta $FFF9
        lda $FE00
        CHECK3 3
        sta $FFF8
        lda $FE00
        CHECK3 2
        sta $FFF7
        lda $FE00
        CHECK3 1
        sta $FFF6
        lda $FE00
        CHECK3 0
        sta $FFF6
        ldx #0
W3      txa
        eor #$5A
        sta $F000,x
        inx
        cpx #128
        bne W3
        sta $FFF9
        ldx #0
R3      txa
        eor #$5A
        cmp $F080,x
        beq K3
        jmp Fail3
K3      inx
        cpx #128
        bne R3
        jmp Pass3
        ORG $3E00
        RORG $FE00
        .byte 3
        ORG $3FFC
        RORG $FFFC
        .word Start3
        .word Start3
