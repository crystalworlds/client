        processor 6502
        include "hw.inc"
        SEG bank0
        ORG $0000
        RORG $F000
        .byte 1, 8, 15, 22, 29, 36, 43, 50, 57, 64, 71, 78, 85, 92, 99, 106
        .byte 113, 120, 127, 134, 141, 148, 155, 162, 169, 176, 183, 190, 197, 204, 211, 218
        .byte 225, 232, 239, 246, 253, 4, 11, 18, 25, 32, 39, 46, 53, 60, 67, 74
        .byte 81, 88, 95, 102, 109, 116, 123, 130, 137, 144, 151, 158, 165, 172, 179, 186
        .byte 193, 200, 207, 214, 221, 228, 235, 242, 249, 0, 7, 14, 21, 28, 35, 42
        .byte 49, 56, 63, 70, 77, 84, 91, 98, 105, 112, 119, 126, 133, 140, 147, 154
        .byte 161, 168, 175, 182, 189, 196, 203, 210, 217, 224, 231, 238, 245, 252, 3, 10
        .byte 17, 24, 31, 38, 45, 52, 59, 66, 73, 80, 87, 94, 101, 108, 115, 122
        .byte 129, 136, 143, 150, 157, 164, 171, 178, 185, 192, 199, 206, 213, 220, 227, 234
        .byte 241, 248, 255, 6, 13, 20, 27, 34, 41, 48, 55, 62, 69, 76, 83, 90
        .byte 97, 104, 111, 118, 125, 132, 139, 146, 153, 160, 167, 174, 181, 188, 195, 202
        .byte 209, 216, 223, 230, 237, 244, 251, 2, 9, 16, 23, 30, 37, 44, 51, 58
        .byte 65, 72, 79, 86, 93, 100, 107, 114, 121, 128, 135, 142, 149, 156, 163, 170
        .byte 177, 184, 191, 198, 205, 212, 219, 226, 233, 240, 247, 254, 5, 12, 19, 26
        .byte 33, 40, 47, 54, 61, 68, 75, 82, 89, 96, 103, 110, 117, 124, 131, 138
        .byte 145, 152, 159, 166, 173, 180, 187, 194, 201, 208, 215, 222, 229, 236, 243, 250
        ORG $0200
        RORG $F200
        MAC CHECK0
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail0
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail0  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show0
Pass0  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show0  sta COLUBK+$00
F0     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V0     sta WSYNC+$00
        dex
        bne V0
        lda #0
        sta VBLANK+$00
        ldx #192
P0     sta WSYNC+$00
        dex
        bne P0
        lda #2
        sta VBLANK+$00
        ldx #30
O0     sta WSYNC+$00
        dex
        bne O0
        jmp F0
Start0   CLEAN_START
        lda $FFF8
        lda $FE00
        CHECK0 0
        lda $FFF9
        lda $FE00
        CHECK0 1
        sta $FFF9
        lda $FE00
        CHECK0 1
        sta $FFF8
        lda $FE00
        CHECK0 0
        jmp Pass0
        ORG $0E00
        RORG $FE00
        .byte 0
        ORG $0FFC
        RORG $FFFC
        .word Start0
        .word Start0
        SEG bank1
        ORG $1000
        RORG $F000
        .byte 14, 21, 28, 35, 42, 49, 56, 63, 70, 77, 84, 91, 98, 105, 112, 119
        .byte 126, 133, 140, 147, 154, 161, 168, 175, 182, 189, 196, 203, 210, 217, 224, 231
        .byte 238, 245, 252, 3, 10, 17, 24, 31, 38, 45, 52, 59, 66, 73, 80, 87
        .byte 94, 101, 108, 115, 122, 129, 136, 143, 150, 157, 164, 171, 178, 185, 192, 199
        .byte 206, 213, 220, 227, 234, 241, 248, 255, 6, 13, 20, 27, 34, 41, 48, 55
        .byte 62, 69, 76, 83, 90, 97, 104, 111, 118, 125, 132, 139, 146, 153, 160, 167
        .byte 174, 181, 188, 195, 202, 209, 216, 223, 230, 237, 244, 251, 2, 9, 16, 23
        .byte 30, 37, 44, 51, 58, 65, 72, 79, 86, 93, 100, 107, 114, 121, 128, 135
        .byte 142, 149, 156, 163, 170, 177, 184, 191, 198, 205, 212, 219, 226, 233, 240, 247
        .byte 254, 5, 12, 19, 26, 33, 40, 47, 54, 61, 68, 75, 82, 89, 96, 103
        .byte 110, 117, 124, 131, 138, 145, 152, 159, 166, 173, 180, 187, 194, 201, 208, 215
        .byte 222, 229, 236, 243, 250, 1, 8, 15, 22, 29, 36, 43, 50, 57, 64, 71
        .byte 78, 85, 92, 99, 106, 113, 120, 127, 134, 141, 148, 155, 162, 169, 176, 183
        .byte 190, 197, 204, 211, 218, 225, 232, 239, 246, 253, 4, 11, 18, 25, 32, 39
        .byte 46, 53, 60, 67, 74, 81, 88, 95, 102, 109, 116, 123, 130, 137, 144, 151
        .byte 158, 165, 172, 179, 186, 193, 200, 207, 214, 221, 228, 235, 242, 249, 0, 7
        ORG $1200
        RORG $F200
        MAC CHECK1
        inc CHECKNO
        cmp #{1}
        beq .ok
        jmp Fail1
.ok
        ENDM
        MAC CLEAN_START
        sei
        cld
        ldx #$FF
        txs
        lda #0
        ldx #$7F
.ram    sta $80,x
        dex
        bpl .ram
        ldx #$3F
.tia    sta $00,x
        dex
        bpl .tia
        ENDM
Fail1  lda #2
        sta RESULT
        lda #FAIL_COLOUR
        jmp Show1
Pass1  lda #1
        sta RESULT
        lda #PASS_COLOUR
Show1  sta COLUBK+$00
F1     lda #2
        sta WSYNC+$00
        sta VSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        sta WSYNC+$00
        lda #0
        sta VSYNC+$00
        lda #2
        sta VBLANK+$00
        ldx #37
V1     sta WSYNC+$00
        dex
        bne V1
        lda #0
        sta VBLANK+$00
        ldx #192
P1     sta WSYNC+$00
        dex
        bne P1
        lda #2
        sta VBLANK+$00
        ldx #30
O1     sta WSYNC+$00
        dex
        bne O1
        jmp F1
Start1   CLEAN_START
        lda $FFF8
        lda $FE00
        CHECK1 0
        lda $FFF9
        lda $FE00
        CHECK1 1
        sta $FFF9
        lda $FE00
        CHECK1 1
        sta $FFF8
        lda $FE00
        CHECK1 0
        jmp Pass1
        ORG $1E00
        RORG $FE00
        .byte 1
        ORG $1FFC
        RORG $FFFC
        .word Start1
        .word Start1
