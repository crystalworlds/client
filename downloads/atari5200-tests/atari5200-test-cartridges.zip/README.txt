Atari 5200 test cartridges, from the CrystalWorlds.Media project
================================================================

We wrote these three self-checking test cartridges for the Atari 5200.
Each checks one part of the console the way the hardware documentation
describes it. Each is a 32 KB cartridge that starts straight away,
without the Atari logo screen.

How to read the result: when the test ends, the background turns green if
every check was as expected and red if one was not. The verdict is also in
the console's RAM: address 3F00 holds A5 for a pass and FA for a fail,
3F01 the number of the failed check and 3F02 the number of checks.

What the real console shows: green. The expected results come from the
hardware documentation, not from photographs of a console.

Files
-----
test_timers.bin    The POKEY sound chip's timers: how often each one
                   interrupts the processor for several dividers and
                   clocks, and the interrupt status and enable registers.
                   Needs no controller; the verdict comes after about
                   seven seconds. Its last check expects the interrupt
                   status F7 that the manual gives while the serial
                   output is idle.
test_pokeyhrm.bin  The POKEY chip against its manual, check by check: the
                   timers, the controller (pot) scan, the keypad and the
                   upper button. Its timing windows that reach a line's
                   memory refresh cycles count them where the console has
                   them, and two checks start just after a WSYNC.
test_keyscan.bin   The keypad scan: every key of every one of the four
                   controllers, each read only when its own controller is
                   selected, and the upper button of each.

The last two were written for emulators, which can press controls at an
exact moment: test_pokeyhrm needs the first stick held at an exact
position, key 5 held on the second controller from switch-on and its upper
button pressed after one and a half seconds; test_keyscan needs every key
of four controllers pressed in turn, each within a fraction of a second.
Pressed by hand on a console, they will most likely end red even when the
console is fine. test_timers needs nothing pressed.

How to run them on a console: copy a .bin file to a 5200 flash cartridge
as you would a 32 KB game, and start it.

How the emulators did on them (measured 28 Oct 2026) is on the site's home
page, on the Atari 5200 card under "How we compare".

Source
------
The source folder holds each cartridge's assembly source and the hardware
names they share (hw5200.inc). They assemble with dasm, for example:
  dasm test_timers.asm -f3 -I. -otest_timers.bin
which gives the file here byte for byte.

Licence: this zip is MIT-licensed (see LICENSE), unlike the rest of the site.
