
  processor 6502
  include "hw5200.inc"
  MAC FNE
  ; fail (check number in X) unless Z is set
  beq *+5
  jmp Fail
  ENDM
  MAC FCS
  ; fail unless C is clear
  bcc *+5
  jmp Fail
  ENDM

  org $4000
Start:
  sei
  cld
  ldx #$FF
  txs
  lda #0
  sta NMIEN
  sta DMACTL
  sta IRQEN
  ; clear RAM 0000-3FFF (inline: the stack page is cleared too)
  tax
.clrzp:
  sta $00,x
  inx
  bne .clrzp
  lda #$01
  sta $01
  lda #0
  tay
.clrpg:
  sta ($00),y
  iny
  bne .clrpg
  inc $01
  ldx $01
  cpx #$40
  bne .clrpg
  sta $01

FRAMES = $80
I = $81
CNT = $82
  lda #<Vbi
  sta VVBLKI
  lda #>Vbi
  sta VVBLKI+1
  lda #$02
  sta SKCTL
  lda #$40
  sta NMIEN
  lda #0
  sta I
.combo:
  ldx I
  lda Ctrl,x
  ora #$04
  sta CONSOL
  lda #0
  sta CNT
.again:
  lda #0
  sta IRQEN
  lda #$40
  sta IRQEN
  ldy #0
.wk:
  sta WSYNC
  lda IRQST
  and #$40
  beq .got
  dey
  bne .wk
  inc CNT
  lda CNT
  cmp #40
  bne .wk
  ldx I
  inx
  jmp Fail
.got:
  lda KBCODE
  and #$1F
  ldx I
  sta DATA,x
  cmp Code,x
  bne .again
.ok1:
  ; another controller selected: no key
  lda Ctrl,x
  clc
  adc #1
  and #3
  ora #$04
  sta CONSOL
  lda #0
  sta IRQEN
  lda #$40
  sta IRQEN
  ldy #80
.wn:
  sta WSYNC
  lda IRQST
  and #$40
  beq .bad
  dey
  bne .wn
  inc I
  lda I
  cmp #60
  bne .combo
  ; the upper button of controller 3 (held throughout): SKSTAT bit 3 low
  ; with controller 3 selected, high with controller 1
  jsr WaitVbl
  lda #$06
  sta CONSOL
  ldy #70
.wt1:
  sta WSYNC
  dey
  bne .wt1
  ldx #61
  lda SKSTAT
  and #$08
  bne .bad2
  lda #$04
  sta CONSOL
  ldy #70
.wt2:
  sta WSYNC
  dey
  bne .wt2
  ldx #62
  lda SKSTAT
  and #$08
  beq .bad2
  lda #62
  sta CHECKS
  jmp Pass
.bad:
  ldx I
  inx
.bad2:
  jmp Fail
Vbi:
  inc FRAMES
  rti
Code:
  .byte $05,$1F,$1D,$1B,$17,$15,$13,$0F,$0D,$0B,$07,$03,$19,$11,$09,$05,$1F,$1D,$1B,$17,$15,$13,$0F,$0D,$0B,$07,$03,$19,$11,$09,$05,$1F,$1D,$1B,$17,$15,$13,$0F,$0D,$0B,$07,$03,$19,$11,$09,$05,$1F,$1D,$1B,$17,$15,$13,$0F,$0D,$0B,$07,$03,$19,$11,$09
Ctrl:
  .byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3

; Pass/Fail: verdict to RESULT, background green or red, then hold.
  SUBROUTINE
Pass:
  lda #$A5
  sta RESULT
  lda #$C8
  sta COLBK
  jmp Hold
Fail:
  stx FAILNO
  lda #$FA
  sta RESULT
  lda #$46
  sta COLBK
Hold:
  jmp Hold

; WaitVbl: wait for the next line 248 (VCOUNT 124) with NMIs off.
  SUBROUTINE
WaitVbl:
.w1:
  lda VCOUNT
  cmp #124
  beq .w1
.w2:
  lda VCOUNT
  cmp #124
  bne .w2
  rts

; a blank display list (24 blank lines, then 192 lines of mode F off a
; zeroed screen when DMA is on) used when a program needs none of its own
  ALIGN 256
BlankDL:
  .byte $70,$70,$70
  .byte $4F,$00,$20
  REPEAT 95
  .byte $0F
  REPEND
  .byte $4F,$00,$21
  REPEAT 95
  .byte $0F
  REPEND
  .byte $41
  .word BlankDL

  org $BFE8
  .byte $2B,$25,$39,$30,$21,$24,$00,$33,$23,$21,$2E,$00,$00,$00,$00,$00,$00,$00,$00,$00
  .byte $19, $FF
  .word Start
