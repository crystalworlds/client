
  processor 6502
  include "hw5200.inc"
  MAC FNE
  ; fail (check number in X) unless Z is set
  beq *+5
  jmp Fail
  ENDM
  MAC FCS
  ; fail unless C is clear
  bcc *+5
  jmp Fail
  ENDM

  org $4000
Start:
  sei
  cld
  ldx #$FF
  txs
  lda #0
  sta NMIEN
  sta DMACTL
  sta IRQEN
  ; clear RAM 0000-3FFF (inline: the stack page is cleared too)
  tax
.clrzp:
  sta $00,x
  inx
  bne .clrzp
  lda #$01
  sta $01
  lda #0
  tay
.clrpg:
  sta ($00),y
  iny
  bne .clrpg
  inc $01
  ldx $01
  cpx #$40
  bne .clrpg
  sta $01

FRAMES = $80
RECP = $81
RECL = $82
RECH = $83
CNT = $84
T0 = $85
  lda #<Irq
  sta VIMIRQ
  lda #>Irq
  sta VIMIRQ+1
  lda #0
  sta NMIEN
  sta IRQEN
  lda #$04
  sta CONSOL        ; the sticks' pots powered, controller 1 selected
  ; 1. AHRM 5.5: STA SKCTL leaving initialisation, LDA RANDOM: 1F (9-bit)
  ; (out of initialisation first, so that entering it resets the
  ; polynomials)
  lda #3
  sta SKCTL
  jsr WaitVbl
  lda #$80
  sta AUDCTL
  lda #0
  sta SKCTL
  sta WSYNC
  lda #3
  sta SKCTL
  lda RANDOM
  sta DATA+0
  ldx #1
  cmp #$1F
  FNE
  ; 2. AHRM 5.2: RANDOM reads FF in initialisation
  lda #0
  sta SKCTL
  nop
  nop
  nop
  nop
  nop
  lda RANDOM
  sta DATA+1
  ldx #2
  cmp #$FF
  FNE
  ; 3. AHRM 5.5: 9-bit, STA WSYNC and LDA RANDOM a line apart: the run
  ; 00 DF EE 16 B9 among 516 samples
  lda #3
  sta SKCTL
  ldx #0
.r1:
  sta WSYNC
  lda RANDOM
  sta $2000,x
  inx
  bne .r1
.r2:
  sta WSYNC
  lda RANDOM
  sta $2100,x
  inx
  bne .r2
  ldx #0
.r3:
  sta WSYNC
  lda RANDOM
  sta $2200,x
  inx
  cpx #8
  bne .r3
  lda #<$2000
  sta RECL
  lda #>$2000
  sta RECH
.find:
  ldy #4
.fc:
  lda (RECL),y
  cmp Run,y
  bne .fnext
  dey
  bpl .fc
  jmp .found
.fnext:
  inc RECL
  bne .fn2
  inc RECH
.fn2:
  lda RECH
  cmp #$22
  bne .find
  lda RECL
  cmp #$05
  bne .find
  ldx #3
  jmp Fail
.found:
  ; 4. AHRM 5.3: a 1.79 MHz timer started by STIMER at T is seen in IRQST
  ; at T + AUDF + 8 (enabled at T + 4, the latest the manual allows)
  sei
  lda #0
  sta IRQEN
  lda #$40
  sta AUDCTL
  lda #1
  sta AUDF1
  ldx #1
  jsr WaitVbl
  sta WSYNC
  sta STIMER
  stx IRQEN
  lda IRQST
  sta DATA+2
  ldx #4
  and #1
  cmp #1
  FNE              ; AUDF1 1: not yet at T + 8
  lda #0
  sta IRQEN
  sta AUDF1
  ldx #1
  jsr WaitVbl
  sta WSYNC
  sta STIMER
  stx IRQEN
  lda IRQST
  sta DATA+3
  ldx #5
  and #1
  FNE              ; AUDF1 0: seen at T + 8
  ; 6. AHRM 5.7: enabled at T + 6, too late for the interrupt at T + 8
  lda #0
  sta IRQEN
  ldx #1
  jsr WaitVbl
  sta WSYNC
  sta STIMER
  nop
  stx IRQEN
  lda IRQST
  sta DATA+4
  ldx #6
  and #1
  cmp #1
  FNE
  ; 30. AHRM 5.7: enabled at T + 6, three cycles before the interrupt
  ; due at T + 9 (AUDF1 1): too late
  lda #0
  sta IRQEN
  lda #1
  sta AUDF1
  ldx #1
  jsr WaitVbl
  sta WSYNC
  sta STIMER
  nop
  stx IRQEN
  lda IRQST
  sta DATA+24
  ldx #30
  and #1
  cmp #1
  FNE
  ; 34. AHRM 5.3: STIMER written again four cycles before an interrupt is
  ; due preempts it (AUDF1 4: due at T + 12 from STIMER at T; STIMER
  ; again at T + 8; nothing at T + 12)
  lda #0
  sta IRQEN
  lda #$40
  sta AUDCTL
  lda #4
  sta AUDF1
  ldx #1
  jsr WaitVbl
  sta WSYNC
  sta STIMER
  stx IRQEN
  sta STIMER
  lda IRQST
  sta DATA+27
  ldx #34
  and #1
  cmp #1
  FNE
  ; 7. AHRM 5.2: a 64 kHz timer of AUDF 0 is asserted 24 cycles after the
  ; SKCTL write leaving initialisation: a read sees it 25 cycles after it,
  ; not 24 (ATARI-D82, 25 Oct 2026: the console's values in Acid800's
  ; pokey_inittiming; this check read "seen at 24, not 23" before)
  lda #0
  sta IRQEN
  sta AUDCTL
  sta AUDF1
  sta SKCTL
  sta STIMER
  lda #1
  sta IRQEN
  jsr WaitVbl
  sta WSYNC
  lda #3
  sta SKCTL
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda IRQST
  sta DATA+5
  ldx #7
  and #1
  cmp #1
  FNE
  lda #0
  sta IRQEN
  sta SKCTL
  sta STIMER
  lda #1
  sta IRQEN
  jsr WaitVbl
  sta WSYNC
  lda #3
  sta SKCTL
  bit $00
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda IRQST
  sta DATA+6
  ldx #8
  and #1
  FNE
  ; 9. the same with the 15 kHz clock: seen 84 cycles after, not 83
  ; (asserted at 83; ATARI-D82, was "83, not 82")
  lda #0
  sta IRQEN
  sta SKCTL
  lda #1
  sta AUDCTL
  sta STIMER
  sta IRQEN
  jsr WaitVbl
  sta WSYNC
  lda #3
  sta SKCTL
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda IRQST
  sta DATA+7
  ldx #9
  and #1
  cmp #1
  FNE
  lda #0
  sta IRQEN
  sta SKCTL
  sta STIMER
  lda #1
  sta IRQEN
  jsr WaitVbl
  sta WSYNC
  lda #3
  sta SKCTL
  bit $00
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda IRQST
  sta DATA+8
  ldx #10
  and #1
  FNE
  ; 11. AHRM 5.2: initialisation leaves IRQST (the latch just seen)
  lda #0
  sta SKCTL
  lda IRQST
  sta DATA+9
  ldx #11
  and #1
  FNE
  lda #0
  sta IRQEN
  ; 12. AHRM 5.9: the slow scan's first step 81 cycles after the SKCTL
  ; write: POT0 (stick at 114) reads 00 there, 01 a cycle later
  jsr WaitVbl
  sta WSYNC
  lda #3
  sta SKCTL
  sta POTGO
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda POT0
  sta DATA+10
  ldx #12
  cmp #0
  FNE
  lda #0
  sta SKCTL
  jsr WaitVbl
  sta WSYNC
  lda #3
  sta SKCTL
  sta POTGO
  bit $00
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda POT0
  sta DATA+11
  ldx #13
  cmp #1
  FNE
  ; 14. a full scan: POT0 114, ALLPOT 00 at its end
  jsr WaitVbl
  sta POTGO
  jsr WaitVbl
  lda POT0
  sta DATA+12
  ldx #14
  cmp #114
  FNE
  lda ALLPOT
  sta DATA+13
  ldx #15
  cmp #0
  FNE
  ; 16. AHRM 13.3: CONSOL bit 2 clear, the pots unpowered: 228
  lda #$00
  sta CONSOL
  sta POTGO
  jsr WaitVbl
  jsr WaitVbl
  lda POT0
  sta DATA+14
  ldx #16
  cmp #228
  FNE
  lda #$04
  sta CONSOL
  ; 17. AHRM 5.9: fast scan: POTGO, the counter counts cycles to 229; a
  ; stick (114 lines' charge) reaches none of it (aligned since 28 Oct 2026:
  ; a refresh cycle between the write and the read adds a count)
  sta WSYNC
  lda #$07
  sta SKCTL
  sta POTGO
  lda POT0
  sta DATA+15
  ldx #17
  cmp #2
  FNE
  ; 31. the same read a cycle later (LDA abs,X across a page: five
  ; cycles): the counts 3 and 4 ANDed, 00
  sta WSYNC
  ldy #$FF
  sta POTGO
  lda $E701,y
  sta DATA+25
  ldx #31
  cmp #0
  FNE
  sta WSYNC
  sta WSYNC
  sta WSYNC
  lda POT0
  sta DATA+16
  ldx #18
  cmp #229
  FNE
  lda ALLPOT
  ldx #19
  cmp #0
  FNE
  lda #$03
  sta SKCTL
  ; 20. AHRM 13.3 and 5.8: key 5 held on controller 2 (from frame 1),
  ; controller 2 selected, debounce off: reported every 32 lines, KBCODE
  ; 15 and 35 by turns
  jsr WaitVbl
  jsr WaitVbl
  lda #$05
  sta CONSOL
  lda #$02
  sta SKCTL
  lda #0
  sta CNT
  sta IRQEN
  lda #$40
  sta IRQEN
  ldy #0
  ldx #0
.k1:
  sta WSYNC
  lda IRQST
  and #$40
  bne .k2
  inc CNT
  lda KBCODE
  sta DATA+$20,y
  iny
  lda #0
  sta IRQEN
  lda #$40
  sta IRQEN
.k2:
  inx
  cpx #0
  bne .k1
  lda CNT
  sta DATA+17
  ldx #20
  cmp #8
  FNE
  lda DATA+$20
  ora DATA+$21
  and #$DF
  ldx #21
  cmp #$15
  FNE
  lda DATA+$20
  eor DATA+$21
  ldx #22
  cmp #$20
  FNE
  ; 23. controller 1 selected: no key
  lda #$04
  sta CONSOL
  lda #0
  sta IRQEN
  lda #$40
  sta IRQEN
  ldx #0
.k3:
  sta WSYNC
  inx
  bne .k3
  lda IRQST
  ldx #23
  and #$40
  cmp #$40
  FNE
  ; 24. AHRM 13.3: debounce on, the keypad's doubled lines never report
  lda #$05
  sta CONSOL
  lda #$03
  sta SKCTL
  lda #0
  sta IRQEN
  lda #$40
  sta IRQEN
  ldx #0
.k4:
  sta WSYNC
  inx
  bne .k4
  lda IRQST
  ldx #24
  and #$40
  cmp #$40
  FNE
  ; 25. AHRM 13.3: the upper button (controller 2, from frame 90): the
  ; break interrupt once, SKSTAT bit 3 low, KBCODE bits 7-6 with the key
  lda #$02
  sta SKCTL
  lda #0
  sta IRQEN
  lda #$C0
  sta IRQEN
  ldy #0
.k6:
  jsr WaitVbl
  lda IRQST
  and #$80
  beq .k7
  dey
  bne .k6
.k7:
  lda IRQST
  sta DATA+18
  ldx #25
  and #$80
  FNE
  lda SKSTAT
  sta DATA+19
  ldx #26
  and #$08
  FNE
  ; 32. the button still held: no second break interrupt (a press, not a
  ; hold, AHRM 5.8)
  lda #$40
  sta IRQEN
  lda #$C0
  sta IRQEN
  jsr WaitVbl
  jsr WaitVbl
  lda IRQST
  ldx #32
  and #$80
  cmp #$80
  FNE
  lda #0
  sta IRQEN
  lda #$40
  sta IRQEN
.k5:
  lda IRQST
  and #$40
  bne .k5
  lda KBCODE
  sta DATA+20
  ldx #27
  and #$C0
  cmp #$C0
  FNE
  lda #0
  sta IRQEN
  lda #$02
  sta SKCTL
  ; 28. AHRM 3.4: CLI with an interrupt pending: the next instruction runs
  ; before it is taken
  lda #$40
  sta AUDCTL
  lda #0
  sta AUDF1
  lda #1
  sta IRQEN
  sta STIMER
  nop
  nop
  nop
  nop
  nop
  nop
  cli
CliNext:
  nop
CliAfter:
  nop
  sei
  lda RECL
  sta DATA+21
  ldx #28
  cmp #<CliAfter
  FNE
  lda RECH
  cmp #>CliAfter
  FNE
  ; 29. AHRM 3.4: CLI, SEI with an interrupt pending: taken after SEI,
  ; the pushed flags with I set
  lda #1
  sta IRQEN
  sta STIMER
  nop
  nop
  nop
  nop
  nop
  nop
  cli
  sei
SeiAfter:
  nop
  lda RECL
  sta DATA+22
  ldx #29
  cmp #<SeiAfter
  FNE
  lda RECP
  sta DATA+23
  and #$04
  cmp #$04
  FNE
  lda #0
  sta IRQEN
  ; 33. AHRM 3.4: a taken branch within its page delays the interrupt by
  ; an instruction: the timer's interrupt latched on the branch's last
  ; cycle is taken after the instruction at its target, not before it
  lda #$40
  sta AUDCTL
  lda #0
  sta AUDF1
  ldx #1
  jsr WaitVbl
  sta WSYNC
  lda #1
  cli
  sta STIMER
  stx IRQEN
  nop
  bne BrTarget
  nop
BrTarget:
  nop
BrAfter:
  nop
  sei
  lda RECL
  sta DATA+26
  ldx #33
  cmp #<BrAfter
  FNE
  lda RECH
  cmp #>BrAfter
  FNE
  lda #0
  sta IRQEN
  ; 35. AHRM 3.4: one entry per interrupt. In the vertical blank, with
  ; the timer's interrupt pending: CLI, then STA WSYNC written after cycle
  ; 106, so that the CPU is held into the next line. STA WSYNC runs (the
  ; one instruction CLI lets through), its poll sees the line, and the
  ; interrupt is entered once when the hold ends at the next line's cycle
  ; 106 (not twice: decision D49's finding). The timer is slowed once it
  ; has latched (64 kHz, AUDF1 FF, restarted), so that no second interrupt
  ; is in flight when the handler's IRQEN write clears it
  lda #$40
  sta AUDCTL
  lda #0
  sta AUDF1
  sta CNT
  lda #1
  sta IRQEN
  sta STIMER
  nop
  nop
  nop
  nop
  nop
  nop
  lda #$FF
  sta AUDF1
  lda #0
  sta AUDCTL
  sta STIMER
  jsr WaitVbl
  sta WSYNC
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  cli
  sta WSYNC
WsAfter:
  nop
  sei
  lda CNT
  sta DATA+28
  ldx #35
  cmp #1
  FNE
  lda RECL
  cmp #<WsAfter
  FNE
  lda RECH
  cmp #>WsAfter
  FNE
  lda #0
  sta IRQEN
  ; 36. AHRM 5.5 "Initialization behavior" (ATARI-D82): entering
  ; initialisation does not clear the 9-bit register at once; 1s fill it
  ; from the left, one a cycle. 9-bit mode, 46 cycles out of
  ; initialisation, RANDOM read 4 cycles after re-entering it: EC (the
  ; rule's value; Acid800 pokey_noise checks the console's E9 at 114)
  lda #$80
  sta AUDCTL
  lda #0
  sta SKCTL
  jsr WaitVbl
  sta WSYNC
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda #3
  sta SKCTL
  bit $00
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda #0
  sta SKCTL
  lda RANDOM
  sta DATA+29
  ldx #36
  cmp #$EC
  FNE
  ; 37. the 17-bit RANDOM (ATARI-D82): STA SKCTL leaving initialisation,
  ; LDA RANDOM: 1F, the register's bits 15-8 four steps on (the old form
  ; read FF; Acid800 pokey_noise: the console's 08 at 114 cycles)
  lda #0
  sta AUDCTL
  jsr WaitVbl
  sta WSYNC
  lda #3
  sta SKCTL
  lda RANDOM
  sta DATA+30
  ldx #37
  cmp #$1F
  FNE
  ; 38. as 36 in 17-bit mode: E0 (Acid800: the console's F0 at 114)
  lda #0
  sta SKCTL
  jsr WaitVbl
  sta WSYNC
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda #3
  sta SKCTL
  bit $00
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda #0
  sta SKCTL
  lda RANDOM
  sta DATA+31
  ldx #38
  cmp #$E0
  FNE
  ; 39. AHRM 5.7 (ATARI-D82): IRQST bit 3, serial output complete, reads
  ; active (0) while the serial output idles, with IRQEN 0
  lda #3
  sta SKCTL
  lda #0
  sta IRQEN
  lda IRQST
  sta DATA+32
  ldx #39
  and #$08
  FNE
  ; 40. AHRM 5.6 "Asynchronous receive mode" (ATARI-D82): SKCTL bit 4
  ; holds timers 3 and 4 while the input waits for a start bit (the
  ; 5200's never comes): a 64 kHz timer 4 of AUDF 0 does not fire
  lda #0
  sta AUDCTL
  sta AUDF4
  lda #$13
  sta SKCTL
  sta STIMER
  lda #4
  sta IRQEN
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  nop
  lda IRQST
  sta DATA+33
  ldx #40
  and #$04
  cmp #$04
  FNE
  lda #0
  sta IRQEN
  lda #3
  sta SKCTL
  lda #40
  sta CHECKS
  jmp Pass

Irq:
  inc CNT
  pha
  txa
  pha
  tsx
  lda $0103,x
  sta RECP
  lda $0104,x
  sta RECL
  lda $0105,x
  sta RECH
  lda #0
  sta IRQEN
  pla
  tax
  pla
  rti

Run:
  .byte $00,$DF,$EE,$16,$B9

; Pass/Fail: verdict to RESULT, background green or red, then hold.
  SUBROUTINE
Pass:
  lda #$A5
  sta RESULT
  lda #$C8
  sta COLBK
  jmp Hold
Fail:
  stx FAILNO
  lda #$FA
  sta RESULT
  lda #$46
  sta COLBK
Hold:
  jmp Hold

; WaitVbl: wait for the next line 248 (VCOUNT 124) with NMIs off.
  SUBROUTINE
WaitVbl:
.w1:
  lda VCOUNT
  cmp #124
  beq .w1
.w2:
  lda VCOUNT
  cmp #124
  bne .w2
  rts

; a blank display list (24 blank lines, then 192 lines of mode F off a
; zeroed screen when DMA is on) used when a program needs none of its own
  ALIGN 256
BlankDL:
  .byte $70,$70,$70
  .byte $4F,$00,$20
  REPEAT 95
  .byte $0F
  REPEND
  .byte $4F,$00,$21
  REPEAT 95
  .byte $0F
  REPEND
  .byte $41
  .word BlankDL

  org $BFE8
  .byte $30,$2F,$2B,$25,$39,$00,$2D,$21,$2E,$35,$21,$2C,$00,$23,$28,$25,$23,$2B,$33,$00
  .byte $19, $FF
  .word Start
