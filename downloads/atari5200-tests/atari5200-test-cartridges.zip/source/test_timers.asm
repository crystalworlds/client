
  processor 6502
  include "hw5200.inc"
  MAC FNE
  ; fail (check number in X) unless Z is set
  beq *+5
  jmp Fail
  ENDM
  MAC FCS
  ; fail unless C is clear
  bcc *+5
  jmp Fail
  ENDM

  org $4000
Start:
  sei
  cld
  ldx #$FF
  txs
  lda #0
  sta NMIEN
  sta DMACTL
  sta IRQEN
  ; clear RAM 0000-3FFF (inline: the stack page is cleared too)
  tax
.clrzp:
  sta $00,x
  inx
  bne .clrzp
  lda #$01
  sta $01
  lda #0
  tay
.clrpg:
  sta ($00),y
  iny
  bne .clrpg
  inc $01
  ldx $01
  cpx #$40
  bne .clrpg
  sta $01

COUNT = $80
FRAMES = $82
T = $84
  lda #<Vbi
  sta VVBLKI
  lda #>Vbi
  sta VVBLKI+1
  lda #<Irq
  sta VIMIRQ
  lda #>Irq
  sta VIMIRQ+1
  lda #$40
  sta NMIEN
  lda #$03
  sta SKCTL
  ldx #0
.test:
  stx T
  lda #0
  sta COUNT
  sta COUNT+1
  sta IRQEN
  jsr WaitVbl
  lda Audctl,x
  sta AUDCTL
  lda Audf1,x
  sta AUDF1
  lda Audf2,x
  sta AUDF2
  lda Audf4,x
  sta AUDF4
  lda #0
  sta FRAMES
  sta STIMER
  lda Irqen,x
  sta IRQEN
  ; wait 30 frames, with interrupts let in only around a WSYNC (so none is
  ; taken in a drawn line's last cycles, where the reference reads past
  ; its cycle table)
.wait:
  cli
  sta WSYNC
  sei
  lda FRAMES
  cmp #30
  bne .wait
  lda #0
  sta IRQEN
  ldx T
  lda COUNT
  sta DATA,x
  lda COUNT+1
  sta DATA+$10,x
  ; within the expected range?
  lda COUNT+1
  cmp MinHi,x
  bcc .bad
  bne .hiok
  lda COUNT
  cmp MinLo,x
  bcc .bad
.hiok:
  lda COUNT+1
  cmp MaxHi,x
  bcc .ok
  bne .bad
  lda COUNT
  cmp MaxLo,x
  bcc .ok
  beq .ok
.bad:
  ldx T
  inx
  jmp Fail
.ok:
  ldx T
  inx
  cpx #NT
  bne .test
  ; IRQST: a disabled timer latches nothing; IRQEN 0 clears the latches,
  ; and IRQST reads F7: bit 3, serial output complete, is not a latch and
  ; reads 0 while the serial output idles, whatever IRQEN holds (AHRM 5.7
  ; and chapter 14, ATARI-D90)
  ldx #NT+1
  lda #$01
  sta IRQEN
  lda #$00
  sta AUDCTL
  sta AUDF1
  sta STIMER
  sta WSYNC
  sta WSYNC
  sta WSYNC
  lda IRQST
  and #$01
  bne .bad2
  lda #0
  sta IRQEN
  lda IRQST
  cmp #$F7
  bne .bad2
  stx CHECKS
  jmp Pass
.bad2:
  jmp Fail

Vbi:
  inc FRAMES
  rti
Irq:
  ; count, and clear the latch: IRQEN off and back on
  inc COUNT
  bne .i1
  inc COUNT+1
.i1:
  pha
  txa
  pha
  lda #0
  sta IRQEN
  ldx T
  lda Irqen,x
  sta IRQEN
  pla
  tax
  pla
  rti
NT = 7
Audctl:
  .byte $00,$00,$01,$00,$00,$40,$50
Audf1:
  .byte $FF,$7F,$0F,$00,$00,$FB,$00
Audf2:
  .byte $00,$00,$00,$3F,$00,$00,$04
Audf4:
  .byte $00,$00,$00,$00,$1F,$00,$00
Irqen:
  .byte $01,$01,$01,$02,$04,$01,$02
MinLo:
  .byte $77,$F0,$DA,$E3,$C8,$4E,$49
MinHi:
  .byte $00,$00,$01,$01,$03,$0D,$03
MaxLo:
  .byte $82,$03,$FB,$05,$08,$25,$81
MaxHi:
  .byte $00,$01,$01,$02,$04,$0E,$03
; Pass/Fail: verdict to RESULT, background green or red, then hold.
  SUBROUTINE
Pass:
  lda #$A5
  sta RESULT
  lda #$C8
  sta COLBK
  jmp Hold
Fail:
  stx FAILNO
  lda #$FA
  sta RESULT
  lda #$46
  sta COLBK
Hold:
  jmp Hold

; WaitVbl: wait for the next line 248 (VCOUNT 124) with NMIs off.
  SUBROUTINE
WaitVbl:
.w1:
  lda VCOUNT
  cmp #124
  beq .w1
.w2:
  lda VCOUNT
  cmp #124
  bne .w2
  rts

; a blank display list (24 blank lines, then 192 lines of mode F off a
; zeroed screen when DMA is on) used when a program needs none of its own
  ALIGN 256
BlankDL:
  .byte $70,$70,$70
  .byte $4F,$00,$20
  REPEAT 95
  .byte $0F
  REPEND
  .byte $4F,$00,$21
  REPEAT 95
  .byte $0F
  REPEND
  .byte $41
  .word BlankDL

  org $BFE8
  .byte $30,$2F,$2B,$25,$39,$00,$34,$29,$2D,$25,$32,$33,$00,$00,$00,$00,$00,$00,$00,$00
  .byte $19, $FF
  .word Start
