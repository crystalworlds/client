Atari 7800 test cartridges, from the CrystalWorlds.Media project
================================================================

There is no public test suite for the Atari 7800, so we wrote these: one
self-checking test cartridge for each 7800 cartridge board, each with the
older (version 3) and the newer (version 4) .a78 header, plus one for the
SOUPER board.

Every byte of each cartridge, apart from the test's own program, is a marker
that says which 16 KB bank and which 1 KB block it came from. The test
switches banks and writes to the cartridge's RAM, as a game would, and after
each step reads the first and last byte of every 4 KB window of cartridge
memory and compares it with what the board must show there.

How to read the result: when the test ends, the screen turns green if every
read was as expected and red if at least one was not. The same verdict is
stored in the console's RAM as one byte after the last result: C8 for a pass,
44 for a fail.

What each cartridge checks, and how three emulators did on them (measured
7 Oct 2026), is on the Atari 7800 Emulation tab of the site, in the section
"Our 7800 test cartridges".

Files
-----
board_flat16          Flat board, 16 KB
board_flat48          Flat board, 48 KB
board_flat_ram        Flat board with 16 KB of RAM at 4000
board_mirror_ram      Mirror RAM board
board_supergame       SuperGame board, 128 KB
board_supergame_ram   SuperGame board with RAM
board_supergame9      SuperGame board, 144 KB (nine banks)
board_absolute        Absolute board, 64 KB
board_activision      Activision board, 128 KB
board_bankset         Bankset board, 64 KB
board_bankset_ram     Bankset board with RAM
board_bankset_sg      Bankset SuperGame board, 256 KB
board_souper          SOUPER board, 512 KB (not counted on our board)

Each name ending in _v4 is the same program with the version 4 header.

Licence: this zip is MIT-licensed (see LICENSE), unlike the rest of the site.
