Atari Lynx test cartridges, from the CrystalWorlds.Media project
================================================================

The Lynx already has a public test suite whose expected results were
recorded on a real Lynx: lynx-tests, by Ignacio Sanchez Gines, MIT licence,
published by its author at https://github.com/drhelius/lynx-tests . The
scores on the site's home page come from it, so it is not repeated here.

These are the test cartridges we wrote for the parts of the Lynx that
lynx-tests does not cover: the cartridge EEPROM, RAM on the cartridge
(the LNX2 file format), the ComLynx cable between two consoles, programs
loaded over the cable into RAM (the BLL format), Suzy's stop request and
switching the console off from a program.

How to read the result: these programs are not self-checking. Each one
leaves its readings in the console's RAM, in a block called g_results
(its address is in the program's .sym file and in the list below), and
byte by byte the block must hold what is listed here. The expected values
follow from what each program writes and from the hardware documentation;
no real console has been measured with them yet. Our emulator and the
reference emulator we compare against both give exactly these bytes, with
one exception, in poweroff.lnx (below).

All values are hexadecimal. Read each cartridge's RAM after about two
seconds (120 frames), the BLL program's after one second.

Files
-----
bll.o            A BLL program (a 10-byte BS93 header, loaded at 0400 and
                 run from RAM, with no cartridge and no boot). Draws bars
                 in every colour with a frame round them. Results at
                 0300-030F:
                   42 4C 4C 21 1E FF 49 65 00 00 00 00 00 00 00 5A
                 "BLL!" (the start-up code ran), 1E (30 frames counted from
                 Timer 2), FF (the cartridge port reads FF: no cartridge),
                 a sum over the program's own code (6549: it was loaded
                 whole), 5A when done.

eeprom46.lnx     The cartridge EEPROM, driven with cc65's EEPROM routines
eeprom66.lnx     as homebrew games drive it. The same program three times;
eeprom86.lnx     the .lnx header's byte 60 names the chip: 1 a 93C46,
                 3 a 93C66, 5 a 93C86, each with 16-bit words. g_results
                 at 069C (46), 05C8 (66), 05D0 (86), 23 bytes, on a fresh
                 chip (all FF):
                   FF FF 34 12 45 23 56 34 67 45 78 56 89 67 9A 78 AB 89
                   5A A5 FF FF 5A
                 word 0 as found (FFFF), words 0-7 read back after writing
                 them (1234, 2345, ... 89AB), the last word read back
                 (A55A), word 3 after erasing it (FFFF; the 93C66 and 93C86
                 write FFFF, since cc65 has no erase for them), 5A when
                 done. Run again with the chip as the first run left it,
                 the first two bytes read 34 12.

cartram.lnx      RAM on the cartridge. The program drives the cartridge
cartram8k.lnx    port the way a loader does, writes to the banks and reads
cartramx.lnx     them back. g_results at 05BC, 256 bytes; the meaning of
                 each byte is at the top of cartram/main.c.
                 cartram.lnx is a plain .lnx file with no bank 1: every
                 bank 1 read gives FF.
                 cartram8k.lnx is an LNX2 file whose bank 1 is 8 KB of
                 kept RAM in 32-byte pages, zero at the start: a write of
                 40 bytes to one page wraps after 32.
                 cartramx.lnx is an LNX2 file whose bank 1 is 64 KB of RAM
                 with its starting contents in the file, and whose second
                 bank set has 1 KB of kept RAM (64-byte pages), of which
                 the file holds the first 100 bytes.
                 Bytes 0-7 and 124-125 for each, then 255:
                   cartram    FF FF FF FF FF FF FF FF ... FF FF ... 5A
                   cartram8k  00 00 00 00 E1 E8 EF F6 ... 00 01 ... 5A
                   cartramx   07 14 21 2E 01 08 0F 16 ... 3B 3C ... 5A
                 (byte 124 counts the runs on a kept bank: run cartram8k
                 again with the RAM it kept and bytes 0-3 read C0 C1 C2 C3,
                 124-125 read 01 02).

link.lnx         Two consoles on the ComLynx cable, both running this file.
                 Hold A on one console as it starts: it is the master. The
                 master sends sixteen bytes (03 14 25 ... F1), the other
                 console answers each one inverted. 62500 baud, even
                 parity. g_results at 0527, 21 bytes:
                   master  01 10 00 FC EB DA C9 B8 A7 96 85 74 63 52 41 30
                           1F 0E FD 00 5A
                   other   00 10 00 03 14 25 36 47 58 69 7A 8B 9C AD BE CF
                           E0 F1 02 00 5A
                 role (1 master), bytes collected (16), cable errors (0),
                 the sixteen bytes collected, own echoes lost (0), 5A when
                 done.

sprstop.lnx      Suzy's stop request (SPRSYS bit 1): Suzy stops at the end
                 of the sprite it is drawing, and a new SPRGO withdraws the
                 request. A list of three sprites (A covers the screen in
                 colour 1, B and C are small, in colours 2 and 3) is drawn
                 four times: as it is; with the stop asked right after
                 SPRGO; with the stop asked by a timer interrupt while A is
                 being drawn; with the stop asked before SPRGO. g_results
                 at 077A, 32 bytes:
                   22 33 11 00  11 11 11 02  11 11 11 02  22 33 11 00
                   01 01 00 ... 00 5A
                 per case the screen byte under B, under C, under A only,
                 then SPRSYS bits 1-0 after the list (A, B and C drawn in
                 the first and last case, A only in the middle two); then
                 the interrupts taken (1), SPRSYS bits 1-0 just after SPRGO
                 in the last case (1), 5A when done.

poweroff.lnx     Switching off from a program: white screen, a tone, 20
                 frames, then SYSCTL1 written with bit 1 clear, which turns
                 the console off. Nothing after that write may run.
                 g_results at 0425, 32 bytes:
                   14 11 00 00 00 ... 00 5A
                 the frames counted (20), 11 written just before the write,
                 00 where the program would write 22 just after it, 00
                 frames counted after it, 5A written before it. The screen
                 goes dark and the sound stops.
                 The reference emulator checks the power once a frame, so
                 it runs on to the end of that frame and writes the 22 (its
                 byte 2 reads 22). How quickly a real console's power falls
                 has not been measured.

How to run them on a console: copy a .lnx file to a Lynx flash cartridge
as you would a game. The EEPROM and RAM files need a flash cartridge that
provides that chip or that RAM. bll.o is sent over the ComLynx cable to a
console running a BLL loader. The results are in RAM, so on a console they
are read with a debugger or a memory dump, not from the screen.

Source
------
The source folder holds each program's C or assembly source, its Makefile,
the build settings (cc65.mak) and build.sh, which builds every file of
this zip into source/out with cc65 2.19 and python3 (set CC65_HOME to the
cc65 folder first). The files built that way are the files here, byte for
byte. The .sym files beside the cartridges come from the same build.

Licence: this zip is MIT-licensed (see LICENSE), unlike the rest of the site.
