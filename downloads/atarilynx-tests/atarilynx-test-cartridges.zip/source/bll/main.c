/* A BLL program (built by ../build.sh with cc65's
 * lynx-bll configuration into bll.o): a 10-byte BS93 header, then
 * code loaded at 0400 and run from RAM with no cartridge and no boot.
 *
 * It draws a picture through the sprite engine (cc65's TGI driver: bars in
 * every pen and a frame) and leaves results at 0300-030F:
 *   0300-0303  "BLL!" once main is reached (the start-up code ran);
 *   0304       30 once 30 frames have been counted from Timer 2's line
 *              count (the display timers run);
 *   0305       FF if the cartridge port reads FF (no cartridge);
 *   0306-0307  a sum over the program's own code (it was loaded whole);
 *   030F       5A when done.
 * A core that runs it right shows the picture and these bytes. */
#include <lynx.h>
#include <tgi.h>
#include <6502.h>
#include <stdint.h>

#define R(a) (*(volatile uint8_t *)(a))
extern void main(void);

void main(void) {
  uint8_t i, f;
  uint16_t sum = 0;
  const uint8_t *p = (const uint8_t *)0x0400;
  R(0x300) = 'B'; R(0x301) = 'L'; R(0x302) = 'L'; R(0x303) = '!';
  tgi_install(tgi_static_stddrv);
  tgi_init();
  CLI();
  while (tgi_busy()) ;
  tgi_clear();
  for (i = 0; i < 16; i++) {
    tgi_setcolor(i);
    tgi_bar(i * 10, 20, i * 10 + 9, 81);
  }
  tgi_setcolor(COLOR_WHITE);
  tgi_line(0, 0, 159, 0);
  tgi_line(159, 0, 159, 101);
  tgi_line(159, 101, 0, 101);
  tgi_line(0, 101, 0, 0);
  tgi_line(0, 0, 159, 101);
  tgi_updatedisplay();
  while (tgi_busy()) ;
  /* count frames by Timer 2's line count passing 50 */
  for (f = 0; f < 30; f++) {
    while (R(0xFD0A) != 50) ;
    while (R(0xFD0A) == 50) ;
    R(0x304) = f + 1;
  }
  R(0x305) = R(0xFCB2) & R(0xFCB3);
  for (i = 0; i < 255; i++) sum += p[i] + (uint16_t)i * p[i + 256];
  R(0x306) = (uint8_t)sum;
  R(0x307) = (uint8_t)(sum >> 8);
  R(0x30F) = 0x5A;
  for (;;) ;
}
