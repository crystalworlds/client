#!/usr/bin/env bash
# Builds the test cartridges of this zip into ./out with cc65 (2.19 was
# used) and python3. Set CC65_HOME to the cc65 folder first.
set -euo pipefail
cd "$(dirname "$0")"; export PATH="$CC65_HOME/bin:$PATH"
O=out; mkdir -p $O
(cd bll && make -s >/dev/null) && mv bll/bll.o $O/bll.o
# one EEPROM program, three files: the .lnx header's byte 60 names the chip
# (1 93C46, 3 93C66, 5 93C86; 16-bit words)
(cd eeprom && make -s >/dev/null)
for p in 46:1 66:3 86:5; do
  python3 - eeprom/eeprom${p%%:*}.lnx $O/eeprom${p%%:*}.lnx ${p##*:} <<'PY'
import sys
d = bytearray(open(sys.argv[1], "rb").read()); d[60] = int(sys.argv[3]); open(sys.argv[2], "wb").write(d)
PY
  mv eeprom/eeprom${p%%:*}.sym $O/; rm -f eeprom/eeprom${p%%:*}.lnx
done
for n in link cartram sprstop poweroff; do
  (cd $n && make -s >/dev/null) && mv $n/$n.lnx $n/$n.sym $O/
done
# two LNX2 files made from cartram.lnx: cartram8k.lnx, bank 1 8 KB of kept
# RAM in 32-byte pages, starting zero; cartramx.lnx, bank 1 64 KB of RAM
# (256-byte pages) whose starting contents the file holds, bank 1 of the
# second set 1 KB of kept RAM (64-byte pages) of which the file holds the
# first 100 bytes, and no bank 0 of the second set. Bank 0 is 16 pages of
# 1 KB in both.
python3 - $O <<'PY'
import sys
o = sys.argv[1]
d = open(o + "/cartram.lnx", "rb").read()
assert d[:4] == b"LYNX" and d[4] | (d[5] << 8) == 1024 and len(d) - 64 <= 16384
body = d[64:] + b"\xff" * (16384 - (len(d) - 64))
def lnx2(banks):
    h = bytearray(64)
    h[0:4] = b"LNX2"; h[4:8] = bytes(banks); h[8] = 1
    h[10:58] = d[10:58]
    return bytes(h)
open(o + "/cartram8k.lnx", "wb").write(lnx2([0xDE, 0, 0x79, 0]) + body + bytes(8192))
ram = bytes((i * 13 + 7) & 0xFF for i in range(65536))
kept = bytes(i ^ 0x3C for i in range(100))
open(o + "/cartramx.lnx", "wb").write(lnx2([0xDE, 0, 0xBC, 0x5A]) + body + ram + kept)
PY
echo "built: $(ls $O | tr '\n' ' ')"
