/* Cartridge RAM program (built by ../build.sh into
 * cartram.lnx, a .lnx file with no bank 1, and from it the LNX2
 * files cartram8k.lnx and cartramx.lnx, which declare RAM banks). It drives
 * the cartridge port the way a loader does (the page shifted in through
 * IODAT bit 1 and the strobe, SYSCTL1 bit 0; the counter advanced by each
 * access of RCART0 or RCART1), writes to the banks and reads them back, and
 * leaves what it read in g_results (256 bytes):
 *   0-3     bank 1 page 3, bytes 0-3, as found (FF with no RAM; the file's
 *           or the kept contents)
 *   4-43    bank 1 page 3 read back after writing 40 bytes there (a bank
 *           of 32-byte pages wraps at 32)
 *   44-59   bank 1 page FF after writing 16 bytes there
 *   60-75   bank 1 page 0 after writing 16 bytes there
 *   76-83   bank 1 page 3 again (what the writes to FF and 0 left)
 *   84-99   AUDIN high: bank 1 page 3 after writing 16 bytes there
 *   100-103 AUDIN high: bank 0 page 0, bytes 0-3
 *   104-119 AUDIN low again: bank 1 page 3
 *   120-123 bank 0 page 1 read back after writing 4 bytes there
 *   124     bank 1 page 7 byte 4 as found; it is then written one higher
 *           (a count of runs, when the RAM is kept)
 *   125     bank 1 page 7 byte 4 read back
 *   255     5A when done */
#include <lynx.h>
#include <stdint.h>

#define SYSCTL1 (*(volatile uint8_t *)0xFD87)
#define IODIR (*(volatile uint8_t *)0xFD8A)
#define IODAT (*(volatile uint8_t *)0xFD8B)
#define RCART0 (*(volatile uint8_t *)0xFCB2)
#define RCART1 (*(volatile uint8_t *)0xFCB3)

volatile uint8_t g_results[256];

static uint8_t aud;   /* 10 while AUDIN is driven high */

/* the page, most significant bit first: the data bit on IODAT bit 1, taken
 * at the rising strobe; the strobe low again leaves the counter at 0 */
static void page(uint8_t p) {
  uint8_t i;
  IODIR = 0x1A;
  for (i = 0; i < 8; i++) {
    IODAT = (uint8_t)(0x08 | aud | ((p & 0x80) ? 0x02 : 0));
    SYSCTL1 = 0x03;
    SYSCTL1 = 0x02;
    p <<= 1;
  }
  IODAT = (uint8_t)(0x0B | aud);
}

static uint8_t n;
static void read1(uint8_t count) { while (count--) g_results[n++] = RCART1; }

void main(void) {
  uint8_t i, v;
  aud = 0;
  page(3); read1(4);
  page(3); for (i = 0; i < 40; i++) RCART1 = (uint8_t)(i * 7 + 1);
  page(3); read1(40);
  page(0xFF); for (i = 0; i < 16; i++) RCART1 = (uint8_t)(0xA0 + i);
  page(0xFF); read1(16);
  page(0); for (i = 0; i < 16; i++) RCART1 = (uint8_t)(0x50 + i);
  page(0); read1(16);
  page(3); read1(8);
  aud = 0x10;
  page(3); for (i = 0; i < 16; i++) RCART1 = (uint8_t)(0xC0 + i);
  page(3); read1(16);
  page(0); for (i = 0; i < 4; i++) g_results[n++] = RCART0;
  aud = 0;
  page(3); read1(16);
  page(1); for (i = 0; i < 4; i++) RCART0 = (uint8_t)(0xE0 + i);
  page(1); for (i = 0; i < 4; i++) g_results[n++] = RCART0;
  page(7); for (i = 0; i < 4; i++) v = RCART1;
  v = RCART1;
  g_results[n++] = v;
  page(7); for (i = 0; i < 4; i++) RCART1 = (uint8_t)(0x4B + i);
  RCART1 = (uint8_t)(v + 1);
  page(7); for (i = 0; i < 4; i++) v = RCART1;
  g_results[n++] = RCART1;
  g_results[255] = 0x5A;
  for (;;) ;
}
