# Tools and flags for building these programs with cc65 (version 2.19 was
# used for the files in this zip). Put cc65's bin folder on PATH and set
# CC65_HOME to the cc65 folder.
SYS=lynx
CC=cc65
AS=ca65
CL=cl65
RM=rm
SEGMENTS=--code-name CODE --rodata-name RODATA --bss-name BSS --data-name DATA
CFLAGS=-g -I . -t $(SYS) -O -Or -Cl -Os
AFLAGS=-g
