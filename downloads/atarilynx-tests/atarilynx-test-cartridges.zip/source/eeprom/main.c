/* Cartridge EEPROM program (built by ../build.sh into
 * eeprom46.lnx, eeprom66.lnx and eeprom86.lnx, the .lnx header's
 * byte 60 naming a 93C46, 93C66 or 93C86 in 16-bit organisation). Drives
 * the chip with cc65's EEPROM routines (the BLL kit's author's, the way
 * homebrew does) and leaves results in g_results:
 *   0-1   word 0 as found (FFFF on a fresh chip; what the host kept, else)
 *   2-17  words 0-7 read back after writing them
 *   18-19 the last word read back after writing it
 *   20-21 word 3 after erasing it (93C46 only: cc65 has no erase for the
 *         others; they write FFFF)
 *   22    5A when done */
#include <lynx.h>
#include <stdint.h>

#if PART == 46
unsigned __fastcall__ lynx_eeread_93c46(unsigned char cell);
void __fastcall__ lynx_eewrite_93c46(unsigned addr, unsigned val);
#define RD(a) lynx_eeread_93c46((unsigned char)(a))
#define WR(a, v) lynx_eewrite_93c46((a), (v))
#define LAST 63
#elif PART == 66
unsigned __fastcall__ lynx_eeread_93c66(unsigned addr);
void __fastcall__ lynx_eewrite_93c66(unsigned addr, unsigned val);
#define RD(a) lynx_eeread_93c66(a)
#define WR(a, v) lynx_eewrite_93c66((a), (v))
#define LAST 255
#else
unsigned __fastcall__ lynx_eeread_93c86(unsigned addr);
void __fastcall__ lynx_eewrite_93c86(unsigned addr, unsigned val);
#define RD(a) lynx_eeread_93c86(a)
#define WR(a, v) lynx_eewrite_93c86((a), (v))
#define LAST 1023
#endif

volatile uint8_t g_results[24];

static void put(uint8_t i, unsigned v) { g_results[i] = (uint8_t)v; g_results[i + 1] = (uint8_t)(v >> 8); }

void main(void) {
  uint8_t i;
  unsigned v;
  put(0, RD(0));
  for (i = 0; i < 8; i++) WR(i, 0x1234 + i * 0x1111u);
  for (i = 0; i < 8; i++) put(2 + 2 * i, RD(i));
  WR(LAST, 0xA55A);
  put(18, RD(LAST));
#if PART == 46
  lynx_eeprom_erase(3);
#else
  WR(3, 0xFFFF);
#endif
  v = RD(3);
  put(20, v);
  g_results[22] = 0x5A;
  for (;;) ;
}
