/* ComLynx link program (built by ../build.sh into
 * link.lnx). Two consoles run it on one cable; the one whose A
 * button is held at the start is the master, the other the slave.
 *
 *  1. The master sends sixteen bytes (17 n + 3), each after the echo of the
 *     one before (every console hears its own frames on the shared wire);
 *     the slave collects them.
 *  2. The slave answers with each byte inverted, the same way; the master
 *     collects the answers.
 * 62500 baud (Timer 4 backup 1), parity even, TXOPEN set (driving the
 * cable). Results in g_results:
 *   0      role: 1 master, 0 slave
 *   1      bytes collected from the other console (16)
 *   2      SERCTL error bits (PARERR, OVERRUN, FRAMERR) seen while collecting
 *   3-18   the bytes collected
 *   19     own echoes that did not come back (0)
 *   20     5A when done */
#include <stdint.h>

#define R(a) (*(volatile uint8_t *)(a))
#define SERCTL R(0xFD8C)
#define SERDAT R(0xFD8D)
#define TIM2CNT R(0xFD0A)
#define JOYSTICK R(0xFCB0)
#define WAIT 60000u

volatile uint8_t g_results[24];

static void wait_frames(uint8_t n) {
  while (n--) {
    while (TIM2CNT != 50) ;
    while (TIM2CNT == 50) ;
  }
}

/* a byte from the wire, or -1 after a while (about half a second a round) */
static int receive_long(uint8_t rounds) {
  uint16_t i;
  uint8_t s;
  while (rounds--)
    for (i = 0; i < WAIT; i++) {
      s = SERCTL;
      if (s & 0x40) {
        g_results[2] |= s & 0x1C;
        return SERDAT;
      }
    }
  return -1;
}
#define receive() receive_long(1)

static void send(uint8_t v) {
  while (!(SERCTL & 0x80)) ;
  SERDAT = v;
  if (receive() != v) g_results[19]++;   /* its own echo */
}

static void collect(void) {
  uint8_t n;
  int v;
  for (n = 0; n < 16; n++) {
    v = receive_long(n ? 1 : 8);   /* the first may be a while coming */
    if (v < 0) break;
    g_results[3 + n] = (uint8_t)v;
  }
  g_results[1] = n;
}

void main(void) {
  uint8_t n, master = (JOYSTICK & 0x01) ? 1 : 0;
  g_results[0] = master;
  R(0xFD10) = 1;                 /* Timer 4: backup 1, 1 us, reload, count */
  R(0xFD12) = 1;
  R(0xFD11) = 0x18;
  SERCTL = 0x1D;                 /* parity on, even, reset errors, TXOPEN */
  SERCTL = 0x15;
  while (SERCTL & 0x40) (void)SERDAT;
  if (master) {
    wait_frames(60);             /* the slave, switched on later, is listening by then */
    for (n = 0; n < 16; n++) send((uint8_t)(17 * n + 3));
    collect();
  } else {
    collect();
    wait_frames(2);
    for (n = 0; n < 16; n++) send((uint8_t)~g_results[3 + n]);
  }
  g_results[20] = 0x5A;
  for (;;) ;
}
