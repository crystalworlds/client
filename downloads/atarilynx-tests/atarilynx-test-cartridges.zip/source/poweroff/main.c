/* Power-off program (built by ../build.sh into
 * poweroff.lnx). Draws a white screen, sounds a tone on channel
 * 0, counts 20 frames (Timer 2 passing line 0), then writes SYSCTL1 with
 * bit 1 clear, which switches the console off (Atari's description of the
 * register: the bit holds the power on). Nothing after that write may run.
 * g_results: 0 the frames counted when the power went, 1 11 written just
 * before, 2 22 written just after (must stay 00), 3 the frames counted by
 * a loop that runs after the write (must stay 00); 31 5A written before
 * the write. The picture goes dark and the sound silent. */
#include <lynx.h>
#include <6502.h>
#include <stdint.h>
#include <string.h>

#define REG(a) (*(volatile uint8_t *)(a))
#define VIDEO 0x6000u

volatile uint8_t g_results[32];

static void wait_frame(void) {
  while (REG(0xFD0A) == 102) ;
  while (REG(0xFD0A) != 102) ;
}

void main(void) {
  uint8_t i;
  SEI();
  memset((void *)VIDEO, 0x11, 0x1FE0);       /* pen 1 everywhere */
  REG(0xFDA1) = 0x0F; REG(0xFDB1) = 0xFF;     /* pen 1 white */
  REG(0xFD94) = (uint8_t)VIDEO; REG(0xFD95) = (uint8_t)(VIDEO >> 8);
  /* a square wave on channel 0: volume 60, feedback bit 0, 1 us clock */
  REG(0xFD20) = 60; REG(0xFD21) = 0x01; REG(0xFD23) = 0x01;
  REG(0xFD24) = 40; REG(0xFD26) = 40;
  REG(0xFD25) = 0x18;
  REG(0xFD50) = 0x00;
  for (i = 0; i < 20; i++) { wait_frame(); g_results[0] = (uint8_t)(i + 1); }
  g_results[31] = 0x5A;
  g_results[1] = 0x11;
  REG(0xFD87) = 0x00;                         /* power off */
  g_results[2] = 0x22;
  for (;;) { wait_frame(); g_results[3]++; }
}
