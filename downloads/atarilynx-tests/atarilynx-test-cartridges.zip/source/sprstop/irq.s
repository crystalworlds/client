; The stop program's interrupt handler (sprstop): asks
; Suzy to stop at the end of the current sprite (SPRSYS bit 1), clears the
; interrupts, stops Timer 1 and counts itself.
        .setcpu "65C02"
        .export _stop_irq, _irq_count
        .segment "BSS"
_irq_count: .res 1
        .segment "CODE"
_stop_irq:
        pha
        lda #$02
        sta $FC92       ; SPRSYS: stop at the end of the current sprite
        stz $FD05       ; TIM1CTLA: no interrupt, not counting
        lda #$FF
        sta $FD80       ; INTRST: every interrupt cleared
        inc _irq_count
        pla
        rti
