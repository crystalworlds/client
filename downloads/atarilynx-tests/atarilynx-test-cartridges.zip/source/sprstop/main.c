/* Sprite stop program (built by ../build.sh into
 * sprstop.lnx). SPRSYS bit 1 asks Suzy to stop at the end of the
 * sprite it is drawing; a SPRGO write withdraws the request. A list of
 * three sprites: A covers the screen with colour 1 and takes about 2.5 ms;
 * B (colour 2) and C (colour 3) are small, drawn over A. The list is drawn
 * four times:
 *   0 as it is: A, B and C drawn;
 *   1 the stop asked right after SPRGO, before the CPU sleeps: A only;
 *   2 the stop asked by a Timer 1 interrupt about 200 us into A (the CPU
 *     woken from its sleep, which it then resumes): A only;
 *   3 the stop asked before SPRGO: withdrawn by it, A, B and C drawn.
 * g_results, 4 bytes a case: the screen byte under B, under C, at the top
 * left (under A only), and SPRSYS bits 1-0 after the list; then byte 16
 * the interrupts taken, 17 SPRSYS bits 1-0 just after SPRGO in case 3;
 * 31 5A when done. */
#include <lynx.h>
#include <6502.h>
#include <stdint.h>
#include <string.h>

#define REG(a) (*(volatile uint8_t *)(a))
#define VIDEO 0x6000u

extern void stop_irq(void);
extern uint8_t irq_count;
volatile uint8_t g_results[32];

static uint8_t scb[3][24];
static uint8_t dataA[23];
static const uint8_t dataB[3] = { 0x02, 0xFF, 0x00 };

static void setscb(uint8_t i, const uint8_t *data, uint16_t next, uint16_t x, uint16_t y, uint16_t vsize, uint8_t pal) {
  uint8_t *s = scb[i];
  memset(s, 0, 24);
  s[0] = 0x01;                 /* 1 bit a pen, background, no collision */
  s[1] = 0x90;                 /* literal; sizes reloaded; palette reloaded */
  s[3] = (uint8_t)next; s[4] = (uint8_t)(next >> 8);
  s[5] = (uint8_t)(uint16_t)data; s[6] = (uint8_t)((uint16_t)data >> 8);
  s[7] = (uint8_t)x; s[8] = (uint8_t)(x >> 8);
  s[9] = (uint8_t)y; s[10] = (uint8_t)(y >> 8);
  s[11] = 0x00; s[12] = 0x01;  /* width scale 1 */
  s[13] = (uint8_t)vsize; s[14] = (uint8_t)(vsize >> 8);
  s[15] = pal;                 /* pen 1 is colour `pal` */
}

static void draw(uint8_t mode) {
  uint8_t *r = (uint8_t *)&g_results[mode * 4];
  memset((void *)VIDEO, 0, 0x1FE0);
  REG(0xFC10) = (uint8_t)(uint16_t)scb[0]; REG(0xFC11) = (uint8_t)((uint16_t)scb[0] >> 8);
  if (mode == 3) REG(0xFC92) = 0x02;
  if (mode == 2) {
    REG(0xFD04) = 200; REG(0xFD06) = 200; REG(0xFD07) = 0;
    REG(0xFD05) = 0x88;        /* interrupt, counting, 1 us; no reload */
    CLI();
  }
  REG(0xFC91) = 0x01;          /* SPRGO */
  if (mode == 3) g_results[17] = REG(0xFC92) & 0x03;
  if (mode == 1) REG(0xFC92) = 0x02;
  REG(0xFD90) = 0;
  do { REG(0xFD91) = 0; } while (REG(0xFC92) & 0x01);
  REG(0xFD90) = 0;
  SEI();
  r[0] = *(volatile uint8_t *)(VIDEO + 20 * 80 + 5);
  r[1] = *(volatile uint8_t *)(VIDEO + 20 * 80 + 20);
  r[2] = *(volatile uint8_t *)VIDEO;
  r[3] = REG(0xFC92) & 0x03;
}

void main(void) {
  uint8_t i;
  SEI();
  *(volatile uint16_t *)0xFFFE = (uint16_t)stop_irq;
  dataA[0] = 0x16;
  for (i = 1; i < 22; i++) dataA[i] = 0xFF;
  dataA[22] = 0;
  setscb(0, dataA, (uint16_t)scb[1], 0, 0, 0x6600, 0x01);
  setscb(1, dataB, (uint16_t)scb[2], 10, 20, 0x0800, 0x02);
  setscb(2, dataB, 0, 40, 20, 0x0800, 0x03);
  /* Suzy as the hardware tests set it up */
  REG(0xFC04) = 0; REG(0xFC05) = 0; REG(0xFC06) = 0; REG(0xFC07) = 0;
  REG(0xFC08) = (uint8_t)VIDEO; REG(0xFC09) = (uint8_t)(VIDEO >> 8);
  REG(0xFC0A) = 0x00; REG(0xFC0B) = 0x80;
  REG(0xFC24) = 23; REG(0xFC25) = 0;
  REG(0xFC28) = 0; REG(0xFC29) = 0; REG(0xFC2A) = 0; REG(0xFC2B) = 0;
  REG(0xFC83) = 0xF3;
  REG(0xFC90) = 0x01;
  REG(0xFC92) = 0x00;
  for (i = 0; i < 4; i++) draw(i);
  g_results[16] = irq_count;
  g_results[31] = 0x5A;
  for (;;) ;
}
