# Licences

What a published probe cartridge carries, part by part.

| Part | Where it is from | Licence | Commit |
|---|---|---|---|
| libdragon's open boot code (IPL3), compat build (`boot/bin/ipl3_compat.z64`, the first 4,096 bytes of every test file, unchanged but for three header fields), SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188 | github.com/DragonMinded/libdragon | the Unlicense, as its repository states it (https://unlicense.org) | 39d0d6096130836a65710da6730290701d060272 |
| libdragon's library | not linked: no probe links any of it | (not carried) | |
| the compiler's helper library, libgcc | named on the link line (`-lgcc`); no routine of it is in any of the 49 linked probes (their symbol tables read with the compiler's `nm`), so none is carried | GCC states it as GPL-3.0 with the GCC Runtime Library Exception 3.1 (not checked against a file here) | mips64-elf-gcc.exe (GCC) 16.2.0 |
| this project's own code: every file under `source/`, the test files' own program, the READMEs and the expected answers | CrystalWorlds.Media | MIT (see `LICENSE`) | |
