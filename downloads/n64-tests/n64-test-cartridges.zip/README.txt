Nintendo 64 test cartridges, from the CrystalWorlds.Media project
=================================================================

We wrote these 49 test cartridges for the Nintendo 64 to ask a real console
what the public test suites leave out. Each asks one question about the
console (its processor, the RSP, the drawing unit, the audio, video,
serial and parallel interfaces, the memory chips, save memory and the
Controller Pak) and prints its answer as lines of text. The scores on the
site's home page come from the public suites; these cover ground between
them.

How to read the result: none of them shows a verdict on the screen. Each
hands its lines to the debug text window (a ring of bytes marked IS64, at
cartridge address 13FF0000 unless its source places it elsewhere), which a
flash cartridge such as the SummerCart64 passes to the computer beside the
console and which emulators such as ares print. Compare its lines with the
console's lines in the test's expected-answers.json.

What the real console shows: the answers are from PAL consoles only, two
PAL consoles (NUS-001) called c1 and c2 in the answers. A run is named by
its console and its number: c1-88 is console one's 88th run. No NTSC
console has been run yet, so on an NTSC console the lines that depend on
the television type will differ. 41 of the 49 have answers from a console;
ai-level, current, frames, pad-film, rsp-behind, rsp-blocks, span-modes and
wait-loop have none yet.

Before running any of them on a console, read its README.md. In short:

  Can hang the console (switch it off by hand if it stops):
    armed-fetch, armed-fill, load-4, load-4-block, load-4-palette
    (the three load-4 tests always stop the drawing unit on a console)
  Write to save memory or a Controller Pak (use a save you do not need):
    si-save    every block of the save chip, the first 32 bytes of a
               Controller Pak in controller 1, and the whole pak if Z is
               held when it starts: take your Controller Paks out first
    save       erases and overwrites all of the save memory
    save-trace overwrites the save memory
    pi         overwrites the first 4 KiB of the save memory
    pi-odd     overwrites the first 8 KiB of the save memory
    si-pak     can send one write to a pak (32 zero bytes at pak address
               8000, outside a Controller Pak's memory, only when the
               controller has just answered that no pak is in)
  Has never been run on a console: current (it drives a memory chip at
    current settings a boot code never leaves it at; if you run it, switch
    the console off as soon as it ends)
  For emulators only, not for a console: span-modes, wait-loop, frames
  Loud: ai-tone and ai-level (turn the television's sound down)
  A test of the flash cartridge, not the console: window-state

Files
-----
PROBES.md      every test in one table, with what it asks
<test>/        one folder for each test: the test file <test>-probe.z64,
               README.md (what it asks, how its lines read, how to build
               and run it, what to take care of) and expected-answers.json
               (every console run, with its lines)
source/        the C and assembly source of all 49, with build.sh and
               pack.py
LICENCES.md    what each test file is made of, and the licence of each part

How to run them on a console: copy a .z64 file to a flash cartridge,
switch the console off for about two seconds and on, and listen at the
cartridge's debug text window.

Source
------
build.sh builds each test file from the source with the MIPS compiler
mips64-elf-gcc (the files here were built with GCC 16.2.0) and libdragon's
open boot code (set IPL3 to boot/bin/ipl3_compat.z64 from libdragon at
commit 39d0d6096130836a65710da6730290701d060272), which gives the 49 files
here byte for byte.

Licence: this zip is MIT-licensed (see LICENSE), unlike the rest of the
site. The first 4,096 bytes of every test file are libdragon's open boot
code, under its own licence, the Unlicense (see LICENCES.md).
