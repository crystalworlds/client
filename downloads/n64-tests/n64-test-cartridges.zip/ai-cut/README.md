# The ai-cut probe (AI CUT PROBE)

## What it tests

In the words of its source:

> The AI cut probe: a small test cartridge for a real console.
> 
> A console empties a playing transfer the moment the AI's bit rate is written zero. This probe
> asks what goes with that: whether the cut raises the AI's interrupt, what becomes of a second
> transfer waiting behind the first, whether anything comes back when the bit rate is set again,
> and what the AI's output side still holds after a cut, as far as a register can show it: a
> transfer written afterwards can fetch at once only if the place ahead of the playing one is
> free. Each answer is a line of text through the debug text window a flash cartridge shows on
> the computer beside the console.
> 
> Every case starts from rest, with the sample clock at 1103 (the setting the AI probe uses) and
> the interrupt taken back; a transfer plays silence from memory the probe clears.
> 
> Lines (every value in hex; times are steps of COUNT, which may differ a little from run to run):
>   U1  len status intr  len status intr     0x800 playing for 20 sample periods, the interrupt
>                                            taken back, the bit rate written zero: the length,
>                                            the status (busy, full, enabled and the fixed bits)
>                                            and the MI's AI interrupt bit, at once and 40 periods on
>   U2  the same                             0x800 and 0x800 written, so that one waits (full)
>   U3  len status steps ok                  U1, then the bit rate back, then 0x100 written at once:
>                                            its length and status straight after, and the time
>                                            until busy clears (ok 1 if it did within half a second)
>   U4  len0 len20 len40 status              U1 with the bit rate written 1, not zero: the length at
>                                            once, 20 and 40 periods on
>   U5  len status intr  len status          the bit rate zero while at rest, 0x800 written, the bit
>                                            rate back after 5 periods: at once, and 20 periods on
>   U6  before during after later status     0x800 playing, the bit rate zero for one read of the
>                                            length, then back at once: the lengths read before,
>                                            between, straight after and 20 periods on
>   X1  intr status intr intr intr           U2 with the MI's bit read at each step: after the
>                                            take-back and before the cut (with the status then),
>                                            straight after the cut, after a second take-back, and
>                                            40 periods on
>   V1 to V9  len status steps ok            U3 with the bit rate held at zero for a while, or with
>                                            a wait between the bit rate's return and the length:
>                                            zero for 40 periods (V1); a wait of 40, 1, 2, 3 and 5
>                                            periods (V2 to V6); zero for 1, 2 and 4 periods (V7 to V9)
>   R1 to R3  len status steps ok            the same length written at rest, with no cut: as it
>                                            stands (R1), after the bit rate went to zero and came
>                                            straight back (R2), and after 40 periods at zero (R3)
>   C1, C2  zero s1 s2 s3                    the sample clock's counter in the status (with its
>                                            word clock and bit clock) while the bit rate is zero
>                                            at rest, and at three reads straight after it is set
>                                            again; C2 sets it 300 steps later than C1 does
>   C3  before zero s1 s2                    the same about a cut: just before it, at zero, and at
>                                            two reads after the bit rate is back
>   X2  len intr intr intr                   U2 with the MI's bit read at the second and at the
>                                            third access after the cut and no take-back between
>                                            (the first access reads the length), and 40 periods on:
>                                            does the interrupt come before the place where X1's
>                                            second take-back stands, or after it
>   D0 to D7  before zero l1 l2 l3 steps ok  at rest, the bit rate to zero and straight back at
>                                            eight places of a sample period, then 0x100: the clocks
>                                            just before zero and at zero, the length at three reads
>                                            straight after the write, and the time until busy
>                                            clears. Where does the first sample boundary lie after
>                                            the return, the word clock having stood high or low?
>   Bf Be B7 B3 B1  zero steps ok            the same start with the bit rate set to 15, 14, 7, 3 and
>                                            1 at the return: does the bit clock pace the fetches?
>   E1 E2 E3 E5  s0 s1 s2                    which write starts the counter anew: the clocks before
>                                            a write and at two reads straight after it. E1 the bit
>                                            rate written as it stands, E2 the bit rate one less,
>                                            E3 the DAC rate as it stands, E5 a length at rest
>   E4  s0 to s11                            the DAC rate written twice as long, and the clocks at
>                                            eleven looks through the sample period that follows:
>                                            at which turn of the word clock does it take hold
>   F0 to F7  where l1 l2 l3 l4              the first two fetches of a transfer from rest: the
>                                            clocks just before the write, then the length at four
>                                            reads, the first of them 0, 2, 4 up to 14 turns of a
>                                            short idle loop after the write
>   W0 to Wf  len before steps ok            a cut at sixteen places of the two sample periods a
>                                            doubleword plays for, the bit rate straight back, then
>                                            0x100: the length and the clocks just before the cut,
>                                            and the time until busy clears
> Each line three times.
> 
> The sample clock runs from the video clock, so the times are a PAL console's when read from one.
> 
> Care for the console: everything here is ordinary. The sound output plays silence; its bit rate
> is set to zero and back as the AI register probe has done on two consoles.

## Ground no public suite covers

What the AI does when its bit rate is written zero while a transfer plays: length, status and interrupt at once and later, with one and two transfers queued, the rate restored, a rate of one, transfers after a cut, and the sample counter about the rate's return; each case three times. N64-AI-Test and n64-systemtest test AI registers in ordinary use; neither, to this reading, writes the rate to zero mid-transfer.

## How it gives its answer

Debug text window; figures only. Plays only silence.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out ai-cut` builds it into `out/`. By hand: compile the files under `source/probes/ai-cut/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `ai-cut-probe.z64`, 16384 bytes, SHA-256 32d5a0e2861c75b248a25c6566d70f227a68b452d969f1cd06192dc9c48c5f11.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-83 (c1, 2026-11-18T23:37:47): 20 lines; the program was another build, b4a90fcf2fc980fa.
- c1-94 (c1, 2026-11-19T20:03:02): 68 lines; the program was another build, 3b92debf104ec801.
- c1-99 (c1, 2026-11-19T20:38:50): 68 lines; the program was another build, 3b92debf104ec801.
- c1-103 (c1, 2026-11-19T21:19:23): 71 lines; the program was another build, 5353e1ab4585cbda.
- c1-111 (c1, 2026-11-20T09:00:58): 197 lines; the program is this set's build.
- c1-116 (c1, 2026-11-20T10:01:17): 197 lines; the program is this set's build.
- c2-50 (c2, 2026-11-21T09:10:13): 197 lines; the program is this set's build.
- Both consoles ran build 32d5a0e2861c75b2: c1-116 and c2-50 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
