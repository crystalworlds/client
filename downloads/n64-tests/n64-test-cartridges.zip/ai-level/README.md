# The ai-level probe (AI LEVEL PROBE)

## What it tests

In the words of its source:

> The level probe: a small test cartridge for a sound recorder on a real console's sound output.
> 
> It plays four short sounds with half a second of nothing after each: a held level, half way up;
> the same level again; the same level the other way; and a square wave of 44 frames to the cycle
> at that level. Each lasts 4,096 frames with the DAC rate setting at 1103 (93 ms on an NTSC
> console). What a recording shows between and after them says what the DAC is fed while the AI
> has nothing to play, which no register shows. If it goes back to nothing, each held level has a
> step at both its ends. If it keeps the last level, the first has no step at its end and the
> second, being the same level, shows nothing at all. The square wave gives the height of a known
> swing to measure the rest against.
> 
> It prints when each sound started and how long the AI stayed busy with it, in steps of the CPU's
> Count register (46.875 MHz), through the debug text window, and never waits for ever. The four
> lines are printed after the last sound: no time printed here has a text inside it, and nothing
> is handed to the cartridge while a recording of the sounds and the silences is being made.

## Ground no public suite covers

Four short sounds with half a second of nothing after each, for a sound recorder: what the DAC is fed when the AI has nothing to play, which no register shows. No public suite listed here reads the DAC's idle level.

## How it gives its answer

The answer is the recording itself; the debug text window gives when each sound started and how long the AI stayed busy. Nothing judged.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out ai-level` builds it into `out/`. By hand: compile the files under `source/probes/ai-level/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `ai-level-probe.z64`, 8192 bytes, SHA-256 fed918839b4f2ccdf4ba6176dc1a95b10ea8664d2af21f5edc8268fdf046f804.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Turn the television's sound down before starting it: it plays four short sounds, each followed by half a second of nothing. It writes nothing to a save chip or a Controller Pak. It has not been run on a console yet.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

No console run of this probe yet.
