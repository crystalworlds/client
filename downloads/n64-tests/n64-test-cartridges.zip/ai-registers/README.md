# The ai-registers probe (AI REGISTER PROBE)

## What it tests

In the words of its source:

> The AI register probe: a small test cartridge for a real console.
> 
> It programs the sound output in a dozen ways and prints what it reads back, as text, through
> the debug text window a flash cartridge shows on the computer beside the console. Every
> experiment asks one question the sources do not agree on, or that nobody has written down:
> when the interrupt comes, what the length reads while a transfer plays, what a length written
> at an odd moment does, and how long a sample period really is. It plays only silence.
> 
> Run here, the same lines show what this core does; the two logs are then compared token by
> token. A plain token must be the same on a console. A token that starts with ~ is a time in
> steps of the CPU's Count register (46.875 MHz) or a count that depends on one, and need only be
> close. A token that starts with ? depends on the moment the question was asked, or is a fact
> about the console that this core does not claim to know: it is recorded, not compared.
> 
> Nothing here waits for ever: every wait gives up after half a second and says so.

## Ground no public suite covers

The AI's registers: when its interrupt comes, what the length reads during play, what a length written at an odd moment does, the true sample period. N64-AI-Test covers some AI register behaviour; the odd-moment writes and the measured period are, to this reading, not covered.

## How it gives its answer

Debug text window; figures only. Plays silence.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out ai-registers` builds it into `out/`. By hand: compile the files under `source/probes/ai-registers/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `ai-registers-probe.z64`, 16384 bytes, SHA-256 7a09b92585c04a56bb84f5d15584854e7398b0e9ccb0b9a55c8af5db8f4b0eba.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-24 (c1, 2026-11-14T10:57:37): 32 lines; the program was another build, 3b5f431c68aa5e9d.
- c1-28 (c1, 2026-11-14T20:29:53): 43 lines; the program was another build, fb75b03d58a2f668.
- c1-59 (c1, 2026-11-18T16:43:07): 46 lines; the program is this set's build.
- c1-151 (c1, 2026-11-22T02:22:25): 46 lines; the program is this set's build.
- c1-152 (c1, 2026-11-22T02:22:59): 46 lines; the program is this set's build.
- c1-153 (c1, 2026-11-22T02:23:32): 46 lines; the program is this set's build.
- c1-154 (c1, 2026-11-22T02:24:05): 46 lines; the program is this set's build.
