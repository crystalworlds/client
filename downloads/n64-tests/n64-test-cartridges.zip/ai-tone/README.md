# The ai-tone probe (AI TONE PROBE)

## What it tests

In the words of its source:

> The tone probe: a small test cartridge that plays a known sound.
> 
> It plays 65,536 frames with the DAC rate setting at 1103: a square wave of 100 frames to the
> cycle on the left, one of 200 frames on the right, a quarter of full level. On an NTSC console
> that is 1.486 seconds at 440.96 Hz and 220.48 Hz; on a PAL console the same setting plays faster,
> 1.457 seconds at 449.79 Hz and 224.89 Hz, because the video crystal differs. So the pitch and the
> length of what comes out, counted, say which clock timed it and what the sample period was.
> 
> The sound goes out as sixteen transfers of 4,096 frames from two buffers in turn, each queued
> behind the one playing so that there is never a gap. Each buffer's second half is cleared before
> it is queued and written afterwards: a machine that reads a transfer from memory when it is
> queued, and not as it plays, plays silence there.
> 
> It also times the whole sound with the CPU's own Count register (46.875 MHz), from the first
> length written to busy falling after the last, and prints that: the sample rate read from a
> clock that is not the AI's.
> 
> It prints what it did as text, through the debug text window, and never waits for ever.

## Ground no public suite covers

A second and a half of square waves (near 450 Hz left, an octave lower right on PAL) and one line of how long it took by the CPU clock, so pitch and length show which clock timed the AI. N64-AI-Test plays sound; to this reading none ties a known tone to the CPU clock on a PAL console.

## How it gives its answer

Sound out, and one line on the debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out ai-tone` builds it into `out/`. By hand: compile the files under `source/probes/ai-tone/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `ai-tone-probe.z64`, 8192 bytes, SHA-256 410dac2729b6188cd66fdea4ab8d5bd1f3fc8166bb273b2ad6497098c70ef0ef.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Loud:** turn the television's sound down before starting it. It plays a second and a half of square waves at a quarter of full level. It writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-25 (c1, 2026-11-14T10:58:15): 3 lines; the program is this set's build.
- c2-09 (c2, 2026-11-14T11:13:21): 3 lines; the program is this set's build.
- Both consoles ran build 410dac2729b6188c: c1-25 and c2-09 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
