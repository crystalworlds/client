# The armed-fetch probe (ARMED FETCH PROBE)

**Warning: this test can hang a console.** It runs a line of instructions fetched from main memory with the memory interface's repeat mode armed, and the hardware notes say a read in that mode may hang a console. A PAL console ran every case without a hang. If it stops, switch the console off, wait a few seconds before switching it on again, and keep the text it printed: the G line before each case tells which case it stopped in.

## What it tests

In the words of its source:

> The armed fetch probe: a small test cartridge for a real console.
> 
> On two consoles the hidden bits probe's line for the MI's repeat mode arrived without its first
> letter, in every run (runs c1-12, c1-13, c2-05). A probe that asked what a load gives straight
> after a store in that mode found nothing wrong (run c1-27). But in the hidden bits probe the
> store was the first instruction of a line of the instruction cache, with the write that arms
> the mode in the line before: so the CPU fetched the store's own line from main memory with the
> mode armed, which the other probe, whose instructions lay in one line, never did. And the log
> is just what the hidden bits probe prints if the one instruction behind the store, the load of
> its line's length, did not load.
> 
> This probe makes that fetch on purpose and says what the CPU was given. Each case writes a
> word to the MI's mode register in one line of the instruction cache and stores into main memory
> with the first instruction of the next; the rest of that line is seven instructions that each
> leave a mark of their own (start.S). All values are in hex.
> 
>   G n          said before case n is run, so that a case that never comes back is known
>   F n m v a b c
>                case n: m the word written to the mode register (0080 takes the repeat mode
>                off, 010f arms it for 16 bytes, 0103 for 4, 011f for 32); v what the line's
>                instructions left (00ff as written for cases 0 to 5, 05fe for cases 6 to 8,
>                whose instruction behind the store is a load of a word that holds 5); a, b, c
>                the first, fourth and fifth word at the place stored to, which held eeee0000
>                to eeee0004: was the store repeated, and how far
> 
>   cases 0 and 6: the mode not armed, the line fetched from memory (the control)
>   cases 1, 5 and 7: armed for 16 bytes, the line fetched from memory with the mode armed
>   cases 2 and 8: armed for 16 bytes, the line put into the instruction cache beforehand
>   cases 3 and 4: armed for 4 and for 32 bytes, the line fetched from memory
> 
> No line depends on the console's television type.
> 
> Care for the console: the repeat mode is the one a common library uses to clear memory, armed
> for one store at a time in a part of memory nothing else uses, and taken off again after each
> case. If a fetch with the mode armed gives the CPU other words than the line holds, they are
> words of that same line: a store, a load and additions.

## Ground no public suite covers

Nine cases that fetch, or do not fetch, a line of instructions from main memory with the MI's repeat mode armed, each saying which instructions the CPU ran. This is what the hidden-bits probe did by accident on both consoles. No listed suite tests instruction fetch in repeat mode.

## How it gives its answer

Debug text window; a line starting G is said before each case so a hang is known; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out armed-fetch` builds it into `out/`. By hand: compile the files under `source/probes/armed-fetch/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `armed-fetch-probe.z64`, 8192 bytes, SHA-256 ffaab3fb4a4b83ffdab119bae2d4919147c1df66a089d929cf99512f702491b2.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test can hang a console.** It runs a line of instructions fetched from main memory with the memory interface's repeat mode armed, and the hardware notes say a read in that mode may hang a console. A PAL console ran every case without a hang. If it stops, switch the console off, wait a few seconds before switching it on again, and keep the text it printed: the G line before each case tells which case it stopped in.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-65 (c1, 2026-11-18T16:58:47): 20 lines; the program is this set's build.
