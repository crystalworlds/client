# The armed-fill probe (ARMED FILL PROBE)

**Warning: this test can hang a console.** It fills the caches from main memory with the memory interface's repeat mode armed, and the hardware notes say a read in that mode may hang a console. A PAL console ran every case without a hang, twice. If it stops, switch the console off, wait a few seconds before switching it on again, and keep the text it printed: the G line before each case tells which case it stopped in.

## What it tests

In the words of its source:

> The armed fill probe: a small test cartridge for a real console.
> 
> The armed fetch probe found on a console that a line of instructions fetched while the MI's
> repeat mode is armed comes to the CPU changed, in a way the sums of its instructions cannot name.
> This probe reads the words the caches were given instead of running them: a line of data whose
> every byte holds its own offset (0x00 to 0x1F) is filled into the instruction cache with the mode
> armed, the mode is cleared, and the cache writes the line back to memory (Hit_Write_Back), where
> an uncached read shows it word for word. The same is asked of the data cache with a load.
> 
> Lines (G n is said before each case, so that a case that never comes back is known by its number):
>   C p  w0 .. w7        the control of the instrument, with the mode never armed: the line filled
>                        into the instruction cache, memory then written ccccccc0 to ccccccc7 without
>                        the cache, the line written back: the cache's words must come back
>   A m p v  w0 .. w7    the instruction cache's line: m the mode written (80 the control, which
>                        arms nothing; 03, 07, 0f, 17, 1f the repeat mode with a count of 4, 8, 16,
>                        24 and 32 bytes), p the line's place in its block (00, 20, 60), v what the
>                        MI carried last before the fill: 0 the uncached writes that laid the line,
>                        1 uncached reads of eight words bbbb0000 to bbbb0007, 2 an uncached 64-bit
>                        write of 1111222233334444 elsewhere
>   D m  w0 .. w3        the data cache's 16-byte line, read with a load (the 16 bytes after it laid
>                        the same way, offsets 0x10 to 0x1F)
> The hardware notes say a read in this mode may hang a console ("further testing needed"); the
> console may then need switching off by hand. A PAL console ran every case without a hang.
> 
> Care for the console: register writes a game makes to the MI's mode register, uncached reads and
> writes of main memory, and the CPU's own cache operations; but a read of memory with the repeat
> mode armed is not ordinary, and is what this probe is for.

## Ground no public suite covers

Which words a cache fill gets from main memory with the repeat mode armed, for the instruction and data caches at each count, with a control. Not in any listed suite.

## How it gives its answer

Debug text window, a G line before each case; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out armed-fill` builds it into `out/`. By hand: compile the files under `source/probes/armed-fill/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `armed-fill-probe.z64`, 8192 bytes, SHA-256 d81c661e8f046e60732dabaa0e3507b9d789089b2d52ba5679c3535c0d1cb2f5.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test can hang a console.** It fills the caches from main memory with the memory interface's repeat mode armed, and the hardware notes say a read in that mode may hang a console. A PAL console ran every case without a hang, twice. If it stops, switch the console off, wait a few seconds before switching it on again, and keep the text it printed: the G line before each case tells which case it stopped in.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-88 (c1, 2026-11-19T00:36:44): 80 lines; the program was another build, 3ad4c607a44cfe0f.
- c1-91 (c1, 2026-11-19T00:40:24): 80 lines; the program is this set's build.
