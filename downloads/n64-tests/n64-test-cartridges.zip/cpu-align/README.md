# The cpu-align probe (CPU ALIGN PROBE)

## What it tests

In the words of its source:

> The alignment probe: a small test cartridge for a real console.
> 
> The phase probe (probes/cpu-phase) showed where the CPU is called away by an interrupt of the
> RCP that a store asks for: after 19, 19 and 18 instructions of a row, by where the store falls
> against the RCP's clock. This probe asks the same question again in other ways, so that the
> answer does not rest on one routine at one place, and asks where the CPU stands after each kind
> of wait for the bus.
> 
> Every routine is put together in memory by the probe itself, at one place whose instruction
> lines nothing else of the probe uses, then every line of it is filled in the instruction cache
> (the Fill operation) and it is called. A routine is: its start moved k instructions into its
> line; the head (the RCP's interrupt line let through, COUNT written with what it read); the
> anchor (an uncached read of the MI's version register: the CPU waits for the RCP's answer); j
> idle instructions and one instruction that waits for the bus; m idle instructions; one or two
> stores that come first; the store that asks the RSP for its interrupt; a row of 64 idle
> instructions. The exception stub (probes/cpu-time/time.S) notes COUNT and the address the CPU
> was called away from.
> 
> Lines, eight tries each after one that brings the data lines in. `t` is how many tries the
> interrupt took, s1 to s8 the row's instructions run before it (ff: not taken), c1 to c8 the
> steps of COUNT from the write to COUNT to the stub (COUNT steps once in two CPU cycles):
>   A  a b c             where the probe's own data begins and ends, and its routines' place
>   P k m t s.. c..      the anchor, m idle instructions, the store; the routine k instructions into its line
>   S k m t s.. c..      the same with no anchor (the routine of the time probe's S lines)
>   G j m t s.. c..      the anchor, j idle instructions, a second read of the same register
>   g x m t s.. c..      the same with no idle instruction and the second read from another part's
>                        register: 0 the RSP's status, 1 the DP's status, 2 the VI's line, 3 the
>                        AI's status, 4 the PI's status, 5 the RI's select, 6 the SI's status
>   V j m ..             the second read from the RSP's data memory
>   U j m ..             from main memory, without the cache
>   Da j m ..            a load through the data cache whose line is not there, its row of memory open
>   Dc j m ..            the same where the line in its place belongs to another address, clean
>   Dd j m ..            the same where that line must first be written back
>   Za Zc Zd j m ..      the three with a store through the data cache
>   F j m ..             the Fill operation on the routine's own last instruction line
>   Fr j m ..            the Fill operation on a line in another row of memory
>   W x m ..             the anchor, m idle instructions, a store of zero, then the store that asks.
>                        The first store goes to: 0 the MI's mask, 1 the RSP's status, 2 the RSP's
>                        semaphore, 3 the DP's status, 4 the VI's line, 5 the AI's status, 6 the
>                        PI's status, 7 the SI's status, 8 main memory, 9 the RSP's data memory,
>                        a the RSP's instruction memory
>   T m ..               two stores of zero to the MI's mask first
>   M m ..               the RSP's interrupt is already asked for and kept from the CPU by the
>                        MI's mask; the store lets it through (to the MI's mask register)
>   X m ..               the store asks for the interrupt and the next store takes it back
>   C m n12 .. n21       interrupts off; the anchor, m idle instructions, the store, q idle
>                        instructions, and Cause read: in how many of eight tries the RCP's
>                        line was up, for q = 12 to 21
>   K x d c1 .. c8       COUNT written, one instruction, d idle instructions, COUNT read: the
>                        steps. The instruction: 0 idle, 1 the anchor's read, 2 a divide, 3 a
>                        multiply, 4 idle and then the read, 5 a load whose data line is not there
> k = 0 to 7, j = 0 to 2, m = 0 to 5, d = 0 to 3.
> 
> No line depends on the console's television type: the VI is switched off.
> 
> Care for the console: everything here is ordinary. Register reads and writes a game makes: the
> RSP's status (its interrupt set and taken back) and semaphore, the MI's mask and version, the
> status registers of the DP, the AI, the PI and the SI and the VI's line register written with
> zero (which takes back an interrupt that is not there, or does nothing), the RSP's two memories
> while the RSP is halted; the CPU's own interrupt and cache operations. Every wait has an end.

## Ground no public suite covers

Where the CPU is called away by an RCP interrupt that a store asks for: the routine at eight places of its instruction line, after each kind of bus wait (register, RSP memory, main memory, a data line, the Fill operation) with cycle counts, a store before the asking store, the interrupt through the MI mask, Cause and COUNT read behind the store. Cycle-level interrupt placement against the RCP clock is, to this reading, not in n64-systemtest, krom timing, n64-asm-timing or n64-systembench.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out cpu-align` builds it into `out/`. By hand: compile the files under `source/probes/cpu-align/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `cpu-align-probe.z64`, 16384 bytes, SHA-256 3b8e1139fb58fbc1bde2f14f793bb863dcd7acdd9dda574d2e785f8b7108a068.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-93 (c1, 2026-11-19T19:54:25): 450 lines; the program is this set's build.
- c1-97 (c1, 2026-11-19T20:10:43): 450 lines; the program is this set's build.
- c2-31 (c2, 2026-11-21T09:00:01): 450 lines; the program is this set's build.
- c2-32 (c2, 2026-11-21T09:00:31): 450 lines; the program is this set's build.
- Both consoles ran build 3b8e1139fb58fbc1: c1-97 and c2-32 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
