# The cpu-pairs probe (CPU PAIRS PROBE)

## What it tests

In the words of its source:

> The pairs probe: a small test cartridge for a real console.
> 
> The alignment probe (probes/cpu-align) built with other lines: what the instruction right behind
> a store through the data cache waits for. The processor's manual says the data cache is busy
> with a store for a second cycle, so that an instruction right behind it that uses the data cache
> waits one cycle. A console's lines of two other probes showed a store made without the cache
> waiting there as well. This probe asks for that again with nothing else in the way (the store's
> line is in the cache), and asks the same of a read made without the cache and of a load and a
> store through it. Its lines are said in lines.h, and everything else is the alignment probe's
> source as it stands.
> 
> No line depends on the console's television type: the VI is switched off.
> 
> Care for the console: as the alignment probe. Register reads and writes a game makes, loads and
> stores of main memory, the CPU's own interrupt and cache operations. Every wait has an end.

## Ground no public suite covers

What the instruction right behind a store through the data cache waits for (uncached read, cached load, second store, with and without one idle instruction, at three places against the RCP clock). n64-asm-timing and krom timing time instruction sequences; this pairing against the RCP clock is, to this reading, not covered.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out cpu-pairs` builds it into `out/`. By hand: compile the files under `source/probes/cpu-pairs/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `cpu-pairs-probe.z64`, 12288 bytes, SHA-256 f0e914a04ff96c42890f6d6e0a46e106449984fee2f5661f2b20dc6512fcbb16.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-139 (c1, 2026-11-20T17:19:22): 171 lines; the program is this set's build.
- c1-140 (c1, 2026-11-20T17:19:55): 171 lines; the program is this set's build.
- c2-35 (c2, 2026-11-21T09:02:05): 171 lines; the program is this set's build.
- c2-36 (c2, 2026-11-21T09:02:37): 171 lines; the program is this set's build.
- Both consoles ran build f0e914a04ff96c42: c1-140 and c2-36 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
