# The cpu-phase probe (CPU PHASE PROBE)

## What it tests

In the words of its source:

> The phase probe: a small test cartridge for a real console.
> 
> On a console the tries probe's S lines (an interrupt of the RSP asked for by a store, every line
> of the routine in the cache) stop the CPU after 19, 19, 18, 19, 19, 18 instructions of a row for
> n = 0 to 5 idle instructions before the store; this core gives another pattern. Two candidates
> give the console's figures: A, the store's bus time starts one tick later than this core has it;
> B, the CPU sees the line one tick later and its cycles fall one tick otherwise against the RCP's
> clock after a wait. They part on where the CPU stands after a wait for the RCP. This probe makes
> that wait first: an uncached read of the MI's version register (the anchor), then m idle
> instructions, then the store.
> 
> Lines (eight tries each, after one that brings the data lines in; every instruction line of the
> routine is filled in the cache first, so the row's place is the wait itself):
>   S m t  s1 .. s8      the time probe's own routine, m idle instructions after the write to COUNT:
>                        t tries taken by the interrupt, s the row's instructions run before it
>   T m  c1 .. c8        their steps of COUNT from the write to COUNT to the stub
>   P m t  s1 .. s8      the anchor, m idle instructions, the store
>   p m  c1 .. c8
>   R m t  s1 .. s8      as P with a store of zero to the MI's mask register just before the store
>   r m  c1 .. c8
>   Q m  c1 .. c8        the anchor, m idle instructions, then 16 pairs of a store to the RSP's
>                        semaphore and an uncached read of its status: steps of COUNT across them
> for m = 0 to 5. COUNT steps once in two CPU cycles.
> 
> No line depends on the console's television type: the VI is switched off.
> 
> Care for the console: everything here is ordinary. Register reads and writes a game makes: the
> RSP's status (its interrupt set and taken back), its semaphore, the MI's mask and version; the
> CPU's own interrupt and cache operations. Every wait has an end.

## Ground no public suite covers

Where the CPU stands against the RCP clock after waiting for it: interrupt lines after an uncached MI read, with a store to the MI mask first, and 16 stores and reads of RSP registers in a row. Not covered by a listed suite to this reading.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out cpu-phase` builds it into `out/`. By hand: compile the files under `source/probes/cpu-phase/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `cpu-phase-probe.z64`, 20480 bytes, SHA-256 fc806e2db622d74ab7196012a76c1aadaaa824f67a401511562d3ed4ef3235fc.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-84 (c1, 2026-11-18T23:42:51): 44 lines; the program is this set's build.
- c1-92 (c1, 2026-11-19T19:42:47): 44 lines; the program is this set's build.
- c2-29 (c2, 2026-11-21T08:58:58): 44 lines; the program is this set's build.
- c2-30 (c2, 2026-11-21T08:59:29): 44 lines; the program is this set's build.
- Both consoles ran build fc806e2db622d74a: c1-92 and c2-30 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
