# The cpu-rows probe (CPU ROWS PROBE)

## What it tests

In the words of its source:

> The rows probe: a small test cartridge for a real console.
> 
> The alignment probe (probes/cpu-align) built with other lines: what a line of instructions
> costs when the memory chip has another row open than the line's. Two instruments disagreed on
> it: the alignment and the waits probes read 5 cycles of the RCP's clock on two consoles, and
> the public bus bench's rows fit 4 on the same two. In the bench a read of the other row made
> without the cache stands a few instructions before the line is asked for; in the probes a read
> of a register of the MI stands between. This probe asks for the line at a chosen number of idle
> instructions behind a read of memory, with each kind of read, by the Fill operation and by
> running into the line. Its lines are said in lines.h, and everything else is the alignment
> probe's source as it stands.
> 
> No line depends on the console's television type: the VI is switched off.
> 
> Care for the console: as the alignment probe. Register reads and writes a game makes, loads and
> stores of main memory, the CPU's own interrupt and cache operations. Every wait has an end.

## Ground no public suite covers

What a line of instructions costs when the memory chip has another row open, asked for by the Fill operation and by running into the line, 0 to 40 idle instructions behind each kind of read. It settles a disagreement between the project's probes and n64-systembench's rows.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out cpu-rows` builds it into `out/`. By hand: compile the files under `source/probes/cpu-rows/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `cpu-rows-probe.z64`, 16384 bytes, SHA-256 2b3134d4b26e6a986e6ad35c5081f62b673b394945579ab78881b621ec9903b3.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-149 (c1, 2026-11-21T17:44:46): 1137 lines; the program is this set's build.
- c1-150 (c1, 2026-11-21T17:45:24): 1137 lines; the program is this set's build.
