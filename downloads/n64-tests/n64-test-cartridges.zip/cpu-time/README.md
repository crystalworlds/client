# The cpu-time probe (CPU TIME PROBE)

## What it tests

In the words of its source:

> The CPU timing probe: a small test cartridge for a real console.
> 
> It asks the questions about the CPU's time that the tests run on this
> computer cannot settle, and prints every answer as a line of text through
> the debug text window a flash cartridge shows on the computer beside the
> console. Run on this core, the same lines show what the core does; the two
> logs are then compared line by line.
> 
> What it asks (every count is in CPU cycles unless the line says steps):
>   N  the measuring loop itself: 0, 1 and 5 instructions that do nothing
>   X  the time to reach the handler: from a breakpoint, an overflow, a load
>      from a misaligned address, and a jump to a misaligned address (an
>      exception of the fetch, which no test here times)
>   C  each CACHE operation, on a line that is in the cache clean, in it
>      dirty, or not in it
>   W  a store and a load through the data cache that must first write a
>      dirty line back
>   J  whether a jump waits after a load when the loaded register's number
>      sits in the jump's target bits
>   R  what Random reads after a divide, against after an instruction of one
>      cycle: once an instruction, or once a cycle
>   T  after how many turns of a six-cycle loop the timer's bit shows in
>      Cause, with the loop moved one instruction at a time
>   I  the timer's interrupt: which instruction of a row it stops, and what
>      COUNT reads in the handler's first instruction
>   S  the same for an interrupt of the RCP that a store asks for (the RSP's
>      own): how long after the store the CPU is called away
>   M  2,048 single reads of main memory with the video chip off, a little
>      further apart each time: how many took each length, and the longest
> 
> A value with a tilde before it may differ by a little from run to run on a
> console. All values are in hex. Nothing here can harm a console: the video
> chip is only turned off, and every wait has an end.

## Ground no public suite covers

The cycles to enter an exception and an interrupt, the cost of each CACHE operation, when the timer bit shows, whether a jump waits after a load, and 2,048 single reads with the VI off. krom timing, n64-asm-timing and n64-systemtest's timing level time some of this; exception entry and CACHE operation costs on PAL consoles were contradicted by the consoles here, and are not, to this reading, settled by those suites.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out cpu-time` builds it into `out/`. By hand: compile the files under `source/probes/cpu-time/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `cpu-time-probe.z64`, 16384 bytes, SHA-256 2204eb6db43cf916c0cecc7cabcfba5da599bc8318c768c56ab436112f4b34ae.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-08 (c1, 2026-11-14T10:30:07): 74 lines; the program was an earlier build, not kept.
- c1-22 (c1, 2026-11-14T10:56:22): 75 lines; the program is this set's build.
- c2-04 (c2, 2026-11-14T11:07:40): 76 lines; the program is this set's build.
- c2-14 (c2, 2026-11-14T11:17:18): 73 lines; the program is this set's build.
- c1-75 (c1, 2026-11-18T23:09:24): 73 lines; the program is this set's build.
- Both consoles ran build 2204eb6db43cf916: c1-75 and c2-14 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
