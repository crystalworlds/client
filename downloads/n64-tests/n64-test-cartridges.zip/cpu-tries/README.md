# The cpu-tries probe (CPU TRIES PROBE)

## What it tests

In the words of its source:

> The tries probe: the CPU timing probe (probes/cpu-time) built to print each of its eight tries
> of every timed piece, where that probe prints the smallest and how many gave it, and with its
> lines for an interrupt of the RCP made anew: the routine's instruction lines are all filled
> before the store, for six distances between the write to COUNT and the store, eight tries each.
> 
> What it is for. On two consoles the eight tries of a piece agree far more often than on this
> core, where they can differ by a cycle with how the CPU's cycle falls against the bus clock
> after a wait: the tries, one by one, show how a console's fall. And the time probe's S lines only
> bound the wait before the CPU sees a line of the RCP rise (the interrupt came while the row's
> next instruction line was being fetched): with the lines filled first, the place the row stops
> at is the wait.
> 
> The lines are the time probe's own, with these differences: the first line reads CPUTRIES and
> the last CPUTRIES END; each timed line carries eight figures; and the S lines are
>     S n taken t stopped s1 .. s8     how many of eight tries were stopped by the interrupt, and
>                                      after how many of the row's instructions each
>     S n steps c1 .. c8               each try's steps of COUNT from the write to COUNT to the stub
> for n = 0 to 5 idle instructions between the write to COUNT and the store.

## Ground no public suite covers

The cpu-time probe printing all eight tries of each timed piece, with its RCP interrupt lines remade so that the wait before the CPU sees the line rise is read directly. Same ground as cpu-time, at finer grain.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out cpu-tries` builds it into `out/`. By hand: compile the files under `source/probes/cpu-tries/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `cpu-tries-probe.z64`, 16384 bytes, SHA-256 6e03546719bc568ba38a2d63eaef6f075954ee63cbb8be49583610754f4ee5fa.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-69 (c1, 2026-11-18T17:30:37): 86 lines; the program is this set's build.
- c1-70 (c1, 2026-11-18T17:31:10): 88 lines; the program is this set's build.
- c2-37 (c2, 2026-11-21T09:03:08): 88 lines; the program is this set's build.
- Both consoles ran build 6e03546719bc568b: c1-70 and c2-37 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
