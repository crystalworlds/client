# The current probe (CURRENT PROBE)

**Warning: this test has never been run on a real console.** It drives the second memory chip of the console at current settings a boot code would never leave it at, one step after another, and then sets a working step back. If you run it on a console, switch the console off as soon as it ends.

## What it tests

In the words of its source:

> The current probe: a small test cartridge for a real console.
> 
> A memory chip must drive enough current for its data to arrive, and a boot code has to find
> the setting at which it does. How a real chip answers at each setting is not written down
> anywhere we have found: this core uses nominal figures. This probe measures it. It takes the
> second memory chip of the console (the 2 MiB from 0x200000, which this program does not use),
> and does to it what a boot code does:
> 
> - with the current set by hand, at each of the 64 steps, it writes a doubleword of ones at the
>   start of the chip ten times and counts the one bits that come back in one byte of it (80 if
>   the chip's data arrives whole, 0 if nothing arrives);
> - with the current regulated by the chip, at each of the 64 steps, it reads back the step the
>   chip says it has settled at, twice;
> - then it works out the setting a boot code would choose from those answers, puts the chip
>   back to it, and checks that the chip's memory answers again.
> 
> Everything this program itself needs (its code, its stack, its data) is in the first chip.
> 
> S  the memory size the boot code stored
> C  the chip's mode register, delay register and type register as found
> A  step, one bits that came back out of 80, with the current set by hand
> B  step, the step read back the first time and the second, with the current regulated
> F  the step aimed for, the regulated step chosen, the mode register written, the mode
>    register read back, and the one bits out of 80 that come back at the end

## Ground no public suite covers

A memory chip's output current: on the second 2 MiB chip, at each of 64 steps set by hand, how many one bits come back; the step the chip settles at when it regulates; then it sets a working step back. No listed suite measures RDRAM current steps.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out current` builds it into `out/`. By hand: compile the files under `source/probes/current/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `current-probe.z64`, 8192 bytes, SHA-256 c6bbb361824f56b5a28cb907c49e9d45616c93f76f746bf5468a68049469ad10.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test has never been run on a real console.** It drives the second memory chip of the console at current settings a boot code would never leave it at, one step after another, and then sets a working step back. If you run it on a console, switch the console off as soon as it ends.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

No console run of this probe yet.
