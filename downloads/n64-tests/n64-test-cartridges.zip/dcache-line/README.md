# The dcache-line probe (DCACHE LINE PROBE)

## What it tests

In the words of its source:

> The data cache line probe: a small test cartridge for a real console.
> 
> A fetched test of the RSP asks an allocator for memory and copies its RSP program there through
> an address that goes past the data cache. The allocator's note in front of the block was stored
> through the cache, and it lies in the same 16-byte line as the first eight bytes of the copy.
> By this core's rules, and the reference emulator's, that line is later written back to memory
> whole, note and old bytes alike, over the first two instructions of the copy. A console ran
> that very file for an hour and never showed the damage (two runs). This probe
> walks the same steps in the open and prints what memory holds afterwards. All values are in
> hex; a word's first two digits say where its value came from:
> 
>     f1  what memory was given before the walk (so: what the line took in when it was filled)
>     cc  a store through the cache
>     a5  a store made without the cache
>     5c  a word of the copy's source
> 
> The lines:
> 
>   X f w r     a word far inside the debug text window, where no text reaches: as found, as
>               written (one more than found), and as read back after another read of the
>               cartridge. It counts the runs in which the window took a write, a run that was
>               listened to without the window among them
>   Z a w...    the 16 bytes at a of main memory as the start left them, before the probe wrote
>               anywhere near: the two places where the fetched test's block lies
>   N n         how many of the 16,384 words from 0x000c0000 on are not zero at that moment
>   K w...      the control: all four words of the line stored through the cache, then all four
>               without it, then a load of another address with the same line number; the
>               block's four words as memory holds them afterwards (a console is known to give
>               cc four times)
>   W c f e w... the walk. Word c alone is stored through the cache (f = 0: the store finds the
>               line not there and has it filled; f = 1: a load filled it before). All four
>               words are then stored without the cache. Then the line is made to go: e = 0 by a
>               load of another address with the same line number, 1 by a store to it, 2 by
>               CACHE Index Write Back Invalidate, 3 by Hit Write Back, 4 by Hit Write Back
>               Invalidate. The block's four words as memory holds them afterwards
>   G k w...    the walk with c = 1 and e = 0, the load k idle instructions after the last store
>               made without the cache, with nothing between that waits for those stores
>   R c w...    what the line shows through the cache after the stores made without it: the
>               walk up to there, then four loads through the cache
>   S c w...    the walk with e = 0 and 64 turns of an idle loop between the store through the
>               cache and the stores made without it
>   M v w...    the copy as the fetched test makes it, at the test's own addresses: the note
>               stored through the cache at 0x800cd294, then 296 words copied from 0x8002ef60,
>               read through the cache, to 0xa00cd298, written without it. The 16 bytes at
>               0x000cd290 afterwards. v = 1: the source is read through the cache, then the
>               note's store finds its line not there. v = 2, the test's own order: the source
>               is read, a first note is stored (the line is filled), a long idle loop passes,
>               and the note is stored again into the line that is there
>   D v d0 d1   the copy's first eight bytes as the RSP's DMA then brings them into its data
>               memory: what the RSP would have been given
> 
> No line depends on the console's television type: the probe uses neither the VI nor the sound
> output. It needs 4 MiB of main memory and no more.
> 
> Care for the console: plain loads and stores in a part of main memory nothing else uses, five
> CACHE operations a library uses every day, and one DMA of eight bytes into the RSP's data
> memory while the RSP stands still.

## Ground no public suite covers

A data cache line written back over bytes stored without the cache: the steps by which the rsp-ruination pair test damages its own RSP code on emulators but not on a console, walked in the open, and what memory and the RSP's DMA then hold. Not in any listed suite.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out dcache-line` builds it into `out/`. By hand: compile the files under `source/probes/dcache-line/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `dcache-line-probe.z64`, 12288 bytes, SHA-256 3ab4c5d4fdc382c20bf33e5ac67fec0df27be81316dd47b09d01f924866d5715.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-64 (c1, 2026-11-18T16:57:50): 39 lines; the program is this set's build.
- c1-68 (c1, 2026-11-18T17:21:26): 39 lines; the program is this set's build.
- c2-38 (c2, 2026-11-21T09:03:39): 39 lines; the program is this set's build.
- Both consoles ran build 3ab4c5d4fdc382c2: c1-68 and c2-38 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
