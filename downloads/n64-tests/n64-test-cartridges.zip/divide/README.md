# The divide probe (DIVIDE PROBE)

## What it tests

In the words of its source:

> The divide probe: a small test cartridge for a real console.
> 
> DIV is a 32-bit signed divide, but the console's divider works on the whole
> 64-bit registers. For operands that are proper sign-extended 32-bit values
> nothing odd shows. When they are not, the quotient follows a rule that is
> known for half the cases and that nobody has worked out for the other half:
> those where bits 63 and 31 of the divisor differ.
> 
> Random operands have not given the rule away, so this probe walks through
> that half in steps: divisors with one upper bit set or one upper bit clear
> over a few lower halves, against a few dividends. It prints the operands and
> both result registers of every case as text, through the debug text window
> a flash cartridge shows on the computer beside the console. Run here, the
> same lines show what this core computes; the two logs are then compared
> line by line.
> 
> Each line: D <dividend> <divisor> <LO> <HI>, all 64 bits in hex.
> U lines are the same for DIVU, as a control.

## Ground no public suite covers

DIV and DIVU with 64-bit register operands that are not sign-extended 32-bit values, walked over the half of cases where bits 63 and 31 of the divisor differ. Thar0's IntegerMulDiv tests random such operands against a model; the stepped walk of that half is, to this reading, not covered.

## How it gives its answer

Debug text window; figures only (D and U lines compared with this emulator's).

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out divide` builds it into `out/`. By hand: compile the files under `source/probes/divide/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `divide-probe.z64`, 8192 bytes, SHA-256 2e3aaecba65bd5ce4e2ccab382bcd2d46a1c94971de805592c0cbdc87f480ace.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-01 (c1, 2026-11-14T09:38:29): 1 lines; the program was an earlier build, not kept.
- c1-02 (c1, 2026-11-14T10:12:53): 3474 lines; the program was another build, 6646696a5199f05f.
- c2-01 (c2, 2026-11-14T11:06:02): 3474 lines; the program is this set's build.
