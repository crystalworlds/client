# The dp-depth probe (DP DEPTH PROBE)

## What it tests

In the words of its source:

> The DP depth probe: a small test cartridge for a real console.
> 
> A console's log of the waiting transfer probe (probes/dp-queue) showed CURRENT at a list's end
> while the list's first rectangle was still being drawn: the DP takes commands in ahead of the
> drawing. How many? This core fetches each command as it runs it. The probe hands over one list:
> a large rectangle that takes a while to draw, then many commands behind it, and reads CURRENT
> and STATUS at fixed times after the write of END. While the rectangle is drawn, CURRENT stands
> still where the commands taken in ahead end: that plateau is the depth; afterwards it climbs as
> the commands leave.
> 
> The list: the colour image (16 bits, 320 wide), the scissor, fill mode, a fill colour, one fill
> rectangle of 320 by 200 pixels, then the filler, then a full sync. The filler by variant k:
>   0   120 Set Fill Color commands of the same value (8 bytes each)
>   1   a pipe sync and a Set Other Modes to one-cycle mode, then 60 Texture Rectangles wholly below
>       the scissor (16 bytes each, nothing drawn): the same bytes in half as many commands
>   2   120 fill rectangles of one pixel inside the large one, in its colour: drawn primitives
>   3   as 0, with 16 more Set Fill Color commands before the rectangle: does the depth count from
>       the command in hand or from the list's start
> Each variant three times. Then the sweep: variant 0 with e = 0 to 15 more Set Fill Color commands
> before the rectangle, once each, so that where CURRENT stands is seen against the rectangle's
> place at every step of 8 bytes (the lines W and F, as D and E with e in place of k and r). Then
> variant 0 with the list (and START) 8 x b bytes further on, b = 0 to 9, once each: are the blocks
> CURRENT stands at counted from START or from the address (the lines V and H, b in place of k;
> CURRENT still counted from the list's start).
> 
> Lines:   D k r j  t c s  (eight times)      three lines a run: j = 0, 1, 2
>          E k r  steps  s  c
>   k r    the variant and the run (0 to 2)
>   t      steps of COUNT from the write of END to the read
>   c      CURRENT, in bytes from the list's start
>   s      STATUS
>   the first twelve samples are taken about 2 microseconds apart, the last twelve about 64 apart
>   steps  steps of COUNT from the write of END until the full sync's interrupt is seen; s and c
>          STATUS and CURRENT then
> COUNT steps at half the CPU's clock (46.875 MHz).
> 
> No line depends on the console's television type: the VI is switched off and the sound output
> is never used.
> 
> Care for the console: everything here is ordinary. Lists of common commands: fill-mode
> rectangles into a 16-bit image, fill colours, a pipe sync and a change to one-cycle mode, and
> texture rectangles that the scissor leaves nothing of, each list ended by a full sync, as every
> game's graphics microcode hands over; no triangle, no 4-bit image.

## Ground no public suite covers

How many commands the DP takes in ahead of the drawing: one large fill and 120 commands behind it, CURRENT and STATUS read 24 times, three runs of each. RDP-Timing-Tests and paraLLEl-RDP conformance do not, to this reading, measure the DP's read-ahead.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out dp-depth` builds it into `out/`. By hand: compile the files under `source/probes/dp-depth/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `dp-depth-probe.z64`, 8192 bytes, SHA-256 dfb57cca7ae1fcff6b41b1fdd8e8359c106e490745e58fd3a78283eb30e19d57.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-79 (c1, 2026-11-18T23:28:04): 38 lines; the program was another build, 218770b52b55a705.
- c1-80 (c1, 2026-11-18T23:29:44): 50 lines; the program was another build, 152523e35c969527.
- c1-81 (c1, 2026-11-18T23:31:44): 114 lines; the program was another build, 61ea01a2327a25bd.
- c1-86 (c1, 2026-11-18T23:49:43): 154 lines; the program is this set's build.
- c2-41 (c2, 2026-11-21T09:05:16): 154 lines; the program is this set's build.
- Both consoles ran build dfb57cca7ae1fcff: c1-86 and c2-41 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
