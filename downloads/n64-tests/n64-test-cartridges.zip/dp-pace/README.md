# The dp-pace probe (DP PACE PROBE)

## What it tests

In the words of its source:

> The DP pace probe: a small test cartridge for a real console.
> 
> A console's logs of the depth probe (probes/dp-depth) showed that the DP reads a list into a
> buffer ahead of the drawing, 80 bytes at a time, and that CURRENT is the place of that reading.
> They gave one point of its pace. This probe asks for the whole course: after the write of END,
> CURRENT (or STATUS) is read once, a chosen number of idle instructions later, and the list is
> run again for every number. The DP's own clock is read before the write and behind the read, so
> every number of idle instructions has its time in cycles of the RCP's clock.
> 
> The lists (v):
>   3   four settings, a fill colour, a rectangle of 19 pixels, a full sync: 56 bytes
>   0   four settings, 121 fill colours, a full sync: 1,008 bytes with no primitive, so nothing
>       holds the commands up and the reading goes at its own pace
>   1   four settings, a fill rectangle of 320 by 200, 120 fill colours, a full sync: the
>       depth probe's first list, where the reading stops at byte 0xF0 while the rectangle is drawn
>   2   as 1 with 16 more fill colours before the rectangle: the reading stops at byte 0x190
>   4   list 0 handed over as a second transfer while a first one (four settings and the rectangle,
>       40 bytes, read at once) is being drawn: how soon a transfer begins when the DP is at
>       work already, and how its reading goes while nothing leaves the buffer. CURRENT reads ff
>       while it still stands in the first transfer
> 
> Lines:   K d  k (16 times)     the clock's cycles from its read before the write of END to a read
>                                of it d, d+1, ... idle instructions behind the write
>          N d  n (16 times)     COUNT's steps over the same runs, from before the write to behind the read
>          C v d  c (32 times)   CURRENT, in 8-byte words from the list's start, for d, d+1, ...
>          S v d  s (16 times)   STATUS for d, d+1, ...
>          k, n, c, s            the same with four idle instructions more from one value to the next
>          T v r  n0 n1          COUNT's steps of a pass's first and last run (r: 0 CURRENT, 1 STATUS)
> 
> Then three cases of their own, each with a rectangle of 320 by 200 that takes about 28,000
> steps of COUNT, and marks of one pixel or one short row drawn behind it:
> 
> W, the waiting transfer: list A (the rectangle, 120 fill colours, a mark in 1235) is handed
> over, and list B (a fill colour abcd, a mark, a full sync) straight after, while A's reading
> stands still for want of room. Does B wait whole until A's reading has reached A's end?
>          W r 0  s1 c1  s2 c2  s3 c3      after A's END, after B's START, after B's END
>          W r 1  (s c) six times           every 3,000 steps of COUNT from then on
>          W r 2  (s c) six times
>          W r 3  s c start  a b  late      at the interrupt; the two marks
>   CURRENT is printed in 8-byte words from A's start, or c000 and up from B's.
> 
> Z, FREEZE while a list is drawn: the list is the rectangle, a fill colour 1235 and 60 marks of
> one pixel, then a full sync. 2,000 steps in, FREEZE is set; 45,000 steps in, the state is read;
> then FREEZE is cleared and the interrupt waited for.
>          Z r 0  s0 c0  s1 c1  s2 c2  intr  rows last  marks marks
>          Z r 1  s3 c3  s4 c4  rows last  marks marks  late
>   s0 c0 before FREEZE, s1 c1 straight after, s2 c2 at 45,000 steps; s3 c3 straight after it is
>   cleared, s4 c4 at the interrupt. rows: how many of the rectangle's 200 rows have their first
>   pixel drawn; last: how many have their last. marks: one bit for each mark drawn (marks 0 to 31,
>   then 32 to 59). CURRENT in bytes from the list's start.
> 
> F, FLUSH while a list is drawn: the same list. 2,000 steps in, FLUSH is set; 400 steps later it
> is cleared; 45,000 steps in, the state is read. Then a short list (a fill colour abcd, a mark, a
> full sync) is handed over, to see the DP take a list again.
>          F r 0  s0 c0  s1 c1  s2 c2  s3 c3
>          F r 1  s4 c4  intr  rows last  marks marks  s5 c5  b  late
>   s0 c0 before FLUSH, s1 c1 straight after, s2 c2 400 steps on, s3 c3 straight after it is
>   cleared, s4 c4 at 45,000 steps; s5 c5 and the mark b when the short list's interrupt has come
>   (its CURRENT printed as c000 and up).
> 
> The last line before the end, L, counts the waits for an interrupt that ran out (0 expected).
> 
> No line depends on the console's television type: the VI is switched off and the sound output
> is never used.
> 
> Care for the console: everything here is ordinary. Lists of fill-mode rectangles into a 16-bit
> image and fill colours, each ended by a full sync; a second list handed over while the first is
> drawn, as every game's graphics microcode does; and the DP's FREEZE and FLUSH bits set and
> cleared once each while a list runs, as the maker's library lets a program do. No triangle, no
> 4-bit image.

## Ground no public suite covers

The pace at which the DP reads a list into its buffer, CURRENT or STATUS read at every count of idle instructions up to 1,535, then a second list during a long first, and FREEZE and FLUSH while drawing. Not in a listed suite to this reading.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out dp-pace` builds it into `out/`. By hand: compile the files under `source/probes/dp-pace/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `dp-pace-probe.z64`, 20480 bytes, SHA-256 bac0136737acf554b724234440fb9c27b42681f3c66ad65356cb2f5cb5380cfd.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-95 (c1, 2026-11-19T20:04:29): 421 lines; the program is this set's build.
- c2-40 (c2, 2026-11-21T09:04:43): 421 lines; the program is this set's build.
- Both consoles ran build bac0136737acf554: c1-95 and c2-40 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
