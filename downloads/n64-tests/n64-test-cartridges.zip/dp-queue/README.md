# The dp-queue probe (DP QUEUE PROBE)

## What it tests

In the words of its source:

> The waiting transfer probe: a small test cartridge for a real console.
> 
> The DP has room for one transfer in hand and one that waits. What does a console do when a
> program writes START and END for a second list while the first is still being drawn? This
> core makes the second wait whole and loses nothing of the first (the rule is read from a
> hardware wiki); games lean on it every frame. Each answer is a line of text through the debug
> text window a flash cartridge shows on the computer beside the console. Run on this core, the
> same lines show what the core does.
> 
> Two lists: A fills a rectangle of 64 by 40 pixels `n` times and then draws a mark; B draws a
> second mark and ends in a full sync. A is started, and B is asked for straight away.
> 
> A line:   Q  n  s1 c1  s2 c2  s3 c3  s4 c4  start  a  b
>   n       how many rectangles A fills before its mark: 0 (A is over before B is asked for) or
>           12 (A is under way then)
>   s1 c1   STATUS and CURRENT read straight after the write of A's END
>   s2 c2   the same after the write of B's START
>   s3 c3   the same after the write of B's END
>   s4 c4   the same when the full sync's interrupt has come; `start` is START read then
>   a  b    the 16-bit pixel at each mark's place at the end: A's mark is 1235, B's abcd
> CURRENT is printed as a count of 8-byte commands from A's first (c000 and up: from B's first).
> 
> Every case is run three times: what differs between two lines of the same n differs from run
> to run on the same console (how far A has got when it is looked at, and the busy marks).
> 
> No line depends on the console's television type: the VI is switched off and the sound output
> is never used.
> 
> Care for the console: everything here is ordinary. Two short lists of fill-mode rectangles into
> a 16-bit image, the second handed over while the first runs, as every game's graphics
> microcode does; no fill-mode triangle, no 4-bit image, nothing the hardware notes warn of.

## Ground no public suite covers

A second DP list handed over straight after a first, with the first over at once or still drawing; status and CURRENT after each write and whether both lists' marks are in memory. Not in a listed suite to this reading.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out dp-queue` builds it into `out/`. By hand: compile the files under `source/probes/dp-queue/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `dp-queue-probe.z64`, 8192 bytes, SHA-256 e0deecc0190240b4a93255c50aade0c885290e68c594c8a7fae6d76d2817d887.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-74 (c1, 2026-11-18T17:49:46): 8 lines; the program is this set's build.
- c1-108 (c1, 2026-11-20T08:10:28): 8 lines; the program is this set's build.
- c2-42 (c2, 2026-11-21T09:05:48): 8 lines; the program is this set's build.
- c2-57 (c2, 2026-11-21T09:16:38): 8 lines; the program is this set's build.
- c1-144 (c1, 2026-11-21T17:06:49): 8 lines; the program is this set's build.
- c1-145 (c1, 2026-11-21T17:07:23): 8 lines; the program is this set's build.
- c1-146 (c1, 2026-11-21T17:08:00): 8 lines; the program is this set's build.
- c1-147 (c1, 2026-11-21T17:31:11): 8 lines; the program is this set's build.
- c1-148 (c1, 2026-11-21T17:31:47): 8 lines; the program is this set's build.
- Both consoles ran build e0deecc0190240b4: c1-148 and c2-57 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
