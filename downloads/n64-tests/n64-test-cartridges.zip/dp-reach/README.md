# The dp-reach probe (DP REACH PROBE)

## What it tests

In the words of its source:

> The DP reach probe: a small test cartridge for a real console.
> 
> A console's log of the waiting transfer probe (probes/dp-queue) showed a fill colour set behind
> a rectangle, with no sync between, reach that rectangle before it was drawn. How far back does a
> setting changed without a sync reach, and what stops it? This core runs every command in order,
> so a setting never reaches back.
> 
> Each case is one list: the colour image (16 bits, 64 wide), the scissor (64 by 48), fill mode,
> Set Fill Color c1; R1, a fill rectangle over rows 0 to h-1 and the whole width; R2, one row at 44
> from x 2 to 20; then what lies between (the gap); then the command under test; then Q, a fill
> rectangle at row 46 from x 2 to 20 that uses the state; a full sync. The CPU clears rows 0 to 47
> before each case.
> 
> Lines:   R c g h  p0 pl0 pl1  m0 m1  q  t
>   c   the command under test: 0 Set Fill Color c2; 1 Set Color Image to another image; 2 Set
>       Scissor to rows 0 to 43 (row 44 and 46 left out); 3 Set Other Modes to one-cycle mode (all else zero),
>       in which a fill rectangle is drawn through the colour combiner and the blender
>   g   the gap: 0 nothing; 1, 2, 3, 4 that many times two Set Fill Color c1 (2, 4, 6, 8 commands);
>       5 a pipe sync; 6 a load sync; 7 a tile sync
>   h   R1's height in rows: 1, 8 or 40
>   p0      R1's first pixel (0, 0)
>   pl0 pl1 R1's last row's first and last pixel (0 and 63, row h-1)
>   m0 m1   R2's first and last pixel (2 and 20, row 44)
>   q       Q's first pixel (2, 46)
>   t   1 if the wait for the full sync's interrupt ran out (never expected)
> c1 is 1235, c2 abcd. Every case runs twice: the second line shows whether the answer moves.
> Then the row map: R1 40 rows high and w pixels wide (64, 32, 16 or 8), R2 one row at 44 of n
> pixels (19 or 64), Set Fill Color c2 straight after, then Q; which of R1's rows took c2:
>   M w n  first last  r2      first: a bit for each of R1's 40 rows, row 39 in the lowest bit,
>                              set where the row's first pixel is abcd; last: the same for the
>                              row's last pixel; r2: R2's first and last pixel, 1 where abcd
> 
> Then the colour clock (the third build): when is a row's fill colour read? Behind the
> rectangles stand 22 Set Fill Color commands, each with a colour of its own (4001 to 4016; the
> rectangles are decoded with 4000 in force). The decoder takes them one cycle apart, so the colour
> a row comes out in says how many cycles after the rectangle's command had been worked off the
> row's colour was read. A load sync (25 cycles) or a tile sync (33) before the colours moves the
> clock on by as much, so three lists cover the first 55 cycles. The image is 320 pixels wide.
>   T s w h x n y   f l (for each of R1's last rows, eight at most)   m0 m1  q
>   s     the image's pixel size: 2 for 16 bits, 3 for 32
>   w h   R1's width and height (rows 0 to h-1); x: its first pixel
>   n     R2's pixels on row 44 (from x 2 for 19, from x 0 for 64), or 0 for no R2
>   y     what stands before the colours: 0 nothing, 1 a load sync, 2 a tile sync, 3 a pipe sync
>   f l   the colour number of a row's first and last pixel: 00 for 4000, 16 for 4016; dd where
>         nothing was drawn, ee for any other value
>   m0 m1 the same for R2's first and last pixel (dd with no R2); q for Q's first pixel (row 46)
> The whole clock is run twice.
> 
> No line depends on the console's television type: the VI is switched off and the sound output
> is never used.
> 
> Care for the console: everything here is ordinary. Short lists of fill-mode rectangles into a
> 16-bit or a 32-bit image, fill colours, a colour image, a scissor, a change to one-cycle mode (a
> fill rectangle in one-cycle mode is how games draw shaded rectangles) and the three syncs, each
> list ended by a full sync; a setting changed with no pipe sync before it, which the graphics
> microcode of games does for some settings. No triangle, no 4-bit image.

## Ground no public suite covers

How far back a setting changed without a sync reaches into drawing already queued: 42 short lists, six pixels each, twice. snapper64 has a group of no-sync fill pictures (credited); the sweep of gaps and settings here is, to this reading, not covered.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out dp-reach` builds it into `out/`. By hand: compile the files under `source/probes/dp-reach/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `dp-reach-probe.z64`, 12288 bytes, SHA-256 c1775dcbce155ca1b8d9353b4cd58d15280e7bd0912bd0d405320563bc5ab89e.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-82 (c1, 2026-11-18T23:34:41): 86 lines; the program was another build, 41d08dbec8d99a60.
- c1-87 (c1, 2026-11-18T23:51:25): 102 lines; the program was another build, b342945e76de2158.
- c1-96 (c1, 2026-11-19T20:06:15): 506 lines; the program is this set's build.
- c2-43 (c2, 2026-11-21T09:06:19): 506 lines; the program is this set's build.
- c2-44 (c2, 2026-11-21T09:06:52): 506 lines; the program is this set's build.
- Both consoles ran build c1775dcbce155ca1: c1-96 and c2-44 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
