# The dp-time probe (DRAWING TIME PROBE)

## What it tests

In the words of its source:

> The drawing time probe: a small test cartridge for a real console.
> 
> What can the CPU see of the time the RDP takes to draw? The probe hands the DP short lists,
> each ending in a full sync, and for each one prints what the DP's registers show at once, how
> long the full sync's interrupt takes to come, what the three busy counters and the clock have
> counted by then, whether they still count afterwards, and, for one large rectangle, which of
> its lines are in memory at four moments on the way. Each answer is a line of text through the
> debug text window a flash cartridge shows on the computer beside the console. Run on this
> core, the same lines show what the core does.
> 
> Every list is run twice, so that two lines with the same letters stand under each other: what
> differs between them differs from run to run on the same console.
> 
> A line for a list:   tag  s0  s1  ticks  buf  pipe  tmem  clock  buf+  pipe+
>   s0      STATUS read straight after the write to END
>   s1      STATUS read when the interrupt has come
>   ticks   COUNT's steps from the write to END until the DP's interrupt shows in the MI
>           (COUNT steps once every two CPU cycles: three steps are four cycles of the RCP)
>   buf, pipe, tmem, clock   the three busy counters and the clock, read when the interrupt has
>           come; all four were cleared between the writes to START and END
>   buf+, pipe+   how far the two counters went on in about 2,000 more steps of COUNT
> 
> The lists (every one ends in a full sync; the image is 32 bits, 320 wide, image read off, no
> depth, so the pipe never waits to read memory):
>   E       nothing else
>   N       sixteen commands that set the primitive colour
>   P T L   one sync pipe, one sync tile, one sync load
>   A1-A6   one fill rectangle in one-cycle mode: 8 by 1, 8 by 8, 64 by 1, 64 by 8, 320 by 8,
>           320 by 64 pixels
>   B1-B6   the same in two-cycle mode
>   F1-F6   the same in fill mode
>   G       one triangle in one-cycle mode, major edge on the left, 64 wide and 64 high
> 
> A line for memory on the way:   H  wait  lines
>   A rectangle of 320 by 200 pixels in one-cycle mode. `wait` is how many steps of COUNT the
>   probe let pass after the write to END before it looked; `lines` has one bit for each of the
>   lines 20, 100 and 180 (bit 2 for line 20): set when that line's first pixel was drawn.
> 
> No line depends on the console's television type: the VI is switched off before anything is
> measured and the sound output is never used, and the CPU's clock and the RCP's are the same
> on every type. On a console the counters differ a little from run to run, because the waits
> for memory do.
> 
> Care for the console: everything here is ordinary. Short lists of common commands, each ended
> by a full sync; rectangles, and one triangle with its major edge on the left; no fill-mode
> triangle, no 4-bit image, nothing the hardware notes warn of.

## Ground no public suite covers

What the CPU can see of the RDP's time: for 24 short lists the DP status, the full sync's interrupt time, the busy counters, and which lines of a large rectangle reach memory on the way. RDP-Timing-Tests covers RDP timing (not built here, so not compared).

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out dp-time` builds it into `out/`. By hand: compile the files under `source/probes/dp-time/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `dp-time-probe.z64`, 8192 bytes, SHA-256 18625bb882dd9c0eca1a63a0dbfebe3ecde848c2287a71af16af541b54595210.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-14 (c1, 2026-11-14T10:45:29): 54 lines; the program is this set's build.
- c2-12 (c2, 2026-11-14T11:15:02): 54 lines; the program is this set's build.
- Both consoles ran build 18625bb882dd9c0e: c1-14 and c2-12 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
