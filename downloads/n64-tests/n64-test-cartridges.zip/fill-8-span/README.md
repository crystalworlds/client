# The fill-8-span probe (FILL SPAN PROBE)

## What it tests

In the words of its source:

> The fill span probe: a small test cartridge for a real console.
> 
> The 8-bit fill probe (probes/fill-8) found that a console's fill into an 8-bit image does not
> write pixel by pixel: in 26 cases it wrote nothing, and once it wrote a byte past the run. One
> rule fits all its 296 lines, but two of its facts rest on one byte, and that probe saw only 32
> bytes and no span of three groups of eight. This probe asks the rule's open points:
> 
>   - the fill writes 64-bit words of memory under a byte mask, counted in groups of eight bytes
>     by the pixels' places in the image (not by their addresses);
>   - one group: one write from the first byte's lane to the last byte's, nothing if the bytes
>     cross a word; two or more: a first write to the word's end and a last from the word's start;
>   - what lies between, for three groups or more;
>   - every byte written takes bit 0 of the fill colour's 16-bit half its address picks;
>   - whether a fill into a 16-bit image off a multiple of eight bytes goes by the same rule.
> 
> For each case the probe lays 64 bytes of main memory (0x5A, every hidden bit clear), has the
> RDP fill a run of pixels in fill mode into an image that begins 16 + a bytes into them, and
> prints the 64 bytes and their hidden bits, in two lines. A write outside the run shows.
> 
> Lines:   S a x n w z t  w0 .. w7  h      and then      s a x n w z t  w8 .. w15  h
>   a   the image begins 16 + a bytes into the 64 (a from 0 to 7)
>   x   the first pixel filled, counted from the image's first
>   n   how many pixels are filled, wrapping into the next line where the line ends
>   w   the image's width in pixels
>   z   the pixel's size: 1 for 8 bits, 2 for 16 bits, 4 for 32 bits
>   t   1 if the wait for the full sync's interrupt ran out (never expected)
>   w0 to w15   the sixteen words of memory
>   h   their hidden bits, a hex digit a word, the first byte's in bit 3
> 
> Cases: an 8-bit image 32 pixels wide, every a, x of 0, 1, 3, 5 and 7, n of 1, 7, 8, 9, 16, 17
> and 24 (280 cases); two-line runs into 8-bit images 12, 13 and 20 pixels wide, every a, from x
> 0 and 1, n the width and seven more (48); a 16-bit image 16 pixels wide at a of 0, 2, 4 and 6,
> four runs each (16). Then a second set, of cases no rule was fitted to: the 8-bit image at every
> a, x of 2, 4 and 6, n of 2, 6, 10, 15 and 23 (120); two-line runs into images 9, 11 and 15 pixels
> wide, every a, from x 0 and 3, n the width and nine more (48); the 16-bit image at a of 2, 4 and
> 6, four other runs each (12). Then a third set, of two things no console had been asked: a 32-bit
> image 8 pixels wide at a of 0, 2, 4 and 6, ten runs each, and two-line runs into one 3 pixels
> wide (48 cases); and the 16-bit image at the odd a of 1, 3, 5 and 7, four runs each (16). The
> fill colour is 0x21426385 throughout (four different bytes).
> 
> No line depends on the console's television type: the VI is switched off and the sound output
> is never used.
> 
> Care for the console: everything here is ordinary. Short lists of four common commands and up
> to two fill-mode rectangles, each list ended by a full sync, into 8-bit, 16-bit and 32-bit
> images, which games do; no fill-mode triangle, no 4-bit image. The memory interface's test mode is on for one
> read at a time, with the instruction cache filled first (hidden_of in probes/fill-8/start.S), as
> the 8-bit fill probe does it on a console.

## Ground no public suite covers

The rule of the 8-bit fill: 344 runs into 64 bytes, at each of eight starts in a group of eight bytes, runs of one to three groups, into a second line, and a 16-bit image off a multiple of eight. Same ground as fill-8.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out fill-8-span` builds it into `out/`. By hand: compile the files under `source/probes/fill-8-span/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `fill-8-span-probe.z64`, 8192 bytes, SHA-256 f56a78481020ea48c8403a51afa27af77095d3f7a4bdceaf69009f60c817d485.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-78 (c1, 2026-11-18T23:21:36): 690 lines; the program was another build, 5007b193adf0172e.
- c1-85 (c1, 2026-11-18T23:48:08): 1050 lines; the program was another build, 5fbea65a6b56687e.
- c1-105 (c1, 2026-11-19T21:32:42): 1178 lines; the program is this set's build.
- c2-46 (c2, 2026-11-21T09:07:55): 1178 lines; the program is this set's build.
- Both consoles ran build f56a78481020ea48: c1-105 and c2-46 give the same lines.
