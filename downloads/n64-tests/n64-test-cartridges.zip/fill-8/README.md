# The fill-8 probe (FILL 8 PROBE)

## What it tests

In the words of its source:

> The 8-bit fill probe: a small test cartridge for a real console.
> 
> What does the RDP write when it fills into an 8-bit colour image? The rule this core follows is
> read from a hardware wiki (each pixel takes the byte of the fill colour that the low two bits
> of the pixel's address pick), and the reference renderer does otherwise, so only a console can
> say. The hidden bits such a fill leaves are known from that renderer alone.
> 
> For each case the probe lays 32 bytes of main memory (the value 0x5A with the lowest bit as
> the case says, so that every hidden bit is known), has the RDP fill a short run of pixels in
> fill mode into an 8-bit colour image, and prints those 32 bytes and their hidden bits. Each
> answer is a line of text through the debug text window a flash cartridge shows on the
> computer beside the console. Run on this core, the same lines show what the core does.
> 
> A line:   tag  a  x  n  s  w0 .. w7  h
>   a   the image begins this many bytes above an address that is a multiple of eight (0 to 3)
>   x   the first pixel filled, counted from the image's first
>   n   how many pixels are filled
>   s   the hidden bits laid before the fill: 0 all clear, 1 all set
>   w0 to w7   the eight words of memory from that multiple of eight
>   h   their hidden bits, a hex digit a word, the first byte's in bit 3
> 
> The lines:
>   F   one line of pixels, the fill colour 0x21426385 (four different bytes, their lowest bits
>       1, 0, 1, 1): every address a, every start x from 0 to 3, n of 1, 2, 3, 4, 5, 8 and 9
>       pixels, over hidden bits laid clear and laid set
>   T   the same colour over two lines of an image 13 pixels wide, so that the second line
>       begins at another place of a group of four: 20 pixels from x 0 and from x 1, which run on
>       into the second line
>   C   three more colours, 4 pixels from x 1 at every address: all zero, all ones, and
>       0x80FE017F
>   E   the same four colours with every byte equal to their first (as games mostly use it)
> 
> No line depends on the console's television type: the VI is not used, nor the sound output.
> 
> Care for the console: everything here is ordinary. Short lists of four common commands, each
> ended by a full sync; fill-mode rectangles into an 8-bit image, which games do; no fill-mode
> triangle, no 4-bit image, nothing the hardware notes warn of. The memory interface's test
> mode is on for one read at a time, with the instruction cache filled first (hidden_of in
> start.S), as the RDP test set that found these bits does it.

## Ground no public suite covers

What the RDP writes when it fills into an 8-bit colour image: 296 runs at four start addresses over hidden bits laid clear or set; 32 bytes and their hidden bits per line. paraLLEl-RDP conformance and snapper64 compare pictures; the hidden bits of 8-bit fills are, to this reading, not covered.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out fill-8` builds it into `out/`. By hand: compile the files under `source/probes/fill-8/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `fill-8-probe.z64`, 8192 bytes, SHA-256 a4082ebaefaba66af4faf569de9b9008f2998642fd0c8584091f863c140dc699.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-73 (c1, 2026-11-18T17:49:01): 298 lines; the program is this set's build.
- c2-45 (c2, 2026-11-21T09:07:24): 298 lines; the program is this set's build.
- Both consoles ran build a4082ebaefaba66a: c1-73 and c2-45 give the same lines.
