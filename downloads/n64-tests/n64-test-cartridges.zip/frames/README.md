# The frames probe (FRAME FILM PROBE)

**A tool for emulators, not a hardware test.** A film of known frames with no end, the known answer for an emulator's frame recorder. It asks a console nothing and has never been run on one.

## What it tests

In the words of its source:

> The frame film probe: a small test cartridge that draws a film of known frames with the RDP.
> 
> A tool that records one frame of a running program (main memory as it stood before the frame's
> first command, and every command word up to its full sync) needs a program whose every frame
> is known in advance. This is that program. It asks nothing of a console; it is the known
> answer the frame recorder is held to.
> 
> Frame n, counted from 0, is one list that stands by itself:
>   the colour image (16 bits a pixel, 320 wide, two megabytes up), the scissor (320 by 240),
>   fill mode, a fill colour that holds n, a rectangle over the whole image in that colour, the
>   fill colour white, a rectangle of 32 by 16 pixels whose corner follows from n, a full sync.
> Before a frame's list is handed over, the probe writes n into the word of memory just below
> the image, straight to memory. So the memory a recorder took before frame n's first command
> holds n in that word, and frame n - 1 in the image.
> 
> The colour of frame n: the 16-bit pixel (n << 1) | 1, taken modulo 32,768 frames.
> The corner of its small rectangle: x = 8 n modulo 256, y = 4 n modulo 200.
> 
> The probe says one line when the film starts and one line after every 256 frames, so that a
> console's log shows it running. The film has no end.
> 
> Care for the console: everything here is ordinary. Fill-mode rectangles into a 16-bit image,
> each list ended by a full sync, the VI left as the boot code left it.

## Ground no public suite covers

A film of known RDP frames with no end, the known answer for the project's frame recorder. It asks a console nothing; it is not a hardware test and covers no gap in the suites.

## How it gives its answer

One line at the start and one every 256 frames on the debug text window. It draws into memory with the VI left as the boot code left it. Nothing judged.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out frames` builds it into `out/`. By hand: compile the files under `source/probes/frames/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `frames-probe.z64`, 8192 bytes, SHA-256 0b78c9aa2ad15bf4721e6a5d7b4e637db056f87e8ba7eeae9bab2a302b5ba932.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**A tool for emulators, not a hardware test.** A film of known frames with no end, the known answer for an emulator's frame recorder. It asks a console nothing and has never been run on one.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

No console run of this probe yet.
