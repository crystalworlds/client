# The hidden-bits probe (HIDDEN BITS PROBE)

## What it tests

In the words of its source:

> The hidden bits probe: a small test cartridge for a real console.
> 
> Every byte of main memory has a ninth bit beside it. The RDP keeps a pixel's coverage in
> them and the VI reads it back. This probe asks what a write by anything else leaves in them,
> and how fast the DP's clock runs. Each answer is a line of text through the debug text window
> a flash cartridge shows on the computer beside the console. Run on this core, the same lines
> show what the core does.
> 
> A hidden value is one hex digit for a 32-bit word: the hidden bits of its four bytes, the
> first byte's in bit 3. All values are in hex.
> 
>   H  16-bit stores: a word's two halves, each with its lowest bit clear or set (four ways)
>   B  one byte stored alone: over hidden bits all clear, then all set; at each of a word's
>      four places; with the byte's lowest bit clear, then set (sixteen ways)
>   W  32-bit stores (four ways), then 64-bit stores (four ways, two digits each)
>   L  stores through the data cache, a byte among them, then the line written back: the
>      line's four words
>   R  one store with the memory interface's repeat mode armed for 16 bytes: those four words
>      and the next
>   P  16 bytes brought from the cartridge by the PI: over hidden bits all clear, then all set;
>      each time the four hidden values, then the four words brought
>   S  the same from the RSP's data memory
>   J  the same for the first 16 of the 64 bytes the SI brings from the PIF
>   K  how far the DP's clock runs while COUNT steps at least 100,000 times: the clock's
>      steps, then COUNT's
> 
> Care for the console: the memory interface's test mode is on for one read at a time, with
> the instruction cache filled first (hidden_of in start.S), as the RDP test set that found
> these bits does it. Nothing else here is out of the ordinary: plain stores, one line of the
> data cache written back, the repeat mode a common library uses to clear memory, and three
> short transfers.

## Ground no public suite covers

The ninth bit beside each byte of main memory: what stores of each size, a written-back cache line, the repeat mode and each kind of DMA leave there, and the DP clock against the CPU counter. No listed suite, to this reading, tests hidden bits outside the RDP's own writes.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out hidden-bits` builds it into `out/`. By hand: compile the files under `source/probes/hidden-bits/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `hidden-bits-probe.z64`, 8192 bytes, SHA-256 a1a28f885e3408d7de5775626e89ef8a8bcc205bf3be1d60fcf8793aed17000f.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

It arms the memory interface's test mode for one read at a time, as its own care note says. It writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-12 (c1, 2026-11-14T10:36:27): 14 lines; the program is this set's build.
- c1-13 (c1, 2026-11-14T10:39:38): 14 lines; the program is this set's build.
- c2-05 (c2, 2026-11-14T11:09:11): 14 lines; the program is this set's build.
- Both consoles ran build a1a28f885e3408d7: c1-13 and c2-05 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
