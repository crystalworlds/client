# The load-4-palette probe (LOAD 4 PALETTE PROBE)

**Warning: this test hangs a real console.** Its first load given while the texture image is set to 4 bits a texel stops the console's drawing unit (the RDP), which then draws nothing until the console is switched off and on again. The test sees that its full sync never came, says so, tries one plain list and ends. Nothing is harmed, but the console must be switched off by hand when it ends.

## What it tests

In the words of its source:

> The 4-bit load probe (../load-4/probe.c says what it asks), built so that a palette load is the
> first load from a 4-bit image the console is given.

## Ground no public suite covers

Loads given while the texture image is set to 4 bits a texel: eleven loads, all of texture memory drawn out in copy mode after each. The public renderers refuse this command and no document describes it; no listed suite covers it. The console's RDP hangs on the first such load, so there are three builds, each putting another load first (tile, block, palette).

## How it gives its answer

Debug text window; if a full sync does not come the probe says so, tries one plain list and ends. Figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out load-4-palette` builds it into `out/`. By hand: compile the files under `source/probes/load-4-palette/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `load-4-palette-probe.z64`, 12288 bytes, SHA-256 ac6da32fb58aab3c744c1683c60eec215c4c2790eb5081857c1873594f649156.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test hangs a real console.** Its first load given while the texture image is set to 4 bits a texel stops the console's drawing unit (the RDP), which then draws nothing until the console is switched off and on again. The test sees that its full sync never came, says so, tries one plain list and ends. Nothing is harmed, but the console must be switched off by hand when it ends.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-138 (c1, 2026-11-20T15:35:31): 165 lines; the program is this set's build.
- c2-49 (c2, 2026-11-21T09:09:38): 165 lines; the program is this set's build.
- Both consoles ran build ac6da32fb58aab3c: c1-138 and c2-49 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
