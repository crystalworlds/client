# The load-4 probe (LOAD 4 PROBE)

**Warning: this test hangs a real console.** Its first load given while the texture image is set to 4 bits a texel stops the console's drawing unit (the RDP), which then draws nothing until the console is switched off and on again. The test sees that its full sync never came, says so, tries one plain list and ends. Nothing is harmed, but the console must be switched off by hand when it ends.

## What it tests

In the words of its source:

> The 4-bit load probe: a small test cartridge for a real console.
> 
> What reaches texture memory when a load command is given while the texture image is set to
> 4 bits a texel? The two public renderers this core is held against refuse the command (one
> stops, one passes it over), and no document says what a console does. So the probe gives such
> loads and reads texture memory back.
> 
> Reading texture memory: the CPU cannot. The probe draws from it, in copy mode, with a tile
> of 16-bit texels, into a 16-bit colour image 64 pixels wide and 32 lines high, one line for
> each 16 words of 64 bits, and each line through a tile of its own that begins at those 16
> words, so that every line is the tile's first row. Copy mode writes a 16-bit texel as it is.
> The 2,048 pixels are then texture memory's 2,048 words of 16 bits in order.
> 
> Before each load all of texture memory is laid with the word 0xEEEE, by a load of the usual
> kind from a 16-bit image. The texture image a case loads from is a stretch of main memory in
> which the 16-bit word number k holds 0x0100 + k: whatever turns up in texture memory says
> which bytes of the image it came from.
> 
> Lines, each through the debug text window a flash cartridge shows on the computer beside the
> console. The id is the case's place in the list below, from 1.
>   L id came              the load's list was run and ended by a full sync: whether the full
>                          sync's interrupt came (1) or the wait ran out (0)
>   B id status clock buf pipe tmem   the DP's status and its four counters after that list
>                          (how long it was busy: a reading of the console's own time, held to
>                          no figure)
>   D id came              the read-out's list was run: whether its full sync came
>   T id first count value step   a run of texture memory that is not the ground: `count` words
>                          of 16 bits from word `first`, the first holding `value`, each later
>                          one `step` more (16 bits, wrapping)
>   N id runs words fold   how many runs, how many words not the ground, and a fold of all
>                          2,048 words
>   R came                 after a list whose full sync did not come: whether a plain list's does
> When a full sync does not come the probe says so and tries one plain list. If that one's does
> not come either the probe ends: the RDP has to be taken as hung, and nothing after it could
> be believed.
> 
> The cases: first no load at all and loads of the usual kind, whose outcome is known (they hold
> the read-out and the pattern to what this core already does), then loads from a 4-bit image: a
> tile load, a block load, loads into tiles of other sizes, a palette load, and one whose
> corners and image width are odd.
> 
> A console's RDP hangs on the first load from a 4-bit image it is given (three runs of this
> probe), so one run can ask about one such load only. The probe is therefore built three
> times: as it stands the tile load comes first of the six, and two small files beside it name
> another case to come first (FIRST_OF_THE_SIX: a block load, a palette load). The ids stay.
> 
> No line depends on the console's television type: the VI is not used, nor the sound output.
> 
> Care for the console: a load from a 4-bit image is what one game of the library does on its
> way to its first screens, so a console has run such a command many times. Should the RDP hang
> on one here, nothing is harmed: it draws nothing until the power is cycled, and the probe
> stops there. Nothing else here is unusual: short lists ended by a full sync, loads, copy-mode
> rectangles.

## Ground no public suite covers

Loads given while the texture image is set to 4 bits a texel: eleven loads, all of texture memory drawn out in copy mode after each. The public renderers refuse this command and no document describes it; no listed suite covers it. The console's RDP hangs on the first such load, so there are three builds, each putting another load first (tile, block, palette).

## How it gives its answer

Debug text window; if a full sync does not come the probe says so, tries one plain list and ends. Figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out load-4` builds it into `out/`. By hand: compile the files under `source/probes/load-4/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `load-4-probe.z64`, 12288 bytes, SHA-256 21f642ea228ad460d72f8b5c8745fe7b86e73e14f1aaedf1abd241d185aac7a8.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test hangs a real console.** Its first load given while the texture image is set to 4 bits a texel stops the console's drawing unit (the RDP), which then draws nothing until the console is switched off and on again. The test sees that its full sync never came, says so, tries one plain list and ends. Nothing is harmed, but the console must be switched off by hand when it ends.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-136 (c1, 2026-11-20T15:31:24): 165 lines; the program is this set's build.
- c2-47 (c2, 2026-11-21T09:08:29): 165 lines; the program is this set's build.
- Both consoles ran build 21f642ea228ad460: c1-136 and c2-47 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
