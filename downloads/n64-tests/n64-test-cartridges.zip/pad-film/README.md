# The pad-film probe (PAD FILM PROBE)

## What it tests

In the words of its source:

> The pad film probe: a small test cartridge that shows a film whose every frame is known, reads
> controller 1 as a game does, once for each field, and plays a tone while A is held.
> 
> A page that shows a machine's picture and feeds it a controller needs a program whose picture
> and whose answer to every press are known in advance, and that is nobody's game. This is that
> program (the project's play page is held to it). It asks nothing of a console that a
> game does not ask.
> 
> It ends the boot first, as every game does (a console's start-up chip holds a program that does
> not), sets the VI to the usual picture of the console's television type (320 by 240 pixels of 16
> bits, resampled to the screen's width and nothing more: no anti-aliasing, no gamma; with the
> resampling off too a console shows a picture this narrow wrongly), and then, once for each field:
> 
>   1. asks controller 1 for its state through the joybus: one exchange, command 1, four bytes back
>      (the button word, then the stick's two counts);
>   2. draws frame n, counted from 0, by plain stores:
>        lines 16 to 23, all 320 pixels: the 16-bit pixel (n << 1) | 1, so every frame differs;
>        lines 4 to 11: sixteen blocks of 12 by 8 pixels, the i-th from the left white when bit
>        15 - i of the button word is set and grey when it is not;
>        a white block of 16 by 16 pixels whose top left corner is at (152 + x, 112 - y) for the
>        stick's counts x and y, kept between lines 32 and 223: where the stick is;
>   3. when the state is not the one last printed, prints it: "PAD bbbb xx yy", in hexadecimal;
>   4. while A is held, keeps the AI fed with a square wave of 64 frames to the cycle, an eighth of
>      full level, the same on both sides: 1,024 frames at a time, queued behind the ones playing.
>      The DAC rate setting is 1521, so on an NTSC console the tone is 499.8 Hz and on a PAL one
>      509.8 Hz. With A let go nothing more is queued, and what was queued plays out.
> 
> A field starts where the VI's line counter starts again. The picture is written through the
> uncached window, because the VI reads memory and not the CPU's data cache.
> 
> A program on a console has no way to wait but to go round a loop. This one waits for the next
> field by looking at the VI's line counter, and between two looks it reads a word of the
> cartridge, which takes the bus a long while. So its wait is a few thousand instructions a field
> where a loop that reads nothing runs more than a million, and a machine that runs instructions
> slower than a console can still keep a console's pace on this program: which is what lets a
> page be tried at full speed, sound and all, before the core is fast enough for a game.
> 
> Care for the console: everything here is ordinary. Nothing is written to a pak or to save memory;
> the tone's buffer does not end at an 8 KiB boundary of memory.

## Ground no public suite covers

A known picture and a known tone driven by controller 1, read once per field as a game reads it, for the project's play page. Not a hardware test.

## How it gives its answer

On screen (it sets the VI itself and draws by plain stores), sound while A is held, and "PAD bbbb xx yy" lines on the debug text window. Nothing judged.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out pad-film` builds it into `out/`. By hand: compile the files under `source/probes/pad-film/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `pad-film-probe.z64`, 12288 bytes, SHA-256 8bf73cfa2d75532a0a25dc31da2c2cfae4d40a907f1470b41c4f0cd79788c926.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

A known picture and a known tone for an emulator's play page more than a hardware test. It writes nothing to a pak or to save memory. It has not been run on a console yet.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

No console run of this probe yet.
