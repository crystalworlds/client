# The pak-check probe (PAK CHECK)

## What it tests

In the words of its source:

> The pak check: a small test cartridge that reads the whole of the Controller Pak in the controller
> in port 1 and prints what it finds as verdicts and checksums, never the pak's own bytes.
> 
> IT SENDS NO WRITE. The only commands it sends are the identity command (0x00) and the pak read
> command (0x02); no frame it builds holds any other command, and there is no routine in it that
> could send a pak write (0x03). Nothing a player has saved can change by running it.
> 
> A Controller Pak is 32,768 bytes: 128 pages of 256 bytes, read as 1,024 blocks of 32. A block
> whose check code does not come right is read again, up to four times in all. The layout the
> verdicts hold the pak to (the n64brew wiki's pages on the Controller Pak and its file system,
> in our own words): page 0 holds the identity block at 0x20 and its copies at 0x60, 0x80 and 0xC0;
> in each, the first checksum is the sum of its first fourteen big-endian 16-bit words and the
> second is 0xFFF2 less the first. Page 1 is the index table and page 2 its copy: two bytes for
> each page, 1 the last page of a note, 3 a free page, 5 to 127 the next page of a note; its byte 1
> is the sum of its bytes 2 to 255, kept to eight bits. Pages 3 and 4 are the note table: 16 notes
> of 32 bytes, the start page in bytes 6 and 7, a note that is all zeros is not in use.
> 
> Each line starts with a short name; every line is in the fold of the last line.
> 
>   I   the identity command, asked twice: the count byte and the status byte of each
>   B   the reads: blocks read whole, blocks read again, blocks never whole, the count byte of the
>       first read that did not come whole (00 if none)
>   D   the identity block, one line for each of its four places (D0 at 0x20, D1 0x60, D2 0x80,
>       D3 0xC0): the first checksum right (1) or not (0), the second right, the block the same as
>       at 0x20, the device bit (bit 0 of byte 0x19), the bank count (byte 0x1A), and a checksum
>       of the block
>   T   the index tables: T0 the table and T1 its copy, each with its stored check right (1) or not,
>       its reserved entries (pages 0 to 4) all zero, and how many of pages 5 to 127 are free (3),
>       end a note (1), lead on (5 to 127) and hold anything else; T2 whether the two tables are
>       the same, byte for byte
>   N   the notes: N0 how many of the 16 are in use, and a mask of which; then for each note in
>       use, its slot, whether its start page lies in 5 to 127, how many pages its chain through
>       the index table holds, how it ends (1 at a page that ends a note, 2 at a free page, 3 at
>       anything else, 4 on a page met twice), and a checksum of its pages in chain order
>   F   the pages: pages free in the table, pages the notes' chains hold, pages neither free nor
>       held by a note (lost), pages held by two notes
>   G   a checksum of every page, eight to a line (G00 for pages 0 to 7 ... G0f for 120 to 127),
>       so that two runs set side by side show any page that changed
> 
> The checksums are this probe's own: FNV-1a of 32 bits over the bytes in order.

## Ground no public suite covers

Reads all 1,024 blocks of a Controller Pak and prints verdicts and checksums: the identity block in four places, the index table and copy, the notes and their chains, free and lost pages, a checksum per page. It never prints the pak's bytes. JoypadTest and n64_controller_test read paks; a full read-only file system check printed as checksums is, to this reading, not in them.

## How it gives its answer

Debug text window. It judges the pak (checksums right or not, chains sound), not the console.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out pak-check` builds it into `out/`. By hand: compile the files under `source/probes/pak-check/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `pak-check-probe.z64`, 12288 bytes, SHA-256 8e8d36be9077200257e4f1304a6ecacb44a9b94bd5c39680805f0250ddec1ffd.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

It only reads: it sends the controller's identity and pak read commands and nothing else. Its lines are checksums of what your Controller Pak holds, so they differ from pak to pak.

## The consoles' answers

In `expected-answers.json`, with the lines themselves left out (they are checksums of the Controller Pak each run read, and differ from pak to pak): **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-89 (c1, 2026-11-19T00:37:18): 31 lines; the program is this set's build.
- c1-90 (c1, 2026-11-19T00:37:59): 31 lines; the program is this set's build.
