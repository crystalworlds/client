# The pi-odd probe (PI ODD CASES)

**Warning: this test overwrites the first 8 KiB of the cartridge's save memory.** Run it only with a blank save, or one you do not need.

## What it tests

In the words of its source:

> The PI's odd cases: a small test cartridge for a real console, run from a flash cartridge whose
> save memory is set to SRAM (the probe needs something on the cartridge bus that can be
> written). It overwrites the first 8 KiB of the save memory.
> 
> The PI probe showed three things on a console that one case each could not explain: a short
> DMA out of memory from a misaligned address left the place's last bytes as they were, the bus
> address register read a value of its own after a reset during a DMA, and a DMA out of memory
> took longer than the same DMA into it. This probe asks each of them over a table of cases.
> 
> All values are in hex.
> 
> T  the eight timing registers as found
> 
> M m l w f e s o r b g
>    A DMA out of memory of l bytes, from a memory address m bytes past a doubleword, to the save
>    memory; then the place is read back. Before it the place was made 0xEE and the PI's buffer
>    was filled with 0x77 by a DMA of 128 such bytes to another place, so that a byte the PI
>    sends from its buffer without having taken it from memory can be told from a byte it never
>    sent. w: how many of the 512 bytes of the place are not what a transfer in order would
>    leave (the l bytes, then 0xEE); f and e: the first and the last of them (all ones when
>    none); s: how many of them hold 0x77; o: how many of them, inside the l bytes, still hold
>    0xEE; r and b: how far the memory address and the bus address moved; g: what the length
>    register reads.
> N d l w f e s o r b g
>    The same from d bytes before the end of a 2 KiB row of memory.
> 
> W l a b c
>    Times, in steps of the CPU's counter (the least of 32 tries, as in the PI probe), of a DMA
>    of l bytes with one timing for all three: a out of memory to the save memory, b out of
>    memory to an address where nothing answers, c into memory from the save memory.
> 
> E l a b c
>    One look at the PI's status after a counted wait, with no loop that asks: a DMA of l bytes
>    into memory is started, so many instructions of one CPU cycle each are run, and the status
>    is read once. The wait is tried at every count from 0 to 1023. a, b, c: the least count at
>    which the look found the transfer ended, with the start set one and two CPU cycles later
>    for b and c (the two clocks stand three to two, so the three cover every way they can
>    meet). A waiting loop sees the end late by up to one of its own turns, and where its looks
>    fall hangs on how long a turn takes; this line does not.
> 
> K n s a i r x y z
>    A DMA of 4 KiB into memory is reset through the status register after a wait that grows
>    with n. s: the status after the reset; a: bytes that had arrived; i: the PI's interrupt
>    line; r: how far the memory address had moved; x, y, z: the bus address register read three
>    times straight after the reset, as it reads.
> J n p q u v
>    After the same reset: p the bus address register after a further wait; q the register read
>    back after 0x10002468 is written to it; u the register after a second reset with nothing
>    running; v the memory address register as it then reads, less the address of the
>    memory the transfer filled (so that the word does not hang on where a build put it).
> K fe, K ff
>    The same three reads after a reset that follows a DMA that had ended (fe), and after a
>    reset with nothing begun since an address was written (ff); s, a, i and r read zero.
> 
> X t p l a b c
>    The times of line W again with another timing for the save memory's part of the bus: t the
>    latch time written and p the pulse width written; the page size and the release stay as in
>    W. If a DMA out of memory sends the address again for each block, its time beyond the same
>    DMA into memory grows with the latch time; if the time is spent taking the bytes out of
>    memory, it does not.
> K 03 to K 0f, J 03 to J 0f
>    The reset of lines K 00 to K 02 at thirteen more moments of the transfer, the last of them
>    after its end. They are printed after the lines of the probe's first build, so that those
>    stand where a run of that build has them.
> 
> EC l h a b n
>    Line E's look made sixteen times over for a DMA of l bytes with the start set h CPU cycles
>    later: a the least and b the greatest of the sixteen answers, n how many of them gave the
>    least. If the end of a transfer itself moves, the sixteen differ.
> KR p a b x
>    A reset after a counted wait, as line E waits: a DMA of 4 KiB into memory is started, so
>    many single-cycle instructions run, the PI is reset through its status register, and the
>    bus address register is read at once. The wait is tried at every count from 0 to 511, in
>    two stretches p: 0 straight after the start, and 1 after a loop of 720 turns of three
>    cycles first, which lies about the end of the transfer's first block. Each line is a run
>    of counts, a to b, that gave the same word x. How many there are hangs on what the
>    register reads.
> 
> The fourth build's lines follow those, so that the others stand where a run of the third
> build has them:
> 
> VF c o w v h
>    The VI as the probe found it: its control register, origin, width, and the two registers
>    that hold a field's and a line's length.
> EV v l e r c0 .. cf
>    Where a DMA of l bytes into memory ends, with the picture in state v: 9 as the probe found
>    it; 0 switched off (the VI's control register cleared, the usual line and field times of
>    the console's television type set); 2 those times with nothing shown, so that no pixel is
>    fetched from memory; 1 a 16-bit picture of 320 pixels a line shown from the third megabyte.
>    e is the least wait at which any of sixteen scans as line EC's found the transfer over.
>    Line E's look is then made 255 times at each of 128 waits, from 8 before e: a line holds
>    sixteen waits, r the first of them less e (a signed byte), and c0 to cf how many of the 255
>    looks at each still found the PI busy. If the end itself moves with what else uses
>    memory, the counts differ with the picture.
> KT m g t n1 .. n6 np x1 x6 xp
>    The bus address register after a reset during a DMA of 4 KiB into memory, the reset made
>    after m turns of a waiting loop. The first read of the register is the 14th instruction after
>    the store that resets, put off by g single-cycle instructions more and by t turns of a
>    loop; then it is read five times more back to back, then once after 4,000 turns of a loop. All of it is done sixteen times: n1 to n6 and np say in how
>    many of the sixteen each read gave a place on the bus (its upper half 0x1000), and x1, x6
>    and xp are the words of the last time. If the register settles with time, a longer wait
>    shows at the first read what the later reads show without one.

## Ground no public suite covers

The PI's odd cases: 156 transfers from misaligned memory addresses, seven lengths timed both ways at four timings, when a transfer ends by one look, and the address register after a reset during a transfer. n64_pi_dma_test covers misaligned DMA into memory; the outward direction, the timings and the reset are, to this reading, not covered.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out pi-odd` builds it into `out/`. By hand: compile the files under `source/probes/pi-odd/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `pi-odd-probe.z64`, 24576 bytes, SHA-256 96aea4902fd03d054064982127c4fc54f7f433ed8ddaf5ac7a0be9ad9cca91f8.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test overwrites the first 8 KiB of the cartridge's save memory.** Run it only with a blank save, or one you do not need.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-62 (c1, 2026-11-18T16:50:37): 179 lines; the program was another build, 51152e7d70f717e6.
- c1-98 (c1, 2026-11-19T20:27:27): 226 lines; the program was another build, 63a41adc6de00c93.
- c1-101 (c1, 2026-11-19T20:48:04): 828 lines; the program was another build, ad532f35342d7b38.
- c1-117 (c1, 2026-11-20T11:04:49): 930 lines; the program is this set's build.
- c1-118 (c1, 2026-11-20T11:08:49): 925 lines; the program is this set's build.
- c2-51 (c2, 2026-11-21T09:10:45): 926 lines; the program is this set's build.
- c2-52 (c2, 2026-11-21T09:11:20): 925 lines; the program is this set's build.
- Both consoles ran build 96aea4902fd03d05: c1-118 and c2-52 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
