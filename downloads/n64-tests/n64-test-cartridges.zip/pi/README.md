# The pi probe (PI PROBE)

**Warning: this test overwrites the first 4 KiB of the cartridge's save memory.** Run it only with a blank save, or one you do not need.

## What it tests

In the words of its source:

> The PI probe: a small test cartridge for a real console, run from a flash cartridge whose save
> memory is set to SRAM (the probe needs something on the cartridge bus that can be written).
> 
> It asks the console the things about the PI that no test set here answers: how a DMA from
> memory to the cartridge bus behaves, how the time of a transfer follows the timing registers,
> what a busy PI does with a second transfer, what its two address registers show while a
> transfer runs, and which timing the disk drive's registers use. It overwrites the first 4 KiB
> of the save memory.
> 
> Times are in ticks of the CPU's clock register (one tick is two CPU cycles), measured by
> reading the clock, starting the thing, asking the PI in a loop whether it is busy, and reading
> the clock again. Each time printed is the least of 32 tries, each begun one CPU cycle later
> than the one before, so that the least depends neither on where the program happened to stand
> against the RCP's clock nor on where the loop's looks happened to fall. One more try comes
> first and is not counted: the first time through, the measuring instructions themselves are
> fetched into the cache, inside the time being measured.
> 
> T   the eight timing registers as found
> R   which read, its time: 01 the game file, 02 the save memory window, 05 the disk drive's
>     registers with the first timing fast and the second slow, 06 the same the other way round
> WT  time until the PI is no longer busy after the CPU's own write to the game file's addresses
> D   bytes, time of a DMA into memory with the usual timing
> DT  latch, pulse, release, page size, time of a DMA of 256 bytes into memory with that timing
> O   case, bytes that arrived wrong, then the first two words at the place written, how far the
>     memory address and the bus address moved, and what the length register reads:
>     00 64 bytes  01 5 bytes  02 16 bytes from a memory address 2 past a doubleword
>     03 300 bytes from such an address  04 200 bytes from 100 before the end of a 2 KiB row of memory
> OT  time of a DMA out of memory of 64 bytes and of 512, and of the same two into memory
> L   during a DMA of 4 KiB into memory: the status, how far the bus address and the memory
>     address have got (four samples, a few hundred cycles apart)
> E   a second transfer started during the first: the status just after, the status at the end,
>     bytes the second one put in its own target, bytes of the first that are wrong, and where
>     the two address registers stand
> X   during a DMA: the word the CPU read from the game file, the word it should be, and the save
>     memory word the CPU tried to write (read afterwards)
> K   a reset through the status register during a DMA: the status after, the bytes that had
>     arrived, the PI's interrupt line, and how far the two address registers had got
> Z   a DMA from where nothing answers, across a page of the bus: four words

## Ground no public suite covers

The PI: DMA from memory out to the cartridge bus, timings, a second transfer while busy, the address registers during a transfer, the disk drive registers' timing. n64_pi_dma_test covers PI DMA into memory; the outward direction and busy cases are, to this reading, not covered.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out pi` builds it into `out/`. By hand: compile the files under `source/probes/pi/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `pi-probe.z64`, 12288 bytes, SHA-256 8a2fcc740252afd09ac5cebc4330d5f3c83dbad0888b14ed1613e1f8fcf98fa1.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test overwrites the first 4 KiB of the cartridge's save memory.** Run it only with a blank save, or one you do not need.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-32 (c1, 2026-11-14T20:39:05): 33 lines; the program is this set's build.
- c1-54 (c1, 2026-11-15T15:52:27): 32 lines; the program is this set's build.
