# The repeat-read probe (REPEAT READ PROBE)

## What it tests

In the words of its source:

> The repeat-read probe: a small test cartridge for a real console.
> 
> On two consoles the hidden bits probe's line for the MI's repeat mode arrived without its
> first letter, in every run (runs c1-12, c1-13, c2-05). That probe armed the repeat mode,
> stored one word into main memory, and in its very next instruction loaded the length of its
> line of text from the data cache; had the load given 140 or more, the probe would have left
> the letter out exactly as the logs show. This probe asks directly what a read gives straight
> after a store in the repeat mode. All values are in hex. Nothing is printed between a store
> and the read that follows it.
> 
>   C k v   the control: no repeat mode. A word that holds 5, in the data cache, loaded k idle
>           instructions after an ordinary store elsewhere (k = 0, 1, 2, 4, 8): what came back
>   A k v   the same with the repeat mode armed for the store: a load from the data cache
>   U k v   the same, the load made without the cache, straight from main memory
>   N k v   the same, the load from a line that is not in the data cache when it is asked for
>   G l t w the hidden bits probe's own three instructions behind the store: the length it
>           loaded, the length as it stands afterwards, and whether the letter was stored
>   M m     the MI's mode register read straight after the store: is the repeat mode still on
>   S a b   the 16 bytes at the store and the 16 bytes behind them, as four words each read
>           back afterwards, folded: was the store repeated over 16 bytes and no further
>   T a     a second store 64 bytes on, with the mode not armed again: its 16 bytes folded: was
>           that one repeated too
>   H h...  the hidden bits of the 16 repeated bytes' four words and of the word behind them,
>           as the hidden bits probe printed them in the line that lost its letter
> 
> No line depends on the console's television type: the probe uses neither the VI nor the
> sound output.
> 
> Care for the console: the repeat mode is the one a common library uses to clear memory, armed
> here for 16 bytes at a time in a part of memory nothing else uses; everything else is plain
> loads and stores.

## Ground no public suite covers

What a read gives straight after a store in the MI's repeat mode, the cause of the hidden-bits probe's lost letter. Not in a listed suite.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out repeat-read` builds it into `out/`. By hand: compile the files under `source/probes/repeat-read/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `repeat-read-probe.z64`, 8192 bytes, SHA-256 57d8a082693b756cb140d55932f2d1b66c475828aff07f1161442e3ce4dea5fa.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-27 (c1, 2026-11-14T20:28:06): 27 lines; the program is this set's build.
- c1-55 (c1, 2026-11-15T15:52:57): 27 lines; the program is this set's build.
