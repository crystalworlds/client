# The rsp-behind probe (RSP BEHIND PROBE)

## What it tests

In the words of its source:

> The rsp-behind probe: what the rest of the machine sees of an RSP that is in the middle of a
> long run of its own instructions.
> 
> The probe was written for the emulator's own use. A faster road keeps the RSP behind the
> machine's time while it runs instructions nothing else can see, and brings it up whenever
> something looks: the CPU through the bus, a word of the SP's DMA, the DP reading its list from
> the RSP's data memory, the host. These are the cases that road has to get right, each with the
> CPU standing well away from the RSP's side until the moment it looks. The probe asks a console
> nothing new and has no console record.
> 
> Each line is one case, in hex:
> 
>   P  the CPU reads the RSP's program counter six times while the RSP counts, each after a wait
>      of its own, then a word of the data memory, then halts the RSP and reads both again.
>   S  single step: the RSP is let go seven times with the single-step bit set; the program
>      counter and the status after each. Then a program that sets the bit itself.
>   D  a DMA into the data memory that the RSP asks for and does not wait for: after so many
>      instructions the RSP loads the transfer's first and last word. The line gives the two
>      words as the RSP found them, for ten counts of instructions around the transfer's time.
>   W  a DMA out of the data memory, with the RSP storing over its first and last word so many
>      instructions after asking: what reached main memory.
>   M  the same transfer with the RSP running on for long: main memory as the CPU finds it
>      after a wait of its own, never having touched the RSP's side.
>   X  the DP reads a list from the RSP's data memory while the RSP keeps storing a count into
>      the list's fill colour: the pixels the rectangle got, the DP's status and how far it
>      read. Then a list whose colour behind the rectangle the RSP keeps storing.
>   H  the CPU writes a word of the instruction memory ahead of the running RSP, and again
>      after halting it: the count the RSP reached.
>   I  a DMA into the instruction memory over instructions the RSP is about to run: the count
>      it reached, for eight places of the transfer.
>   V  a block with vector and scalar instructions side by side, loads, stores, a move from
>      the SP's status behind a vector instruction, a move from the DP's status with an
>      instruction behind it that must wait for the value, a subroutine, a loop: what it
>      stored; and the program counter after ten waits of the CPU, a run each.
>   B  a jump in the delay slot of a jump.
>   L  the RSP counts for three stretches of two and a half fields each, the CPU waiting
>      without a look: the program counter after each, and the count at the end.
> 
> Nothing here can harm a console: every wait has an end, and the picture stays off.

## Ground no public suite covers

What the rest of the machine sees of an RSP in the middle of a long run (PC reads, single step, DMAs the RSP does not wait for, the DP reading from RSP memory, writes ahead of the running RSP). Written for the emulator's own use; asks a console nothing new. Not in a listed suite to this reading.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out rsp-behind` builds it into `out/`. By hand: compile the files under `source/probes/rsp-behind/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `rsp-behind-probe.z64`, 12288 bytes, SHA-256 e12c832302ed7cfa0c164e28fcb0f2f465f5bb8fe7b8f5afd8469cf4430fc162.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak. It has not been run on a console yet.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

No console run of this probe yet.
