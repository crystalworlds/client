# The rsp-blocks probe (RSP BLOCKS PROBE)

## What it tests

In the words of its source:

> The rsp-blocks probe: an RSP that comes to the same instructions again and again, not always in
> the same state and not always before the same words.
> 
> The probe was written for the emulator's own use. A faster road keeps a straight run of the
> RSP's instructions, once its timing is worked out, as a block, and takes the block again
> wherever the RSP stands at the same place. These are the cases in which the same place is not
> the same run. The probe asks a console nothing new and has no console record.
> 
> Each line is one case, in hex:
> 
>   R  the RSP goes round a loop twenty times, then asks for a DMA that brings other words into
>      the instruction memory over the loop's own body, and goes round forty times more: the
>      sum the loop made, the program counter and the status. Three places of the loop.
>   C  the same loop with the CPU writing one word of its body while it runs: the sum, for
>      four waits of the CPU.
>   E  three calls, each by turns to a subroutine with a load in the delay slot of its return
>      and to one without: behind the first call stands an instruction that reads the register
>      just loaded, behind the second a vector instruction that reads the vector register just
>      loaded, behind the third a store, which waits behind a load two cycles back. The second
>      leaves carries in a flag register of the vector unit, which an addition behind the last
>      call takes in.
>      How many rounds the RSP made while the CPU stood away for a fixed time, for three such
>      times, and what it left.
> 
> Nothing here can harm a console: every wait has an end, and the picture stays off.

## Ground no public suite covers

An RSP that comes to the same instructions in other states (code overwritten by DMA, by the CPU, delay-slot loads). For the emulator's own use; asks a console nothing new.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out rsp-blocks` builds it into `out/`. By hand: compile the files under `source/probes/rsp-blocks/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `rsp-blocks-probe.z64`, 8192 bytes, SHA-256 f570beedde7b9c0296e5ea89214a9f76fc58c4d329d8a00ef93dfc1a6e72e228.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak. It has not been run on a console yet.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

No console run of this probe yet.
