# The rsp-dma probe (RSP DMA PROBE)

## What it tests

In the words of its source:

> The probe for how long an SP DMA is busy, read by the RSP itself, and for what asking for one
> costs the main CPU.
> 
> The figures this core uses for an SP DMA's time were chosen to meet a bench that polls the busy
> mark from the main CPU, which moves in steps of about 15 cycles. This probe asks more finely.
> 
> First part, the transfer's own time. The RSP asks for a transfer and then reads the busy mark
> once in every one of its own cycles, 28 times, starting a chosen number of cycles after the
> instruction that asked. The same transfer is asked for again and again with the 28 reads moved
> on by 14 cycles each time, so every cycle after the first 14 is read twice and the cycle in which
> the mark drops is found to the cycle. The main CPU takes no part in what is read.
> 
> The transfers: one to four rows of one word (the start, and the wait before a row); one row of
> 2 and of 8 words (a word); one row of 63, 64, 65, 127, 128 and 129 words (what happens at 64
> words); two rows of 64 and of 65 words. Each both ways. The RSP's side is the upper half of its
> data memory; main memory's side is at 2 MiB, where nothing of the probe lies.
> 
> Each line: T <R or W> <rows> <words> <cycles waited> <the 28 reads>, in hex; R is a transfer
> that reads main memory. The first read is the highest of the 28 bits, and is made in the cycle
> after the cycles waited. A bit is 1 while the transfer is busy.
> 
> Second part, the CPU's side. The bench's console figures for the shortest transfers are met only
> if the CPU's first read after it asks for a transfer comes back some nine cycles later than a
> read after any other store does. Whether a console holds the CPU up there, this part asks: the
> CPU makes a store and then a read, with 0, 8, 16 or 24 empty instructions between them, and
> times the pair with its own count register. The store goes to a register that asks for nothing
> (main memory's address register, P), or to a length register and so asks for a transfer of one
> word (R reads main memory, W writes it). The read is of the SP's status (S) or of a register
> outside the SP (the MI's version, M). Each pair is timed five times.
> 
> Each line: H <P, R or W> <S or M> <empty instructions> <five times in ticks of the count
> register>, in hex. A tick is two CPU cycles.
> 
> The first line ends with the television type the boot code left for the program (0 PAL, 1 NTSC,
> 2 MPAL), so that a log says which console it is from. Nothing else in the probe uses it.

## Ground no public suite covers

How long the RSP's DMA takes, timed by the RSP itself reading its busy mark, so the CPU's bus times are left out. r64emu goldens and rsp-ruination test results, not DMA timing; to this reading no listed suite times it from the RSP side.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out rsp-dma` builds it into `out/`. By hand: compile the files under `source/probes/rsp-dma/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `rsp-dma-probe.z64`, 8192 bytes, SHA-256 e65d5e6446d1ad73d621547a671a6d38d8c6c753295265c8ec6de9ffef7d4478.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-09 (c1, 2026-11-14T10:32:00): 548 lines; the program was an earlier build, not kept.
- c2-11 (c2, 2026-11-14T11:14:24): 548 lines; the program is this set's build.
