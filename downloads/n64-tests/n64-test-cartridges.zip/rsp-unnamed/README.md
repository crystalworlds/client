# The rsp-unnamed probe (RSP UNNAMED PROBE)

## What it tests

In the words of its source:

> The probe for the RSP's vector operations that have no name.
> 
> Twelve of them, in six pairs, each run on four pairs of inputs right after the two loads of its
> sources, as the screen programs for them do: the two loads, the operation, a store of the
> result, then the three parts of the accumulator and the three flag registers. Two test sets say
> different things about four of the first eight (0x3C, 0x3D, 0x3E and 0x3F): whether the first
> three see the loaded values or the registers as they were before the loads, and whether the low
> part of the accumulator reads zero after the last. This probe asks a console, or anything else
> that runs it, and prints what came out as text through the debug text window.
> 
> The last two pairs are a control. Of their four codes, three (0x1C, 0x1E, 0x1F) are known to see
> their sources as they were before the loads on a console, and one (0x1B) the loaded values.
> Whatever runs this probe and shows the loaded values for those three does not have that effect
> at all, and what it shows for the disputed four then says nothing either way.
> 
> Before each pair of operations the two registers, the accumulator and the flags are cleared, so
> that every pair starts as the screen programs start after power-on.
> 
> Each line: R <code> <case> <result> <upper> <middle> <low> <vco> <vcc> <vce>, in hex; the
> vectors as 32 digits.
> 
> The first line ends with the television type the boot code left for the program (0 PAL, 1 NTSC,
> 2 MPAL), so that a log says which console it is from. Nothing else in the probe uses it.

## Ground no public suite covers

The RSP's vector operations with no name, run straight after a vector load, in the cases where four older test programs and n64-systemtest contradict each other. rsp_inval_instrs covers invalid encodings; this probe settles the contradicted cases on PAL consoles.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out rsp-unnamed` builds it into `out/`. By hand: compile the files under `source/probes/rsp-unnamed/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `rsp-unnamed-probe.z64`, 8192 bytes, SHA-256 ae0a7b6e7db09d3547135a21936fd356b1355581e4bc8577f492ab1c8a2bc56c.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-10 (c1, 2026-11-14T10:32:29): 211 lines; the program was an earlier build, not kept.
- c1-11 (c1, 2026-11-14T10:35:54): 210 lines; the program is this set's build.
- c2-10 (c2, 2026-11-14T11:14:00): 210 lines; the program is this set's build.
- Both consoles ran build ae0a7b6e7db09d35: c1-11 and c2-10 give the same lines.
