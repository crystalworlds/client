# The save-step probe (SAVE STEP PROBE)

## What it tests

In the words of its source:

> The save step probe: a small test cartridge for a real console, or rather for the flash cartridge
> it is run from, with its save memory set to SRAM.
> 
> On a console the save probe stopped at its first DMA out of SRAM (runs c1-34 and c1-36, with the
> cartridge tool's save writeback on and off): it had set the second domain's timing to latch 05,
> pulse 0C, page 0F, release 02 and asked for 16 bytes at 0x08007FF0, and the line after that DMA
> never came. With the cartridge set to be FlashRAM the same DMA worked (c1-33). This probe asks the
> same read again, one step at a time, saying each step before it takes it, and gives up on a step
> that does not end. It only reads: nothing is written to the save memory.
> 
> All values are in hex. A timing is the second domain's four registers: latch, pulse, page, release.
> 
>   T l p g r      the timing as the probe found it
>   B n l p g r    said before step n's DMA: the timing it is about to use
>   A n t c s w x  step n's DMA of 16 bytes at 0x08007FF0: t is 1 if it was given up on (the bus still
>                  busy after about 50 ms), c how long it took in steps of the CPU's counter, s the PI's
>                  status after it, w and x the first two words it brought in (all ones if none came)
>   R n t v        step n's read of one word at 0x08000000 by the CPU itself: t as above for the bus
>                  being free first, v the word
> 
> The steps: 0 the timing as found; 1 the maker's library's timing for save memory (05 0C 0D 02);
> 2 the save probe's (05 0C 0F 02); 3 the timing as found again. A step that is given up on resets
> the PI through its status register before the next one. At the end the timing is put back as
> found.
> 
> No line depends on the console's television type.

## Ground no public suite covers

The one 16-byte SRAM read at which the save probe stopped on a console, at four timings, each step said before it is taken and given up after about 50 ms. Same ground as save.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out save-step` builds it into `out/`. By hand: compile the files under `source/probes/save-step/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `save-step-probe.z64`, 8192 bytes, SHA-256 e731f43a8e5b4d8884934b7adeb81d921532af0dac0f3b21409ac3b5ce7c5b56.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

It only reads the save memory.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-44 (c1, 2026-11-15T12:49:51): 15 lines; the program is this set's build.
- c1-56 (c1, 2026-11-15T15:53:27): 15 lines; the program is this set's build.
- c1-60 (c1, 2026-11-18T16:44:15): 15 lines; the program is this set's build.
