# The save-trace probe (SAVE TRACE PROBE)

**Warning: this test overwrites the cartridge's save memory**, as the save test does. Never run it over a save that matters.

## What it tests

In the words of its source:

> The save probe, built to say each step as it takes it: a small test cartridge for a real console.
> 
> On a console the save probe with SRAM printed its first line and then nothing (runs c1-34 and
> c1-36). The DMA it was then making works on a console (c1-44, the save step probe), so the stop
> is somewhere else. This build is the save probe itself (probes/save/probe.c, included whole) with
> four kinds of line added, so that a console's log shows the last step that was begun and whether
> it ended:
> 
>   >  o b n    a DMA is about to start: o 1 out of memory, 0 into it; b the bus address; n bytes
>   <  s        it ended, and the PI's status after it
>   !  s        it was given up on after about 50 ms, with the PI's status; the PI is then reset
>   w  b v      a write by the CPU itself is about to be made: the bus address and the value
>   W  s        the bus was free again after it, and the PI's status (! as above if it never was)
>   .  c        a step of the probe's own, as its letter's code: 74 (t) the timing set, 70 (p) the
>               mark read, 6b (k) the old pattern looked for, 6a (j) the identity read
> 
> Every other line is the save probe's. Its run overwrites the cartridge's save, as the save probe's
> does.

## Ground no public suite covers

The save probe built to print a line before and after each DMA and to give up on one that does not end, to find where the save probe stopped.

## How it gives its answer

Debug text window at 0xB3F00000; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out save-trace` builds it into `out/`. By hand: compile the files under `source/probes/save-trace/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `save-trace-probe.z64`, 16384 bytes, SHA-256 65be2ebd416339f0840d754992f1eb8d83b4d3302d9077b426001808af1b526d.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test overwrites the cartridge's save memory**, as the save test does. Never run it over a save that matters.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-46 (c1, 2026-11-15T13:33:31): 7 lines; the program was another build, fcaaedf63efd0071.
- c1-47 (c1, 2026-11-15T13:36:59): 8 lines; the program was another build, 8e9b1ba62e0e3087.
- c1-48 (c1, 2026-11-15T13:40:06): 67 lines; the program was another build, 8e9b1ba62e0e3087.
