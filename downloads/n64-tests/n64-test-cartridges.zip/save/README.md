# The save probe (SAVE PROBE)

**Warning: this test erases and overwrites the cartridge's save memory**, FlashRAM included. Never run it over a save that matters: use a flash cartridge set to a save you do not need.

## What it tests

In the words of its source:

> The save probe: a small test cartridge for a real console, or rather for the flash cartridge it
> is run from, whose save memory is set to one kind before the probe starts.
> 
> It finds out which kind of save memory is there, tries what the chapter says of that kind, and
> leaves a pattern behind. Run a second time, after the console has been switched off and on, it
> finds the pattern and says how much of it survived. Run here twice, in two machines with the
> save's bytes carried from one to the other by the host, it proves the same of this core.
> 
> It erases and overwrites the save memory: never run it over a save that matters.
> 
> T   the second bus timing's four registers, as found
> PS  the two words where a pattern on SRAM keeps its mark, read before anything is written
> V   (only when a mark is there) part, bytes of the pattern that did not survive, the first of them
> I   eight bytes read after the FlashRAM identity command; J  the CPU's own two reads then
> 
> SRAM:
> A  bytes wrong after 32 KiB written and read back, and the first of them
> M  one word read at 0x100 in the chip, 32 KiB further on, in the second bank's place, and near the window's end
> B  bank, bytes wrong after that bank is written and read back, bytes of the first bank changed by it
> W  a read across the end of the second bank: the word before the end, the word after, the bank's first word
> D  a word written and read back by the CPU itself
> C  a word before and after one byte of it is written by the CPU
> 
> FlashRAM:
> F  the maker and device        Q  bytes 8 to 15 of a sixteen-byte read of the identity
> PF the two words where a pattern on FlashRAM keeps its mark (then V as above)
> S  two reads of the status     U  a status read in the upper half of the window, one at the start after it, one after a new command
> E  status during a sector erase, how long it took (clock ticks, in units of 4096), status after (the status register's 16 bits)
> G  the same for a page program
> R  bytes wrong after page 0 is programmed and read back
> N  bytes wrong after it is programmed again: against both patterns ANDed, against the second alone
> K  the page buffer after 0xA5A5A5A5 and then 0x5A5A5A5A are written to it
> X  a read across the end of the first quarter: the word before the end, the word after, the chip's first word
> O  bytes of page 0 changed by an erase command with nothing set up
> Z  pages written at the end, and every status seen while doing it OR-ed together

## Ground no public suite covers

The cartridge save memory set to one kind before the start (SRAM, three banked SRAM chips, FlashRAM): what it holds, writes, what it holds after a power-off. SaveTest-N64 tells save kinds apart (its questions were restated here); the bank edges, the FlashRAM identity reads and survival across power are, to this reading, not covered there.

## How it gives its answer

Debug text window moved to 0xB3F00000 (the listener must be told); figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out save` builds it into `out/`. By hand: compile the files under `source/probes/save/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `save-probe.z64`, 16384 bytes, SHA-256 7f3eab90d4c1e9b2e5e95fd13badd58143f783a77e9cf37f5151d46ccc633661.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test erases and overwrites the cartridge's save memory**, FlashRAM included. Never run it over a save that matters: use a flash cartridge set to a save you do not need.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-33 (c1, 2026-11-14T20:40:11): 17 lines; the program was another build, a5df9c6aaf00b5eb.
- c1-34 (c1, 2026-11-14T20:41:39): 3 lines; the program was another build, a5df9c6aaf00b5eb.
- c1-35 (c1, 2026-11-14T20:43:15): 1 lines; the program was another build, a5df9c6aaf00b5eb.
- c1-36 (c1, 2026-11-14T20:45:44): 2 lines; the program was another build, a5df9c6aaf00b5eb.
- c1-63 (c1, 2026-11-18T16:55:18): 15 lines; the program is this set's build.
- c1-66 (c1, 2026-11-18T16:59:55): 19 lines; the program is this set's build.
- c1-67 (c1, 2026-11-18T17:00:56): 15 lines; the program is this set's build.
