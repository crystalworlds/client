# The si-joybus probe (JOYBUS PROBE)

## What it tests

In the words of its source:

> The joybus probe: a small test cartridge that talks to the SI and the PIF and prints what comes
> back, as text, through the debug text window. Run on a console it is the answer sheet for the
> rules this core follows; run here, the same lines show what this core does, and the two logs are
> compared line by line.
> 
> It only reads from paks and from the EEPROM: nothing a player has saved is changed. One thing it
> leaves behind on a console until power-off: the SI's error mark, from the test that asks for a
> transfer while another runs.
> 
> Each line starts with a short name. Lines that may differ from one run to the next (times, in
> steps of the CPU's counter, and whatever the player's hands do to a controller) start with T, C
> or H and are left out of the fold in the last line.
> 
>   H   the five registers and the stack pointer the boot code handed over
>   S   the SI's status and the MI's interrupt marks
>   P   the PIF's 64 bytes, read by the CPU, 16 to a line
>   E   the end-of-boot command: status at once, status and interrupts when the SI is idle again
>   G   the SI's registers read back; G2: the memory address after a write and after a read
>   I J the identity command, and the reset command, on each channel: count byte, then the room
>   C   a controller's state
>   U L exchanges that go wrong: an unknown command; too many and too few bytes asked for
>   F   the rules of a frame: padding, the end mark, a line reset, the skip mark, an exchange that
>       does and does not fit, and one frame read twice
>   Q   the command byte after a frame was written, and after it was run
>   R   a read by the CPU from the PIF's memory right after a 64-byte read was started
>   K   the pak in port 1: a read with the right and with a wrong address check, the status after
>   M   the EEPROM: a read of block 0
>   X   a transfer asked for while another runs
>   W   the SI's two 4-byte registers
>   T   times

## Ground no public suite covers

The SI and PIF: registers handed over by the boot firmware, PIF memory, end-of-boot, joybus frame rules (padding, end mark, reset, skip, too many and too few bytes), what empty ports answer, a pak read with right and wrong address checks, a save chip read, a transfer during another, and times. JoypadTest and n64_controller_test exercise controllers and accessories; the frame rules, wrong-check answers and timings are, to this reading, not covered.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out si-joybus` builds it into `out/`. By hand: compile the files under `source/probes/si-joybus/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `si-joybus-probe.z64`, 12288 bytes, SHA-256 bb0eeedcc7b0b147ddacdef7bdaeebfc20d1e790e180f7cf26deb9af20cd25e6.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

It only reads: the controllers, their paks and the save chip. Its K3 line prints the first four bytes of a Controller Pak in controller 1, so its text shows four bytes of your pak. It leaves the serial interface's error mark set until the console is switched off.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-16 (c1, 2026-11-14T10:46:32): 63 lines; the program is this set's build.
- c1-17 (c1, 2026-11-14T10:46:59): 63 lines; the program is this set's build.
- c2-13 (c2, 2026-11-14T11:15:30): 63 lines; the program is this set's build.
- c1-39 (c1, 2026-11-14T20:56:39): 63 lines; the program is this set's build.
- c1-41 (c1, 2026-11-14T21:01:09): 63 lines; the program is this set's build.
- c1-43 (c1, 2026-11-15T12:49:13): 63 lines; the program is this set's build.
- c1-45 (c1, 2026-11-15T12:51:20): 63 lines; the program is this set's build.
- c1-51 (c1, 2026-11-15T13:45:25): 63 lines; the program is this set's build.
- c1-53 (c1, 2026-11-15T15:51:56): 63 lines; the program is this set's build.
- c1-58 (c1, 2026-11-18T16:40:11): 63 lines; the program is this set's build.
- c1-107 (c1, 2026-11-20T08:09:39): 63 lines; the program is this set's build.
- c1-114 (c1, 2026-11-20T09:12:50): 63 lines; the program is this set's build.
- c1-122 (c1, 2026-11-20T12:05:36): 63 lines; the program is this set's build.
- c1-127 (c1, 2026-11-20T12:18:02): 63 lines; the program is this set's build.
- c1-130 (c1, 2026-11-20T12:25:20): 63 lines; the program is this set's build.
- c1-131 (c1, 2026-11-20T12:25:51): 63 lines; the program is this set's build.
- c2-55 (c2, 2026-11-21T09:15:08): 63 lines; the program is this set's build.
- Both consoles ran build bb0eeedcc7b0b147: c1-131 and c2-55 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
