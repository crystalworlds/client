# The si-pak probe (PAK PROBE)

**Warning: this test can send one write to a controller's pak:** 32 zero bytes to pak address 0x8000, which is outside a Controller Pak's memory, sent only when the controller has just answered that no pak is in. Everything else it sends only reads. Use a Controller Pak whose saves you have copied, or none.

## What it tests

In the words of its source:

> The pak probe: a small test cartridge that asks the controller in port 1 about the pak in it,
> and prints what comes back through the debug text window. It is for a console with one
> standard controller in port 1: with a Controller Pak in it, with a Rumble Pak, and with none.
> 
> It only reads. It sends the identity command, the pak read command and one command no device
> knows; it never sends a pak write, so nothing a player has saved can change.
> 
> Each line starts with a short name. Lines that start with T are times, in steps of the CPU's
> counter, and lines that start with C hang on what a hand does to the controller; both are left
> out of the fold in the last line.
> 
>   Q   a pak read at 0x8000 with the right address check, sent before the controller has been
>       asked anything: the count byte, the check code that came, and the probe's own code of the
>       32 bytes. It says whether a pak that is in from power-on answers before the first
>       identity command
>   S   the identity command, asked twice: the count byte, then the three bytes of the reply
>   R   a pak read with the right address check: the count byte, the 32 bytes that came, the check
>       code that came with them, and the check code of those 32 bytes as this probe works it out.
>       R0 at 0x8000, R1 at 0x8020, R2 at 0xC000, R3 at 0xFFE0, R4 at 0x8000 again: none of these
>       is a Controller Pak's memory
>   P   a pak read at address 0, the start of a Controller Pak's memory: the count byte, the check
>       code that came, and the probe's own code of the 32 bytes. The bytes are not printed
>   X   a pak read with a wrong address check: the count byte, the first four bytes of the room,
>       its last byte, and the status byte of an identity command asked straight after.
>       X0 0x8000 with the lowest check bit turned, X1 0x8000 with the highest, X2 address 0
>       with the lowest, X3 address 0 with all five, X4 0x7FE0 with the second, X5 0xFFE0 with
>       the third
>   T   times, each for a frame written twice and read straight after: T0 a pak read at 0x8000
>       with the right check, T1 the same read with a wrong check, T2 a command no device knows,
>       T3 the identity command
>   W   a pak write, sent only when the controller has just said that no pak is in it (bit 0 of
>       its status clear), so that a pak is never written: 32 zero bytes to 0x8000, which is no
>       part of a Controller Pak's memory. The line gives the status asked just before, then
>       the write's count byte, the byte that came back, and the status asked straight after.
>       The check code of 32 zero bytes is 00, and ff when turned over. With a pak in, or with
>       nothing answering, the line says that the write was not sent. It is the probe's last
>       line, so that every line before it stands where a run without it has it
>   Y   a pak read with a wrong address check, then the identity asked twice in a row, then a
>       read with its right check and the identity once more: the three status bytes. It says
>       whether asking the identity takes the mark of the wrong check (bit 2) off the status, or
>       only the next pak command does. Y1 then asks the other half: a read with a wrong check,
>       a read with its right check straight after, and the identity once: the one status byte
>       says whether a good pak command takes the mark off too. Reads only. They come after
>       line W, for the same reason
>   C   the watch. For five seconds, and for five more after each change, the probe asks a pak
>       read at 0x8000 and then the identity, over and over, and prints a line whenever the
>       answers change: the time in milliseconds since the watch began, the read's count byte,
>       what kind of answer it was (0 none, 1 bytes with their right check code, 2 bytes with the
>       code turned over, 3 anything else), the identity's count byte and its status byte. A
>       hand that pulls the pak out and pushes it back in while the watch runs shows what the
>       controller says of a pak taken out and of one put in. Left alone it prints one line

## Ground no public suite covers

A controller's pak: whether a pak in from power-on answers before the first identity command, what lies past a Controller Pak's end, whether wrong address checks are answered, times, a pak pulled and pushed by hand, a write only when the controller says no pak is in. The differences between the maker's and a third-party controller came from it. Not in a listed suite to this reading.

## How it gives its answer

Debug text window; lines starting T (times) and C (hand-made changes) are left out of the fold. Figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out si-pak` builds it into `out/`. By hand: compile the files under `source/probes/si-pak/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `si-pak-probe.z64`, 12288 bytes, SHA-256 4e065da4cffd4e703c5044cfcad810df8aebf2652921467ce315943f81292bdc.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test can send one write to a controller's pak:** 32 zero bytes to pak address 0x8000, which is outside a Controller Pak's memory, sent only when the controller has just answered that no pak is in. Everything else it sends only reads. Use a Controller Pak whose saves you have copied, or none.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-61 (c1, 2026-11-18T16:48:16): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-100 (c1, 2026-11-19T20:41:49): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-109 (c1, 2026-11-20T08:56:48): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-110 (c1, 2026-11-20T08:58:48): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-112 (c1, 2026-11-20T09:09:43): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-113 (c1, 2026-11-20T09:11:02): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-119 (c1, 2026-11-20T12:01:35): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-120 (c1, 2026-11-20T12:03:34): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-121 (c1, 2026-11-20T12:04:40): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-123 (c1, 2026-11-20T12:09:58): 23 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-124 (c1, 2026-11-20T12:11:52): 25 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-125 (c1, 2026-11-20T12:14:51): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-126 (c1, 2026-11-20T12:16:44): 22 lines; the program was another build, c4c92bcf7a06dbbc.
- c1-128 (c1, 2026-11-20T12:19:09): 23 lines; the program was another build, 3d766ad459a5dbdd.
- c1-129 (c1, 2026-11-20T12:20:33): 23 lines; the program was another build, 3d766ad459a5dbdd.
- c1-132 (c1, 2026-11-20T12:33:16): 24 lines; the program was another build, d48157dccc733a99.
- c1-133 (c1, 2026-11-20T12:33:52): 24 lines; the program was another build, d48157dccc733a99.
- c1-134 (c1, 2026-11-20T12:35:19): 25 lines; the program is this set's build.
- c1-135 (c1, 2026-11-20T12:35:55): 25 lines; the program is this set's build.
- c1-141 (c1, 2026-11-20T20:32:43): 24 lines; the program was another build, f32eeee89461e5ff.
- c1-142 (c1, 2026-11-20T20:34:46): 24 lines; the program was another build, f32eeee89461e5ff.
- c2-53 (c2, 2026-11-21T09:12:56): 24 lines; the program was another build, f32eeee89461e5ff.
- c2-54 (c2, 2026-11-21T09:13:31): 24 lines; the program was another build, f32eeee89461e5ff.
- Both consoles ran build f32eeee89461e5ff: c1-142 and c2-54 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
