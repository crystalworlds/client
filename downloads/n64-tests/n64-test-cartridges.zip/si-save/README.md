# The si-save probe (SAVE PROBE)

**Warning: this test overwrites save data.** It writes every block of the cartridge's serial save chip (the EEPROM), and every run it writes the first 32 bytes of any Controller Pak in controller 1. If Z is held on controller 1 when it starts, it overwrites the whole Controller Pak. Run it only with a save chip whose contents you do not need, take every Controller Pak out of the controllers before switching on (or use one whose saves you do not need), and never hold Z while it starts.

## What it tests

In the words of its source:

> The save probe: a small test cartridge that shows whether what is written to the cartridge's
> EEPROM and to a Controller Pak is still there at the next start.
> 
> Each run prints what it finds, writes something new that depends on a run number it keeps in the
> EEPROM's first block, and prints what is there afterwards. Run twice with the power off in
> between, the "before" lines of the second run must be the "after" lines of the first.
> 
> The EEPROM is the probe's own save, so every block of it is written. A Controller Pak may hold a
> player's saves, so only its first 32 bytes are written (a place the pak's file system does not
> use), unless Z is held on controller 1 at the start: then every byte of the pak is overwritten.
> 
>   I4  the EEPROM's identity (count byte, three bytes)
>   EB  the EEPROM before: a block number, then that block and the three after it
>   N   the run number found, and the one this run writes
>   EW  block writes taken, and refused because the chip was still busy
>   T0  the longest wait for the chip to stop being busy, in steps of the CPU's counter (and the
>       shortest); left out of the fold in the last line, as it differs from run to run
>   EA  the EEPROM after
>   C0  controller 1's state at the start (left out of the fold)
>   K0  controller 1's identity
>   KL  the pak's first 32 bytes before
>   KB  the pak before: a page number and a fold of its 256 bytes
>   KW  what was written: 0 the first 32 bytes only, 1 everything; blocks written; check codes that
>       did not come back right
>   KM  the pak's first 32 bytes after
>   KA  the pak after

## Ground no public suite covers

Whether what is written to the cartridge's serial save chip (4 or 16 kilobit) and to a Controller Pak is still there at the next start: before, write, after, run twice across a power-off. SaveTest-N64 tests the save chip in both sizes; survival across power-off, and the pak side, are to this reading not covered.

## How it gives its answer

Debug text window; figures only. Its KL and KM lines print the pak's first 32 bytes.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out si-save` builds it into `out/`. By hand: compile the files under `source/probes/si-save/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `si-save-probe.z64`, 12288 bytes, SHA-256 0db4bf77be91b4b12edbff6bf4c3e11b923dcc42c083c848c9b5e1a9220c3483.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**Warning: this test overwrites save data.** It writes every block of the cartridge's serial save chip (the EEPROM), and every run it writes the first 32 bytes of any Controller Pak in controller 1. If Z is held on controller 1 when it starts, it overwrites the whole Controller Pak. Run it only with a save chip whose contents you do not need, take every Controller Pak out of the controllers before switching on (or use one whose saves you do not need), and never hold Z while it starts.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-37 (c1, 2026-11-14T20:47:55): 40 lines; the program is this set's build.
- c1-38 (c1, 2026-11-14T20:49:58): 40 lines; the program is this set's build.
- c1-115 (c1, 2026-11-20T09:14:04): 40 lines; the program is this set's build.
