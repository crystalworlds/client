#!/usr/bin/env bash
# Build the Nintendo 64 test cartridges (49 probes) from probes/, one .z64 each.
#
#   IPL3=/path/to/ipl3_compat.z64 ./build.sh <out-dir> [probe ...]     (default: every probe)
#
# Needs python3 and the MIPS compiler mips64-elf-gcc with its objcopy (the test files were built
# with GCC 16.2.0; set CC= and OBJCOPY= if they are not on the path), and libdragon's open boot
# code, boot/bin/ipl3_compat.z64 from github.com/DragonMinded/libdragon at commit
# 39d0d6096130836a65710da6730290701d060272 (SHA-256 5632e081...2188, the Unlicense; not vendored here).
# Each probe: its probe.json's sources compiled and linked in that order with link.ld, the flat
# block taken with objcopy, and pack.py puts it behind the boot code with the title from probe.json.
# verify.sh compares each result with manifest.txt.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
P="$HERE/probes"
OUT="${1:?usage: IPL3=/path/to/ipl3_compat.z64 ./build.sh <out-dir> [probe ...]}"; shift
CC="${CC:-mips64-elf-gcc}"; OBJCOPY="${OBJCOPY:-mips64-elf-objcopy}"
command -v "$CC" >/dev/null 2>&1 || { echo "COULD NOT RUN: $CC not found (set CC=)"; exit 3; }
command -v "$OBJCOPY" >/dev/null 2>&1 || { echo "COULD NOT RUN: $OBJCOPY not found (set OBJCOPY=)"; exit 3; }
[ -f "${IPL3:-}" ] || { echo "COULD NOT RUN: set IPL3= to libdragon's boot/bin/ipl3_compat.z64"; exit 3; }
CFLAGS="-march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls
 -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,$P/link.ld
 -Wl,--build-id=none"
mkdir -p "$OUT"
if [ $# -eq 0 ]; then set -- $(cd "$P" && for d in */; do [ -f "$d/probe.json" ] && echo "${d%/}"; done); fi
fail=0; built=0
for n in "$@"; do
  D="$P/$n"
  [ -f "$D/probe.json" ] || { echo "NO SUCH PROBE $n"; fail=1; continue; }
  title=$(python3 -c "import json,sys; print(json.load(open(sys.argv[1], encoding='utf-8'))['title'])" "$D/probe.json")
  srcs=$(python3 -c "import json,sys; print(' '.join(json.load(open(sys.argv[1], encoding='utf-8'))['sources']))" "$D/probe.json")
  W="$OUT/work/$n"; rm -rf "$W"; mkdir -p "$W"
  # shellcheck disable=SC2086
  if ! (cd "$D" && "$CC" $CFLAGS $srcs -lgcc -o "$W/$n.elf") >"$W/build.log" 2>&1; then
    echo "FAILED to build $n (see $W/build.log)"; fail=1; continue
  fi
  "$OBJCOPY" -O binary "$W/$n.elf" "$W/$n.bin"
  python3 "$HERE/pack.py" "$IPL3" "$W/$n.bin" "$title" "$OUT/$n-probe.z64"
  built=$((built+1))
done
echo "built $built test file(s) into $OUT"
exit $fail
