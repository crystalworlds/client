#!/usr/bin/env python3
# Make a Nintendo 64 test file from a probe's flat program block, the way build.sh does it:
#   python3 pack.py <ipl3_compat.z64> <block.bin> <title> <out.z64>
# The first 4,096 bytes are libdragon's open boot code (boot/bin/ipl3_compat.z64 at commit
# 39d0d6096130836a65710da6730290701d060272), unchanged but for three header fields:
#   0x08  the load address, 0x80000400 (the boot code already holds it)
#   0x10  the block's length in bytes (big-endian), rounded up to a whole 8 bytes with zero bytes, and 0 at 0x14
#   0x20  the title from the probe's probe.json, 20 bytes, filled out with spaces
# The block follows at 0x1000, and the file is padded with zero bytes to a whole 4 KiB.
#
#   python3 pack.py --check <ipl3_compat.z64> <test.z64> <title>
# takes a built test file apart and packs it again: prints OK when the result is the same file.
import hashlib, sys

IPL3_SHA256 = '5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188'

def pack(boot, block, title):
    if hashlib.sha256(boot).hexdigest() != IPL3_SHA256:
        sys.exit('pack.py: the boot code is not ipl3_compat.z64 at the pinned commit (SHA-256 differs)')
    block = block + bytes(-len(block) % 8)     # the block is rounded up to a whole 8 bytes, and that length goes at 0x10
    t = title.encode('ascii')
    if len(t) > 20:
        sys.exit('pack.py: title longer than 20 bytes: ' + title)
    h = bytearray(boot)
    h[0x08:0x0C] = (0x80000400).to_bytes(4, 'big')
    h[0x10:0x14] = len(block).to_bytes(4, 'big')
    h[0x14:0x18] = bytes(4)
    h[0x20:0x34] = t.ljust(20, b' ')
    out = bytes(h) + block
    return out + bytes(-len(out) % 4096)

if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == '--check':
        boot, z, title = open(a[1], 'rb').read(), open(a[2], 'rb').read(), a[3]
        n = int.from_bytes(z[0x10:0x14], 'big')
        again = pack(boot, z[0x1000:0x1000 + n], title)
        print('OK' if again == z else 'DIFFERS')
        sys.exit(0 if again == z else 1)
    if len(a) != 4:
        sys.exit(__doc__ if __doc__ else 'usage: pack.py <ipl3_compat.z64> <block.bin> <title> <out.z64>')
    boot, block = open(a[0], 'rb').read(), open(a[1], 'rb').read()
    open(a[3], 'wb').write(pack(boot, block, a[2]))
