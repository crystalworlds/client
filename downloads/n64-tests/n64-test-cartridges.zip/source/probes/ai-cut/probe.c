/* The AI cut probe: a small test cartridge for a real console.

   A console empties a playing transfer the moment the AI's bit rate is written zero. This probe
   asks what goes with that: whether the cut raises the AI's interrupt, what becomes of a second
   transfer waiting behind the first, whether anything comes back when the bit rate is set again,
   and what the AI's output side still holds after a cut, as far as a register can show it: a
   transfer written afterwards can fetch at once only if the place ahead of the playing one is
   free. Each answer is a line of text through the debug text window a flash cartridge shows on
   the computer beside the console.

   Every case starts from rest, with the sample clock at 1103 (the setting the AI probe uses) and
   the interrupt taken back; a transfer plays silence from memory the probe clears.

   Lines (every value in hex; times are steps of COUNT, which may differ a little from run to run):
     U1  len status intr  len status intr     0x800 playing for 20 sample periods, the interrupt
                                              taken back, the bit rate written zero: the length,
                                              the status (busy, full, enabled and the fixed bits)
                                              and the MI's AI interrupt bit, at once and 40 periods on
     U2  the same                             0x800 and 0x800 written, so that one waits (full)
     U3  len status steps ok                  U1, then the bit rate back, then 0x100 written at once:
                                              its length and status straight after, and the time
                                              until busy clears (ok 1 if it did within half a second)
     U4  len0 len20 len40 status              U1 with the bit rate written 1, not zero: the length at
                                              once, 20 and 40 periods on
     U5  len status intr  len status          the bit rate zero while at rest, 0x800 written, the bit
                                              rate back after 5 periods: at once, and 20 periods on
     U6  before during after later status     0x800 playing, the bit rate zero for one read of the
                                              length, then back at once: the lengths read before,
                                              between, straight after and 20 periods on
     X1  intr status intr intr intr           U2 with the MI's bit read at each step: after the
                                              take-back and before the cut (with the status then),
                                              straight after the cut, after a second take-back, and
                                              40 periods on
     V1 to V9  len status steps ok            U3 with the bit rate held at zero for a while, or with
                                              a wait between the bit rate's return and the length:
                                              zero for 40 periods (V1); a wait of 40, 1, 2, 3 and 5
                                              periods (V2 to V6); zero for 1, 2 and 4 periods (V7 to V9)
     R1 to R3  len status steps ok            the same length written at rest, with no cut: as it
                                              stands (R1), after the bit rate went to zero and came
                                              straight back (R2), and after 40 periods at zero (R3)
     C1, C2  zero s1 s2 s3                    the sample clock's counter in the status (with its
                                              word clock and bit clock) while the bit rate is zero
                                              at rest, and at three reads straight after it is set
                                              again; C2 sets it 300 steps later than C1 does
     C3  before zero s1 s2                    the same about a cut: just before it, at zero, and at
                                              two reads after the bit rate is back
     X2  len intr intr intr                   U2 with the MI's bit read at the second and at the
                                              third access after the cut and no take-back between
                                              (the first access reads the length), and 40 periods on:
                                              does the interrupt come before the place where X1's
                                              second take-back stands, or after it
     D0 to D7  before zero l1 l2 l3 steps ok  at rest, the bit rate to zero and straight back at
                                              eight places of a sample period, then 0x100: the clocks
                                              just before zero and at zero, the length at three reads
                                              straight after the write, and the time until busy
                                              clears. Where does the first sample boundary lie after
                                              the return, the word clock having stood high or low?
     Bf Be B7 B3 B1  zero steps ok            the same start with the bit rate set to 15, 14, 7, 3 and
                                              1 at the return: does the bit clock pace the fetches?
     E1 E2 E3 E5  s0 s1 s2                    which write starts the counter anew: the clocks before
                                              a write and at two reads straight after it. E1 the bit
                                              rate written as it stands, E2 the bit rate one less,
                                              E3 the DAC rate as it stands, E5 a length at rest
     E4  s0 to s11                            the DAC rate written twice as long, and the clocks at
                                              eleven looks through the sample period that follows:
                                              at which turn of the word clock does it take hold
     F0 to F7  where l1 l2 l3 l4              the first two fetches of a transfer from rest: the
                                              clocks just before the write, then the length at four
                                              reads, the first of them 0, 2, 4 up to 14 turns of a
                                              short idle loop after the write
     W0 to Wf  len before steps ok            a cut at sixteen places of the two sample periods a
                                              doubleword plays for, the bit rate straight back, then
                                              0x100: the length and the clocks just before the cut,
                                              and the time until busy clears
   Each line three times.

   The sample clock runs from the video clock, so the times are a PAL console's when read from one.

   Care for the console: everything here is ordinary. The sound output plays silence; its bit rate
   is set to zero and back as the AI register probe has done on two consoles. */

#include "../cart-lib/say.h"

#define AI(off) REG32(0xA4500000u + (off))
#define AI_ADDR AI(0x00)
#define AI_LEN AI(0x04)
#define AI_CONTROL AI(0x08)
#define AI_STATUS AI(0x0C)
#define AI_DACRATE AI(0x10)
#define AI_BITRATE AI(0x14)
#define MI_INTR REG32(0xA4300008u)

#define MARKS 0xC3100001u                       /* full (twice), busy, the fixed bits, enabled */
#define CLOCKS 0x00097FFEu                      /* the word clock, the bit clock and the counter */
#define HALF_SECOND 23437500u                   /* in steps of COUNT */
#define DAC 1103u
#define SILENCE 0x00200010u                     /* no transfer here ends at an 8 KiB boundary */

static void pause(u32 steps) { u32 t = count_now(); while (count_now() - t < steps) { } }
static u32 bit_rate_for(u32 dac) { u32 b = (dac + 1u) / 66u; if (b > 16u) b = 16u; if (b < 2u) b = 2u; return b - 1u; }
static u32 period_steps(u32 dac) { return (u32)(((u64)(dac + 1u) * 963u) / 1000u) + 1u; }   /* one sample period in steps of COUNT, near enough */
static void periods(u32 n) { pause(n * period_steps(DAC)); }

/* Waits until nothing plays, then takes the interrupt away. Zero if the AI never came to rest. */
static int settle(void) {
    AI_CONTROL = 1; AI_DACRATE = DAC; AI_BITRATE = bit_rate_for(DAC);
    u32 t = count_now();
    while (AI_STATUS & 0xC0000001u) if (count_now() - t > HALF_SECOND) return 0;
    pause(8u * period_steps(2208u));
    AI_STATUS = 0;
    return 1;
}
static int until_clear(u32 bits, u32 *steps) {
    u32 t = count_now();
    for (;;) { u32 s = AI_STATUS, now = count_now(); if (!(s & bits)) { *steps = now - t; return 1; } if (now - t > HALF_SECOND) { *steps = now - t; return 0; } }
}
static void stuck(const char *tag) { say_text(tag); say_hex(0xDEAD, 4); say_flush(); }
static void three(void) { const u32 l = AI_LEN, s = AI_STATUS & MARKS, i = MI_INTR & 4u; say_hex(l, 5); say_hex(s, 8); say_hex(i, 1); }

/* A transfer of `bytes` playing for 20 periods, the interrupt taken back, then the bit rate `to`. */
static void cut(u32 bytes, u32 twice, u32 to) {
    AI_ADDR = SILENCE; AI_LEN = bytes;
    if (twice) { AI_ADDR = SILENCE; AI_LEN = bytes; }
    periods(20);
    AI_STATUS = 0;
    AI_BITRATE = to;
}

static void u1(void) { if (!settle()) { stuck("U1"); return; } cut(0x800, 0, 0); say_text("U1"); three(); periods(40); three(); say_flush(); }
static void u2(void) { if (!settle()) { stuck("U2"); return; } cut(0x800, 1, 0); say_text("U2"); three(); periods(40); three(); say_flush(); }
static void u3(void) {
    if (!settle()) { stuck("U3"); return; }
    cut(0x800, 0, 0);
    AI_BITRATE = bit_rate_for(DAC);
    AI_STATUS = 0;
    AI_ADDR = SILENCE; AI_LEN = 0x100;
    const u32 l = AI_LEN, s = AI_STATUS & MARKS;
    u32 steps; const int ok = until_clear(0x40000000u, &steps);
    say_text("U3"); say_hex(l, 5); say_hex(s, 8); say_hex(steps, 8); say_hex(ok ? 1u : 0u, 1); say_flush();
}
static void u4(void) {
    if (!settle()) { stuck("U4"); return; }
    cut(0x800, 0, 1);
    const u32 l0 = AI_LEN; periods(20); const u32 l20 = AI_LEN; periods(20); const u32 l40 = AI_LEN, s = AI_STATUS & MARKS;
    say_text("U4"); say_hex(l0, 5); say_hex(l20, 5); say_hex(l40, 5); say_hex(s, 8); say_flush();
}
static void u5(void) {
    if (!settle()) { stuck("U5"); return; }
    AI_BITRATE = 0;
    AI_ADDR = SILENCE; AI_LEN = 0x800;
    periods(5);
    AI_BITRATE = bit_rate_for(DAC);
    say_text("U5"); three(); periods(20); { const u32 l = AI_LEN, s = AI_STATUS & MARKS; say_hex(l, 5); say_hex(s, 8); } say_flush();
}
static void u6(void) {
    if (!settle()) { stuck("U6"); return; }
    AI_ADDR = SILENCE; AI_LEN = 0x800;
    periods(20);
    const u32 before = AI_LEN;
    AI_BITRATE = 0;
    const u32 during = AI_LEN;
    AI_BITRATE = bit_rate_for(DAC);
    const u32 after = AI_LEN;
    periods(20);
    const u32 later = AI_LEN, s = AI_STATUS & MARKS;
    say_text("U6"); say_hex(before, 5); say_hex(during, 5); say_hex(after, 5); say_hex(later, 5); say_hex(s, 8); say_flush();
}

/* The interrupt of a cut with a transfer waiting, read at each step. */
static void x1(void) {
    if (!settle()) { stuck("X1"); return; }
    AI_ADDR = SILENCE; AI_LEN = 0x800;
    AI_ADDR = SILENCE; AI_LEN = 0x800;
    periods(20);
    AI_STATUS = 0;
    const u32 i0 = MI_INTR & 4u, s0 = AI_STATUS & MARKS;
    AI_BITRATE = 0;
    const u32 i1 = MI_INTR & 4u;
    AI_STATUS = 0;
    const u32 i2 = MI_INTR & 4u;
    periods(40);
    const u32 i3 = MI_INTR & 4u;
    say_text("X1"); say_hex(i0, 1); say_hex(s0, 8); say_hex(i1, 1); say_hex(i2, 1); say_hex(i3, 1); say_flush();
}

/* The same cut with no second take-back: the MI's bit at the second and the third access after it. */
static void x2(void) {
    if (!settle()) { stuck("X2"); return; }
    cut(0x800, 1, 0);
    const u32 l = AI_LEN;
    const u32 i2 = MI_INTR & 4u;
    const u32 i3 = MI_INTR & 4u;
    periods(40);
    const u32 i4 = MI_INTR & 4u;
    say_text("X2"); say_hex(l, 5); say_hex(i2, 1); say_hex(i3, 1); say_hex(i4, 1); say_flush();
}

/* A length of 0x100 written now: what it reads straight after, and how long until busy clears. */
static void play_and_time(const char *tag) {
    AI_STATUS = 0;
    AI_ADDR = SILENCE; AI_LEN = 0x100;
    const u32 l = AI_LEN, s = AI_STATUS & MARKS;
    u32 steps; const int ok = until_clear(0x40000000u, &steps);
    say_text(tag); say_hex(l, 5); say_hex(s, 8); say_hex(steps, 8); say_hex(ok ? 1u : 0u, 1); say_flush();
}
/* A cut, the bit rate held at zero for `hold` periods, set again, and `wait` periods more. */
static void after_cut(const char *tag, u32 hold, u32 wait) {
    if (!settle()) { stuck(tag); return; }
    cut(0x800, 0, 0);
    if (hold) periods(hold);
    AI_BITRATE = bit_rate_for(DAC);
    if (wait) periods(wait);
    play_and_time(tag);
}
/* No cut: the bit rate at zero for `hold` periods while at rest (not at all when `zero` is clear). */
static void at_rest(const char *tag, u32 zero, u32 hold) {
    if (!settle()) { stuck(tag); return; }
    if (zero) { AI_BITRATE = 0; if (hold) periods(hold); AI_BITRATE = bit_rate_for(DAC); }
    play_and_time(tag);
}
/* The sample clock's counter as the status shows it, about the bit rate's return. */
static void counter_at_rest(const char *tag, u32 more) {
    if (!settle()) { stuck(tag); return; }
    AI_BITRATE = 0;
    pause(3u * period_steps(DAC) + more);
    const u32 z = AI_STATUS & CLOCKS;
    AI_BITRATE = bit_rate_for(DAC);
    const u32 s1 = AI_STATUS & CLOCKS, s2 = AI_STATUS & CLOCKS, s3 = AI_STATUS & CLOCKS;
    say_text(tag); say_hex(z, 8); say_hex(s1, 8); say_hex(s2, 8); say_hex(s3, 8); say_flush();
}
static void counter_at_a_cut(void) {
    if (!settle()) { stuck("C3"); return; }
    AI_ADDR = SILENCE; AI_LEN = 0x800;
    periods(20);
    const u32 before = AI_STATUS & CLOCKS;
    AI_BITRATE = 0;
    const u32 z = AI_STATUS & CLOCKS;
    AI_BITRATE = bit_rate_for(DAC);
    const u32 s1 = AI_STATUS & CLOCKS, s2 = AI_STATUS & CLOCKS;
    say_text("C3"); say_hex(before, 8); say_hex(z, 8); say_hex(s1, 8); say_hex(s2, 8); say_flush();
}

/* ---- Where the sample clock starts, and what paces a fetch ---------------------------------- */

static const char *const digit16[16] = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };
static void say_tag(const char *kind, u32 i) { say_text(kind); say_text(digit16[i & 15u]); }
static void stuck_tag(const char *kind, u32 i) { say_tag(kind, i); say_hex(0xDEAD, 4); say_flush(); }

/* At rest, the bit rate to zero and straight back at a chosen place of a sample period, then 0x100. */
static void start_by_word_clock(u32 i) {
    if (!settle()) { stuck_tag("D", i); return; }
    pause(i * 137u);
    const u32 before = AI_STATUS & CLOCKS;
    AI_BITRATE = 0;
    const u32 z = AI_STATUS & CLOCKS;
    AI_BITRATE = bit_rate_for(DAC);
    AI_STATUS = 0;
    AI_ADDR = SILENCE; AI_LEN = 0x100;
    const u32 l1 = AI_LEN, l2 = AI_LEN, l3 = AI_LEN;
    u32 steps; const int ok = until_clear(0x40000000u, &steps);
    say_tag("D", i); say_hex(before, 8); say_hex(z, 8); say_hex(l1, 5); say_hex(l2, 5); say_hex(l3, 5); say_hex(steps, 8); say_hex(ok ? 1u : 0u, 1); say_flush();
}

/* The same start with another bit rate set at the return. */
static void pace_by_bit_rate(u32 rate) {
    if (!settle()) { stuck_tag("B", rate); return; }
    AI_BITRATE = 0;
    const u32 z = AI_STATUS & CLOCKS;
    AI_BITRATE = rate;
    AI_STATUS = 0;
    AI_ADDR = SILENCE; AI_LEN = 0x100;
    u32 steps; const int ok = until_clear(0x40000000u, &steps);
    say_tag("B", rate); say_hex(z, 8); say_hex(steps, 8); say_hex(ok ? 1u : 0u, 1); say_flush();
}

/* Which write starts the counter anew, and when a new DAC rate takes hold. */
static void start_by_which_write(void) {
    u32 s0, s1, s2;
    if (!settle()) { stuck("E1"); return; }
    s0 = AI_STATUS & CLOCKS; AI_BITRATE = bit_rate_for(DAC); s1 = AI_STATUS & CLOCKS; s2 = AI_STATUS & CLOCKS;
    say_text("E1"); say_hex(s0, 8); say_hex(s1, 8); say_hex(s2, 8); say_flush();
    if (!settle()) { stuck("E2"); return; }
    s0 = AI_STATUS & CLOCKS; AI_BITRATE = bit_rate_for(DAC) - 1u; s1 = AI_STATUS & CLOCKS; s2 = AI_STATUS & CLOCKS;
    say_text("E2"); say_hex(s0, 8); say_hex(s1, 8); say_hex(s2, 8); say_flush();
    if (!settle()) { stuck("E3"); return; }
    s0 = AI_STATUS & CLOCKS; AI_DACRATE = DAC; s1 = AI_STATUS & CLOCKS; s2 = AI_STATUS & CLOCKS;
    say_text("E3"); say_hex(s0, 8); say_hex(s1, 8); say_hex(s2, 8); say_flush();
    if (!settle()) { stuck("E4"); return; }
    {
        u32 s[12];
        s[0] = AI_STATUS & CLOCKS;
        AI_DACRATE = 2u * DAC + 1u;
        for (u32 i = 1; i < 12u; i++) { s[i] = AI_STATUS & CLOCKS; pause(100); }
        say_text("E4"); for (u32 i = 0; i < 12u; i++) say_hex(s[i], 8); say_flush();
    }
    if (!settle()) { stuck("E5"); return; }
    AI_ADDR = SILENCE;
    s0 = AI_STATUS & CLOCKS; AI_LEN = 0x100; s1 = AI_STATUS & CLOCKS; s2 = AI_STATUS & CLOCKS;
    { u32 steps; until_clear(0x40000000u, &steps); }
    say_text("E5"); say_hex(s0, 8); say_hex(s1, 8); say_hex(s2, 8); say_flush();
}

/* The first two fetches of a transfer from rest, looked at more finely. */
static void first_fetches(u32 i) {
    if (!settle()) { stuck_tag("F", i); return; }
    AI_ADDR = SILENCE;
    const u32 where = AI_STATUS & CLOCKS;
    AI_LEN = 0x100;
    for (u32 k = 0; k < 2u * i; k++) __asm__ volatile("nop");
    const u32 l1 = AI_LEN, l2 = AI_LEN, l3 = AI_LEN, l4 = AI_LEN;
    { u32 steps; until_clear(0x40000000u, &steps); }
    say_tag("F", i); say_hex(where, 8); say_hex(l1, 5); say_hex(l2, 5); say_hex(l3, 5); say_hex(l4, 5); say_flush();
}

/* A cut at a chosen place of the two sample periods a doubleword plays for, the bit rate straight back, then 0x100. */
static void standing_by_place(u32 i) {
    if (!settle()) { stuck_tag("W", i); return; }
    AI_ADDR = SILENCE; AI_LEN = 0x800;
    periods(20); pause(i * 137u);
    AI_STATUS = 0;
    const u32 len = AI_LEN, before = AI_STATUS & CLOCKS;
    AI_BITRATE = 0;
    AI_BITRATE = bit_rate_for(DAC);
    AI_STATUS = 0;
    AI_ADDR = SILENCE; AI_LEN = 0x100;
    u32 steps; const int ok = until_clear(0x40000000u, &steps);
    say_tag("W", i); say_hex(len, 5); say_hex(before, 8); say_hex(steps, 8); say_hex(ok ? 1u : 0u, 1); say_flush();
}

void probe_main(void) {
    u32 status;
    __asm__ volatile("mfc0 %0, $12" : "=r"(status));
    status &= ~1u;                              /* no interrupt is ever taken: the lines are read at the MI */
    __asm__ volatile("mtc0 %0, $12" : : "r"(status));
    for (u32 i = 0; i < 0x2000u; i += 4) REG32(0xA0000000u + (SILENCE & ~0xFu) + i) = 0;   /* silence */
    say_head("AICUT");
    for (u32 run = 0; run < 3u; run++) { u1(); u2(); u3(); u4(); u5(); u6(); }
    for (u32 run = 0; run < 3u; run++) {
        x1();
        after_cut("V1", 40, 0); after_cut("V2", 0, 40); after_cut("V3", 0, 1); after_cut("V4", 0, 2); after_cut("V5", 0, 3); after_cut("V6", 0, 5);
        after_cut("V7", 1, 0); after_cut("V8", 2, 0); after_cut("V9", 4, 0);
        at_rest("R1", 0, 0); at_rest("R2", 1, 0); at_rest("R3", 1, 40);
        counter_at_rest("C1", 0); counter_at_rest("C2", 300); counter_at_a_cut();
        x2();
    }
    for (u32 run = 0; run < 3u; run++) {
        for (u32 i = 0; i < 8u; i++) start_by_word_clock(i);
        pace_by_bit_rate(15); pace_by_bit_rate(14); pace_by_bit_rate(7); pace_by_bit_rate(3); pace_by_bit_rate(1);
        start_by_which_write();
        for (u32 i = 0; i < 8u; i++) first_fetches(i);
        for (u32 i = 0; i < 16u; i++) standing_by_place(i);
    }
    settle();
    say_tail("AICUT");
}
