/* The level probe: a small test cartridge for a sound recorder on a real console's sound output.

   It plays four short sounds with half a second of nothing after each: a held level, half way up;
   the same level again; the same level the other way; and a square wave of 44 frames to the cycle
   at that level. Each lasts 4,096 frames with the DAC rate setting at 1103 (93 ms on an NTSC
   console). What a recording shows between and after them says what the DAC is fed while the AI
   has nothing to play, which no register shows. If it goes back to nothing, each held level has a
   step at both its ends. If it keeps the last level, the first has no step at its end and the
   second, being the same level, shows nothing at all. The square wave gives the height of a known
   swing to measure the rest against.

   It prints when each sound started and how long the AI stayed busy with it, in steps of the CPU's
   Count register (46.875 MHz), through the debug text window, and never waits for ever. The four
   lines are printed after the last sound: no time printed here has a text inside it, and nothing
   is handed to the cartridge while a recording of the sounds and the silences is being made. */

typedef unsigned int u32;
typedef unsigned long long u64;

#define REG(a) (*(volatile u32 *)(a))
#define AI_ADDR REG(0xA4500000u)
#define AI_LEN REG(0xA4500004u)
#define AI_CONTROL REG(0xA4500008u)
#define AI_STATUS REG(0xA450000Cu)
#define AI_DACRATE REG(0xA4500010u)
#define AI_BITRATE REG(0xA4500014u)
#define PI_STATUS REG(0xA4600010u)
#define TEXT_LENGTH REG(0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)

#define DAC_RATE 1103u
#define LEVEL 16384
#define FRAMES 4096u
#define SQUARE_CYCLE 44u
#define HALF_SECOND 23437500u

static u32 count(void) { u32 v; __asm__ volatile("mfc0 %0, $9" : "=r"(v)); return v; }
static void pause(u32 steps) { u32 t = count(); while (count() - t < steps) { } }

#include "../debug-text.h"

static void say(const char *s, u32 n) {
    debug_text(s, n);
}

static char line[160];
static u32 at, lines;
static u64 fold;
static void put(const char *s) { while (*s) line[at++] = *s++; }
static void dec(u32 v) { char b[10]; int n = 0; do { b[n++] = (char)('0' + v % 10u); v /= 10u; } while (v); line[at++] = ' '; while (n) line[at++] = b[--n]; }
static void hex(u32 v) { for (int i = 7; i >= 0; i--) { u32 d = (v >> (i * 4)) & 15u; line[at++] = (char)(d < 10 ? '0' + d : 'a' + d - 10); } }
static void end(void) {
    line[at++] = '\n';
    for (u32 i = 0; i < at; i++) fold = (fold ^ (unsigned char)line[i]) * 0x100000001B3ull;
    say(line, at);
    lines++;
}

/* One buffer, placed so that it does not end at an 8 KiB boundary of memory. */
static unsigned char pool[0x6100] __attribute__((aligned(16)));

/* Frame n of sound number `which`, as the 32 bits the AI plays: the same on both sides. */
static u32 frame(u32 which, u32 n) {
    int v = which == 2u ? -LEVEL : which == 3u ? ((n % SQUARE_CYCLE) < SQUARE_CYCLE / 2u ? LEVEL : -LEVEL) : LEVEL;
    return ((u32)(v & 0xFFFF) << 16) | (u32)(v & 0xFFFF);
}

void probe_main(void) {
    u32 status;
    __asm__ volatile("mfc0 %0, $12" : "=r"(status));
    status &= ~1u;
    __asm__ volatile("mtc0 %0, $12" : : "r"(status));

    u32 buffer = ((((u32)pool + 0x1FFFu) & ~0x1FFFu) + 0x10u) | 0xA0000000u;
    volatile u32 *p = (volatile u32 *)buffer;

    at = 0; put("LEVELPROBE 1 DACRATE"); dec(DAC_RATE); put(" LEVEL"); dec(LEVEL); put(" FRAMES"); dec(FRAMES); put(" SQUARE"); dec(SQUARE_CYCLE); put(" TV"); dec(REG(0x80000300u)); end();

    AI_CONTROL = 1; AI_DACRATE = DAC_RATE; AI_BITRATE = 15; AI_STATUS = 0;
    u32 t = count();
    while (AI_STATUS & 0xC0000001u) if (count() - t > HALF_SECOND) break;
    pause(HALF_SECOND / 5u);

    u32 first = 0, started[4], busy[4], gave_up[4];
    for (u32 which = 0; which < 4u; which++) {
        for (u32 i = 0; i < FRAMES; i++) p[i] = frame(which, i);
        AI_ADDR = buffer;
        u32 began = count();
        AI_LEN = FRAMES * 4u;
        if (which == 0u) first = began;
        gave_up[which] = 0;
        while (AI_STATUS & 0x40000000u) if (count() - began > HALF_SECOND) { gave_up[which] = 1; break; }
        busy[which] = count() - began;
        started[which] = began - first;
        pause(HALF_SECOND);
    }
    for (u32 which = 0; which < 4u; which++) {
        at = 0; put("SOUND"); dec(which); put(" STARTED"); dec(started[which]); put(" BUSY"); dec(busy[which]); put(" GAVE-UP"); dec(gave_up[which]); end();
    }

    at = 0; put("LEVELPROBE END "); hex(lines); line[at++] = ' '; hex((u32)(fold >> 32)); hex((u32)fold); line[at++] = '\n';
    say(line, at);
}
