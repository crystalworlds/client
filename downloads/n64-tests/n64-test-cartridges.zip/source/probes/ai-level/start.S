# The first instruction of the probe: a stack well below the top of the
# smallest memory a console has, then the C code. It never returns.
    .set noreorder
    .section .text.entry, "ax"
    .globl _start
_start:
    lui   $sp, 0x803F
    jal   probe_main
    addiu $sp, $sp, -32
1:  b     1b
    nop
