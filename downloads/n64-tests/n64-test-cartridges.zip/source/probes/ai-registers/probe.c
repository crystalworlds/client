/* The AI register probe: a small test cartridge for a real console.

   It programs the sound output in a dozen ways and prints what it reads back, as text, through
   the debug text window a flash cartridge shows on the computer beside the console. Every
   experiment asks one question the sources do not agree on, or that nobody has written down:
   when the interrupt comes, what the length reads while a transfer plays, what a length written
   at an odd moment does, and how long a sample period really is. It plays only silence.

   Run here, the same lines show what this core does; the two logs are then compared token by
   token. A plain token must be the same on a console. A token that starts with ~ is a time in
   steps of the CPU's Count register (46.875 MHz) or a count that depends on one, and need only be
   close. A token that starts with ? depends on the moment the question was asked, or is a fact
   about the console that this core does not claim to know: it is recorded, not compared.

   Nothing here waits for ever: every wait gives up after half a second and says so. */

typedef unsigned int u32;
typedef unsigned long long u64;

#define REG(a) (*(volatile u32 *)(a))
#define AI(off) REG(0xA4500000u + (off))
#define AI_ADDR AI(0x00)
#define AI_LEN AI(0x04)
#define AI_CONTROL AI(0x08)
#define AI_STATUS AI(0x0C)
#define AI_DACRATE AI(0x10)
#define AI_BITRATE AI(0x14)
#define MI_INTR REG(0xA4300008u)
#define PI_STATUS REG(0xA4600010u)
#define TEXT_LENGTH REG(0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)

#define MARKS 0xC2000001u               /* full (twice), busy, enabled */
#define HALF_SECOND 23437500u           /* in steps of Count */

static u32 count(void) { u32 v; __asm__ volatile("mfc0 %0, $9" : "=r"(v)); return v; }
static void pause(u32 steps) { u32 t = count(); while (count() - t < steps) { } }

#include "../debug-text.h"

/* ---- Text ---------------------------------------------------------------------------------- */

static void say(const char *s, u32 n) {
    debug_text(s, n);
}

static char line[200];
static u32 at, lines;
static u64 fold;

static void put(const char *s) { while (*s) line[at++] = *s++; }
static void hex(u32 v) { for (int i = 7; i >= 0; i--) { u32 d = (v >> (i * 4)) & 15u; line[at++] = (char)(d < 10 ? '0' + d : 'a' + d - 10); } }
static void dec(u32 v) { char b[10]; int n = 0; do { b[n++] = (char)('0' + v % 10u); v /= 10u; } while (v); while (n) line[at++] = b[--n]; }
static void begin(const char *tag) { at = 0; put(tag); }
static void x(u32 v) { line[at++] = ' '; hex(v); }                      /* must be the same on a console */
static void d(u32 v) { line[at++] = ' '; dec(v); }
static void near(u32 v) { line[at++] = ' '; line[at++] = '~'; dec(v); }  /* need only be close */
static void seen(u32 v) { line[at++] = ' '; line[at++] = '?'; hex(v); }  /* recorded, not compared */
static void word(const char *s) { line[at++] = ' '; put(s); }
/* A length read a moment after it was written may or may not have lost its first 8 bytes, as the
   sample clock falls: whether it lies in a range is the fact, and the value itself is recorded. */
static void within(u32 v, u32 above, u32 up_to) { x(v > above && v <= up_to ? 1u : 0u); seen(v); }
static void end(void) {
    line[at++] = '\n';
    for (u32 i = 0; i < at; i++) fold = (fold ^ (unsigned char)line[i]) * 0x100000001B3ull;
    say(line, at);
    lines++;
}

/* ---- The AI -------------------------------------------------------------------------------- */

/* Silence to play: a stretch of memory that no transfer here ends at an 8 KiB boundary of. */
static unsigned char pool[0xA000] __attribute__((aligned(16)));
static u32 buffer;                      /* its address as a program hands it over: in the uncached window */

static u32 bit_rate_for(u32 dac) { u32 b = (dac + 1u) / 66u; if (b > 16u) b = 16u; if (b < 2u) b = 2u; return b - 1u; }
static u32 period_steps(u32 dac) { return (u32)(((u64)(dac + 1u) * 963u) / 1000u) + 1u; }   /* one sample period in steps of Count, near enough */

/* Waits until nothing plays, then takes the interrupt away. Zero if the AI never came to rest.
   Busy falls while a transfer's last frames are still to go out, the first of them at the rate
   that was set before: the wait after it is eight sample periods of the slowest setting used here,
   by when they are out and the new rate has taken hold. */
static int settle(u32 dac) {
    AI_CONTROL = 1; AI_DACRATE = dac; AI_BITRATE = bit_rate_for(dac);
    u32 t = count();
    while (AI_STATUS & 0xC0000001u) if (count() - t > HALF_SECOND) return 0;
    pause(8u * period_steps(2208u));
    AI_STATUS = 0;
    return 1;
}
static int until_clear(u32 bits, u32 *when) {
    u32 t = count();
    for (;;) { u32 s = AI_STATUS; u32 now = count(); if (!(s & bits)) { *when = now; return 1; } if (now - t > HALF_SECOND) { *when = now; return 0; } }
}
static void stuck(const char *tag) { begin(tag); word("STUCK"); end(); }

/* The registers as the boot left them, and what the fixed bits of status read. */
static void at_rest(void) {
    begin("R0");
    for (u32 off = 0; off < 0x20u; off += 4) seen(AI(off));
    end();
    if (!settle(1103)) { stuck("R1"); return; }
    begin("R1"); x(AI_STATUS & 0xC3100001u); x(AI_LEN); x(MI_INTR & 4u); end();     /* at rest: enabled, the two fixed bits, no length, no interrupt */
    AI_CONTROL = 0;
    begin("R2"); x(AI_STATUS & 0xC3100001u); end();
    AI_CONTROL = 1;
}

/* The counter in status: standing still with the bit rate at zero, moving otherwise. */
static void status_counter(void) {
    if (!settle(1103)) { stuck("S0"); return; }
    AI_BITRATE = 0;
    pause(4000);
    u32 a = AI_STATUS, b, c;
    pause(40000); b = AI_STATUS; pause(40000); c = AI_STATUS;
    begin("S0"); x((a == b && b == c) ? 1u : 0u); seen(a); end();                   /* 1: it stands still */
    AI_BITRATE = bit_rate_for(1103);
    pause(4000);
    u32 max = 0, min = 0xFFFFu, word_high = 0, bit_high = 0, moved = 0, prev = AI_STATUS;
    for (u32 i = 0; i < 2048u; i++) {
        u32 s = AI_STATUS, n = (s >> 1) & 0x3FFFu;
        if (n > max) max = n;
        if (n < min) min = n;
        if (s & 0x00080000u) word_high++;
        if (s & 0x00010000u) bit_high++;
        if (s != prev) moved++;
        prev = s;
    }
    begin("S1"); x(moved > 1000u ? 1u : 0u); near(max); seen(min); near(word_high); seen(bit_high); end();
}

/* A transfer started while nothing plays: is the interrupt up at once, is busy up at once, what
   does the length read, and does a second interrupt come when it ends? */
static void start_from_idle(void) {
    if (!settle(1103)) { stuck("A1"); return; }
    AI_ADDR = buffer;
    u32 t0 = count();
    AI_LEN = 0x400;
    u32 mi = MI_INTR, st = AI_STATUS, len = AI_LEN;
    begin("A1"); x(mi & 4u); x(st & MARKS); within(len, 0x3C0, 0x400); end();
    AI_STATUS = 0;
    u32 t1; int ok = until_clear(0x40000000u, &t1);
    begin("A2"); x(ok ? 1u : 0u); x(MI_INTR & 4u); near(t1 - t0); end();
    AI_STATUS = 0;
}

/* The length's steps while one transfer plays: how many, how large, how far apart, and how long
   after the last of them busy falls (in whole sample periods). */
static u32 first_step, zero_at;         /* when the length first fell, and when it reached zero */
static int watch_length(u32 dac, u32 bytes, u32 *steps, u32 *smallest, u32 *largest, u32 *write_at) {
    AI_ADDR = buffer;
    u32 prev = bytes, n = 0, lo = 0xFFFFFFFFu, hi = 0;
    *write_at = count();
    AI_LEN = bytes;
    for (;;) {
        u32 v = AI_LEN, now = count();
        if (v != prev) {
            u32 by = prev - v;
            if (n == 0) first_step = now;
            n++;
            if (by < lo) lo = by;
            if (by > hi) hi = by;
            prev = v;
            if (v == 0) { zero_at = now; break; }
        }
        if (now - *write_at > HALF_SECOND) return 0;
    }
    *steps = n; *smallest = lo; *largest = hi;
    (void)dac;
    return 1;
}
static void length_steps(void) {
    u32 n, lo, hi, t0, idle;
    if (!settle(1103)) { stuck("B1"); return; }
    if (!watch_length(1103, 0x200, &n, &lo, &hi, &t0)) { stuck("B1"); return; }
    int ok = until_clear(0x40000000u, &idle);
    begin("B1"); d(n); d(lo); d(hi); end();
    begin("B2"); seen(first_step - t0); near(zero_at - first_step); end();
    begin("B3"); x(ok ? 1u : 0u); d((idle - zero_at + period_steps(1103) / 2u) / period_steps(1103)); end();
    AI_STATUS = 0;
}

/* The sample period: the time from the length's first step to its last, for odd and even settings.
   The steps are two sample periods apart whenever the transfer started, so the time between the
   first and the last does not depend on that moment. */
static void sample_period(u32 dac) {
    u32 n, lo, hi, t0;
    if (!settle(dac)) { stuck("P"); return; }
    if (!watch_length(dac, 0x2000, &n, &lo, &hi, &t0)) { stuck("P"); return; }
    begin("P"); d(dac); d(n - 1u); near(zero_at - first_step); end();
    u32 idle; until_clear(0x40000000u, &idle);
    AI_STATUS = 0;
}

/* Two transfers: full at once, no interrupt for the second, and at the moment full falls: busy
   still up, the interrupt up, and the length the second one's. Then how long the second one plays. */
static void two_transfers(void) {
    if (!settle(1103)) { stuck("Q1"); return; }
    AI_ADDR = buffer;
    u32 t0 = count();
    AI_LEN = 0x400;
    AI_STATUS = 0;
    AI_ADDR = buffer + 0x400u;
    AI_LEN = 0x800;
    u32 st = AI_STATUS, mi = MI_INTR, len = AI_LEN;
    begin("Q1"); x(st & MARKS); x(mi & 4u); within(len, 0x300, 0x400); end();
    u32 t1; int ok = until_clear(0x80000001u, &t1);
    len = AI_LEN; mi = MI_INTR; st = AI_STATUS;
    begin("Q2"); x(ok ? 1u : 0u); x(st & MARKS); x(mi & 4u); within(len, 0x700, 0x800); near(t1 - t0); end();
    AI_STATUS = 0;
    u32 t2; ok = until_clear(0x40000000u, &t2);
    begin("Q3"); x(ok ? 1u : 0u); x(MI_INTR & 4u); near(t2 - t1); end();
    AI_STATUS = 0;
}

/* A third length while two transfers are held: dropped, or does it take the waiting one's place? */
static void third_length(void) {
    if (!settle(1103)) { stuck("F"); return; }
    AI_ADDR = buffer;
    AI_LEN = 0x100; AI_LEN = 0x300; AI_LEN = 0x500;
    u32 t1; int ok = until_clear(0x80000001u, &t1);
    u32 len = AI_LEN;
    begin("F"); x(ok ? 1u : 0u); d(len > 0x200u && len <= 0x300u ? 3u : len > 0x400u && len <= 0x500u ? 5u : 0u); seen(len); end();     /* 3: the second length plays; 5: the third took its place */
    until_clear(0x40000000u, &t1);
    AI_STATUS = 0;
}

/* A length of zero while nothing plays. */
static void zero_length(void) {
    if (!settle(1103)) { stuck("Z1"); return; }
    AI_ADDR = buffer;
    AI_LEN = 0;
    u32 mi = MI_INTR, st = AI_STATUS;
    begin("Z1"); x(mi & 4u); seen(st & MARKS); end();
    pause(8u * period_steps(1103));
    begin("Z2"); x(AI_STATUS & MARKS); x(MI_INTR & 4u); end();
    AI_STATUS = 0;
}

/* A length with a bit above the 18 the register keeps. */
static void oversize_length(void) {
    if (!settle(1103)) { stuck("O1"); return; }
    AI_ADDR = buffer;
    AI_LEN = 0x00040040u;
    u32 mi = MI_INTR, st = AI_STATUS, len = AI_LEN;
    begin("O1"); x(mi & 4u); x(st & MARKS); within(len, 0, 0x40); end();
    u32 t1; int ok = until_clear(0x40000000u, &t1);
    begin("O2"); x(ok ? 1u : 0u); end();
    AI_STATUS = 0;
}

/* The enable bit clear: is the transfer held without moving, and does its interrupt come? */
static void not_enabled(void) {
    if (!settle(1103)) { stuck("E1"); return; }
    AI_CONTROL = 0;
    AI_ADDR = buffer;
    AI_LEN = 0x100;
    u32 mi = MI_INTR, st = AI_STATUS, len = AI_LEN;
    begin("E1"); x(mi & 4u); x(st & MARKS); x(len); end();
    pause(200u * period_steps(1103));
    begin("E2"); x(AI_STATUS & MARKS); x(AI_LEN); end();
    u32 t0 = count();
    AI_CONTROL = 1;
    len = AI_LEN;
    u32 t1; int ok = until_clear(0x40000000u, &t1);
    begin("E3"); x(ok ? 1u : 0u); end();
    begin("E4"); seen(len); near(t1 - t0); end();   /* what the length reads as soon as the bit is set, and how long the transfer then takes */
    AI_STATUS = 0;
}

/* The bit rate setting at zero: does a transfer still move? */
static void clock_stopped(void) {
    if (!settle(1103)) { stuck("K1"); return; }
    AI_BITRATE = 0;
    AI_ADDR = buffer;
    AI_LEN = 0x100;
    pause(200u * period_steps(1103));            /* three times as long as it plays */
    begin("K1"); x(MI_INTR & 4u); x(AI_STATUS & MARKS); x(AI_LEN); end();
    AI_BITRATE = bit_rate_for(1103);
    u32 t1; int ok = until_clear(0x40000000u, &t1);
    begin("K2"); x(ok ? 1u : 0u); end();
    AI_STATUS = 0;
    /* And how long does it take with the setting at zero? The same length as in A2, timed the same way. */
    if (!settle(1103)) { stuck("K3"); return; }
    AI_BITRATE = 0;
    AI_ADDR = buffer;
    u32 t0 = count();
    AI_LEN = 0x400;
    ok = until_clear(0x40000000u, &t1);
    begin("K3"); x(ok ? 1u : 0u); near(t1 - t0); end();
    AI_BITRATE = bit_rate_for(1103);
    AI_STATUS = 0;
}

/* The first two doublewords of a transfer started from rest: how long after the write the length
   takes its first step, and its second, with the write at eight different places in a sample
   period. Status is read just before the write: its counter and word clock say where that was. */
static void first_two_fetches(void) {
    static const char *const tags[8] = { "G0", "G1", "G2", "G3", "G4", "G5", "G6", "G7" };
    for (u32 i = 0; i < 8u; i++) {
        if (!settle(1103)) { stuck(tags[i]); return; }
        pause(50u + i * 137u);
        AI_ADDR = buffer;
        u32 where = AI_STATUS, t0 = count();
        AI_LEN = 0x100;
        u32 first = 0, second = 0, prev = 0x100, n = 0;
        for (;;) {
            u32 v = AI_LEN, now = count();
            if (v != prev) {
                if (n == 0) first = now - t0;
                if (n == 1 || prev - v >= 16u) { second = now - t0; break; }
                n++; prev = v;
            }
            if (now - t0 > 8u * period_steps(1103)) break;
        }
        begin(tags[i]); seen(where & 0x00097FFEu); seen(first); seen(second); end();
        u32 t1; until_clear(0x40000000u, &t1);
        AI_STATUS = 0;
    }
}

/* A length written at the moment busy falls, while the last frames of the transfer before it are
   still to go out: what the length reads at once, and how long until its first step. */
static void into_the_tail(void) {
    if (!settle(1103)) { stuck("T1"); return; }
    AI_ADDR = buffer;
    AI_LEN = 0x100;
    u32 t0; int ok = until_clear(0x40000000u, &t0);
    AI_LEN = 0x100;
    u32 len = AI_LEN, t1 = t0, prev = len;
    for (;;) {
        u32 v = AI_LEN; t1 = count();
        if (v != prev || t1 - t0 > 16u * period_steps(1103)) break;
    }
    begin("T1"); x(ok ? 1u : 0u); seen(len); near(t1 - t0); end();
    until_clear(0x40000000u, &t1);
    AI_STATUS = 0;
}

/* What the other places read while a transfer plays: the length (1), or something else (0). */
static void mirrors(void) {
    if (!settle(1103)) { stuck("M"); return; }
    AI_ADDR = buffer;
    AI_LEN = 0x2000;
    pause(40u * period_steps(1103));
    begin("M");
    static const u32 places[7] = { 0x00, 0x08, 0x10, 0x14, 0x18, 0x1C, 0x24 };
    for (u32 i = 0; i < 7u; i++) {
        u32 len = AI_LEN, v = AI(places[i]);
        x((len - v) <= 16u && len != 0u ? 1u : 0u);
    }
    end();
    u32 t1; until_clear(0x40000000u, &t1);
    AI_STATUS = 0;
}

/* The bit rate setting at zero, asked more closely. A console showed a transfer written then as
   over at the first look (line K3). K4: what the length, the marks and the interrupt read
   straight after such a write. K5: two more lengths written one after the other, the interrupt
   taken away between them: the marks and the interrupt after each, and the length after the
   second (does the second wait behind the first?). K6: the setting taken to zero while a transfer
   of 0x800 bytes runs: the length just before, straight after, and 40 sample periods later, with
   the marks at the last two moments; then the setting is put back and the transfer waited for. */
static void clock_stopped_more(void) {
    if (!settle(1103)) { stuck("K4"); return; }
    AI_BITRATE = 0;
    AI_ADDR = buffer;
    AI_LEN = 0x400;
    u32 len = AI_LEN, marks = AI_STATUS & MARKS, raised = MI_INTR & 4u;
    begin("K4"); x(len); x(marks); x(raised); end();
    AI_STATUS = 0;
    AI_LEN = 0x200;
    u32 marks1 = AI_STATUS & MARKS, raised1 = MI_INTR & 4u;
    AI_STATUS = 0;
    AI_LEN = 0x200;
    u32 marks2 = AI_STATUS & MARKS, raised2 = MI_INTR & 4u, len2 = AI_LEN;
    begin("K5"); x(marks1); x(raised1); x(marks2); x(raised2); x(len2); end();
    AI_STATUS = 0;
    AI_BITRATE = bit_rate_for(1103);

    if (!settle(1103)) { stuck("K6"); return; }
    AI_ADDR = buffer;
    AI_LEN = 0x800;
    pause(20u * period_steps(1103));
    u32 before = AI_LEN;
    AI_BITRATE = 0;
    u32 after = AI_LEN, marks_after = AI_STATUS & MARKS;
    pause(40u * period_steps(1103));
    u32 later = AI_LEN, marks_later = AI_STATUS & MARKS;
    AI_BITRATE = bit_rate_for(1103);
    u32 t0 = count(), t1; int ok = until_clear(0x40000000u, &t1);
    begin("K6"); seen(before); seen(after); x(marks_after); seen(later); x(marks_later); x(ok ? 1u : 0u); near(t1 - t0); end();
    AI_STATUS = 0;
}

void probe_main(void) {
    u32 status;
    __asm__ volatile("mfc0 %0, $12" : "=r"(status));
    status &= ~1u;                              /* no interrupt is ever taken: the lines are read at the MI */
    __asm__ volatile("mtc0 %0, $12" : : "r"(status));
    buffer = ((((u32)pool + 0x1FFFu) & ~0x1FFFu) + 0x10u) | 0xA0000000u;

    u32 prid;
    __asm__ volatile("mfc0 %0, $15" : "=r"(prid));
    /* The television type as the boot code left it for the program: 0 PAL, 1 NTSC, 2 MPAL. It picks
       the video crystal, so whoever reads the times below needs it. */
    begin("AIPROBE 1 PRID"); x(prid); word("TV"); seen(REG(0x80000300u)); end();

    at_rest();
    status_counter();
    start_from_idle();
    length_steps();
    static const u32 settings[6] = { 1103, 1104, 2207, 2208, 257, 258 };
    for (u32 i = 0; i < 6u; i++) sample_period(settings[i]);
    two_transfers();
    third_length();
    zero_length();
    oversize_length();
    not_enabled();
    clock_stopped();
    mirrors();
    first_two_fetches();
    into_the_tail();
    clock_stopped_more();

    settle(1103);
    at = 0; put("AIPROBE END "); hex(lines); line[at++] = ' '; hex((u32)(fold >> 32)); hex((u32)fold); line[at++] = '\n';
    say(line, at);
}
