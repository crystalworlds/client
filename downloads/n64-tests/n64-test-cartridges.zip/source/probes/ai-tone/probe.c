/* The tone probe: a small test cartridge that plays a known sound.

   It plays 65,536 frames with the DAC rate setting at 1103: a square wave of 100 frames to the
   cycle on the left, one of 200 frames on the right, a quarter of full level. On an NTSC console
   that is 1.486 seconds at 440.96 Hz and 220.48 Hz; on a PAL console the same setting plays faster,
   1.457 seconds at 449.79 Hz and 224.89 Hz, because the video crystal differs. So the pitch and the
   length of what comes out, counted, say which clock timed it and what the sample period was.

   The sound goes out as sixteen transfers of 4,096 frames from two buffers in turn, each queued
   behind the one playing so that there is never a gap. Each buffer's second half is cleared before
   it is queued and written afterwards: a machine that reads a transfer from memory when it is
   queued, and not as it plays, plays silence there.

   It also times the whole sound with the CPU's own Count register (46.875 MHz), from the first
   length written to busy falling after the last, and prints that: the sample rate read from a
   clock that is not the AI's.

   It prints what it did as text, through the debug text window, and never waits for ever. */

typedef unsigned int u32;
typedef unsigned long long u64;

#define REG(a) (*(volatile u32 *)(a))
#define AI_ADDR REG(0xA4500000u)
#define AI_LEN REG(0xA4500004u)
#define AI_CONTROL REG(0xA4500008u)
#define AI_STATUS REG(0xA450000Cu)
#define AI_DACRATE REG(0xA4500010u)
#define AI_BITRATE REG(0xA4500014u)
#define PI_STATUS REG(0xA4600010u)
#define TEXT_LENGTH REG(0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)

#define DAC_RATE 1103u
#define LEFT_CYCLE 100u
#define RIGHT_CYCLE 200u
#define LEVEL 8192
#define BUFFER_FRAMES 4096u
#define BUFFERS 16u
#define HALF_SECOND 23437500u

static u32 count(void) { u32 v; __asm__ volatile("mfc0 %0, $9" : "=r"(v)); return v; }

#include "../debug-text.h"

static void say(const char *s, u32 n) {
    debug_text(s, n);
}

static char line[160];
static u32 at, lines;
static u64 fold;
static void put(const char *s) { while (*s) line[at++] = *s++; }
static void dec(u32 v) { char b[10]; int n = 0; do { b[n++] = (char)('0' + v % 10u); v /= 10u; } while (v); line[at++] = ' '; while (n) line[at++] = b[--n]; }
static void hex(u32 v) { for (int i = 7; i >= 0; i--) { u32 d = (v >> (i * 4)) & 15u; line[at++] = (char)(d < 10 ? '0' + d : 'a' + d - 10); } }
static void end(void) {
    line[at++] = '\n';
    for (u32 i = 0; i < at; i++) fold = (fold ^ (unsigned char)line[i]) * 0x100000001B3ull;
    say(line, at);
    lines++;
}

/* Two buffers, placed so that neither ends at an 8 KiB boundary of memory. */
static unsigned char pool[0xA100] __attribute__((aligned(16)));

/* Frame number n of the sound, as the 32 bits the AI plays: left, then right. */
static u32 frame(u32 n) {
    int left = (n % LEFT_CYCLE) < LEFT_CYCLE / 2u ? LEVEL : -LEVEL;
    int right = (n % RIGHT_CYCLE) < RIGHT_CYCLE / 2u ? LEVEL : -LEVEL;
    return ((u32)(left & 0xFFFF) << 16) | (u32)(right & 0xFFFF);
}

void probe_main(void) {
    u32 status;
    __asm__ volatile("mfc0 %0, $12" : "=r"(status));
    status &= ~1u;
    __asm__ volatile("mtc0 %0, $12" : : "r"(status));

    /* The buffers as a program hands them over and writes them: through the uncached window, so
       that what is written is in memory at once. */
    u32 first = ((((u32)pool + 0x1FFFu) & ~0x1FFFu) + 0x10u) | 0xA0000000u;
    u32 buffers[2] = { first, first + BUFFER_FRAMES * 4u + 0x10u };

    at = 0; put("TONEPROBE 1 DACRATE"); dec(DAC_RATE); put(" LEFT"); dec(LEFT_CYCLE); put(" RIGHT"); dec(RIGHT_CYCLE);
    put(" LEVEL"); dec(LEVEL); put(" FRAMES"); dec(BUFFER_FRAMES * BUFFERS); put(" TV"); dec(REG(0x80000300u)); end();

    AI_CONTROL = 1; AI_DACRATE = DAC_RATE; AI_BITRATE = 15; AI_STATUS = 0;
    u32 t = count();
    while (AI_STATUS & 0xC0000001u) if (count() - t > HALF_SECOND) break;

    u32 n = 0, queued = 0, ran_dry = 0, gave_up = 0, began = 0, took;
    for (u32 b = 0; b < BUFFERS && !gave_up; b++) {
        volatile u32 *p = (volatile u32 *)buffers[b & 1u];
        t = count();
        while (AI_STATUS & 0x80000001u) if (count() - t > HALF_SECOND) { gave_up = 1; break; }
        if (gave_up) break;
        if (b >= 2u && !(AI_STATUS & 0x40000000u)) ran_dry++;       /* the one before ended with nothing behind it */
        for (u32 i = 0; i < BUFFER_FRAMES / 2u; i++) p[i] = frame(n + i);
        for (u32 i = BUFFER_FRAMES / 2u; i < BUFFER_FRAMES; i++) p[i] = 0;
        AI_ADDR = buffers[b & 1u];
        if (b == 0u) began = count();
        AI_LEN = BUFFER_FRAMES * 4u;
        for (u32 i = BUFFER_FRAMES / 2u; i < BUFFER_FRAMES; i++) p[i] = frame(n + i);
        n += BUFFER_FRAMES;
        queued++;
    }
    t = count();
    while (AI_STATUS & 0x40000000u) if (count() - t > HALF_SECOND * 2u) { gave_up = 1; break; }
    took = count() - began;

    at = 0; put("PLAYED"); dec(queued); put(" RAN-DRY"); dec(ran_dry); put(" GAVE-UP"); dec(gave_up); put(" TOOK"); dec(took); end();
    at = 0; put("TONEPROBE END "); hex(lines); line[at++] = ' '; hex((u32)(fold >> 32)); hex((u32)fold); line[at++] = '\n';
    say(line, at);
}
