/* The armed fetch probe: a small test cartridge for a real console.

   On two consoles the hidden bits probe's line for the MI's repeat mode arrived without its first
   letter, in every run (runs c1-12, c1-13, c2-05). A probe that asked what a load gives straight
   after a store in that mode found nothing wrong (run c1-27). But in the hidden bits probe the
   store was the first instruction of a line of the instruction cache, with the write that arms
   the mode in the line before: so the CPU fetched the store's own line from main memory with the
   mode armed, which the other probe, whose instructions lay in one line, never did. And the log
   is just what the hidden bits probe prints if the one instruction behind the store, the load of
   its line's length, did not load.

   This probe makes that fetch on purpose and says what the CPU was given. Each case writes a
   word to the MI's mode register in one line of the instruction cache and stores into main memory
   with the first instruction of the next; the rest of that line is seven instructions that each
   leave a mark of their own (start.S). All values are in hex.

     G n          said before case n is run, so that a case that never comes back is known
     F n m v a b c
                  case n: m the word written to the mode register (0080 takes the repeat mode
                  off, 010f arms it for 16 bytes, 0103 for 4, 011f for 32); v what the line's
                  instructions left (00ff as written for cases 0 to 5, 05fe for cases 6 to 8,
                  whose instruction behind the store is a load of a word that holds 5); a, b, c
                  the first, fourth and fifth word at the place stored to, which held eeee0000
                  to eeee0004: was the store repeated, and how far

     cases 0 and 6: the mode not armed, the line fetched from memory (the control)
     cases 1, 5 and 7: armed for 16 bytes, the line fetched from memory with the mode armed
     cases 2 and 8: armed for 16 bytes, the line put into the instruction cache beforehand
     cases 3 and 4: armed for 4 and for 32 bytes, the line fetched from memory

   No line depends on the console's television type.

   Care for the console: the repeat mode is the one a common library uses to clear memory, armed
   for one store at a time in a part of memory nothing else uses, and taken off again after each
   case. If a fetch with the mode armed gives the CPU other words than the line holds, they are
   words of that same line: a store, a load and additions. */

#include "../cart-lib/say.h"

u32 case_0(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);
u32 case_1(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);
u32 case_2(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);
u32 case_3(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);
u32 case_4(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);
u32 case_5(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);
u32 case_6(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);
u32 case_7(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);
u32 case_8(volatile u32 *store_at, u32 mode_word, const volatile u32 *five);

#define AREA 0x00200000u                                    /* two megabytes up: nothing else is there */
#define UNCACHED(offset) ((volatile u32 *)(0xA0000000u + AREA + (offset)))
#define CACHED(offset) ((volatile u32 *)(0x80000000u + AREA + (offset)))

typedef u32 (*a_case)(volatile u32 *, u32, const volatile u32 *);
static const a_case CASES[9] = { case_0, case_1, case_2, case_3, case_4, case_5, case_6, case_7, case_8 };
static const u16 MODE[9] = { 0x0080, 0x010F, 0x010F, 0x0103, 0x011F, 0x010F, 0x0080, 0x010F, 0x010F };
static const u8 IN_THE_CACHE[9] = { 0, 0, 1, 0, 0, 0, 0, 0, 1 };

void probe_main(void) {
    say_head("AFPROBE");
    for (u32 n = 0; n < 9; n++) {
        volatile u32 *place = UNCACHED(n * 0x40u), *five = CACHED(0x1800u + n * 0x40u);
        for (u32 i = 0; i < 8; i++) place[i] = 0xEEEE0000u | i;
        *five = 5u;                                         /* in the data cache, as the other probe's length was */
        /* The second line of the case, put into the instruction cache beforehand where the case asks for it. */
        if (IN_THE_CACHE[n]) __asm__ volatile("cache 0x14, 32(%0)" : : "r"(CASES[n]));
        say_text("G"); say_hex(n, 2); say_flush();
        const u32 v = CASES[n](place, MODE[n], five);
        MI_MODE = 0x0080u;                                  /* the repeat mode off, whatever the case left */
        say_text("F"); say_hex(n, 2); say_hex(MODE[n], 4); say_hex(v, 4); say_hex(place[0], 8); say_hex(place[3], 8); say_hex(place[4], 8); say_flush();
    }
    say_tail("AFPROBE");
}
