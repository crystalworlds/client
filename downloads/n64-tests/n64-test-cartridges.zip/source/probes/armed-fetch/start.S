# The first instruction of the probe, and its cases.
    .set noreorder
    .section .text.entry, "ax"
    .globl _start
_start:
    lui   $sp, 0x803F
    jal   probe_main
    addiu $sp, $sp, -32
1:  b     1b
    nop

# One case: u32 case_n(u32 *store_at, u32 mode_word, const u32 *five).
#
# The case is three lines of the instruction cache. The first holds the write of `mode_word` to
# the MI's mode register, and the two instructions the hidden bits probe had behind that write.
# The second begins with the store into main memory that the armed mode repeats: so when the line
# is not in the instruction cache, the CPU fetches it from main memory between the arming and the
# store, with the mode armed. The rest of the second line tells what the CPU was given: seven
# instructions that each do something of their own to a register.
#
# With the plain line they add 1, 2, 4, 8, 16, 32 and 64 to v0, and the third line adds 128: the
# sum is ff when every instruction ran once and no other did.
#
# With the loading line the instruction behind the store loads v1 from a word that holds 5, as
# the hidden bits probe loaded the length of its line; the six after it add 2 to 64. The case
# hands back the sum in the low byte and what v1 held in the byte above it: 05fe as written.
    .macro plain_case n
    .balign 32
    .globl case_\n
case_\n:
    lui   $t0, 0xA430
    addiu $v0, $zero, 0
    addiu $v1, $zero, 0x77
    nop
    nop
    sw    $a1, 0($t0)           # the mode register is written
    lui   $t1, 0x1110
    addiu $t1, $t1, 0x2221
    sw    $t1, 0($a0)           # the store: the first instruction of the second line
    addiu $v0, $v0, 1
    addiu $v0, $v0, 2
    addiu $v0, $v0, 4
    addiu $v0, $v0, 8
    addiu $v0, $v0, 16
    addiu $v0, $v0, 32
    addiu $v0, $v0, 64
    jr    $ra
    addiu $v0, $v0, 128
    .endm

    .macro loading_case n
    .balign 32
    .globl case_\n
case_\n:
    lui   $t0, 0xA430
    addiu $v0, $zero, 0
    addiu $v1, $zero, 0x77
    nop
    nop
    sw    $a1, 0($t0)
    lui   $t1, 0x1110
    addiu $t1, $t1, 0x2221
    sw    $t1, 0($a0)
    lw    $v1, 0($a2)           # behind the store: a load from the data cache
    addiu $v0, $v0, 2
    addiu $v0, $v0, 4
    addiu $v0, $v0, 8
    addiu $v0, $v0, 16
    addiu $v0, $v0, 32
    addiu $v0, $v0, 64
    andi  $v1, $v1, 0xFF
    sll   $v1, $v1, 8
    or    $v0, $v0, $v1
    jr    $ra
    addiu $v0, $v0, 128
    .endm

    .section .text, "ax"
    plain_case 0
    plain_case 1
    plain_case 2
    plain_case 3
    plain_case 4
    plain_case 5
    loading_case 6
    loading_case 7
    loading_case 8
