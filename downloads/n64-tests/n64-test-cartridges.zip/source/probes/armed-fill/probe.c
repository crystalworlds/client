/* The armed fill probe: a small test cartridge for a real console.

   The armed fetch probe found on a console that a line of instructions fetched while the MI's
   repeat mode is armed comes to the CPU changed, in a way the sums of its instructions cannot name.
   This probe reads the words the caches were given instead of running them: a line of data whose
   every byte holds its own offset (0x00 to 0x1F) is filled into the instruction cache with the mode
   armed, the mode is cleared, and the cache writes the line back to memory (Hit_Write_Back), where
   an uncached read shows it word for word. The same is asked of the data cache with a load.

   Lines (G n is said before each case, so that a case that never comes back is known by its number):
     C p  w0 .. w7        the control of the instrument, with the mode never armed: the line filled
                          into the instruction cache, memory then written ccccccc0 to ccccccc7 without
                          the cache, the line written back: the cache's words must come back
     A m p v  w0 .. w7    the instruction cache's line: m the mode written (80 the control, which
                          arms nothing; 03, 07, 0f, 17, 1f the repeat mode with a count of 4, 8, 16,
                          24 and 32 bytes), p the line's place in its block (00, 20, 60), v what the
                          MI carried last before the fill: 0 the uncached writes that laid the line,
                          1 uncached reads of eight words bbbb0000 to bbbb0007, 2 an uncached 64-bit
                          write of 1111222233334444 elsewhere
     D m  w0 .. w3        the data cache's 16-byte line, read with a load (the 16 bytes after it laid
                          the same way, offsets 0x10 to 0x1F)
   The hardware notes say a read in this mode may hang a console ("further testing needed"); the
   console may then need switching off by hand. A PAL console ran every case without a hang.

   Care for the console: register writes a game makes to the MI's mode register, uncached reads and
   writes of main memory, and the CPU's own cache operations; but a read of memory with the repeat
   mode armed is not ordinary, and is what this probe is for. */

#include "../cart-lib/say.h"

#define MI_BASE ((volatile u32 *)0xA4300000u)
#define BLOCK 0x80303000u                       /* away from the program's places in both caches */
#define B_LINE 0x80305000u
#define WRITE_AT 0x80306000u
#define D_LINE 0x80304000u
#define UNCACHED(a) ((volatile u32 *)((a) | 0x20000000u))

void armed_code_fill(u32 line, u32 mode, volatile u32 *mi);
void armed_data_load(u32 line, u32 mode, volatile u32 *mi, volatile u32 *out);
extern char armed_code_fill_end[], armed_data_load_end[];

static void fill_lines(u32 from, u32 to) { for (u32 a = from & ~31u; a < to; a += 32u) __asm__ volatile("cache 0x14, 0(%0)" : : "r"(a)); }
static void lay(u32 line, u32 bytes) { for (u32 i = 0; i < bytes; i += 4) UNCACHED(line)[i / 4] = ((i << 24) | ((i + 1) << 16) | ((i + 2) << 8) | (i + 3)); }
static u32 cases;
static void say_case(void) { say_text("G"); say_hex(cases++, 2); say_flush(); }

static void code_case(u32 mode, u32 place, u32 v) {
    const u32 line = BLOCK + place;
    say_case();
    lay(line, 32);
    if (v == 1) for (u32 i = 0; i < 8u; i++) (void)UNCACHED(B_LINE)[i];
    if (v == 2) *(volatile u64 *)(WRITE_AT | 0x20000000u) = 0x1111222233334444ull;
    fill_lines((u32)armed_code_fill, (u32)armed_code_fill_end);
    armed_code_fill(line, mode, MI_BASE);
    say_text("A"); say_hex(mode & 0xFFu, 2); say_hex(place, 2); say_hex(v, 1);
    for (u32 i = 0; i < 8u; i++) say_hex(UNCACHED(line)[i], 8);
    say_flush();
}

static void control_case(u32 place) {
    const u32 line = BLOCK + place;
    say_case();
    lay(line, 32);
    __asm__ volatile("cache 0x14, 0(%0)" : : "r"(line));
    for (u32 i = 0; i < 8u; i++) UNCACHED(line)[i] = 0xCCCCCCC0u + i;
    __asm__ volatile("cache 0x18, 0(%0)" : : "r"(line));
    __asm__ volatile("cache 0x10, 0(%0)" : : "r"(line));
    say_text("C"); say_hex(place, 2);
    for (u32 i = 0; i < 8u; i++) say_hex(UNCACHED(line)[i], 8);
    say_flush();
}

static void data_case(u32 mode) {
    static volatile u32 out[4];
    say_case();
    lay(D_LINE, 32);                                            /* the line and the 16 bytes after it, which a count past 16 reads */
    __asm__ volatile("cache 0x01, 0(%0)" : : "r"(D_LINE));   /* the line's place in the data cache written back and emptied */
    __asm__ volatile("cache 0x01, 0(%0)" : : "r"((u32)out));
    fill_lines((u32)armed_data_load, (u32)armed_data_load_end);
    armed_data_load(D_LINE, mode, MI_BASE, (volatile u32 *)((u32)out | 0x20000000u));
    say_text("D"); say_hex(mode & 0xFFu, 2);
    for (u32 i = 0; i < 4u; i++) say_hex(UNCACHED((u32)out)[i], 8);
    say_flush();
}

static const u32 MODES[6] = { 0x0080u, 0x0103u, 0x0107u, 0x010Fu, 0x0117u, 0x011Fu };

void probe_main(void) {
    for (u32 i = 0; i < 8u; i++) UNCACHED(B_LINE)[i] = 0xBBBB0000u + i;
    say_head("ARMFILL");
    for (u32 p = 0; p < 3u; p++) control_case(p == 0 ? 0x00u : p == 1 ? 0x20u : 0x60u);
    for (u32 k = 0; k < 6u; k++) for (u32 p = 0; p < 3u; p++) code_case(MODES[k], p == 0 ? 0x00u : p == 1 ? 0x20u : 0x60u, 0);
    for (u32 k = 0; k < 6u; k++) for (u32 v = 1; v < 3u; v++) code_case(MODES[k], 0x00u, v);
    for (u32 k = 0; k < 6u; k++) data_case(MODES[k]);
    say_tail("ARMFILL");
}
