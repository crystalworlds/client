# The first instruction of the probe, and the two routines that make a cache fill with the MI's
# repeat mode armed.
    .set noreorder
    .section .text.entry, "ax"
    .globl _start
_start:
    lui   $sp, 0x803F
    jal   probe_main
    addiu $sp, $sp, -32
1:  b     1b
    nop

    .section .text, "ax"
# void armed_code_fill(u32 line, u32 mode, u32 *mi): the MI's mode written, the instruction cache's
# Fill of `line` (a cached address: the line is read from main memory with the mode as written), the
# repeat mode cleared (0x0080, which writes nothing to memory), then Hit_Write_Back of the line, so
# that the words the cache was given go to main memory, where an uncached read shows them, and then
# the line is thrown out of the cache. The caller has every line of this routine in the instruction cache
# first: from the write of the mode to its clearing the CPU fetches nothing and reads nothing else.
    .balign 32
    .globl armed_code_fill
    .globl armed_code_fill_end
armed_code_fill:
    addiu $t0, $zero, 0x0080
    sw    $a1, 0($a2)               # the mode
    cache 0x14, 0($a0)              # Fill: the line read with the mode armed
    sw    $t0, 0($a2)               # the repeat mode cleared
    cache 0x18, 0($a0)              # Hit_Write_Back: the cache's words to memory
    cache 0x10, 0($a0)              # Hit_Invalidate
    jr    $ra
    nop
armed_code_fill_end:

# void armed_data_load(u32 line, u32 mode, u32 *mi, u32 *out): the same for the data cache: the mode
# written, a cached load from `line` (a 16-byte line, not in the cache: read from main memory with the
# mode armed), the repeat mode cleared, then the line's four words read from the cache and stored
# without the cache to `out`, and the line thrown out without being written back. The caller has
# the place of the line in the data cache written back and emptied first, so that nothing is written to
# memory while the mode is armed.
    .balign 32
    .globl armed_data_load
    .globl armed_data_load_end
armed_data_load:
    addiu $t0, $zero, 0x0080
    sw    $a1, 0($a2)               # the mode
    lw    $t1, 0($a0)               # the line read with the mode armed
    sw    $t0, 0($a2)               # the repeat mode cleared
    lw    $t2, 0($a0)
    lw    $t3, 4($a0)
    lw    $v0, 8($a0)
    lw    $v1, 12($a0)
    sw    $t2, 0($a3)
    sw    $t3, 4($a3)
    sw    $v0, 8($a3)
    sw    $v1, 12($a3)
    cache 0x11, 0($a0)              # Hit_Invalidate: thrown out, not written back
    jr    $ra
    nop
armed_data_load_end:
