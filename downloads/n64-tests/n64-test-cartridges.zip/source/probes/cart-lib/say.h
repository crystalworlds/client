/* What every probe of the cartridge side shares: printing a line of text through the debug text
   window (which a flash cartridge shows on the computer beside the console), and a running count
   and fold of every value printed, so that the last line can vouch for the lines before it.

   A line is built in a small buffer: a tag, then values in hex, each after one space. */
#ifndef PROBE_CART_LIB_SAY_H
#define PROBE_CART_LIB_SAY_H

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

#define REG32(address) (*(volatile u32 *)(address))
#define PI_DRAM_ADDR REG32(0xA4600000u)
#define PI_CART_ADDR REG32(0xA4600004u)
#define PI_RD_LEN REG32(0xA4600008u)
#define PI_WR_LEN REG32(0xA460000Cu)
#define PI_STATUS REG32(0xA4600010u)
#define MI_MODE REG32(0xA4300000u)
#define TEXT_LENGTH REG32(0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)

#include "../debug-text.h"

/* The cartridge bus does one thing at a time: wait until it is free. */
static void bus_free(void) { while (PI_STATUS & 3u) { } }

static char line_buffer[160];
static u32 line_length, lines_said;
static u64 said_fold;

static void say_flush(void) {
    line_buffer[line_length++] = '\n';
    debug_text(line_buffer, line_length);
    bus_free();
    line_length = 0;
    lines_said++;
}

static void say_text(const char *s) { while (*s && line_length < sizeof line_buffer - 20) line_buffer[line_length++] = *s++; }

static void say_hex(u64 v, u32 digits) {
    if (line_length >= sizeof line_buffer - 20) return;
    line_buffer[line_length++] = ' ';
    for (u32 i = 0; i < digits; i++) { u32 d = (u32)(v >> ((digits - 1 - i) * 4)) & 15u; line_buffer[line_length++] = (char)(d < 10 ? '0' + d : 'a' + d - 10); }
    said_fold = (said_fold << 7 | said_fold >> 57) ^ (v * 0x9E3779B97F4A7C15ull);
}

/* The first and the last line of a probe. The last one carries how many lines came before it and
   the fold of every value in them. */
static void say_head(const char *name) {
    u32 prid;
    __asm__ volatile("mfc0 %0, $15" : "=r"(prid));
    say_text(name); say_text(" 1 PRID"); say_hex(prid, 8);
    say_flush();
    lines_said = 0;                         /* the first line is not counted, nor folded in */
    said_fold = 0;
}
static void say_tail(const char *name) {
    u32 n = lines_said; u64 f = said_fold;
    say_text(name); say_text(" END"); say_hex(n, 8); say_hex(f, 16);
    say_flush();
}

/* COUNT, which steps once every two CPU cycles. */
__attribute__((unused)) static u32 count_now(void) { u32 v; __asm__ volatile("mfc0 %0, $9" : "=r"(v)); return v; }

#endif
