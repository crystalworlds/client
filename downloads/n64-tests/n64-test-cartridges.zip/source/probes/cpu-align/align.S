# The alignment probe's pieces. No routine here is run where it stands: the probe copies these
# instructions, with idle instructions between them, to one place in memory for each of its lines
# (probe.c says how a routine is put together), fills that place's instruction lines, and calls it.
# Kept as assembly so that the assembler makes the words.
#
# Registers of a routine: $a0 and $a1 the address and the value of the store that asks for the
# interrupt, $a2 the MI's registers, $a3 and $a4 as the line needs them.
    .set noreorder
    .set noat
    .text

# The head: the RCP's interrupt line is let through, and COUNT is written with what it read (which
# fixes the cycle it steps on). $v0 keeps the value written.
    .globl bit_head
    .globl bit_head_end
bit_head:
    mfc0  $t2, $12
    ori   $t2, $t2, 0x0401
    mtc0  $t2, $12
    nop
    nop
    nop
    nop
    mfc0  $v0, $9
    nop
    nop
    mtc0  $v0, $9
bit_head_end:

# The same with the CPU's interrupts left off: for the routines that only read.
    .globl bit_quiet_head
    .globl bit_quiet_head_end
bit_quiet_head:
    mfc0  $t2, $12
    ori   $t2, $t2, 0x0400
    mtc0  $t2, $12
    nop
    nop
    nop
    nop
    mfc0  $v0, $9
    nop
    nop
    mtc0  $v0, $9
bit_quiet_head_end:

# One instruction each.
    .globl bit_anchor
bit_anchor:
    lw    $t3, 4($a2)               # the anchor: the MI's version register, read without the cache
    .globl bit_load
bit_load:
    lw    $t3, 0($a3)               # a load from the address in $a3
    .globl bit_stow
bit_stow:
    sw    $zero, 0($a3)             # a store of zero to the address in $a3
    .globl bit_fill
bit_fill:
    cache 0x14, 0($a3)              # the Fill operation on the instruction line of the address in $a3
    .globl bit_first
bit_first:
    sw    $a3, 0($a4)               # a store before the store that asks
    .globl bit_ask
bit_ask:
    sw    $a1, 0($a0)               # the store that asks for the interrupt
    .globl bit_return
bit_return:
    jr    $ra
    .globl bit_cause
bit_cause:
    mfc0  $v0, $13
    .globl bit_divide
bit_divide:
    div   $zero, $a1, $a1
    .globl bit_multiply
bit_multiply:
    mult  $a1, $a1

# COUNT written with what it read, and read again: the routine returns the steps between.
    .globl bit_count_in
    .globl bit_count_in_end
bit_count_in:
    mfc0  $v0, $9
    nop
    nop
    mtc0  $v0, $9
bit_count_in_end:
    .globl bit_count_out
    .globl bit_count_out_end
bit_count_out:
    mfc0  $v1, $9
    nop
    jr    $ra
    subu  $v0, $v1, $v0
bit_count_out_end:
