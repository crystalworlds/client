/* The alignment probe: a small test cartridge for a real console.

   The phase probe (probes/cpu-phase) showed where the CPU is called away by an interrupt of the
   RCP that a store asks for: after 19, 19 and 18 instructions of a row, by where the store falls
   against the RCP's clock. This probe asks the same question again in other ways, so that the
   answer does not rest on one routine at one place, and asks where the CPU stands after each kind
   of wait for the bus.

   Every routine is put together in memory by the probe itself, at one place whose instruction
   lines nothing else of the probe uses, then every line of it is filled in the instruction cache
   (the Fill operation) and it is called. A routine is: its start moved k instructions into its
   line; the head (the RCP's interrupt line let through, COUNT written with what it read); the
   anchor (an uncached read of the MI's version register: the CPU waits for the RCP's answer); j
   idle instructions and one instruction that waits for the bus; m idle instructions; one or two
   stores that come first; the store that asks the RSP for its interrupt; a row of 64 idle
   instructions. The exception stub (probes/cpu-time/time.S) notes COUNT and the address the CPU
   was called away from.

   Lines, eight tries each after one that brings the data lines in. `t` is how many tries the
   interrupt took, s1 to s8 the row's instructions run before it (ff: not taken), c1 to c8 the
   steps of COUNT from the write to COUNT to the stub (COUNT steps once in two CPU cycles):
     A  a b c             where the probe's own data begins and ends, and its routines' place
     P k m t s.. c..      the anchor, m idle instructions, the store; the routine k instructions into its line
     S k m t s.. c..      the same with no anchor (the routine of the time probe's S lines)
     G j m t s.. c..      the anchor, j idle instructions, a second read of the same register
     g x m t s.. c..      the same with no idle instruction and the second read from another part's
                          register: 0 the RSP's status, 1 the DP's status, 2 the VI's line, 3 the
                          AI's status, 4 the PI's status, 5 the RI's select, 6 the SI's status
     V j m ..             the second read from the RSP's data memory
     U j m ..             from main memory, without the cache
     Da j m ..            a load through the data cache whose line is not there, its row of memory open
     Dc j m ..            the same where the line in its place belongs to another address, clean
     Dd j m ..            the same where that line must first be written back
     Za Zc Zd j m ..      the three with a store through the data cache
     F j m ..             the Fill operation on the routine's own last instruction line
     Fr j m ..            the Fill operation on a line in another row of memory
     W x m ..             the anchor, m idle instructions, a store of zero, then the store that asks.
                          The first store goes to: 0 the MI's mask, 1 the RSP's status, 2 the RSP's
                          semaphore, 3 the DP's status, 4 the VI's line, 5 the AI's status, 6 the
                          PI's status, 7 the SI's status, 8 main memory, 9 the RSP's data memory,
                          a the RSP's instruction memory
     T m ..               two stores of zero to the MI's mask first
     M m ..               the RSP's interrupt is already asked for and kept from the CPU by the
                          MI's mask; the store lets it through (to the MI's mask register)
     X m ..               the store asks for the interrupt and the next store takes it back
     C m n12 .. n21       interrupts off; the anchor, m idle instructions, the store, q idle
                          instructions, and Cause read: in how many of eight tries the RCP's
                          line was up, for q = 12 to 21
     K x d c1 .. c8       COUNT written, one instruction, d idle instructions, COUNT read: the
                          steps. The instruction: 0 idle, 1 the anchor's read, 2 a divide, 3 a
                          multiply, 4 idle and then the read, 5 a load whose data line is not there
   k = 0 to 7, j = 0 to 2, m = 0 to 5, d = 0 to 3.

   No line depends on the console's television type: the VI is switched off.

   Care for the console: everything here is ordinary. Register reads and writes a game makes: the
   RSP's status (its interrupt set and taken back) and semaphore, the MI's mask and version, the
   status registers of the DP, the AI, the PI and the SI and the VI's line register written with
   zero (which takes back an interrupt that is not there, or does nothing), the RSP's two memories
   while the RSP is halted; the CPU's own interrupt and cache operations. Every wait has an end. */

#include "../cart-lib/say.h"

#define VI_CTRL REG32(0xA4400000u)
#define MI_MASK REG32(0xA430000Cu)
#define SI_STATUS REG32(0xA4800018u)
#define PIF_LAST_WORD REG32(0xBFC007FCu)
#define SP_STATUS ((volatile u32 *)0xA4040010u)
#define MI_BASE ((volatile u32 *)0xA4300000u)
#define UNCACHED(a) ((volatile u32 *)((a) | 0x20000000u))

#define CODE 0x80103800u                    /* where every routine is put: instruction lines the probe's own code does not use */
#define OTHER_ROW (CODE + 0x4400u)          /* an instruction line in another row of memory, its place in the cache used by nothing else */
#define D_LINE 0x80201800u                  /* the data line the waits work on: a place in the data cache the probe's own data does not use */
#define D_OTHER (D_LINE + 0x2000u)          /* the line that shares its place in the data cache */

/* What the exception stub leaves (probes/cpu-time/time.S). */
volatile u32 stamp, stamp_on, seen_epc, seen_cause, resume_at;
extern char vector_stub[], vector_stub_end[];
extern char __bss_start[], __bss_end[];

extern const u32 bit_head[], bit_head_end[], bit_quiet_head[], bit_quiet_head_end[], bit_anchor[], bit_load[], bit_stow[], bit_fill[], bit_first[], bit_ask[],
    bit_return[], bit_cause[], bit_divide[], bit_multiply[], bit_count_in[], bit_count_in_end[], bit_count_out[], bit_count_out_end[];

typedef u32 (*go_t)(volatile u32 *, u32, volatile u32 *, u32, volatile u32 *);

/* Long enough for the write buffer to empty and a store to take effect. */
static void idle(void) { for (volatile u32 i = 0; i < 200u; i++) { } }
static void fill_lines(u32 from, u32 to) { for (u32 a = from & ~31u; a < to; a += 32u) __asm__ volatile("cache 0x14, 0(%0)" : : "r"(a)); }
static void interrupts_off(void) { u32 s; __asm__ volatile("mfc0 %0, $12" : "=r"(s)); __asm__ volatile("mtc0 %0, $12" : : "r"(s & ~1u)); }

/* The data line before a try. Its place in the data cache is left holding: the line of another
   address, clean; that line with a store in it, which must go back to memory first; or nothing,
   with the row of memory the line lies in open (an uncached read of that row comes last). */
static void prepare_other_clean(void) { (void)*(volatile u32 *)D_OTHER; __asm__ volatile("cache 0x19, 0(%0)" : : "r"(D_OTHER)); }
static void prepare_other_dirty(void) { *(volatile u32 *)D_OTHER = 1; }
static void prepare_row_open(void) { (void)*UNCACHED(D_LINE + 0x40u); }
static void prepare_absent(void) {
    __asm__ volatile("cache 0x19, 0(%0)" : : "r"(D_LINE));
    __asm__ volatile("cache 0x11, 0(%0)" : : "r"(D_LINE));
    prepare_row_open();
}

/* ---- Putting a routine together ---------------------------------------------------- */

static u32 laid, code_go, code_row, code_back, code_end;
static void lay(u32 word) { UNCACHED(CODE)[laid++] = word; }
static void lay_idle(u32 n) { while (n--) lay(0); }
static void lay_piece(const u32 *from, const u32 *to) { while (from < to) lay(*from++); }
static u32 here(void) { return CODE + 4u * laid; }

/* A routine that asks for the interrupt: `wait` is the instruction that waits for the bus behind
   the anchor (none when zero). */
static void lay_asking(u32 k, u32 anchor, u32 j, u32 wait, u32 m, u32 firsts) {
    laid = 0;
    lay_idle(k);
    code_go = here();
    lay_piece(bit_head, bit_head_end);
    if (anchor) lay(bit_anchor[0]);
    if (wait) { lay_idle(j); lay(wait); }
    lay_idle(m);
    for (u32 i = 0; i < firsts; i++) lay(bit_first[0]);
    lay(bit_ask[0]);
    code_row = here();
    lay_idle(64u);
    code_back = here();
    lay(bit_return[0]); lay(0);
    code_end = here();
}

/* A routine that reads Cause q idle instructions behind the store, and returns it. */
static void lay_polling(u32 m, u32 q) {
    laid = 0;
    code_go = here();
    lay_piece(bit_quiet_head, bit_quiet_head_end);
    lay(bit_anchor[0]);
    lay_idle(m);
    lay(bit_ask[0]);
    lay_idle(q);
    lay(bit_cause[0]); lay(0);
    lay(bit_return[0]); lay(0);
    code_row = code_back = code_end = here();
}

/* A routine that writes COUNT, runs one instruction and d idle ones, and returns COUNT's steps. */
static void lay_counting(u32 kind, u32 d) {
    laid = 0;
    code_go = here();
    lay_piece(bit_quiet_head, bit_quiet_head_end);
    lay(bit_anchor[0]); lay(0); lay(0);
    lay_piece(bit_count_in, bit_count_in_end);
    if (kind == 0) lay(0);
    else if (kind == 1) lay(bit_anchor[0]);
    else if (kind == 2) lay(bit_divide[0]);
    else if (kind == 3) lay(bit_multiply[0]);
    else if (kind == 4) { lay(0); lay(bit_anchor[0]); }
    else lay(bit_load[0]);
    lay_idle(d);
    lay_piece(bit_count_out, bit_count_out_end);
    code_row = code_back = code_end = here();
}

/* ---- A line -------------------------------------------------------------------------- */

struct ask {
    volatile u32 *at; u32 with;         /* the store that asks */
    u32 a3; volatile u32 *a4;           /* what the routine's other two registers hold */
    void (*prepare)(void);
    u32 masked;                         /* the interrupt is asked for beforehand and the store lets it through the MI's mask */
};

static void asking_line(const char *tag, u32 x, u32 y, const struct ask *q) {
    u32 stopped[8], steps[8], taken = 0;
    for (u32 turn = 0; turn < 9u; turn++) {
        interrupts_off();
        if (q->masked) { MI_MASK = 0x1u; *SP_STATUS = 0x10u; }      /* asked for, and kept from the CPU */
        else { *SP_STATUS = 0x8u; MI_MASK = 0x2u; }                 /* taken back, and let through the MI */
        idle();
        if (q->prepare) q->prepare();
        stamp_on = 0;
        resume_at = code_back;
        fill_lines(code_go, code_back + 8u);
        const u32 set = ((go_t)code_go)(q->at, q->with, MI_BASE, q->a3, q->a4);
        MI_MASK = 0x1u;
        *SP_STATUS = 0x8u;
        idle();
        if (turn == 0) continue;                /* the first turn brings the data lines in */
        stopped[turn - 1] = stamp_on ? ((seen_epc - code_row) / 4u) & 0xFFu : 0xFFu;
        steps[turn - 1] = stamp_on ? (stamp - set) & 0xFFu : 0xFFu;
        if (stamp_on) taken++;
    }
    say_text(tag); say_hex(x, 1); say_hex(y, 1); say_hex(taken, 1);
    for (u32 i = 0; i < 8u; i++) say_hex(stopped[i], 2);
    for (u32 i = 0; i < 8u; i++) say_hex(steps[i], 2);
    say_flush();
}

/* The lines of one instruction that waits behind the anchor, for j = 0 to 2 and m = 0 to 5. */
static void waiting_lines(const char *tag, u32 wait, u32 a3, void (*prepare)(void)) {
    for (u32 j = 0; j < 3u; j++) for (u32 m = 0; m < 6u; m++) {
        lay_asking(0, 1, j, wait, m, 0);
        const struct ask q = { SP_STATUS, 0x10u, a3 ? a3 : (code_back & ~31u), 0, prepare, 0 };
        asking_line(tag, j, m, &q);
    }
}

static void cause_line(u32 m) {
    say_text("C"); say_hex(m, 1);
    for (u32 q = 12u; q < 22u; q++) {
        u32 seen = 0;
        lay_polling(m, q);
        for (u32 turn = 0; turn < 9u; turn++) {
            interrupts_off();
            *SP_STATUS = 0x8u;
            MI_MASK = 0x2u;
            idle();
            fill_lines(code_go, code_end);
            const u32 cause = ((go_t)code_go)(SP_STATUS, 0x10u, MI_BASE, 0, 0);
            MI_MASK = 0x1u;
            *SP_STATUS = 0x8u;
            idle();
            if (turn && (cause & 0x400u)) seen++;
        }
        say_hex(seen, 1);
    }
    say_flush();
}

static void count_line(u32 kind, u32 d) {
    u32 steps[8];
    lay_counting(kind, d);
    for (u32 turn = 0; turn < 9u; turn++) {
        interrupts_off();
        idle();
        if (kind == 5u) prepare_absent();
        fill_lines(code_go, code_end);
        const u32 v = ((go_t)code_go)(SP_STATUS, 0x10u, MI_BASE, D_LINE, 0);
        if (turn) steps[turn - 1] = v & 0xFFu;
    }
    say_text("K"); say_hex(kind, 1); say_hex(d, 1);
    for (u32 i = 0; i < 8u; i++) say_hex(steps[i], 2);
    say_flush();
}

static const u32 mark = 1;

/* Another probe is this one with lines of its own in place of these: it names its tag and the file
   that holds its lines (a routine `other_lines`), and takes everything above as it stands. */
#ifdef PROBE_OTHER_LINES
#include PROBE_OTHER_LINES
#endif
#ifndef PROBE_TAG
#define PROBE_TAG "CPUALIGN"
#endif

void probe_main(void) {
    /* The PIF stops a console whose program has not told it within five seconds that the boot is over. */
    while (SI_STATUS & 3u) { }
    PIF_LAST_WORD = 8u;
    while (SI_STATUS & 3u) { }
    MI_MASK = 0x555u;                           /* no interrupt of the RCP reaches the CPU */
    VI_CTRL = 0;                                /* the video chip off: it reads no memory */
    __asm__ volatile("mtc0 %0, $12" : : "r"(0x34000000u));
    /* The stub goes to the three vectors, written without the cache, and their instruction lines are thrown out. */
    for (u32 v = 0; v < 3u; v++) {
        const u32 to = v == 0 ? 0x80000000u : v == 1 ? 0x80000080u : 0x80000180u;
        const u32 *from = (const u32 *)vector_stub, words = (u32)(vector_stub_end - vector_stub) / 4u;
        for (u32 i = 0; i < words; i++) UNCACHED(to)[i] = from[i];
        for (u32 a = to; a < to + words * 4u; a += 32u) __asm__ volatile("cache 0x10, 0(%0)" : : "r"(a));
        __asm__ volatile("cache 0x10, 0(%0)" : : "r"(to + words * 4u - 4u));
    }
    say_head(PROBE_TAG);
    say_text("A"); say_hex((u32)&mark, 8); say_hex((u32)__bss_end, 8); say_hex(CODE, 8); say_flush();

#ifdef PROBE_OTHER_LINES
    other_lines();
#else
    static const struct ask plain = { SP_STATUS, 0x10u, 0, 0, 0, 0 };
    for (u32 k = 0; k < 8u; k++) for (u32 m = 0; m < 6u; m++) { lay_asking(k, 1, 0, 0, m, 0); asking_line("P", k, m, &plain); }
    for (u32 k = 0; k < 8u; k++) for (u32 m = 0; m < 6u; m++) { lay_asking(k, 0, 0, 0, m, 0); asking_line("S", k, m, &plain); }

    waiting_lines("G", bit_load[0], 0xA4300004u, 0);
    {
        static const u32 OTHER[7] = { 0xA4040010u, 0xA410000Cu, 0xA4400010u, 0xA450000Cu, 0xA4600010u, 0xA470000Cu, 0xA4800018u };
        for (u32 x = 0; x < 7u; x++) for (u32 m = 0; m < 6u; m++) {
            lay_asking(0, 1, 0, bit_load[0], m, 0);
            const struct ask q = { SP_STATUS, 0x10u, OTHER[x], 0, 0, 0 };
            asking_line("g", x, m, &q);
        }
    }
    waiting_lines("V", bit_load[0], 0xA4000000u, 0);
    waiting_lines("U", bit_load[0], D_LINE | 0x20000000u, prepare_row_open);
    waiting_lines("Da", bit_load[0], D_LINE, prepare_absent);
    waiting_lines("Dc", bit_load[0], D_LINE, prepare_other_clean);
    waiting_lines("Dd", bit_load[0], D_LINE, prepare_other_dirty);
    waiting_lines("Za", bit_stow[0], D_LINE, prepare_absent);
    waiting_lines("Zc", bit_stow[0], D_LINE, prepare_other_clean);
    waiting_lines("Zd", bit_stow[0], D_LINE, prepare_other_dirty);
    waiting_lines("F", bit_fill[0], 0, 0);
    waiting_lines("Fr", bit_fill[0], OTHER_ROW, 0);

    {
        static volatile u32 *const FIRST[11] = { (volatile u32 *)0xA430000Cu, (volatile u32 *)0xA4040010u, (volatile u32 *)0xA404001Cu, (volatile u32 *)0xA410000Cu,
            (volatile u32 *)0xA4400010u, (volatile u32 *)0xA450000Cu, (volatile u32 *)0xA4600010u, (volatile u32 *)0xA4800018u,
            (volatile u32 *)((D_LINE + 0x80u) | 0x20000000u), (volatile u32 *)0xA4000FF0u, (volatile u32 *)0xA4001FF0u };
        for (u32 x = 0; x < 11u; x++) for (u32 m = 0; m < 6u; m++) {
            lay_asking(0, 1, 0, 0, m, 1);
            const struct ask q = { SP_STATUS, 0x10u, 0, FIRST[x], x == 8u ? prepare_row_open : 0, 0 };
            asking_line("W", x, m, &q);
        }
        for (u32 m = 0; m < 6u; m++) {
            lay_asking(0, 1, 0, 0, m, 2);
            const struct ask q = { SP_STATUS, 0x10u, 0, FIRST[0], 0, 0 };
            asking_line("T", 0, m, &q);
        }
    }
    for (u32 m = 0; m < 6u; m++) {
        lay_asking(0, 1, 0, 0, m, 0);
        const struct ask q = { (volatile u32 *)0xA430000Cu, 0x2u, 0, 0, 0, 1 };
        asking_line("M", 0, m, &q);
    }
    for (u32 m = 0; m < 6u; m++) {
        lay_asking(0, 1, 0, 0, m, 1);
        const struct ask q = { SP_STATUS, 0x8u, 0x10u, SP_STATUS, 0, 0 };
        asking_line("X", 0, m, &q);
    }
    for (u32 m = 0; m < 3u; m++) cause_line(m);
    for (u32 kind = 0; kind < 6u; kind++) for (u32 d = 0; d < 4u; d++) count_line(kind, d);
#endif
    say_tail(PROBE_TAG);
}
