/* The pairs probe's lines (taken into probes/cpu-align/probe.c, whose routines they use).

   What the instruction right behind a store through the data cache waits for. A routine is the
   alignment probe's: the head, the anchor, j idle instructions, a pair of instructions, m idle
   instructions, the store that asks, the row. The data line the pair works on is brought into the
   cache before every try, so nothing here waits for memory.
     Sh j m t s.. c..   a store through the data cache; the store that asks (made without the
                        cache, as it always is) follows m idle instructions behind it
     Lh j m ..          the same with a load through the data cache in the store's place
     Sr j m ..          a store through the data cache, and right behind it a read made without
                        the cache (the MI's version register)
     Si j m ..          the same with one idle instruction between the two
     Lr j m ..          a load through the data cache, and the same read right behind it
     G x m ..           no pair: x idle instructions (1 to 4) and the read, as the alignment
                        probe's G lines
     Sc j m ..          a store through the data cache, and a load through it right behind
     Sd j m ..          the same with one idle instruction between the two
     Ss j m ..          two stores through the data cache, one right behind the other
   j = 0 to 2, m = 0 to 5.

   How they are read. An instruction that waits one cycle leaves the routine where the same
   routine with one idle instruction more stands, in the row's place and in COUNT's steps alike:
     the read waits behind the store               the lines Sr j are the lines Si j (which are
                                                   G j+2); if it does not, they are G j+1
     the load through the cache waits              the lines Sc j are the lines Sd j
   At one place in three the RCP's clock gives both routines the same tick, and the lines cannot
   tell there: so each is asked at three places (j). The store that asks is read by its lines'
   own figures: a wait moves the tick at which it takes the bus as well as the row behind it.

   Care for the console: as the alignment probe. */

extern const u32 bit_load_line[], bit_read_version[];

/* The data line is in the cache when the routine is called. */
static void prepare_present(void) { (void)*(volatile u32 *)D_LINE; }

/* A routine that asks, with `n` instructions of its own between the j idle instructions behind
   the anchor and the m idle instructions before the store. */
static void lay_pair(u32 j, const u32 *pair, u32 n, u32 m) {
    laid = 0;
    code_go = here();
    lay_piece(bit_head, bit_head_end);
    lay(bit_anchor[0]);
    lay_idle(j);
    for (u32 i = 0; i < n; i++) lay(pair[i]);
    lay_idle(m);
    lay(bit_ask[0]);
    code_row = here();
    lay_idle(64u);
    code_back = here();
    lay(bit_return[0]); lay(0);
    code_end = here();
}

static void pair_lines(const char *tag, const u32 *pair, u32 n, u32 first, u32 last) {
    for (u32 j = first; j <= last; j++) for (u32 m = 0; m < 6u; m++) {
        lay_pair(j, pair, n, m);
        const struct ask q = { SP_STATUS, 0x10u, D_LINE, 0, prepare_present, 0 };
        asking_line(tag, j, m, &q);
    }
}

static void other_lines(void) {
    const u32 stow = bit_stow[0], load = bit_load_line[0], read = bit_read_version[0];
    { const u32 p[1] = { stow }; pair_lines("Sh", p, 1u, 0, 2u); }
    { const u32 p[1] = { load }; pair_lines("Lh", p, 1u, 0, 2u); }
    { const u32 p[2] = { stow, read }; pair_lines("Sr", p, 2u, 0, 2u); }
    { const u32 p[3] = { stow, 0, read }; pair_lines("Si", p, 3u, 0, 2u); }
    { const u32 p[2] = { load, read }; pair_lines("Lr", p, 2u, 0, 2u); }
    { const u32 p[1] = { read }; pair_lines("G", p, 1u, 1u, 4u); }
    { const u32 p[2] = { stow, load }; pair_lines("Sc", p, 2u, 0, 2u); }
    { const u32 p[3] = { stow, 0, load }; pair_lines("Sd", p, 3u, 0, 2u); }
    { const u32 p[2] = { stow, stow }; pair_lines("Ss", p, 2u, 0, 2u); }
}
