# The pairs probe's own pieces, beside the alignment probe's (probes/cpu-align/align.S). Each load
# here fills a register of its own, so that no instruction of a routine names the register the
# load before it filled: nothing in these routines waits for a loaded value.
    .set noreorder
    .set noat
    .text

    .globl bit_load_line
bit_load_line:
    lw    $12, 0($7)                # a load through the data cache from the address in $a3
    .globl bit_read_version
bit_read_version:
    lw    $13, 4($6)                # the MI's version register, read without the cache
