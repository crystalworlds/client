/* The pairs probe: a small test cartridge for a real console.

   The alignment probe (probes/cpu-align) built with other lines: what the instruction right behind
   a store through the data cache waits for. The processor's manual says the data cache is busy
   with a store for a second cycle, so that an instruction right behind it that uses the data cache
   waits one cycle. A console's lines of two other probes showed a store made without the cache
   waiting there as well. This probe asks for that again with nothing else in the way (the store's
   line is in the cache), and asks the same of a read made without the cache and of a load and a
   store through it. Its lines are said in lines.h, and everything else is the alignment probe's
   source as it stands.

   No line depends on the console's television type: the VI is switched off.

   Care for the console: as the alignment probe. Register reads and writes a game makes, loads and
   stores of main memory, the CPU's own interrupt and cache operations. Every wait has an end. */
#pragma GCC diagnostic ignored "-Wunused-function"
#define PROBE_TAG "CPUPAIRS"
#define PROBE_OTHER_LINES "../cpu-pairs/lines.h"
#include "../cpu-align/probe.c"
