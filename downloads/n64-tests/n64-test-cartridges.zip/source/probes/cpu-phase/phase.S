# The phase probe's routines. Each lets the RCP's interrupt line through, writes COUNT (as the time
# probe's S routine does), and then, by its kind:
#   S   n idle instructions, the store that asks the RSP for its interrupt, a row of 64 idle
#       instructions (the time probe's own routine, for n = 0 to 5)
#   P   an uncached read of the MI's version register (the anchor: the CPU waits for the RCP's answer),
#       m idle instructions, the same store, the same row
#   R   as P with a store of zero to the MI's mask register (which changes nothing) just before
#       the interrupt store
# The stub (probes/cpu-time/time.S) notes COUNT and the address it was called away from, and comes
# back behind the row. Each returns COUNT as it was set.
#   u32 phase_K_m(u32 *sp_status, u32 set, u32 *mi)
# And Q: the anchor, m idle instructions, then 16 pairs of a store to the RSP's semaphore and an
# uncached read of its status, timed by COUNT.
#   u32 pairs_m(u32 *sp, u32 *mi): steps of COUNT across the 16 pairs
    .set noreorder
    .set noat
    .text

    .macro phase kind, m
    .globl phase_\kind\()_\m
    .globl row_\kind\()_\m
    .globl back_\kind\()_\m
    .balign 32
phase_\kind\()_\m:
    mfc0  $t2, $12
    ori   $t2, $t2, 0x0401
    mtc0  $t2, $12
    nop
    nop
    nop
    nop
    mfc0  $v0, $9
    nop
    nop
    mtc0  $v0, $9
    .ifnc \kind, S
    lw    $t3, 4($a2)
    .endif
    .rept \m
    nop
    .endr
    .ifc \kind, R
    sw    $zero, 0xC($a2)
    .endif
    sw    $a1, 0($a0)
row_\kind\()_\m:
    .rept 64
    nop
    .endr
back_\kind\()_\m:
    jr    $ra
    nop
    .endm

    .irp kind, S, P, R
    .irp m, 0, 1, 2, 3, 4, 5
    phase \kind, \m
    .endr
    .endr

    .macro pairs m
    .globl pairs_\m
    .balign 32
pairs_\m:
    lw    $t3, 4($a1)
    .rept \m
    nop
    .endr
    mfc0  $t0, $9
    .rept 16
    sw    $zero, 0x1C($a0)
    lw    $t1, 0x10($a0)
    .endr
    mfc0  $v0, $9
    jr    $ra
    subu  $v0, $v0, $t0
    .endm

    .irp m, 0, 1, 2, 3, 4, 5
    pairs \m
    .endr
