/* The phase probe: a small test cartridge for a real console.

   On a console the tries probe's S lines (an interrupt of the RSP asked for by a store, every line
   of the routine in the cache) stop the CPU after 19, 19, 18, 19, 19, 18 instructions of a row for
   n = 0 to 5 idle instructions before the store; this core gives another pattern. Two candidates
   give the console's figures: A, the store's bus time starts one tick later than this core has it;
   B, the CPU sees the line one tick later and its cycles fall one tick otherwise against the RCP's
   clock after a wait. They part on where the CPU stands after a wait for the RCP. This probe makes
   that wait first: an uncached read of the MI's version register (the anchor), then m idle
   instructions, then the store.

   Lines (eight tries each, after one that brings the data lines in; every instruction line of the
   routine is filled in the cache first, so the row's place is the wait itself):
     S m t  s1 .. s8      the time probe's own routine, m idle instructions after the write to COUNT:
                          t tries taken by the interrupt, s the row's instructions run before it
     T m  c1 .. c8        their steps of COUNT from the write to COUNT to the stub
     P m t  s1 .. s8      the anchor, m idle instructions, the store
     p m  c1 .. c8
     R m t  s1 .. s8      as P with a store of zero to the MI's mask register just before the store
     r m  c1 .. c8
     Q m  c1 .. c8        the anchor, m idle instructions, then 16 pairs of a store to the RSP's
                          semaphore and an uncached read of its status: steps of COUNT across them
   for m = 0 to 5. COUNT steps once in two CPU cycles.

   No line depends on the console's television type: the VI is switched off.

   Care for the console: everything here is ordinary. Register reads and writes a game makes: the
   RSP's status (its interrupt set and taken back), its semaphore, the MI's mask and version; the
   CPU's own interrupt and cache operations. Every wait has an end. */

#include "../cart-lib/say.h"

#define VI_CTRL REG32(0xA4400000u)
#define MI_MASK REG32(0xA430000Cu)
#define SI_STATUS REG32(0xA4800018u)
#define PIF_LAST_WORD REG32(0xBFC007FCu)
#define SP_STATUS ((volatile u32 *)0xA4040010u)
#define SP_BASE ((volatile u32 *)0xA4040000u)
#define MI_BASE ((volatile u32 *)0xA4300000u)
#define UNCACHED(a) ((volatile u32 *)((a) | 0x20000000u))

/* What the exception stub leaves (probes/cpu-time/time.S). */
volatile u32 stamp, stamp_on, seen_epc, seen_cause, resume_at;
extern char vector_stub[], vector_stub_end[];

typedef u32 (*ask_t)(volatile u32 *, u32, volatile u32 *);
#define DECLARE(K) extern u32 phase_##K##_0(volatile u32 *, u32, volatile u32 *), phase_##K##_1(volatile u32 *, u32, volatile u32 *), phase_##K##_2(volatile u32 *, u32, volatile u32 *), \
    phase_##K##_3(volatile u32 *, u32, volatile u32 *), phase_##K##_4(volatile u32 *, u32, volatile u32 *), phase_##K##_5(volatile u32 *, u32, volatile u32 *); \
    extern char row_##K##_0[], row_##K##_1[], row_##K##_2[], row_##K##_3[], row_##K##_4[], row_##K##_5[], back_##K##_0[], back_##K##_1[], back_##K##_2[], back_##K##_3[], back_##K##_4[], back_##K##_5[];
DECLARE(S) DECLARE(P) DECLARE(R)
extern u32 pairs_0(volatile u32 *, volatile u32 *), pairs_1(volatile u32 *, volatile u32 *), pairs_2(volatile u32 *, volatile u32 *), pairs_3(volatile u32 *, volatile u32 *), pairs_4(volatile u32 *, volatile u32 *), pairs_5(volatile u32 *, volatile u32 *);

static const ask_t ASK[3][6] = { { phase_S_0, phase_S_1, phase_S_2, phase_S_3, phase_S_4, phase_S_5 }, { phase_P_0, phase_P_1, phase_P_2, phase_P_3, phase_P_4, phase_P_5 }, { phase_R_0, phase_R_1, phase_R_2, phase_R_3, phase_R_4, phase_R_5 } };
static char *const ROW[3][6] = { { row_S_0, row_S_1, row_S_2, row_S_3, row_S_4, row_S_5 }, { row_P_0, row_P_1, row_P_2, row_P_3, row_P_4, row_P_5 }, { row_R_0, row_R_1, row_R_2, row_R_3, row_R_4, row_R_5 } };
static char *const BACK[3][6] = { { back_S_0, back_S_1, back_S_2, back_S_3, back_S_4, back_S_5 }, { back_P_0, back_P_1, back_P_2, back_P_3, back_P_4, back_P_5 }, { back_R_0, back_R_1, back_R_2, back_R_3, back_R_4, back_R_5 } };
static u32 (*const PAIRS[6])(volatile u32 *, volatile u32 *) = { pairs_0, pairs_1, pairs_2, pairs_3, pairs_4, pairs_5 };

/* Long enough for the write buffer to empty and a store to take effect. */
static void idle(void) { for (volatile u32 i = 0; i < 200u; i++) { } }
static void fill_lines(u32 from, u32 to) { for (u32 a = from & ~31u; a < to; a += 32u) __asm__ volatile("cache 0x14, 0(%0)" : : "r"(a)); }

static void interrupt_lines(u32 k, u32 m) {
    static const char *const TAG[3] = { "S", "P", "R" }, *const STEPS[3] = { "T", "p", "r" };
    u32 stopped[8], steps[8], taken = 0;
    for (u32 turn = 0; turn < 9u; turn++) {
        *SP_STATUS = 0x8u;                      /* the RSP's interrupt taken back */
        MI_MASK = 0x2u;                         /* and let through the MI */
        idle();
        stamp_on = 0;
        resume_at = (u32)BACK[k][m];
        fill_lines((u32)ASK[k][m], (u32)BACK[k][m] + 8u);
        const u32 set = ASK[k][m](SP_STATUS, 0x10u, MI_BASE);
        MI_MASK = 0x1u;
        *SP_STATUS = 0x8u;
        idle();
        if (turn == 0) continue;                /* the first turn brings the data lines in */
        stopped[turn - 1] = (seen_epc - (u32)ROW[k][m]) / 4u; steps[turn - 1] = stamp - set;
        if (stamp_on) taken++;
    }
    say_text(TAG[k]); say_hex(m, 1); say_hex(taken, 1); for (u32 i = 0; i < 8u; i++) say_hex(stopped[i], 2); say_flush();
    say_text(STEPS[k]); say_hex(m, 1); for (u32 i = 0; i < 8u; i++) say_hex(steps[i], 4); say_flush();
}

static void pair_line(u32 m) {
    u32 steps[8];
    for (u32 turn = 0; turn < 9u; turn++) {
        idle();
        fill_lines((u32)PAIRS[m], (u32)PAIRS[m] + 192u);
        const u32 v = PAIRS[m](SP_BASE, MI_BASE);
        if (turn) steps[turn - 1] = v;
    }
    say_text("Q"); say_hex(m, 1); for (u32 i = 0; i < 8u; i++) say_hex(steps[i], 4); say_flush();
}

void probe_main(void) {
    /* The PIF stops a console whose program has not told it within five seconds that the boot is over. */
    while (SI_STATUS & 3u) { }
    PIF_LAST_WORD = 8u;
    while (SI_STATUS & 3u) { }
    MI_MASK = 0x555u;                           /* no interrupt of the RCP reaches the CPU */
    VI_CTRL = 0;                                /* the video chip off: it reads no memory */
    __asm__ volatile("mtc0 %0, $12" : : "r"(0x34000000u));
    /* The stub goes to the three vectors, written without the cache, and their instruction lines are thrown out. */
    for (u32 v = 0; v < 3u; v++) {
        const u32 to = v == 0 ? 0x80000000u : v == 1 ? 0x80000080u : 0x80000180u;
        const u32 *from = (const u32 *)vector_stub, words = (u32)(vector_stub_end - vector_stub) / 4u;
        for (u32 i = 0; i < words; i++) UNCACHED(to)[i] = from[i];
        for (u32 a = to; a < to + words * 4u; a += 32u) __asm__ volatile("cache 0x10, 0(%0)" : : "r"(a));
        __asm__ volatile("cache 0x10, 0(%0)" : : "r"(to + words * 4u - 4u));
    }
    say_head("CPUPHASE");
    for (u32 k = 0; k < 3u; k++) for (u32 m = 0; m < 6u; m++) interrupt_lines(k, m);
    for (u32 m = 0; m < 6u; m++) pair_line(m);
    say_tail("CPUPHASE");
}
