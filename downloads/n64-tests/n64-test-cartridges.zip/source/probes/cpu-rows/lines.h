/* The rows probe's lines (taken into probes/cpu-align/probe.c, whose routines they use).

   A routine is the alignment probe's with a read made without the cache in the anchor's place:
   the head, the read, g idle instructions, the line of instructions asked for, m idle
   instructions, the store that asks, the row. Before it is called a read of memory made without
   the cache leaves one row of the memory chip open, and the MI's version register is read twice
   with one idle instruction between (the waits probe's way of leaving the CPU at one place).
     Rv gg m t s.. c..  the line is asked for by the Fill operation
     Ev gg m ..         the routine runs on into the line, which was thrown out of the cache
     Qv gg m ..         as Rv with a read of the MI's version register between the read and
                        the g idle instructions (v = 0 and 1, g = 0 to 2)
     Uv gg m ..         as Rv with a read of the line's place made without the cache where the
                        Fill operation stands: what one word pays for the row (v = 1 to 4,
                        g = 0, 1, 2, 4, 8 and 16)
   v says what the read in the routine is, and what it leaves the line to find:
     0   a read of the line's own row, which changes the open row: the line finds its row open
     1   a read of a row that is neither the open one nor the line's: the read changes the row,
         and the line changes it again (the bus bench's rows are of this kind)
     2   a read of the open row, which is not the line's: the line changes the row
     3   a read of the MI's version register; the open row is not the line's: the line changes
         the row (the alignment probe's Fr lines and the waits probe's Nb lines are of this kind)
     4   a read of the open row, which is the line's: nothing changes the row
   gg is 0 to 9, 12, 16, 24 and for the Fill operation 40, in hexadecimal.

   A store and a load through the data cache whose line is not there, with the store that asks
   up to eleven idle instructions behind (the alignment probe's lines stop at five):
     Da j m ..          a load, its line thrown out clean, the line's row open
     Za j m ..          a store, the same
     Dm j m ..          a load, its line written back and left invalid with its dirty mark on
                        (what the bus bench's rows for a store leave)
     Zm j m ..          a store, the same
   j = 0 to 2 idle instructions behind the anchor, m = 0 to 11.

   How they are read. The lines of one routine for m = 0 to 5 give where the asking store fell
   against the RCP's clock and COUNT's steps to the handler. What the other row costs a line is
   read by setting the six lines of v = 1, 2 and 3 beside those of v = 0 and 4 at the same g,
   and beside this core's own lines with the row's figure at 4 and at 5.

   Care for the console: as the alignment probe. */

extern const u32 bit_open[];

#define ROWS_LINE (CODE + 0x800u)           /* the line a routine runs into: the first of a row of memory */
#define ROWS_THIRD (CODE + 0x5000u)         /* a row that is neither the routines' nor the Fill operation's */
#define MI_VERSION_AT 0xA4300004u

static void prepare_marked(void) {
    *(volatile u32 *)D_LINE = 1;
    __asm__ volatile("cache 0x15, 0(%0)" : : "r"(D_LINE));
    prepare_row_open();
}

/* Nine tries of the routine that is laid: the first brings everything in, eight are printed. */
static void rows_try(const char *tag, u32 g, u32 m, u32 before, u32 a3, u32 a4, u32 thrown) {
    u32 stopped[8], steps[8], taken = 0;
    for (u32 turn = 0; turn < 9u; turn++) {
        interrupts_off();
        *SP_STATUS = 0x8u;
        MI_MASK = 0x2u;
        idle();
        stamp_on = 0;
        resume_at = code_back;
        fill_lines(code_go, code_back + 8u);
        if (thrown) __asm__ volatile("cache 0x10, 0(%0)" : : "r"(thrown));
        (void)*UNCACHED(before);                    /* the row of memory left open */
        __asm__ volatile(".set push\n.set noreorder\nlw $2, 4(%0)\nnop\nlw $2, 4(%0)\n.set pop" : : "r"(MI_BASE) : "$2");
        const u32 set = ((go_t)code_go)(SP_STATUS, 0x10u, MI_BASE, a3, (volatile u32 *)a4);
        MI_MASK = 0x1u;
        *SP_STATUS = 0x8u;
        idle();
        if (turn == 0) continue;
        stopped[turn - 1] = stamp_on ? ((seen_epc - code_row) / 4u) & 0xFFu : 0xFFu;
        steps[turn - 1] = stamp_on ? (stamp - set) & 0xFFu : 0xFFu;
        if (stamp_on) taken++;
    }
    say_text(tag); say_hex(g, 2); say_hex(m, 1); say_hex(taken, 1);
    for (u32 i = 0; i < 8u; i++) say_hex(stopped[i], 2);
    for (u32 i = 0; i < 8u; i++) say_hex(steps[i], 2);
    say_flush();
}

/* The head, the read, an anchor if asked for, g idle instructions, the instruction that asks for
   the line (the Fill operation, or a read of its place), m idle instructions, the store that asks,
   the row. */
static void lay_fill(u32 anchor, u32 g, u32 m, u32 asks) {
    laid = 0;
    code_go = here();
    lay_piece(bit_head, bit_head_end);
    lay(bit_open[0]);
    if (anchor) lay(bit_anchor[0]);
    lay_idle(g);
    lay(asks);
    lay_idle(m);
    lay(bit_ask[0]);
    code_row = here();
    lay_idle(64u);
    code_back = here();
    lay(bit_return[0]); lay(0);
    code_end = here();
}

/* The head, the read and g idle instructions end where the line ROWS_LINE begins; m idle
   instructions, the store that asks and the row lie in that line and behind it. */
static void lay_into_line(u32 g, u32 m) {
    const u32 k = (8u - (12u + g) % 8u) % 8u;
    const u32 base = ROWS_LINE - 4u * (k + 12u + g);
    volatile u32 *w = (volatile u32 *)(base | 0x20000000u);
    u32 n = 0;
    for (u32 i = 0; i < k; i++) w[n++] = 0;
    code_go = base + 4u * n;
    for (const u32 *p = bit_head; p < bit_head_end; p++) w[n++] = *p;
    w[n++] = bit_open[0];
    for (u32 i = 0; i < g + m; i++) w[n++] = 0;
    w[n++] = bit_ask[0];
    code_row = base + 4u * n;
    for (u32 i = 0; i < 64u; i++) w[n++] = 0;
    code_back = base + 4u * n;
    w[n++] = bit_return[0]; w[n++] = 0;
    code_end = base + 4u * n;
}

static void other_lines(void) {
    static const u32 GAPS[14] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 16, 24, 40 };
    /* What is read before the call and in the routine, for each v: by the Fill operation, whose line
       is OTHER_ROW, and by running into ROWS_LINE. */
    static const u32 FILL_BEFORE[5] = { CODE + 0x400u, OTHER_ROW + 0x40u, CODE + 0x400u, CODE + 0x400u, OTHER_ROW + 0x40u };
    static const u32 FILL_READ[5] = { (OTHER_ROW + 0x40u) | 0x20000000u, ROWS_THIRD | 0x20000000u, (CODE + 0x440u) | 0x20000000u, MI_VERSION_AT, (OTHER_ROW + 0x80u) | 0x20000000u };
    static const u32 LINE_BEFORE[5] = { ROWS_LINE - 0x400u, ROWS_LINE + 0x400u, ROWS_LINE - 0x400u, ROWS_LINE - 0x400u, ROWS_LINE + 0x400u };
    static const u32 LINE_READ[5] = { (ROWS_LINE + 0x400u) | 0x20000000u, (ROWS_LINE - 0x400u) | 0x20000000u, (ROWS_LINE - 0x3C0u) | 0x20000000u, MI_VERSION_AT, (ROWS_LINE + 0x440u) | 0x20000000u };
    static const char *const R[5] = { "R0", "R1", "R2", "R3", "R4" }, *const E[5] = { "E0", "E1", "E2", "E3", "E4" }, *const Q[2] = { "Q0", "Q1" };

    for (u32 v = 0; v < 5u; v++) for (u32 i = 0; i < 14u; i++) for (u32 m = 0; m < 6u; m++) {
        lay_fill(0, GAPS[i], m, bit_fill[0]);
        rows_try(R[v], GAPS[i], m, FILL_BEFORE[v], OTHER_ROW, FILL_READ[v], 0);
    }
    for (u32 v = 0; v < 2u; v++) for (u32 g = 0; g < 3u; g++) for (u32 m = 0; m < 6u; m++) {
        lay_fill(1, g, m, bit_fill[0]);
        rows_try(Q[v], g, m, FILL_BEFORE[v], OTHER_ROW, FILL_READ[v], 0);
    }
    for (u32 v = 1; v < 5u; v++) for (u32 i = 0; i < 6u; i++) for (u32 m = 0; m < 6u; m++) {
        static const u32 WORD_GAPS[6] = { 0, 1, 2, 4, 8, 16 };
        static const char *const U[5] = { "U0", "U1", "U2", "U3", "U4" };
        lay_fill(0, WORD_GAPS[i], m, bit_load[0]);
        rows_try(U[v], WORD_GAPS[i], m, FILL_BEFORE[v], OTHER_ROW | 0x20000000u, FILL_READ[v], 0);
    }
    for (u32 v = 0; v < 5u; v++) for (u32 i = 0; i < 13u; i++) for (u32 m = 0; m < 6u; m++) {
        lay_into_line(GAPS[i], m);
        rows_try(E[v], GAPS[i], m, LINE_BEFORE[v], 0, LINE_READ[v], ROWS_LINE);
    }
    for (u32 kind = 0; kind < 4u; kind++) for (u32 j = 0; j < 3u; j++) for (u32 m = 0; m < 12u; m++) {
        lay_asking(0, 1, j, kind & 1u ? bit_stow[0] : bit_load[0], m, 0);
        const struct ask q = { SP_STATUS, 0x10u, D_LINE, 0, kind & 2u ? prepare_marked : prepare_absent, 0 };
        asking_line(kind == 0 ? "Da" : kind == 1 ? "Za" : kind == 2 ? "Dm" : "Zm", j, m, &q);
    }
}
