/* The rows probe: a small test cartridge for a real console.

   The alignment probe (probes/cpu-align) built with other lines: what a line of instructions
   costs when the memory chip has another row open than the line's. Two instruments disagreed on
   it: the alignment and the waits probes read 5 cycles of the RCP's clock on two consoles, and
   the public bus bench's rows fit 4 on the same two. In the bench a read of the other row made
   without the cache stands a few instructions before the line is asked for; in the probes a read
   of a register of the MI stands between. This probe asks for the line at a chosen number of idle
   instructions behind a read of memory, with each kind of read, by the Fill operation and by
   running into the line. Its lines are said in lines.h, and everything else is the alignment
   probe's source as it stands.

   No line depends on the console's television type: the VI is switched off.

   Care for the console: as the alignment probe. Register reads and writes a game makes, loads and
   stores of main memory, the CPU's own interrupt and cache operations. Every wait has an end. */
#pragma GCC diagnostic ignored "-Wunused-function"
#define PROBE_TAG "CPUROWS"
#define PROBE_OTHER_LINES "../cpu-rows/lines.h"
#include "../cpu-align/probe.c"
