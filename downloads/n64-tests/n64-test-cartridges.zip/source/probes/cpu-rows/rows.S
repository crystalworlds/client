# The rows probe's own piece, beside the alignment probe's (probes/cpu-align/align.S). The read
# fills a register of its own, so that no instruction of a routine names the register it filled.
    .set noreorder
    .set noat
    .text

    .globl bit_open
bit_open:
    lw    $13, 0($8)                # a read made without the cache from the address in $a4
