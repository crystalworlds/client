/* The CPU timing probe: a small test cartridge for a real console.

   It asks the questions about the CPU's time that the tests run on this
   computer cannot settle, and prints every answer as a line of text through
   the debug text window a flash cartridge shows on the computer beside the
   console. Run on this core, the same lines show what the core does; the two
   logs are then compared line by line.

   What it asks (every count is in CPU cycles unless the line says steps):
     N  the measuring loop itself: 0, 1 and 5 instructions that do nothing
     X  the time to reach the handler: from a breakpoint, an overflow, a load
        from a misaligned address, and a jump to a misaligned address (an
        exception of the fetch, which no test here times)
     C  each CACHE operation, on a line that is in the cache clean, in it
        dirty, or not in it
     W  a store and a load through the data cache that must first write a
        dirty line back
     J  whether a jump waits after a load when the loaded register's number
        sits in the jump's target bits
     R  what Random reads after a divide, against after an instruction of one
        cycle: once an instruction, or once a cycle
     T  after how many turns of a six-cycle loop the timer's bit shows in
        Cause, with the loop moved one instruction at a time
     I  the timer's interrupt: which instruction of a row it stops, and what
        COUNT reads in the handler's first instruction
     S  the same for an interrupt of the RCP that a store asks for (the RSP's
        own): how long after the store the CPU is called away
     M  2,048 single reads of main memory with the video chip off, a little
        further apart each time: how many took each length, and the longest

   A value with a tilde before it may differ by a little from run to run on a
   console. All values are in hex. Nothing here can harm a console: the video
   chip is only turned off, and every wait has an end. */

typedef unsigned int u32;

#define PI_STATUS (*(volatile u32 *)0xA4600010u)
#define TEXT_LENGTH (*(volatile u32 *)0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)
#define VI_CTRL (*(volatile u32 *)0xA4400000u)
#define MI_MASK (*(volatile u32 *)0xA430000Cu)
#define SI_STATUS (*(volatile u32 *)0xA4800018u)
#define PIF_LAST_WORD (*(volatile u32 *)0xBFC007FCu)
#define SP_STATUS ((volatile u32 *)0xA4040010u)

/* What the exception stub leaves (time.S). */
volatile u32 stamp, stamp_on, seen_epc, seen_cause, resume_at;

extern char vector_stub[], vector_stub_end[];
extern u32 measure(void (*piece)(void), u32 arg, void (*prepare)(void));
extern void piece_0(void), piece_1(void), piece_5(void);
extern void piece_break(void), piece_overflow(void), piece_load_error(void), piece_fetch_error(void);
extern char piece_break_back[], piece_overflow_back[], piece_load_error_back[], piece_fetch_error_back[];
extern void piece_cache_0x00(void), piece_cache_0x01(void), piece_cache_0x04(void), piece_cache_0x05(void), piece_cache_0x08(void), piece_cache_0x09(void),
    piece_cache_0x0D(void), piece_cache_0x10(void), piece_cache_0x11(void), piece_cache_0x14(void), piece_cache_0x15(void), piece_cache_0x18(void), piece_cache_0x19(void);
extern void piece_store(void), piece_load(void), piece_jump_named(void), piece_jump_other(void);
extern u32 random_after_divide(u32), random_after_nop(u32);
extern u32 timer_poll_0(void), timer_poll_1(void), timer_poll_2(void), timer_poll_3(void), timer_poll_4(void), timer_poll_5(void);
extern u32 timer_interrupt_0(u32 ahead), timer_interrupt_1(u32 ahead);
extern char timer_row_0[], timer_back_0[], timer_row_1[], timer_back_1[];
extern u32 rcp_interrupt_0(volatile u32 *sp_status, u32 set), rcp_interrupt_1(volatile u32 *sp_status, u32 set);
extern char rcp_row_0[], rcp_back_0[], rcp_row_1[], rcp_back_1[];
#ifdef CPU_TIME_EACH_TRY
extern u32 rcp_interrupt_2(volatile u32 *sp_status, u32 set), rcp_interrupt_3(volatile u32 *sp_status, u32 set), rcp_interrupt_4(volatile u32 *sp_status, u32 set), rcp_interrupt_5(volatile u32 *sp_status, u32 set);
extern char rcp_row_2[], rcp_back_2[], rcp_row_3[], rcp_back_3[], rcp_row_4[], rcp_back_4[], rcp_row_5[], rcp_back_5[];
#endif
extern u32 read_once(volatile u32 *where);
extern char _start[];

/* ---- Printing ---------------------------------------------------------------------- */

static char line[200];
static char *at;
static u32 lines, fold;

#include "../debug-text.h"

static void put(const char *s) { while (*s) *at++ = *s++; }
static void hex(u32 v, u32 digits) { for (u32 i = 0; i < digits; i++) { u32 d = (v >> ((digits - 1u - i) * 4u)) & 15u; *at++ = (char)(d < 10u ? '0' + d : 'a' + d - 10u); } }
static void num(u32 v) { *at++ = ' '; hex(v, 8); }
static void small(u32 v) { *at++ = ' '; hex(v, 4); }
static void about(u32 v) { *at++ = ' '; *at++ = '~'; hex(v, 4); }
static void begin(const char *tag) { at = line; put(tag); }
static void end(void) {
    *at++ = '\n';
    u32 n = (u32)(at - line);
    for (u32 i = 0; i < n; i++) fold = (fold << 5 | fold >> 27) ^ (u32)(unsigned char)line[i];
    debug_text(line, n);
    lines++;
}

/* ---- The pieces of memory the probe works on ----------------------------------------- */

/* 32 KiB that nothing else uses, at a fixed place well above the program: its first instruction
   line and its data lines do not share a place in either cache with the program's own code. */
#define FIELD 0x80200000u
#define I_LINE (FIELD + 0x3000u)            /* the instruction line the CACHE pieces work on */
#define D_LINE (FIELD + 0x1000u)            /* the data line */
#define D_OTHER (D_LINE + 0x2000u)          /* the line that shares the data line's place in the cache */
#define UNCACHED(a) ((volatile u32 *)((a) | 0x20000000u))

static void prepare_clean(void) { (void)*(volatile u32 *)D_LINE; __asm__ volatile("cache 0x19, 0(%0)" : : "r"(D_LINE)); }
static void prepare_dirty(void) { *(volatile u32 *)D_LINE = 1; }
static void prepare_absent(void) { __asm__ volatile("cache 0x11, 0(%0)" : : "r"(D_LINE)); }
static void prepare_other_dirty(void) { *(volatile u32 *)D_OTHER = 1; }
static void prepare_other_clean(void) { (void)*(volatile u32 *)D_OTHER; __asm__ volatile("cache 0x19, 0(%0)" : : "r"(D_OTHER)); }
static void prepare_code_in(void) { __asm__ volatile("cache 0x14, 0(%0)" : : "r"(I_LINE)); }
static void prepare_code_out(void) { __asm__ volatile("cache 0x10, 0(%0)" : : "r"(I_LINE)); }
static void prepare_tag_zero(void) { __asm__ volatile("mtc0 $0, $28"); }

/* Long enough for the write buffer to empty and a store to take effect. */
static void idle(void) { for (volatile u32 i = 0; i < 200u; i++) { } }

/* The smallest of eight measurements, and how many of the eight gave it. The tries probe is this
   same program built with CPU_TIME_EACH_TRY: it prints each of the eight instead. */
static void timed(const char *tag, void (*piece)(void), u32 arg, void (*prepare)(void), u32 beyond) {
#ifdef CPU_TIME_EACH_TRY
    begin(tag);
    for (u32 i = 0; i < 8; i++) small(measure(piece, arg, prepare) - beyond);
    end();
#else
    u32 least = ~0u, times = 0;
    for (u32 i = 0; i < 8; i++) {
        u32 v = measure(piece, arg, prepare) - beyond;
        if (v < least) { least = v; times = 1; } else if (v == least) times++;
    }
    begin(tag); small(least); small(times); end();
#endif
}

static void to_handler(const char *tag, void (*piece)(void), u32 arg, char *back) {
    resume_at = (u32)back;
    timed(tag, piece, arg, 0, 2);
    begin(tag); put(" cause"); num(seen_cause & 0x7Cu); put(" epc"); num(seen_epc - (u32)piece); end();
}

void probe_main(void) {
    /* The PIF stops a console whose program has not told it within five seconds that the boot is over. */
    while (SI_STATUS & 3u) { }
    PIF_LAST_WORD = 8u;
    while (SI_STATUS & 3u) { }
    MI_MASK = 0x555u;                           /* no interrupt of the RCP reaches the CPU */
    VI_CTRL = 0;                                /* the video chip off: it reads no memory */
    __asm__ volatile("mtc0 %0, $12" : : "r"(0x34000000u));

    /* The stub goes to the three vectors, written without the cache, and their instruction lines are thrown out. */
    for (u32 v = 0; v < 3; v++) {
        u32 to = v == 0 ? 0x80000000u : v == 1 ? 0x80000080u : 0x80000180u;
        const u32 *from = (const u32 *)vector_stub;
        u32 words = (u32)(vector_stub_end - vector_stub) / 4u;
        for (u32 i = 0; i < words; i++) UNCACHED(to)[i] = from[i];
        for (u32 a = to; a < to + words * 4u; a += 32u) __asm__ volatile("cache 0x10, 0(%0)" : : "r"(a));
        __asm__ volatile("cache 0x10, 0(%0)" : : "r"(to + words * 4u - 4u));
    }
    /* A routine of two instructions (return, and nothing) where a jump's target bits name register 1. */
    UNCACHED(0x80040000u)[0] = 0x03E00008u; UNCACHED(0x80040000u)[1] = 0;
    /* The field: instructions that do nothing, ending in a return, so that its lines can be filled as code. */
    for (u32 i = 0; i < 0x2000u; i++) UNCACHED(FIELD)[i] = 0;
    UNCACHED(I_LINE)[7] = 0x03E00008u;

#ifdef CPU_TIME_EACH_TRY
    begin("CPUTRIES 1"); num((u32)(vector_stub_end - vector_stub)); end();
#else
    begin("CPUPROBE 1"); num((u32)(vector_stub_end - vector_stub)); end();
#endif
    begin("CODE"); num((u32)_start); num((u32)read_once - (u32)_start); end();

    /* N: the loop itself. */
    timed("N 0", piece_0, 0, 0, 5);
    timed("N 1", piece_1, 0, 0, 5);
    timed("N 5", piece_5, 0, 0, 5);

    /* X: to the handler. */
    to_handler("X break", piece_break, 0, piece_break_back);
    to_handler("X overflow", piece_overflow, 0x7FFFFFFFu, piece_overflow_back);
    to_handler("X load", piece_load_error, D_LINE + 1u, piece_load_error_back);
    to_handler("X fetch", piece_fetch_error, (u32)piece_fetch_error_back + 2u, piece_fetch_error_back);

    /* C: the CACHE operations. The data cache's first. */
    timed("C 01 clean", piece_cache_0x01, D_LINE, prepare_clean, 5);
    timed("C 01 dirty", piece_cache_0x01, D_LINE, prepare_dirty, 5);
    timed("C 05 clean", piece_cache_0x05, D_LINE, prepare_clean, 5);
    prepare_tag_zero();
    timed("C 09", piece_cache_0x09, D_LINE, prepare_tag_zero, 5);
    timed("C 0d absent", piece_cache_0x0D, D_LINE, prepare_absent, 5);
    timed("C 11 clean", piece_cache_0x11, D_LINE, prepare_clean, 5);
    timed("C 11 absent", piece_cache_0x11, D_LINE, prepare_absent, 5);
    timed("C 15 clean", piece_cache_0x15, D_LINE, prepare_clean, 5);
    timed("C 15 dirty", piece_cache_0x15, D_LINE, prepare_dirty, 5);
    timed("C 19 clean", piece_cache_0x19, D_LINE, prepare_clean, 5);
    timed("C 19 dirty", piece_cache_0x19, D_LINE, prepare_dirty, 5);
    timed("C 19 absent", piece_cache_0x19, D_LINE, prepare_absent, 5);
    /* The instruction cache's. */
    timed("C 00 in", piece_cache_0x00, I_LINE, prepare_code_in, 5);
    timed("C 04 in", piece_cache_0x04, I_LINE, prepare_code_in, 5);
    timed("C 08", piece_cache_0x08, I_LINE, prepare_tag_zero, 5);
    timed("C 10 in", piece_cache_0x10, I_LINE, prepare_code_in, 5);
    timed("C 10 out", piece_cache_0x10, I_LINE, prepare_code_out, 5);
    timed("C 14 in", piece_cache_0x14, I_LINE, prepare_code_in, 5);
    timed("C 14 out", piece_cache_0x14, I_LINE, prepare_code_out, 5);
    timed("C 18 in", piece_cache_0x18, I_LINE, prepare_code_in, 5);

    /* W: a line that must be written back first, against one that need not be. */
    timed("W store clean", piece_store, D_LINE, prepare_other_clean, 5);
    timed("W store dirty", piece_store, D_LINE, prepare_other_dirty, 5);
    timed("W load clean", piece_load, D_LINE, prepare_other_clean, 5);
    timed("W load dirty", piece_load, D_LINE, prepare_other_dirty, 5);

    /* J: a jump after a load. */
    timed("J named", piece_jump_named, D_LINE, 0, 5);
    timed("J other", piece_jump_other, D_LINE, 0, 5);

    /* R: Random. */
    begin("R divide"); small(random_after_divide(3)); put(" nop"); small(random_after_nop(3)); end();

    /* T: the timer's bit. */
    begin("T");
    small(timer_poll_0()); small(timer_poll_1()); small(timer_poll_2()); small(timer_poll_3()); small(timer_poll_4()); small(timer_poll_5());
    end();

    /* I: the timer's interrupt: once with COMPARE far ahead, to have the row in the cache, then ten steps ahead. */
    for (u32 n = 0; n < 2; n++) {
        u32 compare = 0;
        for (u32 turn = 0; turn < 2; turn++) {
            stamp_on = 0;
            resume_at = (u32)(n ? timer_back_1 : timer_back_0);
            compare = n ? timer_interrupt_1(turn ? 10u : 200u) : timer_interrupt_0(turn ? 10u : 200u);
        }
        begin(n ? "I 1" : "I 0");
        put(stamp_on ? " taken" : " none");
        put(" stopped"); small((seen_epc - (u32)(n ? timer_row_1 : timer_row_0)) / 4u);
        put(" steps"); small(stamp - compare);
        put(" cause"); num(seen_cause & 0xFF7Cu);
        end();
    }

#ifdef CPU_TIME_EACH_TRY
    /* S: an interrupt of the RCP, asked for by a store to the RSP's status register, with every
       instruction line of the routine and of its row of 64 idle instructions filled beforehand
       (the Fill operation), so that the interrupt never comes while the row's next line is still
       being fetched: where the row stops is then the wait itself. Six distances between the write
       to COUNT and the store, eight tries each: where each try stopped, and its steps of COUNT. */
    for (u32 n = 0; n < 6; n++) {
        static u32 (*const ASK[6])(volatile u32 *, u32) = { rcp_interrupt_0, rcp_interrupt_1, rcp_interrupt_2, rcp_interrupt_3, rcp_interrupt_4, rcp_interrupt_5 };
        static char *const ROW[6] = { rcp_row_0, rcp_row_1, rcp_row_2, rcp_row_3, rcp_row_4, rcp_row_5 };
        static char *const BACK[6] = { rcp_back_0, rcp_back_1, rcp_back_2, rcp_back_3, rcp_back_4, rcp_back_5 };
        u32 stopped[8], steps[8], taken = 0;
        for (u32 turn = 0; turn < 9; turn++) {
            *SP_STATUS = 0x8u;                  /* the RSP's interrupt taken back */
            MI_MASK = 0x2u;                     /* and let through the MI */
            idle();
            stamp_on = 0;
            resume_at = (u32)BACK[n];
            for (u32 a = (u32)ASK[n] & ~31u; a < (u32)BACK[n] + 8u; a += 32u) __asm__ volatile("cache 0x14, 0(%0)" : : "r"(a));
            const u32 set = ASK[n](SP_STATUS, 0x10u);
            MI_MASK = 0x1u;
            *SP_STATUS = 0x8u;
            idle();
            if (turn == 0) continue;            /* the first turn brings the data lines in */
            stopped[turn - 1] = (seen_epc - (u32)ROW[n]) / 4u; steps[turn - 1] = stamp - set;
            if (stamp_on) taken++;
        }
        begin("S"); small(n); put(" taken"); small(taken); put(" stopped"); for (u32 i = 0; i < 8; i++) small(stopped[i]); end();
        begin("S"); small(n); put(" steps"); for (u32 i = 0; i < 8; i++) small(steps[i]); end();
    }
#else
    /* S: an interrupt of the RCP, asked for by a store to the RSP's status register. */
    for (u32 n = 0; n < 2; n++) {
        u32 set = 0;
        for (u32 turn = 0; turn < 2; turn++) {
            *SP_STATUS = 0x8u;                  /* the RSP's interrupt taken back */
            MI_MASK = 0x2u;                     /* and let through the MI */
            idle();
            stamp_on = 0;
            resume_at = (u32)(n ? rcp_back_1 : rcp_back_0);
            set = n ? rcp_interrupt_1(SP_STATUS, 0x10u) : rcp_interrupt_0(SP_STATUS, 0x10u);
            MI_MASK = 0x1u;
            *SP_STATUS = 0x8u;
            idle();
        }
        begin(n ? "S 1" : "S 0");
        put(stamp_on ? " taken" : " none");
        put(" stopped"); small((seen_epc - (u32)(n ? rcp_row_1 : rcp_row_0)) / 4u);
        put(" steps"); small(stamp - set);
        put(" cause"); num(seen_cause & 0xFF7Cu);
        end();
    }
#endif

    /* M: single reads of main memory, the video chip off. The wait between two reads grows by one
       turn each time, so the reads fall at every place of a picture line. */
    {
        static u32 seen[64];
        u32 longest = 0, long_at = 0, longs = 0;
        volatile u32 *where = UNCACHED(FIELD + 0x4000u);
        (void)read_once(where);
        for (u32 i = 0; i < 2048u; i++) {
            for (volatile u32 k = 0; k < (i & 255u); k++) { }
            u32 steps = read_once(where);
            seen[steps < 63u ? steps : 63u]++;
            if (steps > longest) { longest = steps; long_at = i; }
            if (steps > 20u) longs++;
        }
        for (u32 s = 0; s < 64u; s++) if (seen[s]) { begin("M steps"); small(s); put(" reads"); about(seen[s]); end(); }
        begin("M longest"); about(longest); put(" at"); about(long_at); put(" over 20 steps"); about(longs); end();
    }

#ifdef CPU_TIME_EACH_TRY
    begin("CPUTRIES END"); num(lines); num(fold); end();
#else
    begin("CPUPROBE END"); num(lines); num(fold); end();
#endif
}
