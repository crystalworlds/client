# The CPU timing probe's assembly: the measuring loop, the exception stub, and
# the small pieces of code that are timed.
#
# How a piece is timed. COUNT steps once in two CPU cycles, so one reading says
# little. A write to COUNT fixes which of each two cycles it steps on; the piece
# is then run twice, the second time one instruction later, and the two
# differences of COUNT add up to the number of cycles between the two readings.
# (The same idea as the system test suite's timing level; the code is ours.)

    .set noreorder
    .set noat
    .text

# ---- The exception stub ---------------------------------------------------------
# Copied to the three exception vectors. It notes COUNT before anything else,
# then where and why it was called, puts the timer's next request far away
# (which also takes back the one that may have brought it here), shuts every
# interrupt out, and goes on at the address the probe left in resume_at.
    .globl vector_stub
    .globl vector_stub_end
vector_stub:
    mfc0  $k1, $9
    lui   $k0, %hi(stamp)
    sw    $k1, %lo(stamp)($k0)
    mfc0  $k1, $14
    lui   $k0, %hi(seen_epc)
    sw    $k1, %lo(seen_epc)($k0)
    mfc0  $k1, $13
    lui   $k0, %hi(seen_cause)
    sw    $k1, %lo(seen_cause)($k0)
    mfc0  $k1, $9
    addiu $k1, $k1, -1
    mtc0  $k1, $11
    lui   $k0, %hi(resume_at)
    lw    $k1, %lo(resume_at)($k0)
    lui   $k0, %hi(stamp_on)
    sw    $k0, %lo(stamp_on)($k0)
    mtc0  $k1, $14
    mfc0  $k1, $12
    srl   $k1, $k1, 1
    sll   $k1, $k1, 1
    mtc0  $k1, $12
    nop
    nop
    eret
vector_stub_end:

# ---- The measuring loop ---------------------------------------------------------
# u32 measure(void (*piece)(void), u32 arg, void (*prepare)(void))
# Runs the piece three times: once to warm the caches, once with one instruction
# left out before the first reading of COUNT, once with it. Before each turn the
# prepare routine runs, if there is one, outside the timed stretch. The piece
# gets arg in $a1. Returns the sum of the two timed turns' steps of COUNT: the
# cycles from the first reading to the second (or to the stub's reading, when an
# exception came), which is the piece's own time and 5 more (2 more for the stub).
    .globl measure
measure:
    addiu $sp, $sp, -80
    sd    $ra, 0($sp)
    sd    $s0, 8($sp)
    sd    $s1, 16($sp)
    sd    $s2, 24($sp)
    sd    $s3, 32($sp)
    sd    $s4, 40($sp)
    sd    $s5, 48($sp)
    sd    $s6, 56($sp)
    sd    $s7, 64($sp)
    move  $s0, $a0
    move  $s7, $a1
    move  $s6, $a2
    li    $s1, 3
1:  beqz  $s6, 5f
    nop
    jalr  $s6
    nop
5:  lui   $at, %hi(stamp_on)
    sw    $zero, %lo(stamp_on)($at)
    move  $a1, $s7
    mfc0  $t0, $9
    nop
    nop
    mtc0  $t0, $9
    nop
    li    $t1, 2
    beq   $s1, $t1, 2f
    nop
    nop
2:  mfc0  $s2, $9
    jalr  $s0
    nop
    mfc0  $s3, $9
    lui   $at, %hi(stamp_on)
    lw    $t0, %lo(stamp_on)($at)
    beqz  $t0, 3f
    nop
    lui   $at, %hi(stamp)
    lw    $s3, %lo(stamp)($at)
3:  move  $s4, $s5
    subu  $s5, $s3, $s2
    li    $t0, 120
4:  bnez  $t0, 4b
    addiu $t0, $t0, -1
    addiu $s1, $s1, -1
    bnez  $s1, 1b
    nop
    addu  $v0, $s4, $s5
    ld    $ra, 0($sp)
    ld    $s0, 8($sp)
    ld    $s1, 16($sp)
    ld    $s2, 24($sp)
    ld    $s3, 32($sp)
    ld    $s4, 40($sp)
    ld    $s5, 48($sp)
    ld    $s6, 56($sp)
    ld    $s7, 64($sp)
    jr    $ra
    addiu $sp, $sp, 80

# ---- Pieces: plain ---------------------------------------------------------------
    .globl piece_0
piece_0:
    jr    $ra
    nop
    .globl piece_1
piece_1:
    nop
    jr    $ra
    nop
    .globl piece_5
piece_5:
    nop
    nop
    nop
    nop
    nop
    jr    $ra
    nop

# ---- Pieces: exceptions. Each has a place the stub comes back to. ------------------
    .globl piece_break
    .globl piece_break_back
piece_break:
    break
piece_break_back:
    jr    $ra
    nop

    .globl piece_overflow
    .globl piece_overflow_back
piece_overflow:                     # arg 0x7FFFFFFF
    addi  $a1, $a1, 1
piece_overflow_back:
    jr    $ra
    nop

    .globl piece_load_error
    .globl piece_load_error_back
piece_load_error:                   # arg: an address with its lowest bit set
    lw    $t0, 0($a1)
piece_load_error_back:
    jr    $ra
    nop

    .globl piece_fetch_error
    .globl piece_fetch_error_back
piece_fetch_error:                  # arg: an address that is not a multiple of four
    jr    $a1
    nop
piece_fetch_error_back:
    jr    $ra
    nop

# ---- Pieces: CACHE. arg is the address. --------------------------------------------
    .macro cache_piece op
    .globl piece_cache_\op
piece_cache_\op:
    cache \op, 0($a1)
    jr    $ra
    nop
    .endm
    cache_piece 0x00
    cache_piece 0x01
    cache_piece 0x04
    cache_piece 0x05
    cache_piece 0x08
    cache_piece 0x09
    cache_piece 0x0D
    cache_piece 0x10
    cache_piece 0x11
    cache_piece 0x14
    cache_piece 0x15
    cache_piece 0x18
    cache_piece 0x19

# A store through the data cache that must first write another line back: arg is the address,
# and the line 8 KiB above it, which shares its place in the cache, was made dirty by prepare.
    .globl piece_store
piece_store:
    sw    $zero, 0($a1)
    jr    $ra
    nop
    .globl piece_load
piece_load:
    lw    $t0, 0($a1)
    jr    $ra
    nop

# ---- Pieces: a jump after a load -----------------------------------------------------
# The jump's target is a two-instruction routine the probe has put at 0x80040000, so that the
# jump's second register field holds the number 1. One piece loads register 1 before it, the
# other register 2.
    .globl piece_jump_named
piece_jump_named:
    lw    $1, 0($a1)
    j     0x80040000
    nop
    .globl piece_jump_other
piece_jump_other:
    lw    $2, 0($a1)
    j     0x80040000
    nop

# ---- Random after a long instruction -------------------------------------------------
    .globl random_after_divide
random_after_divide:                # arg in $a0: any number but zero
    mtc0  $zero, $6
    nop
    nop
    div   $zero, $a0, $a0
    mfc0  $v0, $1
    jr    $ra
    nop
    .globl random_after_nop
random_after_nop:
    mtc0  $zero, $6
    nop
    nop
    nop
    mfc0  $v0, $1
    jr    $ra
    nop

# ---- The timer's bit ---------------------------------------------------------------
# u32 timer_poll_N(void): COMPARE is set eight steps of COUNT ahead, N instructions pass, and
# a loop of six cycles looks at Cause until the timer's bit is there. Returns the turns that
# found it missing. Interrupts are off. The whole is done twice: the first time with COMPARE far
# ahead, so that a line of this code that is not yet in the cache cannot make COUNT run past it.
    .macro timer_poll n
    .globl timer_poll_\n
timer_poll_\n:
    li    $t3, 200
1:  mfc0  $t0, $9
    nop
    nop
    mtc0  $t0, $9
    addu  $t1, $t0, $t3
    mtc0  $t1, $11
    .rept \n
    nop
    .endr
    li    $v0, 0
2:  mfc0  $t2, $13
    srl   $t2, $t2, 15
    andi  $t2, $t2, 1
    beqzl $t2, 2b
    addiu $v0, $v0, 1
    li    $a3, 8
    bne   $t3, $a3, 1b
    move  $t3, $a3
    jr    $ra
    nop
    .endm
    timer_poll 0
    timer_poll 1
    timer_poll 2
    timer_poll 3
    timer_poll 4
    timer_poll 5

# ---- The timer's interrupt -----------------------------------------------------------
# u32 timer_interrupt_N(u32 ahead): COMPARE is set `ahead` steps of COUNT ahead, N instructions
# pass, the timer's interrupt is let through, and a row of 64 instructions that do nothing
# follows. The stub notes COUNT and the address it was called away from, and comes back behind
# the row. Returns the value put in COMPARE. Called first with COMPARE far ahead (no interrupt
# comes in the row; the code gets into the cache), then with ten steps.
    .macro timer_interrupt n
    .globl timer_interrupt_\n
    .globl timer_row_\n
    .globl timer_back_\n
timer_interrupt_\n:
    mfc0  $t0, $9
    nop
    nop
    mtc0  $t0, $9
    addu  $v0, $t0, $a0
    mtc0  $v0, $11
    .rept \n
    nop
    .endr
    mfc0  $t2, $12
    ori   $t2, $t2, 0x8001
    mtc0  $t2, $12
timer_row_\n:
    .rept 64
    nop
    .endr
timer_back_\n:
    mfc0  $t2, $12
    srl   $t2, $t2, 1
    sll   $t2, $t2, 1
    mtc0  $t2, $12
    nop
    jr    $ra
    nop
    .endm
    timer_interrupt 0
    timer_interrupt 1

# ---- An interrupt of the RCP ------------------------------------------------------------
# u32 rcp_interrupt_N(u32 *sp_status, u32 set): the RCP's interrupt line is let through, N
# instructions pass, a store asks the RSP's status register to raise its interrupt, and a row of
# 64 instructions that do nothing follows. The stub notes COUNT and the address it was called
# away from, and comes back behind the row. Returns COUNT as it was set before the store.
    .macro rcp_interrupt n
    .globl rcp_interrupt_\n
    .globl rcp_row_\n
    .globl rcp_back_\n
rcp_interrupt_\n:
    mfc0  $t2, $12
    ori   $t2, $t2, 0x0401
    mtc0  $t2, $12
    nop
    nop
    nop
    nop
    mfc0  $v0, $9
    nop
    nop
    mtc0  $v0, $9
    .rept \n
    nop
    .endr
    sw    $a1, 0($a0)
rcp_row_\n:
    .rept 64
    nop
    .endr
rcp_back_\n:
    jr    $ra
    nop
    .endm
    rcp_interrupt 0
    rcp_interrupt 1

# ---- One read of main memory, timed -----------------------------------------------------
# u32 read_once(u32 *where): the steps of COUNT across one read made without the cache.
    .globl read_once
read_once:
    mfc0  $t0, $9
    lw    $t1, 0($a0)
    mfc0  $v0, $9
    jr    $ra
    subu  $v0, $v0, $t0
