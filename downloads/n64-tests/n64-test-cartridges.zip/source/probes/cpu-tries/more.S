# The tries probe's four further routines for an interrupt of the RCP: the time probe's own routine
# (its time.S says what it does) with 2, 3, 4 and 5 idle instructions between the write to COUNT
# and the store.
    .set noreorder
    .set noat
    .text
    .macro rcp_interrupt_more n
    .globl rcp_interrupt_\n
    .globl rcp_row_\n
    .globl rcp_back_\n
rcp_interrupt_\n:
    mfc0  $t2, $12
    ori   $t2, $t2, 0x0401
    mtc0  $t2, $12
    nop
    nop
    nop
    nop
    mfc0  $v0, $9
    nop
    nop
    mtc0  $v0, $9
    .rept \n
    nop
    .endr
    sw    $a1, 0($a0)
rcp_row_\n:
    .rept 64
    nop
    .endr
rcp_back_\n:
    jr    $ra
    nop
    .endm
    rcp_interrupt_more 2
    rcp_interrupt_more 3
    rcp_interrupt_more 4
    rcp_interrupt_more 5
