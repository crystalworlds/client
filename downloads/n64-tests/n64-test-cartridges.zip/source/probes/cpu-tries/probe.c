/* The tries probe: the CPU timing probe (probes/cpu-time) built to print each of its eight tries
   of every timed piece, where that probe prints the smallest and how many gave it, and with its
   lines for an interrupt of the RCP made anew: the routine's instruction lines are all filled
   before the store, for six distances between the write to COUNT and the store, eight tries each.

   What it is for. On two consoles the eight tries of a piece agree far more often than on this
   core, where they can differ by a cycle with how the CPU's cycle falls against the bus clock
   after a wait: the tries, one by one, show how a console's fall. And the time probe's S lines only
   bound the wait before the CPU sees a line of the RCP rise (the interrupt came while the row's
   next instruction line was being fetched): with the lines filled first, the place the row stops
   at is the wait.

   The lines are the time probe's own, with these differences: the first line reads CPUTRIES and
   the last CPUTRIES END; each timed line carries eight figures; and the S lines are
       S n taken t stopped s1 .. s8     how many of eight tries were stopped by the interrupt, and
                                        after how many of the row's instructions each
       S n steps c1 .. c8               each try's steps of COUNT from the write to COUNT to the stub
   for n = 0 to 5 idle instructions between the write to COUNT and the store. */
#define CPU_TIME_EACH_TRY 1
#include "../cpu-time/probe.c"
