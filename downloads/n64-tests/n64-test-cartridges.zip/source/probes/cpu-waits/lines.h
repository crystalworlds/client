/* The waits probe's lines (taken into probes/cpu-align/probe.c, whose routines they use).

   What the alignment probe's two console runs left open, each asked here:
     Na j m t s.. c..   the anchor, j idle instructions, and the routine runs on into an instruction
                        line that is not in the cache (thrown out just before the call); m idle
                        instructions, the store. The line's row of memory is open (an uncached read
                        of that row comes last before the call). j = 2 to 5
     Nb j m ..          the same with another row of memory open
     Nr j m ..          the same routine with the line left in the cache: what the two are read against
     Oa p t s.. c..     the anchor, p idle instructions, the store, and the row of idle instructions
                        runs into a line that is not in the cache after its twelfth: the interrupt
                        comes while the CPU waits for the line. p = 0 to 2; the line's row open
     Ob p ..            the same with another row open
     Or p ..            the same routine with the line left in the cache
   Before each of these routines is called the probe reads the MI's version register twice with one
   idle instruction between, which leaves the CPU at one place against the RCP's clock whatever
   came before (the alignment probe's G lines), so that the anchor always begins at the same place.
     G 3 m, V 3 m, U 3 m   the alignment probe's lines with three idle instructions before the
                        second wait: the CPU's first place again, with no wait straight behind another
     K 6 d c1 .. c8     COUNT written, the anchor's read twice with nothing between, d idle
                        instructions, COUNT read
     Dd 0 m, Zd 0 m     the alignment probe's lines for a load and a store that must first write
                        another line back, for m = 6 to 9: how long the asking store is held up
     B x y m ..         the anchor, a store of zero (x: 0 to the MI's mask, 1 to the RSP's status),
                        a read straight behind it (y: 0 of the MI's version, 1 of the RSP's status),
                        m idle instructions, the store that asks
     Y x m ..           the request already made and kept back by the MI's mask; a store of zero
                        (x: 0 to the MI's mask, 1 to the RSP's semaphore, 2 to the DP's status) and
                        then the store that lets it through
   Care for the console: as the alignment probe. */

extern const u32 bit_first_zero[];

/* A routine that asks, with a read behind a store of zero in front of the m idle instructions. */
static void lay_store_read(u32 m) {
    laid = 0;
    code_go = here();
    lay_piece(bit_head, bit_head_end);
    lay(bit_anchor[0]);
    lay(bit_first_zero[0]);
    lay(bit_load[0]);
    lay_idle(m);
    lay(bit_ask[0]);
    code_row = here();
    lay_idle(64u);
    code_back = here();
    lay(bit_return[0]); lay(0);
    code_end = here();
}

/* A routine that asks, laid so that the word `boundary` instructions behind its first is the first of
   an instruction line: `lines_before` lines lie before that line, which begins a row of memory. */
#define FRESH_LINE (CODE + 0x800u)
static u32 fresh_base;
static void lay_into_fresh_line(u32 k, u32 idle, u32 first_store) {
    const u32 boundary = k + 12u + idle + (first_store ? 13u : 0u);     /* words from the start of the routine's first line */
    volatile u32 *w;
    fresh_base = FRESH_LINE - 4u * boundary;
    w = (volatile u32 *)(fresh_base | 0x20000000u);
    u32 n = 0;
    for (u32 i = 0; i < k; i++) w[n++] = 0;
    code_go = fresh_base + 4u * n;
    for (const u32 *p = bit_head; p < bit_head_end; p++) w[n++] = *p;
    w[n++] = bit_anchor[0];
    for (u32 i = 0; i < idle; i++) w[n++] = 0;
    if (first_store) { w[n++] = bit_ask[0]; code_row = fresh_base + 4u * n; for (u32 i = 0; i < 64u; i++) w[n++] = 0; }
    else {
        /* the caller lays the m idle instructions and the store behind the boundary */
    }
    laid = n;
}

static void fresh_line_try(const char *tag, u32 x, u32 y, u32 other_row, u32 thrown_out) {
    u32 stopped[8], steps[8], taken = 0;
    for (u32 turn = 0; turn < 9u; turn++) {
        interrupts_off();
        *SP_STATUS = 0x8u;
        MI_MASK = 0x2u;
        idle();
        stamp_on = 0;
        resume_at = code_back;
        fill_lines(code_go, code_back + 8u);
        if (thrown_out) __asm__ volatile("cache 0x10, 0(%0)" : : "r"(FRESH_LINE));  /* the line the routine runs into: thrown out */
        (void)*UNCACHED(other_row ? FRESH_LINE - 0x400u : FRESH_LINE + 0x400u);     /* the row of memory left open */
        /* Two reads of the MI's version register with one idle instruction between: wherever the CPU stood
           against the RCP's clock, it now stands at one place. */
        __asm__ volatile(".set push\n.set noreorder\nlw $2, 4(%0)\nnop\nlw $2, 4(%0)\n.set pop" : : "r"(MI_BASE) : "$2");
        const u32 set = ((go_t)code_go)(SP_STATUS, 0x10u, MI_BASE, 0, 0);
        MI_MASK = 0x1u;
        *SP_STATUS = 0x8u;
        idle();
        if (turn == 0) continue;
        stopped[turn - 1] = stamp_on ? ((seen_epc - code_row) / 4u) & 0xFFu : 0xFFu;
        steps[turn - 1] = stamp_on ? (stamp - set) & 0xFFu : 0xFFu;
        if (stamp_on) taken++;
    }
    say_text(tag); say_hex(x, 1); say_hex(y, 1); say_hex(taken, 1);
    for (u32 i = 0; i < 8u; i++) say_hex(stopped[i], 2);
    for (u32 i = 0; i < 8u; i++) say_hex(steps[i], 2);
    say_flush();
}

static void other_lines(void) {
    /* N: the routine runs into a line that is not in the cache, j idle instructions behind the anchor. */
    for (u32 row = 0; row < 3u; row++) for (u32 j = 2u; j < 6u; j++) for (u32 m = 0; m < 6u; m++) {
        const u32 k = (8u - (12u + j) % 8u) % 8u;
        lay_into_fresh_line(k, j, 0);
        volatile u32 *w = (volatile u32 *)(fresh_base | 0x20000000u);
        u32 n = laid;
        for (u32 i = 0; i < m; i++) w[n++] = 0;
        w[n++] = bit_ask[0];
        code_row = fresh_base + 4u * n;
        for (u32 i = 0; i < 64u; i++) w[n++] = 0;
        code_back = fresh_base + 4u * n;
        w[n++] = bit_return[0]; w[n++] = 0;
        code_end = fresh_base + 4u * n;
        fresh_line_try(row == 2u ? "Nr" : row ? "Nb" : "Na", j, m, row == 1u, row < 2u);
    }
    /* O: the interrupt comes while the CPU waits for the line: the store p idle instructions behind the
       anchor, the line twelve instructions into the row. */
    for (u32 row = 0; row < 3u; row++) for (u32 p = 0; p < 3u; p++) {
        const u32 k = (8u - (25u + p) % 8u) % 8u;
        lay_into_fresh_line(k, p, 1);
        volatile u32 *w = (volatile u32 *)(fresh_base | 0x20000000u);
        u32 n = laid;
        code_back = fresh_base + 4u * n;
        w[n++] = bit_return[0]; w[n++] = 0;
        code_end = fresh_base + 4u * n;
        fresh_line_try(row == 2u ? "Or" : row ? "Ob" : "Oa", p, 0, row == 1u, row < 2u);
    }
    /* The alignment probe's waits again, three idle instructions behind the anchor. */
    for (u32 m = 0; m < 6u; m++) { lay_asking(0, 1, 3, bit_load[0], m, 0); const struct ask q = { SP_STATUS, 0x10u, 0xA4300004u, 0, 0, 0 }; asking_line("G", 3, m, &q); }
    for (u32 m = 0; m < 6u; m++) { lay_asking(0, 1, 3, bit_load[0], m, 0); const struct ask q = { SP_STATUS, 0x10u, 0xA4000000u, 0, 0, 0 }; asking_line("V", 3, m, &q); }
    for (u32 m = 0; m < 6u; m++) { lay_asking(0, 1, 3, bit_load[0], m, 0); const struct ask q = { SP_STATUS, 0x10u, D_LINE | 0x20000000u, 0, prepare_row_open, 0 }; asking_line("U", 3, m, &q); }
    /* COUNT behind two reads with nothing between. */
    for (u32 d = 0; d < 4u; d++) {
        u32 steps[8];
        laid = 0; code_go = here();
        lay_piece(bit_quiet_head, bit_quiet_head_end);
        lay(bit_anchor[0]); lay(0); lay(0);
        lay_piece(bit_count_in, bit_count_in_end);
        lay(bit_anchor[0]); lay(bit_anchor[0]);
        lay_idle(d);
        lay_piece(bit_count_out, bit_count_out_end);
        code_row = code_back = code_end = here();
        for (u32 turn = 0; turn < 9u; turn++) {
            interrupts_off();
            idle();
            fill_lines(code_go, code_end);
            const u32 v = ((go_t)code_go)(SP_STATUS, 0x10u, MI_BASE, D_LINE, 0);
            if (turn) steps[turn - 1] = v & 0xFFu;
        }
        say_text("K"); say_hex(6, 1); say_hex(d, 1);
        for (u32 i = 0; i < 8u; i++) say_hex(steps[i], 2);
        say_flush();
    }
    /* A load and a store that must first write another line back: the store that asks further behind. */
    for (u32 m = 6u; m < 10u; m++) { lay_asking(0, 1, 0, bit_load[0], m, 0); const struct ask q = { SP_STATUS, 0x10u, D_LINE, 0, prepare_other_dirty, 0 }; asking_line("Dd", 0, m, &q); }
    for (u32 m = 6u; m < 10u; m++) { lay_asking(0, 1, 0, bit_stow[0], m, 0); const struct ask q = { SP_STATUS, 0x10u, D_LINE, 0, prepare_other_dirty, 0 }; asking_line("Zd", 0, m, &q); }
    /* A read straight behind a store. */
    for (u32 x = 0; x < 2u; x++) for (u32 y = 0; y < 2u; y++) for (u32 m = 0; m < 6u; m++) {
        lay_store_read(m);
        const struct ask q = { SP_STATUS, 0x10u, y ? 0xA4040010u : 0xA4300004u, x ? SP_STATUS : (volatile u32 *)0xA430000Cu, 0, 0 };
        asking_line("B", x * 2u + y, m, &q);
    }
    /* A store of zero before the store that lets the request through the MI's mask. */
    {
        static volatile u32 *const FIRST[3] = { (volatile u32 *)0xA430000Cu, (volatile u32 *)0xA404001Cu, (volatile u32 *)0xA410000Cu };
        for (u32 x = 0; x < 3u; x++) for (u32 m = 0; m < 6u; m++) {
            lay_asking(0, 1, 0, 0, m, 1);
            const struct ask q = { (volatile u32 *)0xA430000Cu, 0x2u, 0, FIRST[x], 0, 1 };
            asking_line("Y", x, m, &q);
        }
    }
}
