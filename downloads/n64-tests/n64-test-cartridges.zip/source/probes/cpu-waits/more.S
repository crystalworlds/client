# The waits probe's own pieces, beside the alignment probe's (probes/cpu-align/align.S).
    .set noreorder
    .set noat
    .text

    .globl bit_first_zero
bit_first_zero:
    sw    $zero, 0($a4)             # a store of zero before the store that asks, or before a read
