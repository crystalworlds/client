/* The waits probe: a small test cartridge for a real console.

   The alignment probe (probes/cpu-align) built with other lines: what its two console runs left
   open. Where the CPU stands after it has run into an instruction line that is not in the cache,
   with the line's row of memory open and with another; what an interrupt costs that comes while the
   CPU waits for such a line; the CPU's first place against the RCP's clock again without one wait
   straight behind another; how long a line written back keeps the bus; a read straight behind a
   store; a store before the store that lets a request through the MI's mask. Its lines are said in
   lines.h, and everything else is the alignment probe's source as it stands.

   No line depends on the console's television type: the VI is switched off.

   Care for the console: as the alignment probe. Register reads and writes a game makes, the CPU's
   own interrupt and cache operations. Every wait has an end. */
#pragma GCC diagnostic ignored "-Wunused-function"
#define PROBE_TAG "CPUWAITS"
#define PROBE_OTHER_LINES "../cpu-waits/lines.h"
#include "../cpu-align/probe.c"
