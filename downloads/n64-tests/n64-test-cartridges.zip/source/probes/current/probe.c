/* The current probe: a small test cartridge for a real console.

   A memory chip must drive enough current for its data to arrive, and a boot code has to find
   the setting at which it does. How a real chip answers at each setting is not written down
   anywhere we have found: this core uses nominal figures. This probe measures it. It takes the
   second memory chip of the console (the 2 MiB from 0x200000, which this program does not use),
   and does to it what a boot code does:

   - with the current set by hand, at each of the 64 steps, it writes a doubleword of ones at the
     start of the chip ten times and counts the one bits that come back in one byte of it (80 if
     the chip's data arrives whole, 0 if nothing arrives);
   - with the current regulated by the chip, at each of the 64 steps, it reads back the step the
     chip says it has settled at, twice;
   - then it works out the setting a boot code would choose from those answers, puts the chip
     back to it, and checks that the chip's memory answers again.

   Everything this program itself needs (its code, its stack, its data) is in the first chip.

   S  the memory size the boot code stored
   C  the chip's mode register, delay register and type register as found
   A  step, one bits that came back out of 80, with the current set by hand
   B  step, the step read back the first time and the second, with the current regulated
   F  the step aimed for, the regulated step chosen, the mode register written, the mode
      register read back, and the one bits out of 80 that come back at the end */

#include "../cart-lib/say.h"

#define PLACE 2u
#define CHIP_REG(n) REG32(0xA3F00000u + (PLACE << 10) + (n) * 4u)
#define CHIP_MEMORY ((volatile u32 *)(0xA0000000u + (PLACE << 20)))
#define REG_TYPE 0
#define REG_DELAY 2
#define REG_MODE 3

#define MODE_AUTO 0x80000000u
#define MODE_FIXED 0x46000000u          /* the bits a boot code always writes: one it must set, automatic skip, enabled */

/* The current is six bits scattered over the mode register, counting down: 63 less the field is the step. */
static u32 current_bits(u32 field) {
    return ((field & 1u) << 6) | (((field >> 1) & 1u) << 14) | (((field >> 2) & 1u) << 22) | (((field >> 3) & 1u) << 7) | (((field >> 4) & 1u) << 15) | (((field >> 5) & 1u) << 23);
}
static u32 current_field(u32 mode) {
    return ((mode >> 6) & 1u) | (((mode >> 14) & 1u) << 1) | (((mode >> 22) & 1u) << 2) | (((mode >> 7) & 1u) << 3) | (((mode >> 15) & 1u) << 4) | (((mode >> 23) & 1u) << 5);
}

/* An odd-numbered register is read through the MI's upper mode. */
static u32 chip_read(u32 reg) {
    if (reg & 1u) MI_MODE = 0x2000u;
    u32 v = CHIP_REG(reg);
    if (reg & 1u) MI_MODE = 0x1000u;
    return v;
}
static void mode_write(int regulated, u32 step) { CHIP_REG(REG_MODE) = MODE_FIXED | (regulated ? MODE_AUTO : 0u) | current_bits(63u - step); }
static void pause(u32 turns) { for (volatile u32 i = 0; i < turns; i++) { } }

static u32 ones_of_80(void) {
    u32 ones = 0;
    for (u32 t = 0; t < 10; t++) {
        CHIP_MEMORY[0] = 0xFFFFFFFFu;
        CHIP_MEMORY[1] = 0xFFFFFFFFu;
        u32 b = ((volatile u8 *)CHIP_MEMORY)[5];
        while (b) { ones += b & 1u; b >>= 1; }
    }
    return ones;
}

void probe_main(void) {
    static u8 came_back[64], settled[64];
    say_head("CCPROBE");
    say_text("S"); say_hex(REG32(0x80000318u), 8); say_flush();
    say_text("C"); say_hex(chip_read(REG_MODE), 8); say_hex(chip_read(REG_DELAY), 8); say_hex(chip_read(REG_TYPE), 8); say_flush();

    for (u32 step = 0; step < 64; step++) {
        mode_write(0, step);
        came_back[step] = (u8)ones_of_80();
    }
    for (u32 step = 0; step < 64; step++) {
        mode_write(1, step);
        pause(256);
        u32 first = current_field(chip_read(REG_MODE)), second = current_field(chip_read(REG_MODE));
        settled[step] = (u8)second;
        say_text("B"); say_hex(step, 2); say_hex(first, 2); say_hex(second, 2); say_flush();
    }
    for (u32 step = 0; step < 64; step++) { say_text("A"); say_hex(step, 2); say_hex(came_back[step], 2); say_flush(); }

    /* What a boot code makes of it: the step where the data begins to arrive, weighted by how much
       more arrives at each step; a little over twice that is the step to aim for; and the regulated
       setting whose read-back comes nearest to it. */
    u32 sum = 0, before = 0;
    for (u32 step = 0; step < 64; step++) { if (came_back[step] > before) sum += step * (came_back[step] - before); before = came_back[step]; if (before >= 80u) break; }
    u32 aim = (sum * 22u + 400u) / 800u;
    u32 chosen = 0, least = 0xFFFFFFFFu;
    for (u32 step = 0; step < 64; step++) {
        u32 off = settled[step] > aim ? settled[step] - aim : aim - settled[step];
        if (off < least) { least = off; chosen = step; }
        if (settled[step] > aim) break;
    }
    if (!aim) chosen = 32;                                  /* nothing came back at any step: leave the chip at a middling setting rather than at none */
    mode_write(1, chosen);
    pause(256);
    (void)chip_read(REG_MODE);
    u32 back = chip_read(REG_MODE);
    say_text("F"); say_hex(aim, 2); say_hex(chosen, 2); say_hex(MODE_FIXED | MODE_AUTO | current_bits(63u - chosen), 8); say_hex(back, 8); say_hex(ones_of_80(), 2); say_flush();

    say_tail("CCPROBE");
}
