# The first instruction of the probe: a stack inside the first memory chip
# (the first 2 MiB), because this probe changes how the second one answers,
# then the C code. It never returns.
    .set noreorder
    .section .text.entry, "ax"
    .globl _start
_start:
    lui   $sp, 0x801F
    jal   probe_main
    addiu $sp, $sp, -32
1:  b     1b
    nop
