/* The data cache line probe: a small test cartridge for a real console.

   A fetched test of the RSP asks an allocator for memory and copies its RSP program there through
   an address that goes past the data cache. The allocator's note in front of the block was stored
   through the cache, and it lies in the same 16-byte line as the first eight bytes of the copy.
   By this core's rules, and the reference emulator's, that line is later written back to memory
   whole, note and old bytes alike, over the first two instructions of the copy. A console ran
   that very file for an hour and never showed the damage (two runs). This probe
   walks the same steps in the open and prints what memory holds afterwards. All values are in
   hex; a word's first two digits say where its value came from:

       f1  what memory was given before the walk (so: what the line took in when it was filled)
       cc  a store through the cache
       a5  a store made without the cache
       5c  a word of the copy's source

   The lines:

     X f w r     a word far inside the debug text window, where no text reaches: as found, as
                 written (one more than found), and as read back after another read of the
                 cartridge. It counts the runs in which the window took a write, a run that was
                 listened to without the window among them
     Z a w...    the 16 bytes at a of main memory as the start left them, before the probe wrote
                 anywhere near: the two places where the fetched test's block lies
     N n         how many of the 16,384 words from 0x000c0000 on are not zero at that moment
     K w...      the control: all four words of the line stored through the cache, then all four
                 without it, then a load of another address with the same line number; the
                 block's four words as memory holds them afterwards (a console is known to give
                 cc four times)
     W c f e w... the walk. Word c alone is stored through the cache (f = 0: the store finds the
                 line not there and has it filled; f = 1: a load filled it before). All four
                 words are then stored without the cache. Then the line is made to go: e = 0 by a
                 load of another address with the same line number, 1 by a store to it, 2 by
                 CACHE Index Write Back Invalidate, 3 by Hit Write Back, 4 by Hit Write Back
                 Invalidate. The block's four words as memory holds them afterwards
     G k w...    the walk with c = 1 and e = 0, the load k idle instructions after the last store
                 made without the cache, with nothing between that waits for those stores
     R c w...    what the line shows through the cache after the stores made without it: the
                 walk up to there, then four loads through the cache
     S c w...    the walk with e = 0 and 64 turns of an idle loop between the store through the
                 cache and the stores made without it
     M v w...    the copy as the fetched test makes it, at the test's own addresses: the note
                 stored through the cache at 0x800cd294, then 296 words copied from 0x8002ef60,
                 read through the cache, to 0xa00cd298, written without it. The 16 bytes at
                 0x000cd290 afterwards. v = 1: the source is read through the cache, then the
                 note's store finds its line not there. v = 2, the test's own order: the source
                 is read, a first note is stored (the line is filled), a long idle loop passes,
                 and the note is stored again into the line that is there
     D v d0 d1   the copy's first eight bytes as the RSP's DMA then brings them into its data
                 memory: what the RSP would have been given

   No line depends on the console's television type: the probe uses neither the VI nor the sound
   output. It needs 4 MiB of main memory and no more.

   Care for the console: plain loads and stores in a part of main memory nothing else uses, five
   CACHE operations a library uses every day, and one DMA of eight bytes into the RSP's data
   memory while the RSP stands still. */

#include "../cart-lib/say.h"

void walk(volatile u32 *block, volatile u32 *other, u32 how, u32 *out, u32 first, u32 uncached, u32 cached);
typedef void (*closer)(volatile u32 *block, volatile u32 *other, u32 first, u32 uncached, u32 cached);
void close_0(volatile u32 *, volatile u32 *, u32, u32, u32);
void close_1(volatile u32 *, volatile u32 *, u32, u32, u32);
void close_2(volatile u32 *, volatile u32 *, u32, u32, u32);
void close_4(volatile u32 *, volatile u32 *, u32, u32, u32);
void close_8(volatile u32 *, volatile u32 *, u32, u32, u32);
void close_16(volatile u32 *, volatile u32 *, u32, u32, u32);
void close_64(volatile u32 *, volatile u32 *, u32, u32, u32);
void close_256(volatile u32 *, volatile u32 *, u32, u32, u32);
void copy_walk(volatile u32 *source, volatile u32 *to, volatile u32 *note, u32 words, u32 note_value, u32 read_first);

#define CACHED(a) ((volatile u32 *)(0x80000000u + (a)))
#define UNCACHED(a) ((volatile u32 *)(0xA0000000u + (a)))
#define BLOCK 0x000CD290u               /* the fetched test's block begins 8 bytes into this line */
#define OTHER 0x0002F290u               /* its source lies here: the same line number, another page */
#define BLOCK_MOVED 0x000CD050u         /* where the block lies in the test's other build with no window */
#define SOURCE 0x0002EF60u
#define COPY_WORDS 296u
#define FAR_WORD ((volatile u32 *)0xB3FFF000u)

#define SP_MEM_ADDR REG32(0xA4040000u)
#define SP_DRAM_ADDR REG32(0xA4040004u)
#define SP_RD_LEN REG32(0xA4040008u)
#define SP_DMA_BUSY REG32(0xA4040018u)

static u32 walks;                       /* each walk's values carry its number */
static u32 first_of(void) { return 0xF1000000u | (walks << 8); }
static u32 uncached_of(void) { return 0xA5000000u | (walks << 8); }
static u32 cached_of(u32 word) { return 0xCC000000u | (walks << 8) | word; }

static void say_block(u32 at) { for (u32 i = 0; i < 4; i++) say_hex(UNCACHED(at)[i], 8); }

static void one_walk(u32 c, u32 filled_first, u32 way) {
    walks++;
    walk(CACHED(BLOCK), CACHED(OTHER), c | (filled_first ? 8u : 0u) | (way << 4), 0, first_of(), uncached_of(), cached_of(c));
    say_text("W"); say_hex(c, 1); say_hex(filled_first, 1); say_hex(way, 1); say_block(BLOCK); say_flush();
}

void probe_main(void) {
    /* The far word first, before any text is handed over. */
    bus_free();
    const u32 found = *FAR_WORD;
    const u32 wrote = (found >> 16) == 0x5858u ? found + 1u : 0x58580001u;
    bus_free();
    *FAR_WORD = wrote;
    bus_free();
    (void)REG32(0xB0000000u);
    bus_free();
    const u32 back = *FAR_WORD;
    bus_free();

    /* And memory as the start left it, before the probe writes there. */
    u32 as_left[8], not_zero = 0;
    for (u32 i = 0; i < 4; i++) { as_left[i] = UNCACHED(BLOCK)[i]; as_left[4 + i] = UNCACHED(BLOCK_MOVED)[i]; }
    for (u32 a = 0x000C0000u; a < 0x000D0000u; a += 4) if (*UNCACHED(a)) not_zero++;

    say_head("DLPROBE");
    say_text("X"); say_hex(found, 8); say_hex(wrote, 8); say_hex(back, 8); say_flush();
    say_text("Z"); say_hex(BLOCK, 8); for (u32 i = 0; i < 4; i++) say_hex(as_left[i], 8); say_flush();
    say_text("Z"); say_hex(BLOCK_MOVED, 8); for (u32 i = 0; i < 4; i++) say_hex(as_left[4 + i], 8); say_flush();
    say_text("N"); say_hex(not_zero, 8); say_flush();

    /* The control: every word stored through the cache. */
    walks++;
    walk(CACHED(BLOCK), CACHED(OTHER), 4u, 0, first_of(), uncached_of(), cached_of(0));
    say_text("K"); say_block(BLOCK); say_flush();

    /* The walk, the line made to go as the fetched test makes it go. */
    for (u32 filled_first = 0; filled_first < 2; filled_first++) for (u32 c = 0; c < 4; c++) one_walk(c, filled_first, 0);

    /* The same with less and less time between the stores without the cache and the load. */
    {
        static const closer CLOSERS[8] = { close_0, close_1, close_2, close_4, close_8, close_16, close_64, close_256 };
        static const u32 IDLE[8] = { 0, 1, 2, 4, 8, 16, 64, 256 };
        for (u32 i = 0; i < 8; i++) {
            walks++;
            CLOSERS[i](CACHED(BLOCK), CACHED(OTHER), first_of(), uncached_of(), cached_of(1));
            say_text("G"); say_hex(IDLE[i], 3); say_block(BLOCK); say_flush();
        }
    }

    /* What the line itself shows after the stores made without the cache. */
    for (u32 c = 0; c < 4; c++) {
        u32 shown[4];
        walks++;
        walk(CACHED(BLOCK), CACHED(OTHER), c | (7u << 4), shown, first_of(), uncached_of(), cached_of(c));
        say_text("R"); say_hex(c, 1); for (u32 i = 0; i < 4; i++) say_hex(shown[i], 8); say_flush();
    }

    /* The other ways a line goes to memory. */
    for (u32 way = 1; way < 5; way++) one_walk(1, 0, way);

    /* Time between the store through the cache and the stores made without it. */
    for (u32 c = 0; c < 4; c++) {
        walks++;
        walk(CACHED(BLOCK), CACHED(OTHER), c | (64u << 24), 0, first_of(), uncached_of(), cached_of(c));
        say_text("S"); say_hex(c, 1); say_block(BLOCK); say_flush();
    }

    /* The copy as the fetched test makes it. */
    for (u32 i = 0; i < COPY_WORDS; i++) UNCACHED(SOURCE)[i] = 0x5C000000u | i;
    for (u32 version = 1; version <= 2; version++) {
        walks++;
        (void)*CACHED(OTHER);                               /* the block's line is not held, and is clean */
        for (u32 i = 0; i < 4; i++) UNCACHED(BLOCK)[i] = first_of() | i;
        if (version == 2) {
            for (u32 i = 0; i < COPY_WORDS; i++) (void)CACHED(SOURCE)[i];
            *CACHED(BLOCK + 4u) = cached_of(9);
            for (volatile u32 idle = 0; idle < 20000u; idle++) { }
        }
        copy_walk(CACHED(SOURCE), UNCACHED(BLOCK + 8u), CACHED(BLOCK + 4u), COPY_WORDS, cached_of(1), version == 1);
        say_text("M"); say_hex(version, 1); say_block(BLOCK); say_flush();
        while (SP_DMA_BUSY & 1u) { }
        SP_MEM_ADDR = 0u;
        SP_DRAM_ADDR = BLOCK + 8u;
        SP_RD_LEN = 7u;
        while (SP_DMA_BUSY & 1u) { }
        say_text("D"); say_hex(version, 1); say_hex(REG32(0xA4000000u), 8); say_hex(REG32(0xA4000004u), 8); say_flush();
    }

    say_tail("DLPROBE");
}
