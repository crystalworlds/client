# The data cache line probe's first instruction and its measuring routines. Each routine walks
# one line of the data cache through a store through the cache, stores made without the cache
# into the same 16 bytes, and something that makes the line go to memory. Between the first and
# the last step of a walk nothing but registers is used: no data of the probe's own is read or
# written, so no line is moved by anything but the walk. Nothing is printed inside a walk.
    .set noreorder
    .set noat
    .section .text.entry, "ax"
    .globl _start
_start:
    lui   $sp, 0x803F
    jal   probe_main
    addiu $sp, $sp, -32
1:  b     1b
    nop

    .section .text, "ax"

# The first steps of every walk. In: $a0 the block through the cache, $a1 another address with
# the same line number, $a4 $a5 $a6 the three values' bases (what memory is given first, what the
# stores without the cache give, what the store through the cache gives). Out: $t8 the block
# without the cache.
#   1. a load of the other address: the line holds that, clean, and the block is not held
#   2. memory's block is given its first values, without the cache; a load without the cache
#      follows, and such a load waits until the stores before it have landed
    .macro WALK_BEGIN
    lui   $t9, 0x2000
    or    $t8, $a0, $t9
    lw    $t0, 0($a1)
    sw    $a4, 0($t8)
    addiu $t1, $a4, 1
    sw    $t1, 4($t8)
    addiu $t1, $a4, 2
    sw    $t1, 8($t8)
    addiu $t1, $a4, 3
    sw    $t1, 12($t8)
    lw    $t0, 0($t8)
    .endm

# The four stores made without the cache: every word of the block gets a new value.
    .macro WALK_UNCACHED
    sw    $a5, 0($t8)
    addiu $t1, $a5, 1
    sw    $t1, 4($t8)
    addiu $t1, $a5, 2
    sw    $t1, 8($t8)
    addiu $t1, $a5, 3
    sw    $t1, 12($t8)
    .endm

# void walk(u32 *block, u32 *other, u32 how, u32 *out, u32 first, u32 uncached, u32 cached)
#   how bits 0-1  which word of the block is stored through the cache
#       bit 2     all four words are, each with its own value
#       bit 3     a load through the cache fills the line first, so that the store finds it there
#       bits 4-6  what makes the line go: 0 a load of the other address, 1 a store to it,
#                 2 CACHE Index Write Back Invalidate, 3 CACHE Hit Write Back,
#                 4 CACHE Hit Write Back Invalidate, 7 nothing: the block's four words are read
#                 through the cache into `out` instead
#       bits 8-23 turns of an idle loop between the stores without the cache and that step
#       bits 24-31 turns of an idle loop between the store through the cache and the stores
#                 made without it
#   A load without the cache from elsewhere stands behind the stores made without the cache, so
#   they have landed before the line goes.
    .globl walk
    .balign 32
walk:
    WALK_BEGIN
    andi  $t0, $a2, 8
    beqz  $t0, 1f
    nop
    lw    $t0, 0($a0)               # the line is filled by a load: the store will find it there
1:  andi  $t0, $a2, 4
    bnez  $t0, 2f
    andi  $t0, $a2, 3
    sll   $t0, $t0, 2
    addu  $t1, $a0, $t0
    b     3f
    sw    $a6, 0($t1)               # the one store through the cache
2:  sw    $a6, 0($a0)               # or four of them
    addiu $t1, $a6, 1
    sw    $t1, 4($a0)
    addiu $t1, $a6, 2
    sw    $t1, 8($a0)
    addiu $t1, $a6, 3
    sw    $t1, 12($a0)
3:  srl   $t2, $a2, 24
6:  beqz  $t2, 7f
    nop
    b     6b
    addiu $t2, $t2, -1
7:  WALK_UNCACHED
    lw    $t0, 0x100($t8)           # a load without the cache, elsewhere: the stores have landed
    srl   $t2, $a2, 8
    andi  $t2, $t2, 0xFFFF
4:  beqz  $t2, 5f
    nop
    b     4b
    addiu $t2, $t2, -1
5:  srl   $t0, $a2, 4
    andi  $t0, $t0, 7
    beqz  $t0, 10f
    addiu $t1, $t0, -1
    beqz  $t1, 11f
    addiu $t1, $t0, -2
    beqz  $t1, 12f
    addiu $t1, $t0, -3
    beqz  $t1, 13f
    addiu $t1, $t0, -4
    beqz  $t1, 14f
    nop
    lw    $t0, 0($a0)               # 7: what the line shows, read through the cache
    lw    $t1, 4($a0)
    lw    $t2, 8($a0)
    lw    $t3, 12($a0)
    sw    $t0, 0($a3)
    sw    $t1, 4($a3)
    sw    $t2, 8($a3)
    jr    $ra
    sw    $t3, 12($a3)
10: jr    $ra
    lw    $t0, 0($a1)               # 0: a load of the other address
11: jr    $ra
    sw    $t0, 0($a1)               # 1: a store to it
12: jr    $ra
    cache 0x01, 0($a0)              # 2: Index Write Back Invalidate
13: jr    $ra
    cache 0x19, 0($a0)              # 3: Hit Write Back
14: jr    $ra
    cache 0x15, 0($a0)              # 4: Hit Write Back Invalidate

# void close_k(u32 *block, u32 *other, u32 first, u32 uncached, u32 cached): the walk with its
# second word stored through the cache and the line made to go by a load of the other address k
# idle instructions after the last store without the cache, with no load without the cache in
# between: at k = 0 the four stores are still on their way when the line has to go.
    .macro CLOSE name, idle
    .globl \name
    .balign 32
\name:
    move  $a6, $a4
    move  $a4, $a2
    move  $a5, $a3
    WALK_BEGIN
    sw    $a6, 4($a0)
    WALK_UNCACHED
    .rept \idle
    nop
    .endr
    lw    $t0, 0($a1)
    jr    $ra
    nop
    .endm

    CLOSE close_0, 0
    CLOSE close_1, 1
    CLOSE close_2, 2
    CLOSE close_4, 4
    CLOSE close_8, 8
    CLOSE close_16, 16
    CLOSE close_64, 64
    CLOSE close_256, 256

# void copy_walk(u32 *source, u32 *to, u32 *note, u32 words, u32 note_value, u32 read_first):
# the copy as a program makes it that asks an allocator for memory and then writes there without
# the cache.
#   1. with `read_first`, every word of the source is read through the cache, as a program reads
#      its own data
#   2. a store through the cache to `note`, the word in front of `to` (an allocator's note in
#      front of its block), which lies in the same line as the first eight bytes at `to`
#   3. `words` words are copied from the source, read through the cache, to `to`, written
#      without the cache, one after another
# When the source and the line of step 2 share a line number, step 3 itself makes that line go.
    .globl copy_walk
    .balign 32
copy_walk:
    beqz  $a5, 3f
    move  $t0, $a0
    move  $t2, $a3
1:  lw    $t1, 0($t0)
    addiu $t2, $t2, -1
    bnez  $t2, 1b
    addiu $t0, $t0, 4
3:  sw    $a4, 0($a2)
    move  $t0, $a0
    move  $t3, $a1
    move  $t2, $a3
2:  lw    $t1, 0($t0)
    addiu $t0, $t0, 4
    sw    $t1, 0($t3)
    addiu $t2, $t2, -1
    bnez  $t2, 2b
    addiu $t3, $t3, 4
    jr    $ra
    nop
