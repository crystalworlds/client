/* How every probe hands its text to whatever listens at the debug text window.

   Two kinds of listener exist.

   An emulator's window prints the first n bytes of the window when n is written as the length.
   That is all it looks at.

   A flash cartridge's listener keeps to the window's own rules. The window is a ring of bytes
   with a mark at its start and two counters: how far the program has written, and how far the
   listener has read. The listener looks only while the mark stands, takes the bytes between the
   two counters (round the end of the ring if the written one is the smaller), and then writes
   down how far it has read. It reads the mark and the counters one after another, not in one
   look, so a program must never set a counter back while the mark stands or has only just gone.

   The first text is given in a way both understand. The mark is taken away, and the program
   waits long enough for any look that had begun to end. Then both counters go to nothing, the
   text goes to the window's start, the length is written (an emulator prints here), and the
   mark is put back (a cartridge looks from here on). Then the program watches for a while
   whether something writes down that it has read the text.

   If something does, the listener is a cartridge's: every later text is written on round the
   ring behind the one before, and only after the one before has been read, so the ring cannot
   run over and no counter is ever set back. If nothing answers, the listener is an emulator's
   window (or nothing listens), and every later text is the window's words and the length alone.

   On a console the time a text takes to hand over depends on the listener, so a probe must take
   its measurements between texts, never across one. */
#ifndef PROBE_DEBUG_TEXT_H
#define PROBE_DEBUG_TEXT_H

#define DBG_PI_STATUS (*(volatile unsigned int *)0xA4600010u)
/* Where the window is, as the CPU reaches it. A probe may name another place before it includes
   this file, and whatever listens must then be told the same place. A flash cartridge keeps its
   save memory in the block of its own memory where the usual window lies, so a probe that writes
   the upper part of the save memory's addresses needs its window elsewhere. */
#ifndef DBG_BASE
#define DBG_BASE 0xB3FF0000u
#endif
#define DBG_MARK ((volatile unsigned int *)DBG_BASE)
#define DBG_TAKEN ((volatile unsigned int *)(DBG_BASE + 0x04u))     /* how far a listener has read */
#define DBG_LENGTH ((volatile unsigned int *)(DBG_BASE + 0x14u))    /* how far the program has written */
#define DBG_WINDOW ((volatile unsigned int *)(DBG_BASE + 0x20u))
#define DBG_THE_MARK 0x49533634u                             /* the letters I, S, 6, 4 */
#define DBG_RING 65504u                                      /* the ring's bytes: 64 KiB less the 32 before it */
#define DBG_SETTLE 4000u                                     /* reads of the bus that outlast a look that had begun */
#define DBG_TRIES 400000u                                    /* how long the first text waits for an answer */

/* The cartridge bus does one access at a time: wait until it is free. */
static void dbg_put(volatile unsigned int *at, unsigned int v) { while (DBG_PI_STATUS & 3u) { } *at = v; }
static unsigned int dbg_get(volatile unsigned int *at) { while (DBG_PI_STATUS & 3u) { } return *at; }

static unsigned int dbg_listener;   /* 0 not known yet, 1 a cartridge's (it says how far it has read), 2 a window that prints at the length */
static unsigned int dbg_written;    /* how far the ring is written, as the cartridge's listener counts it */
static unsigned int dbg_part;       /* the bytes of the ring's word that is only partly written */

/* The emulator's way, and the first text's: the text from the window's start. */
static void dbg_from_the_start(const char *s, unsigned int n) {
    for (unsigned int i = 0; i < n; i += 4) {
        unsigned int w = 0;
        for (unsigned int k = 0; k < 4; k++) w |= (unsigned int)(unsigned char)(i + k < n ? s[i + k] : 0) << (24 - 8 * k);
        dbg_put(&DBG_WINDOW[i / 4], w);
        if (i + 4 > n) dbg_part = w;
    }
    if ((n & 3u) == 0) dbg_part = 0;
}

/* The cartridge's way: the text behind what is there, round the end of the ring if need be. A
   word that is only partly written is kept, and written again with the bytes that follow. */
static void dbg_behind(const char *s, unsigned int n) {
    unsigned int at = dbg_written;
    for (unsigned int i = 0; i < n; i++) {
        unsigned int shift = 24 - 8 * (at & 3u);
        dbg_part = (dbg_part & ~(0xFFu << shift)) | ((unsigned int)(unsigned char)s[i] << shift);
        if ((at & 3u) == 3u || i + 1 == n) dbg_put(&DBG_WINDOW[at / 4], dbg_part);
        at++;
        if ((at & 3u) == 0) dbg_part = 0;
        if (at == DBG_RING) at = 0;
    }
    dbg_written = at;
    dbg_put(DBG_LENGTH, at);
}

static void debug_text(const char *s, unsigned int n) {
    if (n == 0 || n >= DBG_RING) return;
    if (dbg_listener == 2) { dbg_from_the_start(s, n); dbg_put(DBG_LENGTH, n); return; }
    if (dbg_listener == 1) {
        while (dbg_get(DBG_TAKEN) != dbg_written) { }       /* the text before has been read */
        dbg_behind(s, n);
        return;
    }
    dbg_put(DBG_MARK, 0);
    for (unsigned int i = 0; i < DBG_SETTLE; i++) (void)dbg_get(DBG_MARK);
    dbg_put(DBG_TAKEN, 0);
    dbg_put(DBG_LENGTH, 0);
    dbg_from_the_start(s, n);
    dbg_put(DBG_LENGTH, n);
    dbg_put(DBG_MARK, DBG_THE_MARK);
    dbg_written = n;
    dbg_listener = 2;
    for (unsigned int tries = 0; tries < DBG_TRIES; tries++) { if (dbg_get(DBG_TAKEN) == n) { dbg_listener = 1; break; } }
}

#endif
