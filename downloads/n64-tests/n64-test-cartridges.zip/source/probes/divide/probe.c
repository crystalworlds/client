/* The divide probe: a small test cartridge for a real console.

   DIV is a 32-bit signed divide, but the console's divider works on the whole
   64-bit registers. For operands that are proper sign-extended 32-bit values
   nothing odd shows. When they are not, the quotient follows a rule that is
   known for half the cases and that nobody has worked out for the other half:
   those where bits 63 and 31 of the divisor differ.

   Random operands have not given the rule away, so this probe walks through
   that half in steps: divisors with one upper bit set or one upper bit clear
   over a few lower halves, against a few dividends. It prints the operands and
   both result registers of every case as text, through the debug text window
   a flash cartridge shows on the computer beside the console. Run here, the
   same lines show what this core computes; the two logs are then compared
   line by line.

   Each line: D <dividend> <divisor> <LO> <HI>, all 64 bits in hex.
   U lines are the same for DIVU, as a control. */

typedef unsigned int u32;
typedef unsigned long long u64;

/* How the text is handed to whatever listens at the debug text window: an emulator's window, or
   a flash cartridge's stricter listener. */
#include "../debug-text.h"

static void say(const char *s, u32 n) { debug_text(s, n); }

static char *hex(char *p, u64 v, u32 digits) {
    for (u32 i = 0; i < digits; i++) { u32 d = (u32)(v >> ((digits - 1 - i) * 4)) & 15u; *p++ = (char)(d < 10 ? '0' + d : 'a' + d - 10); }
    return p;
}

static u64 sext(u32 v) { return (u64)(long long)(int)v; }

static u32 cases;
static u64 fold;

/* One case: the bare instruction, with no check for a zero divisor around it. */
static void one(int is_unsigned, u64 rs, u64 rt) {
    u64 lo, hi;
    if (is_unsigned)
        __asm__ volatile(".set push\n\t.set noreorder\n\tdivu $0, %2, %3\n\tmflo %0\n\tmfhi %1\n\t.set pop" : "=&r"(lo), "=&r"(hi) : "r"(rs), "r"(rt) : "lo", "hi");
    else
        __asm__ volatile(".set push\n\t.set noreorder\n\tdiv $0, %2, %3\n\tmflo %0\n\tmfhi %1\n\t.set pop" : "=&r"(lo), "=&r"(hi) : "r"(rs), "r"(rt) : "lo", "hi");
    char line[80], *p = line;
    *p++ = is_unsigned ? 'U' : 'D';
    *p++ = ' '; p = hex(p, rs, 16);
    *p++ = ' '; p = hex(p, rt, 16);
    *p++ = ' '; p = hex(p, lo, 16);
    *p++ = ' '; p = hex(p, hi, 16);
    *p++ = '\n';
    say(line, (u32)(p - line));
    cases++;
    fold = (fold << 7 | fold >> 57) ^ lo ^ (hi * 0x9E3779B97F4A7C15ull);
}

static u64 next_random(u64 *s) { u64 x = *s; x ^= x << 13; x ^= x >> 7; x ^= x << 17; *s = x; return x; }

void probe_main(void) {
    static const u64 dividends[8] = {
        1ull, 7ull, 0x7FFFFFFFull, 0xFFFFFFFF80000000ull, 0xFFFFFFFFFFFFFFF9ull,
        0x0000000100000007ull, 0x7FFFFFFF00000000ull, 0x123456789ABCDEF0ull };
    static const u32 low_set[6] = { 0x80000000u, 0x80000001u, 0x80000003u, 0xC0000000u, 0xFFFFFFFDu, 0xFFFFFFFFu };    /* bit 31 set */
    static const u32 low_clear[6] = { 1u, 2u, 3u, 0x10u, 0x40000000u, 0x7FFFFFFFu };                                   /* bit 31 clear */
    char line[64], *p = line;
    u32 prid;
    __asm__ volatile("mfc0 %0, $15" : "=r"(prid));
    const char *head = "DIVPROBE 1 PRID ";
    while (*head) *p++ = *head++;
    p = hex(p, prid, 8);
    *p++ = '\n';
    say(line, (u32)(p - line));

    /* Controls first: divisors whose bits 63 and 31 agree, the half that is understood. */
    for (u32 d = 0; d < 8; d++) {
        one(0, dividends[d], 3ull);
        one(0, dividends[d], sext(0xFFFFFFFDu));
        one(0, dividends[d], 0x0000000100000003ull);            /* an upper bit set, bit 63 and bit 31 both clear */
        one(0, dividends[d], 0xFFFFFFFEFFFFFFFDull);            /* an upper bit clear, both set */
        one(1, dividends[d], 3ull);
        one(1, dividends[d], 0x8000000080000003ull);
    }

    /* The half that is not: bit 63 clear with bit 31 set. The upper half is zero, then all ones below
       its sign, then each single bit. */
    for (u32 l = 0; l < 6; l++) {
        for (u32 h = 0; h < 33; h++) {
            u32 upper = h == 0 ? 0u : h == 1 ? 0x7FFFFFFFu : 1u << (h - 2);
            for (u32 d = 0; d < 8; d++) one(0, dividends[d], ((u64)upper << 32) | low_set[l]);
        }
    }
    /* And bit 63 set with bit 31 clear: all ones, the sign alone, then each single bit clear. */
    for (u32 l = 0; l < 6; l++) {
        for (u32 h = 0; h < 33; h++) {
            u32 upper = h == 0 ? 0xFFFFFFFFu : h == 1 ? 0x80000000u : ~(1u << (h - 2));
            for (u32 d = 0; d < 8; d++) one(0, dividends[d], ((u64)upper << 32) | low_clear[l]);
        }
    }
    /* Last, operands with no pattern, forced into the same half, to check any rule the walks suggest. */
    u64 seed = 0x243F6A8885A308D3ull;
    for (u32 i = 0; i < 256; i++) {
        u64 rs = next_random(&seed), rt = next_random(&seed);
        if (!(((rt >> 63) ^ (rt >> 31)) & 1ull)) rt ^= 0x8000000000000000ull;
        one(0, rs, rt);
    }

    p = line;
    const char *tail = "DIVPROBE END ";
    while (*tail) *p++ = *tail++;
    p = hex(p, cases, 8);
    *p++ = ' ';
    p = hex(p, fold, 16);
    *p++ = '\n';
    say(line, (u32)(p - line));
}
