/* The DP depth probe: a small test cartridge for a real console.

   A console's log of the waiting transfer probe (probes/dp-queue) showed CURRENT at a list's end
   while the list's first rectangle was still being drawn: the DP takes commands in ahead of the
   drawing. How many? This core fetches each command as it runs it. The probe hands over one list:
   a large rectangle that takes a while to draw, then many commands behind it, and reads CURRENT
   and STATUS at fixed times after the write of END. While the rectangle is drawn, CURRENT stands
   still where the commands taken in ahead end: that plateau is the depth; afterwards it climbs as
   the commands leave.

   The list: the colour image (16 bits, 320 wide), the scissor, fill mode, a fill colour, one fill
   rectangle of 320 by 200 pixels, then the filler, then a full sync. The filler by variant k:
     0   120 Set Fill Color commands of the same value (8 bytes each)
     1   a pipe sync and a Set Other Modes to one-cycle mode, then 60 Texture Rectangles wholly below
         the scissor (16 bytes each, nothing drawn): the same bytes in half as many commands
     2   120 fill rectangles of one pixel inside the large one, in its colour: drawn primitives
     3   as 0, with 16 more Set Fill Color commands before the rectangle: does the depth count from
         the command in hand or from the list's start
   Each variant three times. Then the sweep: variant 0 with e = 0 to 15 more Set Fill Color commands
   before the rectangle, once each, so that where CURRENT stands is seen against the rectangle's
   place at every step of 8 bytes (the lines W and F, as D and E with e in place of k and r). Then
   variant 0 with the list (and START) 8 x b bytes further on, b = 0 to 9, once each: are the blocks
   CURRENT stands at counted from START or from the address (the lines V and H, b in place of k;
   CURRENT still counted from the list's start).

   Lines:   D k r j  t c s  (eight times)      three lines a run: j = 0, 1, 2
            E k r  steps  s  c
     k r    the variant and the run (0 to 2)
     t      steps of COUNT from the write of END to the read
     c      CURRENT, in bytes from the list's start
     s      STATUS
     the first twelve samples are taken about 2 microseconds apart, the last twelve about 64 apart
     steps  steps of COUNT from the write of END until the full sync's interrupt is seen; s and c
            STATUS and CURRENT then
   COUNT steps at half the CPU's clock (46.875 MHz).

   No line depends on the console's television type: the VI is switched off and the sound output
   is never used.

   Care for the console: everything here is ordinary. Lists of common commands: fill-mode
   rectangles into a 16-bit image, fill colours, a pipe sync and a change to one-cycle mode, and
   texture rectangles that the scissor leaves nothing of, each list ended by a full sync, as every
   game's graphics microcode hands over; no triangle, no 4-bit image. */

#include "../cart-lib/say.h"

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_CURRENT REG32(0xA4100008u)
#define DP_STATUS REG32(0xA410000Cu)
#define MI_INTR REG32(0xA4300008u)
#define VI_CONTROL REG32(0xA4400000u)

#define IMAGE 0x00200000u                                   /* two megabytes up: nothing else is there */
#define LIST 0x00280000u
#define WIDTH 320u
#define SAMPLES 24u

static volatile u64 *list_at;
static u32 list_words;
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }
static void fill_rect(u32 x0, u32 y0, u32 x1, u32 y1) { put(0x36000000u | (x1 << 14) | (y1 << 2), (x0 << 14) | (y0 << 2)); }

static u32 base = LIST;
static u32 build(u32 k, u32 extra) {
    list_at = (volatile u64 *)(0xA0000000u + base); list_words = 0;
    put(0x3F000000u | (2u << 19) | (WIDTH - 1u), IMAGE);                     /* the colour image: 16 bits a pixel */
    put(0x2D000000u, (WIDTH << 14) | (200u << 2));                           /* the scissor: 320 by 200 */
    put(0x2F300000u, 0u);                                                    /* fill mode */
    put(0x37000000u, 0x00010001u);
    for (u32 i = 0; i < extra; i++) put(0x37000000u, 0x00010001u);
    fill_rect(0, 0, WIDTH - 1u, 199);
    if (k == 0 || k == 3) for (u32 i = 0; i < 120u; i++) put(0x37000000u, 0x00010001u);
    if (k == 1) {
        put(0x27000000u, 0u);                                                /* pipe sync */
        put(0x2F000000u, 0u);                                                /* one-cycle mode, nothing else set */
        for (u32 i = 0; i < 60u; i++) {                                      /* texture rectangles at rows 240 to 247: below the scissor */
            put(0x24000000u | (40u << 14) | (247u << 2), (0u << 24) | (8u << 14) | (240u << 2));
            put(0u, 0x04000400u);
        }
    }
    if (k == 2) for (u32 i = 0; i < 120u; i++) fill_rect(i, 10, i, 10);
    put(0x29000000u, 0u);                                                    /* full sync */
    return base + list_words * 8u;
}

static void one_run(u32 k, u32 r, u32 extra, const char *tag, const char *last) {
    static u32 t[SAMPLES], c[SAMPLES], s[SAMPLES];
    const u32 end = build(tag[0] == 'W' || tag[0] == 'V' ? 0u : k, extra);         /* the sweep is variant 0 throughout */
    DP_STATUS = 0x0015u;                                                     /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                                       /* takes back the DP's interrupt */
    DP_START = base;
    const u32 t0 = count_now();
    DP_END = end;
    for (u32 i = 0; i < SAMPLES; i++) {
        const u32 due = i < 12u ? i * 94u : 11u * 94u + (i - 11u) * 3000u;
        while (count_now() - t0 < due) { }
        t[i] = count_now() - t0; c[i] = DP_CURRENT - base; s[i] = DP_STATUS;
    }
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    const u32 steps = count_now() - t0, s_end = DP_STATUS, c_end = DP_CURRENT - base;
    MI_MODE = 0x0800u;
    for (u32 j = 0; j < 3u; j++) {
        say_text(tag); say_hex(k, 1); say_hex(r, 1); say_hex(j, 1);
        for (u32 i = j * 8u; i < j * 8u + 8u; i++) { say_hex(t[i], 5); say_hex(c[i], 4); say_hex(s[i], 3); }
        say_flush();
    }
    say_text(last); say_hex(k, 1); say_hex(r, 1); say_hex(guard >= 20000000u ? 0xFFFFFFFFu : steps, 8); say_hex(s_end, 3); say_hex(c_end, 4);
    say_flush();
}

void probe_main(void) {
    say_head("DPDEPTH");
    VI_CONTROL = 0u;                                        /* the VI off: it would take memory time, by the television type */
    for (u32 k = 0; k < 4u; k++) for (u32 r = 0; r < 3u; r++) one_run(k, r, k == 3 ? 16u : 0u, "D", "E");
    for (u32 e = 0; e < 16u; e++) one_run(e, 0, e, "W", "F");
    for (u32 b = 0; b < 10u; b++) { base = LIST + 8u * b; one_run(b, 0, 0, "V", "H"); }
    base = LIST;
    say_tail("DPDEPTH");
}
