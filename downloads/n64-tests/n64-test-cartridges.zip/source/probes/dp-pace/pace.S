# The pace probe's timed part: the DP's clock is read, END is written, a chosen number of idle
# instructions pass, and one DP register is read; then COUNT and the clock are read again.
#
#   u32 pace_sample(u32 end, u32 read_address, void *enter, u32 *figures)
#     $4  the value for END
#     $5  the register to read behind the idle instructions
#     $6  where to enter the row of idle instructions: pace_row_end less four bytes for each
#     $7  where to put three figures: COUNT's steps from before the write to after the read, the
#         clock's cycles from its first read to its last, and the clock as first read
#
# The first read of the clock is a read of the RCP: it sets where the CPU stands against the RCP's
# clock, so that the write of END falls at the same place every time. The write stands in the
# jump's delay slot, the idle instructions follow it, and the read under test follows them: the
# time from the write to the read is the same from call to call but for the idle instructions.

    .set noreorder
    .set noat
    .text
    .globl pace_sample
    .globl pace_row
    .globl pace_row_end
    .balign 32
pace_sample:
    lui   $12, 0xA410
    lw    $13, 0x10($12)
    mfc0  $14, $9
    jr    $6
    sw    $4, 4($12)
pace_row:
    .rept 1536
    nop
    .endr
pace_row_end:
    lw    $2, 0($5)
    mfc0  $15, $9
    lw    $24, 0x10($12)
    subu  $15, $15, $14
    sw    $15, 0($7)
    subu  $24, $24, $13
    sw    $24, 4($7)
    jr    $31
    sw    $13, 8($7)
