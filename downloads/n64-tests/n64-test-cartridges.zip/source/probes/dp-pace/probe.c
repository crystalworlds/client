/* The DP pace probe: a small test cartridge for a real console.

   A console's logs of the depth probe (probes/dp-depth) showed that the DP reads a list into a
   buffer ahead of the drawing, 80 bytes at a time, and that CURRENT is the place of that reading.
   They gave one point of its pace. This probe asks for the whole course: after the write of END,
   CURRENT (or STATUS) is read once, a chosen number of idle instructions later, and the list is
   run again for every number. The DP's own clock is read before the write and behind the read, so
   every number of idle instructions has its time in cycles of the RCP's clock.

   The lists (v):
     3   four settings, a fill colour, a rectangle of 19 pixels, a full sync: 56 bytes
     0   four settings, 121 fill colours, a full sync: 1,008 bytes with no primitive, so nothing
         holds the commands up and the reading goes at its own pace
     1   four settings, a fill rectangle of 320 by 200, 120 fill colours, a full sync: the
         depth probe's first list, where the reading stops at byte 0xF0 while the rectangle is drawn
     2   as 1 with 16 more fill colours before the rectangle: the reading stops at byte 0x190
     4   list 0 handed over as a second transfer while a first one (four settings and the rectangle,
         40 bytes, read at once) is being drawn: how soon a transfer begins when the DP is at
         work already, and how its reading goes while nothing leaves the buffer. CURRENT reads ff
         while it still stands in the first transfer

   Lines:   K d  k (16 times)     the clock's cycles from its read before the write of END to a read
                                  of it d, d+1, ... idle instructions behind the write
            N d  n (16 times)     COUNT's steps over the same runs, from before the write to behind the read
            C v d  c (32 times)   CURRENT, in 8-byte words from the list's start, for d, d+1, ...
            S v d  s (16 times)   STATUS for d, d+1, ...
            k, n, c, s            the same with four idle instructions more from one value to the next
            T v r  n0 n1          COUNT's steps of a pass's first and last run (r: 0 CURRENT, 1 STATUS)

   Then three cases of their own, each with a rectangle of 320 by 200 that takes about 28,000
   steps of COUNT, and marks of one pixel or one short row drawn behind it:

   W, the waiting transfer: list A (the rectangle, 120 fill colours, a mark in 1235) is handed
   over, and list B (a fill colour abcd, a mark, a full sync) straight after, while A's reading
   stands still for want of room. Does B wait whole until A's reading has reached A's end?
            W r 0  s1 c1  s2 c2  s3 c3      after A's END, after B's START, after B's END
            W r 1  (s c) six times           every 3,000 steps of COUNT from then on
            W r 2  (s c) six times
            W r 3  s c start  a b  late      at the interrupt; the two marks
     CURRENT is printed in 8-byte words from A's start, or c000 and up from B's.

   Z, FREEZE while a list is drawn: the list is the rectangle, a fill colour 1235 and 60 marks of
   one pixel, then a full sync. 2,000 steps in, FREEZE is set; 45,000 steps in, the state is read;
   then FREEZE is cleared and the interrupt waited for.
            Z r 0  s0 c0  s1 c1  s2 c2  intr  rows last  marks marks
            Z r 1  s3 c3  s4 c4  rows last  marks marks  late
     s0 c0 before FREEZE, s1 c1 straight after, s2 c2 at 45,000 steps; s3 c3 straight after it is
     cleared, s4 c4 at the interrupt. rows: how many of the rectangle's 200 rows have their first
     pixel drawn; last: how many have their last. marks: one bit for each mark drawn (marks 0 to 31,
     then 32 to 59). CURRENT in bytes from the list's start.

   F, FLUSH while a list is drawn: the same list. 2,000 steps in, FLUSH is set; 400 steps later it
   is cleared; 45,000 steps in, the state is read. Then a short list (a fill colour abcd, a mark, a
   full sync) is handed over, to see the DP take a list again.
            F r 0  s0 c0  s1 c1  s2 c2  s3 c3
            F r 1  s4 c4  intr  rows last  marks marks  s5 c5  b  late
     s0 c0 before FLUSH, s1 c1 straight after, s2 c2 400 steps on, s3 c3 straight after it is
     cleared, s4 c4 at 45,000 steps; s5 c5 and the mark b when the short list's interrupt has come
     (its CURRENT printed as c000 and up).

   The last line before the end, L, counts the waits for an interrupt that ran out (0 expected).

   No line depends on the console's television type: the VI is switched off and the sound output
   is never used.

   Care for the console: everything here is ordinary. Lists of fill-mode rectangles into a 16-bit
   image and fill colours, each ended by a full sync; a second list handed over while the first is
   drawn, as every game's graphics microcode does; and the DP's FREEZE and FLUSH bits set and
   cleared once each while a list runs, as the maker's library lets a program do. No triangle, no
   4-bit image. */

#include "../cart-lib/say.h"

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_CURRENT REG32(0xA4100008u)
#define DP_STATUS REG32(0xA410000Cu)
#define MI_INTR REG32(0xA4300008u)
#define VI_CONTROL REG32(0xA4400000u)
#define REG_CURRENT 0xA4100008u
#define REG_STATUS 0xA410000Cu
#define REG_CLOCK 0xA4100010u

#define IMAGE 0x00200000u                                   /* two megabytes up: nothing else is there */
#define LIST 0x00280000u
#define LIST_B 0x00281000u
#define WIDTH 320u
#define PIXEL(x, y) (*(volatile u16 *)(0xA0000000u + IMAGE + ((y) * WIDTH + (x)) * 2u))
#define GUARD 2000000u

extern u32 pace_sample(u32 end, u32 read_address, void *enter, u32 *figures);
extern u8 pace_row_end[];

static volatile u64 *list_at;
static u32 list_words;
static void list_begin(u32 at) { list_at = (volatile u64 *)(0xA0000000u + at); list_words = 0; }
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }
static void fill_rect(u32 x0, u32 y0, u32 x1, u32 y1) { put(0x36000000u | (x1 << 14) | (y1 << 2), (x0 << 14) | (y0 << 2)); }
static void settings(void) {
    put(0x3F000000u | (2u << 19) | (WIDTH - 1u), IMAGE);                     /* the colour image: 16 bits a pixel */
    put(0x2D000000u, (WIDTH << 14) | (240u << 2));                           /* the scissor: 320 by 240 */
    put(0x2F300000u, 0u);                                                    /* fill mode */
    put(0x37000000u, 0x00010001u);
}
static u32 place(u32 current) { return current >= LIST_B ? 0xC000u + ((current - LIST_B) >> 3) : (current - LIST) >> 3; }

static u32 late;
static u32 figures[3];
static u32 first_end;                                       /* the end of a transfer handed over first, or 0 for none */

static u32 build(u32 v) {
    first_end = 0;
    if (v == 4u) { list_begin(LIST_B); settings(); fill_rect(0, 0, WIDTH - 1u, 199); first_end = LIST_B + list_words * 8u; }
    list_begin(LIST);
    settings();
    if (v == 0u || v == 4u) for (u32 i = 0; i < 121u; i++) put(0x37000000u, 0x00010001u);
    if (v == 2u) for (u32 i = 0; i < 16u; i++) put(0x37000000u, 0x00010001u);
    if (v == 1u || v == 2u) { fill_rect(0, 0, WIDTH - 1u, 199); for (u32 i = 0; i < 120u; i++) put(0x37000000u, 0x00010001u); }
    if (v == 3u) { put(0x37000000u, 0x12351235u); fill_rect(2, 210, 20, 210); }
    put(0x29000000u, 0u);                                                    /* full sync */
    return LIST + list_words * 8u;
}

static u32 wait_for_the_interrupt(void) {
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < GUARD) guard++;
    if (guard >= GUARD) { late++; return 1u; }
    return 0u;
}

/* One run of the list in hand: the register read `idle` idle instructions behind the write of END. */
static u32 one(u32 end, u32 reg, u32 idle) {
    DP_STATUS = 0x0015u;                                                     /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                                       /* takes back the DP's interrupt */
    if (first_end) { DP_START = LIST_B; DP_END = first_end; }
    DP_START = LIST;
    const u32 v = pace_sample(end, reg, pace_row_end - 4u * idle, figures);
    wait_for_the_interrupt();
    MI_MODE = 0x0800u;
    return v;
}

static void pass(u32 v, u32 reg, const char *tag, u32 from, u32 to, u32 step, u32 a_line) {
    static u32 values[32];
    const u32 end = build(v);
    u32 n0 = 0, n1 = 0;
    for (u32 d = from; d < to; d += a_line * step) {
        for (u32 i = 0; i < a_line; i++) {
            const u32 x = one(end, reg, d + i * step);
            values[i] = reg != REG_CURRENT ? x : x >= LIST_B ? 0xFFu : (x - LIST) >> 3;
            if (d == from && i == 0u) n0 = figures[0];
            n1 = figures[0];
        }
        say_text(tag); say_hex(v, 1); say_hex(d, 3);
        for (u32 i = 0; i < a_line; i++) say_hex(values[i], reg == REG_CURRENT ? 2 : 3);
        say_flush();
    }
    say_text("T"); say_hex(v, 1); say_hex(reg == REG_CURRENT ? 0u : 1u, 1); say_hex(n0, 4); say_hex(n1, 4);
    say_flush();
}

/* The clock's cycles and COUNT's steps for every number of idle instructions. */
static void clock_pass(const char *tag_k, const char *tag_n, u32 from, u32 to, u32 step) {
    static u32 k[16], n[16];
    const u32 end = build(3);
    for (u32 d = from; d < to; d += 16u * step) {
        for (u32 i = 0; i < 16u; i++) { const u32 x = one(end, REG_CLOCK, d + i * step); k[i] = (x - figures[2]) & 0xFFFFFFu; n[i] = figures[0]; }
        say_text(tag_k); say_hex(d, 3); for (u32 i = 0; i < 16u; i++) say_hex(k[i], 3); say_flush();
        say_text(tag_n); say_hex(d, 3); for (u32 i = 0; i < 16u; i++) say_hex(n[i], 3); say_flush();
    }
}

static void clear_rows(u32 from, u32 to) { for (u32 y = from; y < to; y++) for (u32 x = 0; x < WIDTH; x++) PIXEL(x, y) = 0; }
static void wait_until(u32 t0, u32 steps) { while (count_now() - t0 < steps) { } }

static void waiting_case(u32 r) {
    static u32 s[16], c[16];
    clear_rows(204, 216);
    list_begin(LIST);
    settings();
    fill_rect(0, 0, WIDTH - 1u, 199);
    for (u32 i = 0; i < 120u; i++) put(0x37000000u, 0x00010001u);
    put(0x37000000u, 0x12351235u);
    fill_rect(2, 210, 20, 210);                                              /* A's mark */
    const u32 end_a = LIST + list_words * 8u;
    list_begin(LIST_B);
    put(0x37000000u, 0xABCDABCDu);
    fill_rect(2, 212, 20, 212);                                              /* B's mark */
    put(0x29000000u, 0u);
    const u32 end_b = LIST_B + list_words * 8u;

    DP_STATUS = 0x0015u;
    MI_MODE = 0x0800u;
    DP_START = LIST;
    const u32 t0 = count_now();
    DP_END = end_a;
    s[0] = DP_STATUS; c[0] = DP_CURRENT;
    DP_START = LIST_B;
    s[1] = DP_STATUS; c[1] = DP_CURRENT;
    DP_END = end_b;
    s[2] = DP_STATUS; c[2] = DP_CURRENT;
    for (u32 i = 0; i < 12u; i++) { wait_until(t0, 3000u * (i + 1u)); s[3u + i] = DP_STATUS; c[3u + i] = DP_CURRENT; }
    const u32 ran_out = wait_for_the_interrupt();
    const u32 s_end = DP_STATUS, c_end = DP_CURRENT, start = DP_START;
    MI_MODE = 0x0800u;
    say_text("W"); say_hex(r, 1); say_hex(0, 1); for (u32 i = 0; i < 3u; i++) { say_hex(s[i], 3); say_hex(place(c[i]), 4); } say_flush();
    say_text("W"); say_hex(r, 1); say_hex(1, 1); for (u32 i = 3; i < 9u; i++) { say_hex(s[i], 3); say_hex(place(c[i]), 4); } say_flush();
    say_text("W"); say_hex(r, 1); say_hex(2, 1); for (u32 i = 9; i < 15u; i++) { say_hex(s[i], 3); say_hex(place(c[i]), 4); } say_flush();
    say_text("W"); say_hex(r, 1); say_hex(3, 1); say_hex(s_end, 3); say_hex(place(c_end), 4); say_hex(place(start), 4);
    say_hex(PIXEL(2, 210), 4); say_hex(PIXEL(2, 212), 4); say_hex(ran_out, 1);
    say_flush();
}

/* The list of the two cases that set a bit while it is drawn, and what of it is in memory. */
static u32 marked_list(void) {
    clear_rows(0, 216);
    list_begin(LIST);
    settings();
    fill_rect(0, 0, WIDTH - 1u, 199);
    put(0x37000000u, 0x12351235u);
    for (u32 i = 0; i < 60u; i++) fill_rect(2u * i, 210, 2u * i, 210);
    put(0x29000000u, 0u);
    return LIST + list_words * 8u;
}
static void say_what_is_drawn(void) {
    u32 rows = 0, last = 0, lo = 0, hi = 0;
    for (u32 y = 0; y < 200u; y++) { if (PIXEL(0, y) == 0x0001u) rows++; if (PIXEL(WIDTH - 1u, y) == 0x0001u) last++; }
    for (u32 i = 0; i < 60u; i++) if (PIXEL(2u * i, 210) == 0x1235u) { if (i < 32u) lo |= 1u << i; else hi |= 1u << (i - 32u); }
    say_hex(rows, 2); say_hex(last, 2); say_hex(lo, 8); say_hex(hi, 8);
}

static void freeze_case(u32 r) {
    const u32 end = marked_list();
    DP_STATUS = 0x0015u;
    MI_MODE = 0x0800u;
    DP_START = LIST;
    const u32 t0 = count_now();
    DP_END = end;
    wait_until(t0, 2000u);
    const u32 s0 = DP_STATUS, c0 = DP_CURRENT - LIST;
    DP_STATUS = 0x0008u;                                                     /* FREEZE */
    const u32 s1 = DP_STATUS, c1 = DP_CURRENT - LIST;
    wait_until(t0, 45000u);
    const u32 s2 = DP_STATUS, c2 = DP_CURRENT - LIST, intr = (MI_INTR & 0x20u) ? 1u : 0u;
    say_text("Z"); say_hex(r, 1); say_hex(0, 1); say_hex(s0, 3); say_hex(c0, 4); say_hex(s1, 3); say_hex(c1, 4); say_hex(s2, 3); say_hex(c2, 4); say_hex(intr, 1);
    say_what_is_drawn();
    say_flush();
    DP_STATUS = 0x0004u;                                                     /* no longer frozen */
    const u32 s3 = DP_STATUS, c3 = DP_CURRENT - LIST;
    const u32 ran_out = wait_for_the_interrupt();
    const u32 s4 = DP_STATUS, c4 = DP_CURRENT - LIST;
    MI_MODE = 0x0800u;
    say_text("Z"); say_hex(r, 1); say_hex(1, 1); say_hex(s3, 3); say_hex(c3, 4); say_hex(s4, 3); say_hex(c4, 4);
    say_what_is_drawn();
    say_hex(ran_out, 1);
    say_flush();
}

static void flush_case(u32 r) {
    const u32 end = marked_list();
    DP_STATUS = 0x0015u;
    MI_MODE = 0x0800u;
    DP_START = LIST;
    const u32 t0 = count_now();
    DP_END = end;
    wait_until(t0, 2000u);
    const u32 s0 = DP_STATUS, c0 = DP_CURRENT - LIST;
    DP_STATUS = 0x0020u;                                                     /* FLUSH */
    const u32 s1 = DP_STATUS, c1 = DP_CURRENT - LIST;
    wait_until(t0, 2400u);
    const u32 s2 = DP_STATUS, c2 = DP_CURRENT - LIST;
    DP_STATUS = 0x0010u;                                                     /* no longer flushing */
    const u32 s3 = DP_STATUS, c3 = DP_CURRENT - LIST;
    wait_until(t0, 45000u);
    const u32 s4 = DP_STATUS, c4 = DP_CURRENT - LIST, intr = (MI_INTR & 0x20u) ? 1u : 0u;
    say_text("F"); say_hex(r, 1); say_hex(0, 1); say_hex(s0, 3); say_hex(c0, 4); say_hex(s1, 3); say_hex(c1, 4); say_hex(s2, 3); say_hex(c2, 4); say_hex(s3, 3); say_hex(c3, 4);
    say_flush();
    say_text("F"); say_hex(r, 1); say_hex(1, 1); say_hex(s4, 3); say_hex(c4, 4); say_hex(intr, 1);
    say_what_is_drawn();
    /* A short list, to see the DP take a list again. */
    clear_rows(212, 213);
    list_begin(LIST_B);
    put(0x37000000u, 0xABCDABCDu);
    fill_rect(2, 212, 20, 212);
    put(0x29000000u, 0u);
    MI_MODE = 0x0800u;
    DP_START = LIST_B;
    DP_END = LIST_B + list_words * 8u;
    const u32 ran_out = wait_for_the_interrupt();
    const u32 s5 = DP_STATUS, c5 = DP_CURRENT;
    MI_MODE = 0x0800u;
    say_hex(s5, 3); say_hex(place(c5), 4); say_hex(PIXEL(2, 212), 4); say_hex(ran_out, 1);
    say_flush();
}

void probe_main(void) {
    say_head("DPPACE");
    VI_CONTROL = 0u;                                        /* the VI off: it would take memory time, by the television type */
    /* Every instruction of the timed part is run once first, so that none of it is fetched from
       memory while a time is taken. */
    { const u32 end = build(3); one(end, REG_CLOCK, 1536u); one(end, REG_CLOCK, 1536u); one(end, REG_CLOCK, 0u); }
    clock_pass("K", "N", 0u, 512u, 1u);
    clock_pass("k", "n", 512u, 1536u, 4u);
    static const u8 ORDER[5] = { 3, 0, 1, 2, 4 };
    for (u32 i = 0; i < 5u; i++) {
        pass(ORDER[i], REG_CURRENT, "C", 0u, 512u, 1u, 32u);
        pass(ORDER[i], REG_STATUS, "S", 0u, 512u, 1u, 16u);
    }
    for (u32 v = 0; v < 3u; v += 2u) {
        pass(v, REG_CURRENT, "c", 512u, 1536u, 4u, 32u);
        pass(v, REG_STATUS, "s", 512u, 1536u, 4u, 16u);
    }
    for (u32 r = 0; r < 3u; r++) waiting_case(r);
    for (u32 r = 0; r < 2u; r++) freeze_case(r);
    for (u32 r = 0; r < 2u; r++) flush_case(r);
    say_text("L"); say_hex(late, 4); say_flush();
    say_tail("DPPACE");
}
