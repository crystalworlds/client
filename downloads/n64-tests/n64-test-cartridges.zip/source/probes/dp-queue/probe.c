/* The waiting transfer probe: a small test cartridge for a real console.

   The DP has room for one transfer in hand and one that waits. What does a console do when a
   program writes START and END for a second list while the first is still being drawn? This
   core makes the second wait whole and loses nothing of the first (the rule is read from a
   hardware wiki); games lean on it every frame. Each answer is a line of text through the debug
   text window a flash cartridge shows on the computer beside the console. Run on this core, the
   same lines show what the core does.

   Two lists: A fills a rectangle of 64 by 40 pixels `n` times and then draws a mark; B draws a
   second mark and ends in a full sync. A is started, and B is asked for straight away.

   A line:   Q  n  s1 c1  s2 c2  s3 c3  s4 c4  start  a  b
     n       how many rectangles A fills before its mark: 0 (A is over before B is asked for) or
             12 (A is under way then)
     s1 c1   STATUS and CURRENT read straight after the write of A's END
     s2 c2   the same after the write of B's START
     s3 c3   the same after the write of B's END
     s4 c4   the same when the full sync's interrupt has come; `start` is START read then
     a  b    the 16-bit pixel at each mark's place at the end: A's mark is 1235, B's abcd
   CURRENT is printed as a count of 8-byte commands from A's first (c000 and up: from B's first).

   Every case is run three times: what differs between two lines of the same n differs from run
   to run on the same console (how far A has got when it is looked at, and the busy marks).

   No line depends on the console's television type: the VI is switched off and the sound output
   is never used.

   Care for the console: everything here is ordinary. Two short lists of fill-mode rectangles into
   a 16-bit image, the second handed over while the first runs, as every game's graphics
   microcode does; no fill-mode triangle, no 4-bit image, nothing the hardware notes warn of. */

#include "../cart-lib/say.h"

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_CURRENT REG32(0xA4100008u)
#define DP_STATUS REG32(0xA410000Cu)
#define MI_INTR REG32(0xA4300008u)
#define VI_CONTROL REG32(0xA4400000u)

#define IMAGE 0x00200000u                                   /* two megabytes up: nothing else is there */
#define LIST_A 0x00280000u
#define LIST_B 0x00281000u
#define WIDTH 64u
#define PIXEL(x, y) (*(volatile u16 *)(0xA0000000u + IMAGE + ((y) * WIDTH + (x)) * 2u))

static volatile u64 *list_at;
static u32 list_words;
static void list_begin(u32 at) { list_at = (volatile u64 *)(0xA0000000u + at); list_words = 0; }
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }
static void fill_rect(u32 x0, u32 y0, u32 x1, u32 y1) { put(0x36000000u | (x1 << 14) | (y1 << 2), (x0 << 14) | (y0 << 2)); }

static u32 place(u32 current) { return current >= LIST_B ? 0xC000u + ((current - LIST_B) >> 3) : (current - LIST_A) >> 3; }

static void one_case(u32 n) {
    for (u32 y = 44; y < 48; y++) for (u32 x = 0; x < 24; x++) PIXEL(x, y) = 0;
    list_begin(LIST_A);
    put(0x3F000000u | (2u << 19) | (WIDTH - 1u), IMAGE);                    /* the colour image: 16 bits a pixel */
    put(0x2D000000u, (WIDTH << 14) | (48u << 2));                           /* the scissor */
    put(0x2F300000u, 0u);                                                   /* fill mode */
    put(0x37000000u, 0xFFFFFFFFu);
    for (u32 i = 0; i < n; i++) fill_rect(0, 0, WIDTH - 1u, 39);
    put(0x37000000u, 0x12351235u);
    fill_rect(2, 44, 20, 44);                                               /* A's mark */
    const u32 end_a = LIST_A + list_words * 8u;
    list_begin(LIST_B);
    put(0x37000000u, 0xABCDABCDu);
    fill_rect(2, 46, 20, 46);                                               /* B's mark */
    put(0x29000000u, 0u);                                                   /* full sync */
    const u32 end_b = LIST_B + list_words * 8u;

    DP_STATUS = 0x0015u;                                                    /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                                      /* takes back the DP's interrupt */
    DP_START = LIST_A;
    DP_END = end_a;
    const u32 s1 = DP_STATUS, c1 = DP_CURRENT;
    DP_START = LIST_B;
    const u32 s2 = DP_STATUS, c2 = DP_CURRENT;
    DP_END = end_b;
    const u32 s3 = DP_STATUS, c3 = DP_CURRENT;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    const u32 s4 = DP_STATUS, c4 = DP_CURRENT, start = DP_START;
    MI_MODE = 0x0800u;
    say_text("Q"); say_hex(n, 2);
    say_hex(s1, 3); say_hex(place(c1), 4); say_hex(s2, 3); say_hex(place(c2), 4); say_hex(s3, 3); say_hex(place(c3), 4); say_hex(s4, 3); say_hex(place(c4), 4);
    say_hex(place(start), 4); say_hex(PIXEL(2, 44), 4); say_hex(PIXEL(2, 46), 4);
    say_flush();
}

void probe_main(void) {
    say_head("DPQUEUE");
    VI_CONTROL = 0u;                                        /* the VI off: it would take memory time, by the television type */
    for (u32 run = 0; run < 3; run++) one_case(0);
    for (u32 run = 0; run < 3; run++) one_case(12);
    say_tail("DPQUEUE");
}
