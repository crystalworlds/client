/* The DP reach probe: a small test cartridge for a real console.

   A console's log of the waiting transfer probe (probes/dp-queue) showed a fill colour set behind
   a rectangle, with no sync between, reach that rectangle before it was drawn. How far back does a
   setting changed without a sync reach, and what stops it? This core runs every command in order,
   so a setting never reaches back.

   Each case is one list: the colour image (16 bits, 64 wide), the scissor (64 by 48), fill mode,
   Set Fill Color c1; R1, a fill rectangle over rows 0 to h-1 and the whole width; R2, one row at 44
   from x 2 to 20; then what lies between (the gap); then the command under test; then Q, a fill
   rectangle at row 46 from x 2 to 20 that uses the state; a full sync. The CPU clears rows 0 to 47
   before each case.

   Lines:   R c g h  p0 pl0 pl1  m0 m1  q  t
     c   the command under test: 0 Set Fill Color c2; 1 Set Color Image to another image; 2 Set
         Scissor to rows 0 to 43 (row 44 and 46 left out); 3 Set Other Modes to one-cycle mode (all else zero),
         in which a fill rectangle is drawn through the colour combiner and the blender
     g   the gap: 0 nothing; 1, 2, 3, 4 that many times two Set Fill Color c1 (2, 4, 6, 8 commands);
         5 a pipe sync; 6 a load sync; 7 a tile sync
     h   R1's height in rows: 1, 8 or 40
     p0      R1's first pixel (0, 0)
     pl0 pl1 R1's last row's first and last pixel (0 and 63, row h-1)
     m0 m1   R2's first and last pixel (2 and 20, row 44)
     q       Q's first pixel (2, 46)
     t   1 if the wait for the full sync's interrupt ran out (never expected)
   c1 is 1235, c2 abcd. Every case runs twice: the second line shows whether the answer moves.
   Then the row map: R1 40 rows high and w pixels wide (64, 32, 16 or 8), R2 one row at 44 of n
   pixels (19 or 64), Set Fill Color c2 straight after, then Q; which of R1's rows took c2:
     M w n  first last  r2      first: a bit for each of R1's 40 rows, row 39 in the lowest bit,
                                set where the row's first pixel is abcd; last: the same for the
                                row's last pixel; r2: R2's first and last pixel, 1 where abcd

   Then the colour clock (the third build): when is a row's fill colour read? Behind the
   rectangles stand 22 Set Fill Color commands, each with a colour of its own (4001 to 4016; the
   rectangles are decoded with 4000 in force). The decoder takes them one cycle apart, so the colour
   a row comes out in says how many cycles after the rectangle's command had been worked off the
   row's colour was read. A load sync (25 cycles) or a tile sync (33) before the colours moves the
   clock on by as much, so three lists cover the first 55 cycles. The image is 320 pixels wide.
     T s w h x n y   f l (for each of R1's last rows, eight at most)   m0 m1  q
     s     the image's pixel size: 2 for 16 bits, 3 for 32
     w h   R1's width and height (rows 0 to h-1); x: its first pixel
     n     R2's pixels on row 44 (from x 2 for 19, from x 0 for 64), or 0 for no R2
     y     what stands before the colours: 0 nothing, 1 a load sync, 2 a tile sync, 3 a pipe sync
     f l   the colour number of a row's first and last pixel: 00 for 4000, 16 for 4016; dd where
           nothing was drawn, ee for any other value
     m0 m1 the same for R2's first and last pixel (dd with no R2); q for Q's first pixel (row 46)
   The whole clock is run twice.

   No line depends on the console's television type: the VI is switched off and the sound output
   is never used.

   Care for the console: everything here is ordinary. Short lists of fill-mode rectangles into a
   16-bit or a 32-bit image, fill colours, a colour image, a scissor, a change to one-cycle mode (a
   fill rectangle in one-cycle mode is how games draw shaded rectangles) and the three syncs, each
   list ended by a full sync; a setting changed with no pipe sync before it, which the graphics
   microcode of games does for some settings. No triangle, no 4-bit image. */

#include "../cart-lib/say.h"

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_STATUS REG32(0xA410000Cu)
#define MI_INTR REG32(0xA4300008u)
#define VI_CONTROL REG32(0xA4400000u)

#define IMAGE 0x00200000u                                   /* two megabytes up: nothing else is there */
#define OTHER 0x00210000u                                   /* the other image */
#define LIST 0x00280000u
#define WIDTH 64u
#define PIXEL(x, y) (*(volatile u16 *)(0xA0000000u + IMAGE + ((y) * WIDTH + (x)) * 2u))
#define C1 0x12351235u
#define C2 0xABCDABCDu

static volatile u64 *list_at;
static u32 list_words;
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }
static void fill_rect(u32 x0, u32 y0, u32 x1, u32 y1) { put(0x36000000u | (x1 << 14) | (y1 << 2), (x0 << 14) | (y0 << 2)); }

static void one_case(u32 c, u32 g, u32 h) {
    for (u32 y = 0; y < 48u; y++) for (u32 x = 0; x < WIDTH; x++) PIXEL(x, y) = 0;
    list_at = (volatile u64 *)(0xA0000000u + LIST); list_words = 0;
    put(0x3F000000u | (2u << 19) | (WIDTH - 1u), IMAGE);                     /* the colour image: 16 bits a pixel */
    put(0x2D000000u, (WIDTH << 14) | (48u << 2));                            /* the scissor: 64 by 48 */
    put(0x2F300000u, 0u);                                                    /* fill mode */
    put(0x37000000u, C1);
    fill_rect(0, 0, WIDTH - 1u, h - 1u);                                     /* R1 */
    fill_rect(2, 44, 20, 44);                                                /* R2 */
    if (g >= 1u && g <= 4u) for (u32 i = 0; i < 2u * g; i++) put(0x37000000u, C1);
    if (g == 5u) put(0x27000000u, 0u);                                       /* pipe sync */
    if (g == 6u) put(0x26000000u, 0u);                                       /* load sync */
    if (g == 7u) put(0x28000000u, 0u);                                       /* tile sync */
    if (c == 0u) put(0x37000000u, C2);
    if (c == 1u) put(0x3F000000u | (2u << 19) | (WIDTH - 1u), OTHER);
    if (c == 2u) put(0x2D000000u, (WIDTH << 14) | (44u << 2));               /* rows 0 to 43 */
    if (c == 3u) put(0x2F000000u, 0u);                                       /* one-cycle mode */
    fill_rect(2, 46, 20, 46);                                                /* Q */
    put(0x29000000u, 0u);                                                    /* full sync */
    DP_STATUS = 0x0015u;                                                     /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                                       /* takes back the DP's interrupt */
    DP_START = LIST;
    DP_END = LIST + list_words * 8u;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    MI_MODE = 0x0800u;
    say_text("R"); say_hex(c, 1); say_hex(g, 1); say_hex(h, 2);
    say_hex(PIXEL(0, 0), 4); say_hex(PIXEL(0, h - 1u), 4); say_hex(PIXEL(WIDTH - 1u, h - 1u), 4);
    say_hex(PIXEL(2, 44), 4); say_hex(PIXEL(20, 44), 4); say_hex(PIXEL(2, 46), 4); say_hex(guard >= 20000000u ? 1u : 0u, 1);
    say_flush();
}

static u64 rows_of(u32 x) { u64 m = 0; for (u32 y = 0; y < 40u; y++) m = (m << 1) | (PIXEL(x, y) == 0xABCDu ? 1u : 0u); return m; }

static void row_map(u32 w, u32 n) {
    for (u32 y = 0; y < 48u; y++) for (u32 x = 0; x < WIDTH; x++) PIXEL(x, y) = 0;
    list_at = (volatile u64 *)(0xA0000000u + LIST); list_words = 0;
    put(0x3F000000u | (2u << 19) | (WIDTH - 1u), IMAGE);
    put(0x2D000000u, (WIDTH << 14) | (48u << 2));
    put(0x2F300000u, 0u);
    put(0x37000000u, C1);
    fill_rect(0, 0, w - 1u, 39);                                             /* R1 */
    fill_rect(0, 44, n - 1u, 44);                                            /* R2 */
    put(0x37000000u, C2);
    fill_rect(2, 46, 20, 46);                                                /* Q */
    put(0x29000000u, 0u);
    DP_STATUS = 0x0015u;
    MI_MODE = 0x0800u;
    DP_START = LIST;
    DP_END = LIST + list_words * 8u;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    MI_MODE = 0x0800u;
    say_text("M"); say_hex(w, 2); say_hex(n, 2); say_hex(rows_of(0), 10); say_hex(rows_of(w - 1u), 10);
    say_hex((PIXEL(0, 44) == 0xABCDu ? 2u : 0u) | (PIXEL(n - 1u, 44) == 0xABCDu ? 1u : 0u), 1);
    say_flush();
}

/* The colour clock. */
#define CLOCK 22u
#define WIDE 320u
static u32 clock_colour(u32 size, u32 i) { return size == 3u ? 0x4000u + i : ((0x4000u + i) << 16) | (0x4000u + i); }
static u32 clock_pixel(u32 size, u32 x, u32 y) {
    const u32 at = 0xA0000000u + IMAGE + (y * WIDE + x) * (size == 3u ? 4u : 2u);
    const u32 v = size == 3u ? *(volatile u32 *)at : *(volatile u16 *)at;
    return v == 0u ? 0xDDu : (v >= 0x4000u && v <= 0x4000u + CLOCK) ? v - 0x4000u : 0xEEu;
}
static void clock_case(u32 size, u32 w, u32 h, u32 x, u32 n, u32 sync) {
    for (u32 y = 0; y < 47u; y++) {
        if (y == 8u) y = 44u;
        for (u32 i = 0; i < WIDE * (size == 3u ? 2u : 1u); i++) *(volatile u16 *)(0xA0000000u + IMAGE + y * WIDE * (size == 3u ? 4u : 2u) + i * 2u) = 0;
    }
    list_at = (volatile u64 *)(0xA0000000u + LIST); list_words = 0;
    put(0x3F000000u | (size << 19) | (WIDE - 1u), IMAGE);
    put(0x2D000000u, (WIDE << 14) | (48u << 2));
    put(0x2F300000u, 0u);
    put(0x37000000u, clock_colour(size, 0));
    fill_rect(x, 0, x + w - 1u, h - 1u);                                     /* R1 */
    if (n == 19u) fill_rect(2, 44, 20, 44);                                  /* R2 */
    else if (n) fill_rect(0, 44, n - 1u, 44);
    if (sync == 1u) put(0x26000000u, 0u);
    if (sync == 2u) put(0x28000000u, 0u);
    if (sync == 3u) put(0x27000000u, 0u);
    for (u32 i = 1; i <= CLOCK; i++) put(0x37000000u, clock_colour(size, i));
    fill_rect(2, 46, 20, 46);                                                /* Q */
    put(0x29000000u, 0u);
    DP_STATUS = 0x0015u;
    MI_MODE = 0x0800u;
    DP_START = LIST;
    DP_END = LIST + list_words * 8u;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    MI_MODE = 0x0800u;
    say_text("T"); say_hex(size, 1); say_hex(w, 3); say_hex(h, 2); say_hex(x, 2); say_hex(n, 2); say_hex(sync, 1);
    for (u32 y = h > 8u ? h - 8u : 0u; y < h; y++) { say_hex(clock_pixel(size, x, y), 2); say_hex(clock_pixel(size, x + w - 1u, y), 2); }
    say_hex(n ? clock_pixel(size, n == 19u ? 2u : 0u, 44) : 0xDDu, 2); say_hex(n ? clock_pixel(size, n == 19u ? 20u : n - 1u, 44) : 0xDDu, 2);
    say_hex(clock_pixel(size, 2, 46), 2);
    say_flush();
}
static const u16 CLOCK_WIDTHS[6] = { 8, 16, 32, 64, 128, 320 };
static const u8 CLOCK_HEIGHTS[3] = { 1, 2, 8 };
static const u8 CLOCK_SECOND[3] = { 0, 19, 64 };
static const u8 CLOCK_WIDTHS_32[6] = { 8, 16, 24, 48, 92, 128 };
static void colour_clock(void) {
    for (u32 i = 0; i < 6u; i++) for (u32 j = 0; j < 3u; j++) for (u32 k = 0; k < 3u; k++) for (u32 sync = 0; sync < 3u; sync++)
        clock_case(2, CLOCK_WIDTHS[i], CLOCK_HEIGHTS[j], 0, CLOCK_SECOND[k], sync);
    for (u32 i = 1; i < 4u; i += 2u) for (u32 j = 0; j < 3u; j++) for (u32 sync = 0; sync < 3u; sync++)
        clock_case(2, CLOCK_WIDTHS[i], CLOCK_HEIGHTS[j], 12, 0, sync);                /* 16 and 64 pixels from x 12: off a 64-byte block */
    for (u32 i = 0; i < 6u; i++) for (u32 sync = 0; sync < 3u; sync++) clock_case(3, CLOCK_WIDTHS_32[i], 8, 0, 0, sync);
    for (u32 j = 0; j < 3u; j += 2u) for (u32 k = 0; k < 2u; k++) clock_case(2, 64, CLOCK_HEIGHTS[j], 0, CLOCK_SECOND[k], 3);    /* a pipe sync before the colours */
}

static const u8 HEIGHTS[3] = { 1, 8, 40 };

void probe_main(void) {
    say_head("DPREACH");
    VI_CONTROL = 0u;                                        /* the VI off: it would take memory time, by the television type */
    for (u32 run = 0; run < 2u; run++) {
        for (u32 i = 0; i < 3u; i++) for (u32 g = 0; g < 8u; g++) one_case(0, g, HEIGHTS[i]);
        for (u32 c = 1; c < 3u; c++) for (u32 g = 0; g < 8u; g++) one_case(c, g, 40);
        one_case(3, 0, 40); one_case(3, 5, 40);
    }
    for (u32 run = 0; run < 2u; run++) for (u32 i = 0; i < 4u; i++) for (u32 j = 0; j < 2u; j++) row_map(64u >> i, j ? 64u : 19u);
    for (u32 run = 0; run < 2u; run++) colour_clock();
    say_tail("DPREACH");
}
