/* The drawing time probe: a small test cartridge for a real console.

   What can the CPU see of the time the RDP takes to draw? The probe hands the DP short lists,
   each ending in a full sync, and for each one prints what the DP's registers show at once, how
   long the full sync's interrupt takes to come, what the three busy counters and the clock have
   counted by then, whether they still count afterwards, and, for one large rectangle, which of
   its lines are in memory at four moments on the way. Each answer is a line of text through the
   debug text window a flash cartridge shows on the computer beside the console. Run on this
   core, the same lines show what the core does.

   Every list is run twice, so that two lines with the same letters stand under each other: what
   differs between them differs from run to run on the same console.

   A line for a list:   tag  s0  s1  ticks  buf  pipe  tmem  clock  buf+  pipe+
     s0      STATUS read straight after the write to END
     s1      STATUS read when the interrupt has come
     ticks   COUNT's steps from the write to END until the DP's interrupt shows in the MI
             (COUNT steps once every two CPU cycles: three steps are four cycles of the RCP)
     buf, pipe, tmem, clock   the three busy counters and the clock, read when the interrupt has
             come; all four were cleared between the writes to START and END
     buf+, pipe+   how far the two counters went on in about 2,000 more steps of COUNT

   The lists (every one ends in a full sync; the image is 32 bits, 320 wide, image read off, no
   depth, so the pipe never waits to read memory):
     E       nothing else
     N       sixteen commands that set the primitive colour
     P T L   one sync pipe, one sync tile, one sync load
     A1-A6   one fill rectangle in one-cycle mode: 8 by 1, 8 by 8, 64 by 1, 64 by 8, 320 by 8,
             320 by 64 pixels
     B1-B6   the same in two-cycle mode
     F1-F6   the same in fill mode
     G       one triangle in one-cycle mode, major edge on the left, 64 wide and 64 high

   A line for memory on the way:   H  wait  lines
     A rectangle of 320 by 200 pixels in one-cycle mode. `wait` is how many steps of COUNT the
     probe let pass after the write to END before it looked; `lines` has one bit for each of the
     lines 20, 100 and 180 (bit 2 for line 20): set when that line's first pixel was drawn.

   No line depends on the console's television type: the VI is switched off before anything is
   measured and the sound output is never used, and the CPU's clock and the RCP's are the same
   on every type. On a console the counters differ a little from run to run, because the waits
   for memory do.

   Care for the console: everything here is ordinary. Short lists of common commands, each ended
   by a full sync; rectangles, and one triangle with its major edge on the left; no fill-mode
   triangle, no 4-bit image, nothing the hardware notes warn of. */

#include "../cart-lib/say.h"

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_STATUS REG32(0xA410000Cu)
#define DP_CLOCK REG32(0xA4100010u)
#define DP_BUFBUSY REG32(0xA4100014u)
#define DP_PIPEBUSY REG32(0xA4100018u)
#define DP_TMEM REG32(0xA410001Cu)
#define MI_INTR REG32(0xA4300008u)
#define VI_CONTROL REG32(0xA4400000u)

#define IMAGE 0x00200000u                                   /* two megabytes up: nothing else is there */
#define LISTS 0x00280000u
#define WIDTH 320u
#define PIXEL(x, y) (*(volatile u32 *)(0xA0000000u + IMAGE + ((y) * WIDTH + (x)) * 4u))

static volatile u64 *list_at;
static u32 list_words;

static void list_begin(void) { list_at = (volatile u64 *)(0xA0000000u + LISTS); list_words = 0; }
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }

/* The commands used, each as its two 32-bit halves. Coordinates are whole pixels. */
static void set_image(void) { put(0x3F000000u | (0u << 21) | (3u << 19) | (WIDTH - 1u), IMAGE); }
static void set_scissor(void) { put(0x2D000000u, (WIDTH << 14) | (240u << 2)); }
static void set_modes(u32 cycle) { put(0x2F0000F0u | (cycle << 20), 0x00000000u); }     /* the cycle type; no dither, no antialiasing, no depth, image read off */
static void set_combine_env(void) { put(0x3C887F10u, 0x88FEFD7Eu); }       /* both cycles: the environment colour, alpha one */
static void set_env(u32 c) { put(0x3B000000u, c); }
static void set_fill(u32 c) { put(0x37000000u, c); }
static void set_prim(u32 c) { put(0x3A000000u, c); }
static void fill_rect(u32 x, u32 y, u32 w, u32 h, u32 inclusive) { put(0x36000000u | ((x + w - inclusive) << 14) | ((y + h - inclusive) << 2), (x << 14) | (y << 2)); }
static void full_sync(void) { put(0x29000000u, 0u); }

/* Runs the list in hand and leaves what was seen. */
struct seen { u32 s0, s1, ticks, buf, pipe, tmem, clock, buf_more, pipe_more; };
static void wait_ticks(u32 ticks) { const u32 from = count_now(); while (count_now() - from < ticks) { } }

static void start_list(void) {
    DP_STATUS = 0x0015u;                                    /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                      /* takes back the DP's interrupt */
    DP_START = LISTS;
    DP_STATUS = 0x03C0u;                                    /* clears the three busy counters and the clock */
    DP_END = LISTS + list_words * 8u;
}
static void end_list(void) {
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    MI_MODE = 0x0800u;
}
static void run_list(struct seen *v) {
    start_list();
    const u32 from = count_now();
    v->s0 = DP_STATUS;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    v->ticks = count_now() - from;
    v->s1 = DP_STATUS;
    v->buf = DP_BUFBUSY; v->pipe = DP_PIPEBUSY; v->tmem = DP_TMEM; v->clock = DP_CLOCK;
    wait_ticks(2000u);
    v->buf_more = DP_BUFBUSY - v->buf; v->pipe_more = DP_PIPEBUSY - v->pipe;
    MI_MODE = 0x0800u;
}
static void say_seen(const char *tag, const struct seen *v) {
    say_text(tag);
    say_hex(v->s0, 3); say_hex(v->s1, 3); say_hex(v->ticks, 6);
    say_hex(v->buf & 0xFFFFFFu, 6); say_hex(v->pipe & 0xFFFFFFu, 6); say_hex(v->tmem & 0xFFFFFFu, 6); say_hex(v->clock & 0xFFFFFFu, 6);
    say_hex(v->buf_more & 0xFFFFFFu, 6); say_hex(v->pipe_more & 0xFFFFFFu, 6);
    say_flush();
}
static void measure(const char *tag) {
    full_sync();
    static struct seen v;
    for (u32 run = 0; run < 2; run++) { run_list(&v); say_seen(tag, &v); }
}

/* The registers every later list relies on, set once and waited for. */
static void set_up(u32 cycle) {
    list_begin();
    set_image(); set_scissor(); set_modes(cycle); set_combine_env(); set_env(0xFFFFFFFFu); set_fill(0xFFFFFFFFu);
    full_sync();
    start_list(); end_list();
}

static const struct { u16 w, h; } SIZES[6] = { { 8, 1 }, { 8, 8 }, { 64, 1 }, { 64, 8 }, { 320, 8 }, { 320, 64 } };

static void rectangles(const char *letter, u32 cycle) {
    set_up(cycle);
    for (u32 i = 0; i < 6; i++) {
        char tag[3] = { letter[0], (char)('1' + i), 0 };
        list_begin();
        fill_rect(0, 8, SIZES[i].w, SIZES[i].h, cycle >= 2u ? 1u : 0u);    /* fill mode takes the last pixel in */
        measure(tag);
    }
}

static void triangle(void) {
    set_up(0);
    list_begin();
    /* A fill triangle with the major edge on the left: from (64, 16) straight down to (64, 80),
       the other corner at (128, 80). Edge coefficients are 16.16; y is in quarter lines. */
    put(0x08800000u | (80u << 2), ((80u << 2) << 16) | (16u << 2));       /* left major; YL, YM, YH */
    put(64u << 16, 0u);                                     /* XL and its slope: used below YM only */
    put(64u << 16, 0u);                                     /* XH: the major edge, upright */
    put(64u << 16, 1u << 16);                               /* XM: one pixel right for each line down */
    measure("G");
}

static void on_the_way(void) {
    static const u32 WAITS[4] = { 0u, 12000u, 24000u, 60000u };
    set_up(0);
    for (u32 i = 0; i < 4; i++) {
        PIXEL(0, 20) = 0u; PIXEL(0, 100) = 0u; PIXEL(0, 180) = 0u;
        list_begin();
        fill_rect(0, 0, 320, 200, 0);
        full_sync();
        start_list();
        wait_ticks(WAITS[i]);
        const u32 lines = (PIXEL(0, 20) ? 4u : 0u) | (PIXEL(0, 100) ? 2u : 0u) | (PIXEL(0, 180) ? 1u : 0u);
        end_list();
        say_text("H"); say_hex(WAITS[i], 6); say_hex(lines, 1); say_flush();
    }
}

void probe_main(void) {
    say_head("DPTIME");
    VI_CONTROL = 0u;                                        /* the VI off: it would take memory time, by the television type */
    set_up(0);
    list_begin(); measure("E");
    list_begin(); for (u32 i = 0; i < 16; i++) set_prim(0x01010101u * i); measure("N");
    list_begin(); put(0x27000000u, 0u); measure("P");
    list_begin(); put(0x28000000u, 0u); measure("T");
    list_begin(); put(0x26000000u, 0u); measure("L");
    rectangles("A", 0);
    rectangles("B", 1);
    rectangles("F", 3);
    triangle();
    on_the_way();
    say_tail("DPTIME");
}
