/* The fill span probe: a small test cartridge for a real console.

   The 8-bit fill probe (probes/fill-8) found that a console's fill into an 8-bit image does not
   write pixel by pixel: in 26 cases it wrote nothing, and once it wrote a byte past the run. One
   rule fits all its 296 lines, but two of its facts rest on one byte, and that probe saw only 32
   bytes and no span of three groups of eight. This probe asks the rule's open points:

     - the fill writes 64-bit words of memory under a byte mask, counted in groups of eight bytes
       by the pixels' places in the image (not by their addresses);
     - one group: one write from the first byte's lane to the last byte's, nothing if the bytes
       cross a word; two or more: a first write to the word's end and a last from the word's start;
     - what lies between, for three groups or more;
     - every byte written takes bit 0 of the fill colour's 16-bit half its address picks;
     - whether a fill into a 16-bit image off a multiple of eight bytes goes by the same rule.

   For each case the probe lays 64 bytes of main memory (0x5A, every hidden bit clear), has the
   RDP fill a run of pixels in fill mode into an image that begins 16 + a bytes into them, and
   prints the 64 bytes and their hidden bits, in two lines. A write outside the run shows.

   Lines:   S a x n w z t  w0 .. w7  h      and then      s a x n w z t  w8 .. w15  h
     a   the image begins 16 + a bytes into the 64 (a from 0 to 7)
     x   the first pixel filled, counted from the image's first
     n   how many pixels are filled, wrapping into the next line where the line ends
     w   the image's width in pixels
     z   the pixel's size: 1 for 8 bits, 2 for 16 bits, 4 for 32 bits
     t   1 if the wait for the full sync's interrupt ran out (never expected)
     w0 to w15   the sixteen words of memory
     h   their hidden bits, a hex digit a word, the first byte's in bit 3

   Cases: an 8-bit image 32 pixels wide, every a, x of 0, 1, 3, 5 and 7, n of 1, 7, 8, 9, 16, 17
   and 24 (280 cases); two-line runs into 8-bit images 12, 13 and 20 pixels wide, every a, from x
   0 and 1, n the width and seven more (48); a 16-bit image 16 pixels wide at a of 0, 2, 4 and 6,
   four runs each (16). Then a second set, of cases no rule was fitted to: the 8-bit image at every
   a, x of 2, 4 and 6, n of 2, 6, 10, 15 and 23 (120); two-line runs into images 9, 11 and 15 pixels
   wide, every a, from x 0 and 3, n the width and nine more (48); the 16-bit image at a of 2, 4 and
   6, four other runs each (12). Then a third set, of two things no console had been asked: a 32-bit
   image 8 pixels wide at a of 0, 2, 4 and 6, ten runs each, and two-line runs into one 3 pixels
   wide (48 cases); and the 16-bit image at the odd a of 1, 3, 5 and 7, four runs each (16). The
   fill colour is 0x21426385 throughout (four different bytes).

   No line depends on the console's television type: the VI is switched off and the sound output
   is never used.

   Care for the console: everything here is ordinary. Short lists of four common commands and up
   to two fill-mode rectangles, each list ended by a full sync, into 8-bit, 16-bit and 32-bit
   images, which games do; no fill-mode triangle, no 4-bit image. The memory interface's test mode is on for one
   read at a time, with the instruction cache filled first (hidden_of in probes/fill-8/start.S), as
   the 8-bit fill probe does it on a console. */

#include "../cart-lib/say.h"

u32 hidden_of(const volatile u32 *word);

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_STATUS REG32(0xA410000Cu)
#define MI_INTR REG32(0xA4300008u)
#define VI_CONTROL REG32(0xA4400000u)

#define AREA 0x00200000u                                    /* two megabytes up: nothing else is there */
#define LISTS 0x00280000u
#define U16(offset) (*(volatile u16 *)(0xA0000000u + AREA + (offset)))
#define U8(offset) (*(volatile u8 *)(0xA0000000u + AREA + (offset)))
#define U32(offset) (*(volatile u32 *)(0xA0000000u + AREA + (offset)))
#define BYTES 64u
#define COLOUR 0x21426385u

static volatile u64 *list_at;
static u32 list_words;
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }

/* 64 bytes of 0x5A, by the two writes a console is known for: a 16-bit store, then the word's
   second byte stored again alone. Every hidden bit is then clear. */
static void lay(void) { for (u32 i = 0; i < BYTES; i += 2) { U16(i) = 0x5A5Au; U8(i + 1) = 0x5Au; } }

/* One fill: an image `width` pixels wide of `size` bytes a pixel that begins `at` bytes into the
   area, and `n` pixels from pixel `x` on, wrapping into the next line where the line ends. Returns
   1 if the wait for the full sync ran out. */
static u32 fill(u32 at, u32 width, u32 size, u32 x, u32 n) {
    list_at = (volatile u64 *)(0xA0000000u + LISTS); list_words = 0;
    put(0x3F000000u | ((size == 1u ? 1u : size == 2u ? 2u : 3u) << 19) | (width - 1u), AREA + at);  /* the colour image */
    put(0x2D000000u, (width << 14) | (8u << 2));                                   /* the scissor: the whole image, eight lines */
    put(0x2F300000u, 0x00000000u);                                                 /* fill mode */
    put(0x37000000u, COLOUR);
    for (u32 left = n, p = x; left; ) {
        const u32 line = p / width, from = p % width, run = left < width - from ? left : width - from;
        put(0x36000000u | ((from + run - 1u) << 14) | (line << 2), (from << 14) | (line << 2));
        left -= run; p += run;
    }
    put(0x29000000u, 0u);                                                          /* full sync */
    DP_STATUS = 0x0015u;                                                           /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                                             /* takes back the DP's interrupt */
    DP_START = LISTS;
    DP_END = LISTS + list_words * 8u;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    MI_MODE = 0x0800u;
    return guard >= 20000000u ? 1u : 0u;
}

static void head(const char *tag, u32 a, u32 x, u32 n, u32 width, u32 size, u32 late) {
    say_text(tag); say_hex(a, 1); say_hex(x, 1); say_hex(n, 2); say_hex(width, 2); say_hex(size, 1); say_hex(late, 1);
}

static void one_case(u32 a, u32 width, u32 size, u32 x, u32 n) {
    lay();
    const u32 late = fill(16u + a, width, size, x, n);
    for (u32 half = 0; half < 2u; half++) {
        head(half ? "s" : "S", a, x, n, width, size, late);
        u32 hidden = 0;
        for (u32 i = half * 32u; i < half * 32u + 32u; i += 4) {
            say_hex(U32(i), 8);
            hidden = (hidden << 4) | (hidden_of((const volatile u32 *)(0xA0000000u + AREA + i)) & 15u);
        }
        say_hex(hidden, 8);
        say_flush();
    }
}

static const u8 STARTS[5] = { 0, 1, 3, 5, 7 };
static const u8 LENGTHS[7] = { 1, 7, 8, 9, 16, 17, 24 };
static const u8 WIDTHS[3] = { 13, 12, 20 };
static const u8 RUNS16[4][2] = { { 0, 4 }, { 1, 3 }, { 1, 8 }, { 3, 9 } };
static const u8 STARTS2[3] = { 2, 4, 6 };
static const u8 LENGTHS2[5] = { 2, 6, 10, 15, 23 };
static const u8 WIDTHS2[3] = { 9, 11, 15 };
static const u8 RUNS16B[4][2] = { { 0, 5 }, { 2, 6 }, { 1, 11 }, { 3, 12 } };
static const u8 RUNS32[10][2] = { { 0, 1 }, { 0, 2 }, { 1, 1 }, { 1, 2 }, { 0, 3 }, { 1, 3 }, { 2, 4 }, { 1, 5 }, { 0, 6 }, { 3, 2 } };

void probe_main(void) {
    say_head("FSPAN");
    VI_CONTROL = 0u;                                        /* the VI off: it would take memory time, by the television type */
    for (u32 a = 0; a < 8u; a++) for (u32 i = 0; i < 5u; i++) for (u32 k = 0; k < 7u; k++) one_case(a, 32, 1, STARTS[i], LENGTHS[k]);
    for (u32 w = 0; w < 3u; w++) for (u32 a = 0; a < 8u; a++) for (u32 x = 0; x < 2u; x++) one_case(a, WIDTHS[w], 1, x, WIDTHS[w] + 7u);
    for (u32 a = 0; a < 8u; a += 2u) for (u32 r = 0; r < 4u; r++) one_case(a, 16, 2, RUNS16[r][0], RUNS16[r][1]);
    for (u32 a = 0; a < 8u; a++) for (u32 i = 0; i < 3u; i++) for (u32 k = 0; k < 5u; k++) one_case(a, 32, 1, STARTS2[i], LENGTHS2[k]);
    for (u32 w = 0; w < 3u; w++) for (u32 a = 0; a < 8u; a++) for (u32 x = 0; x < 4u; x += 3u) one_case(a, WIDTHS2[w], 1, x, WIDTHS2[w] + 9u);
    for (u32 a = 2; a < 8u; a += 2u) for (u32 r = 0; r < 4u; r++) one_case(a, 16, 2, RUNS16B[r][0], RUNS16B[r][1]);
    /* The third set: a 32-bit image, and the 16-bit image at an odd address. */
    for (u32 a = 0; a < 8u; a += 2u) for (u32 i = 0; i < 10u; i++) one_case(a, 8, 4, RUNS32[i][0], RUNS32[i][1]);
    for (u32 a = 0; a < 8u; a += 2u) for (u32 x = 0; x < 2u; x++) one_case(a, 3, 4, x, 5);
    for (u32 a = 1; a < 8u; a += 2u) for (u32 i = 0; i < 4u; i++) one_case(a, 16, 2, RUNS16B[i][0], RUNS16B[i][1]);
    say_tail("FSPAN");
}
