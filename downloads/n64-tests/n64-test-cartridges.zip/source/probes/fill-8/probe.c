/* The 8-bit fill probe: a small test cartridge for a real console.

   What does the RDP write when it fills into an 8-bit colour image? The rule this core follows is
   read from a hardware wiki (each pixel takes the byte of the fill colour that the low two bits
   of the pixel's address pick), and the reference renderer does otherwise, so only a console can
   say. The hidden bits such a fill leaves are known from that renderer alone.

   For each case the probe lays 32 bytes of main memory (the value 0x5A with the lowest bit as
   the case says, so that every hidden bit is known), has the RDP fill a short run of pixels in
   fill mode into an 8-bit colour image, and prints those 32 bytes and their hidden bits. Each
   answer is a line of text through the debug text window a flash cartridge shows on the
   computer beside the console. Run on this core, the same lines show what the core does.

   A line:   tag  a  x  n  s  w0 .. w7  h
     a   the image begins this many bytes above an address that is a multiple of eight (0 to 3)
     x   the first pixel filled, counted from the image's first
     n   how many pixels are filled
     s   the hidden bits laid before the fill: 0 all clear, 1 all set
     w0 to w7   the eight words of memory from that multiple of eight
     h   their hidden bits, a hex digit a word, the first byte's in bit 3

   The lines:
     F   one line of pixels, the fill colour 0x21426385 (four different bytes, their lowest bits
         1, 0, 1, 1): every address a, every start x from 0 to 3, n of 1, 2, 3, 4, 5, 8 and 9
         pixels, over hidden bits laid clear and laid set
     T   the same colour over two lines of an image 13 pixels wide, so that the second line
         begins at another place of a group of four: 20 pixels from x 0 and from x 1, which run on
         into the second line
     C   three more colours, 4 pixels from x 1 at every address: all zero, all ones, and
         0x80FE017F
     E   the same four colours with every byte equal to their first (as games mostly use it)

   No line depends on the console's television type: the VI is not used, nor the sound output.

   Care for the console: everything here is ordinary. Short lists of four common commands, each
   ended by a full sync; fill-mode rectangles into an 8-bit image, which games do; no fill-mode
   triangle, no 4-bit image, nothing the hardware notes warn of. The memory interface's test
   mode is on for one read at a time, with the instruction cache filled first (hidden_of in
   start.S), as the RDP test set that found these bits does it. */

#include "../cart-lib/say.h"

u32 hidden_of(const volatile u32 *word);

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_STATUS REG32(0xA410000Cu)
#define MI_INTR REG32(0xA4300008u)

#define AREA 0x00200000u                                    /* two megabytes up: nothing else is there */
#define LISTS 0x00280000u
#define U16(offset) (*(volatile u16 *)(0xA0000000u + AREA + (offset)))
#define U8(offset) (*(volatile u8 *)(0xA0000000u + AREA + (offset)))
#define U32(offset) (*(volatile u32 *)(0xA0000000u + AREA + (offset)))
#define BYTES 32u

static volatile u64 *list_at;
static u32 list_words;
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }

/* 32 bytes of 0x5A or 0x5B, by the two writes a console is known for: a 16-bit store, then the
   word's second byte stored again alone. Every hidden bit is then the byte's lowest bit. */
static void lay(u32 set) { for (u32 i = 0; i < BYTES; i += 2) { U16(i) = (u16)(0x5A5Au | (set << 8) | set); U8(i + 1) = (u8)(0x5Au | set); } }

/* One fill: an 8-bit image `width` pixels wide that begins `a` bytes into the area, and `n` pixels
   from pixel `x` on, wrapping into the next line where the line ends. */
static void fill(u32 a, u32 width, u32 x, u32 n, u32 colour) {
    list_at = (volatile u64 *)(0xA0000000u + LISTS); list_words = 0;
    put(0x3F000000u | (1u << 19) | (width - 1u), AREA + a);                 /* the colour image: 8 bits a pixel */
    put(0x2D000000u, (width << 14) | (8u << 2));                            /* the scissor: the whole image, eight lines */
    put(0x2F300000u, 0x00000000u);                                          /* fill mode */
    put(0x37000000u, colour);
    for (u32 left = n, at = x; left; ) {
        const u32 line = at / width, from = at % width, run = left < width - from ? left : width - from;
        put(0x36000000u | ((from + run - 1u) << 14) | (line << 2), (from << 14) | (line << 2));
        left -= run; at += run;
    }
    put(0x29000000u, 0u);                                                   /* full sync */
    DP_STATUS = 0x0015u;                                                    /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                                      /* takes back the DP's interrupt */
    DP_START = LISTS;
    DP_END = LISTS + list_words * 8u;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    MI_MODE = 0x0800u;
}

static void one_case(const char *tag, u32 a, u32 width, u32 x, u32 n, u32 set, u32 colour) {
    lay(set);
    fill(a, width, x, n, colour);
    say_text(tag); say_hex(a, 1); say_hex(x, 1); say_hex(n, 2); say_hex(set, 1);
    for (u32 i = 0; i < BYTES; i += 4) say_hex(U32(i), 8);
    u32 hidden = 0;
    for (u32 i = 0; i < BYTES; i += 4) hidden = (hidden << 4) | (hidden_of((const volatile u32 *)(0xA0000000u + AREA + i)) & 15u);
    say_hex(hidden, 8);
    say_flush();
}

static const u8 LENGTHS[7] = { 1, 2, 3, 4, 5, 8, 9 };
static const u32 COLOURS[3] = { 0x00000000u, 0xFFFFFFFFu, 0x80FE017Fu };
#define COLOUR 0x21426385u

void probe_main(void) {
    say_head("F8PROBE");
    for (u32 set = 0; set < 2; set++) for (u32 a = 0; a < 4; a++) for (u32 x = 0; x < 4; x++) for (u32 k = 0; k < 7; k++)
        one_case("F", a, 16, x, LENGTHS[k], set, COLOUR);
    for (u32 set = 0; set < 2; set++) for (u32 a = 0; a < 4; a++) for (u32 x = 0; x < 2; x++)
        one_case("T", a, 13, x, 20, set, COLOUR);
    for (u32 c = 0; c < 3; c++) for (u32 set = 0; set < 2; set++) for (u32 a = 0; a < 4; a++)
        one_case("C", a, 16, 1, 4, set, COLOURS[c]);
    for (u32 c = 0; c < 4; c++) for (u32 set = 0; set < 2; set++) for (u32 a = 0; a < 4; a++) {
        const u32 first = (c ? COLOURS[c - 1] : COLOUR) >> 24;
        one_case("E", a, 16, 1, 4, set, first * 0x01010101u);
    }
    say_tail("F8PROBE");
}
