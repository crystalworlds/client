# The first instruction of the probe: a stack well below the top of the
# smallest memory a console has, then the C code. It never returns.
    .set noreorder
    .section .text.entry, "ax"
    .globl _start
_start:
    lui   $sp, 0x803F
    jal   probe_main
    addiu $sp, $sp, -32
1:  b     1b
    nop

# u32 hidden_of(const u32 *word): the four hidden bits of a 32-bit word of main memory, the first
# byte's in bit 3. The address must be an uncached one.
#
# The memory interface has a test mode in which a read of main memory gives the hidden bits of
# the word and not its data. While the mode is on that holds for every read of main memory, an
# instruction fetch too. So the routine first has the two lines of the instruction cache it lies
# in filled, and from the write that turns the mode on to the write that turns it off it reads
# nothing but the one word.
    .section .text, "ax"
    .globl hidden_of
    .balign 32
hidden_of:
    lui   $t0, %hi(hidden_of)
    addiu $t0, $t0, %lo(hidden_of)
    cache 0x14, 0($t0)              # fill these two lines of the instruction cache
    cache 0x14, 32($t0)
    lui   $t1, 0xA430               # the MI's mode register
    addiu $t2, $zero, 0x0400        # turns the test mode on
    addiu $t3, $zero, 0x0200        # turns it off
    sw    $t2, 0($t1)
    lw    $v0, 0($a0)
    sw    $t3, 0($t1)
    jr    $ra
    nop
