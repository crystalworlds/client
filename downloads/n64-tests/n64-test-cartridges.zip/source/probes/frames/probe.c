/* The frame film probe: a small test cartridge that draws a film of known frames with the RDP.

   A tool that records one frame of a running program (main memory as it stood before the frame's
   first command, and every command word up to its full sync) needs a program whose every frame
   is known in advance. This is that program. It asks nothing of a console; it is the known
   answer the frame recorder is held to.

   Frame n, counted from 0, is one list that stands by itself:
     the colour image (16 bits a pixel, 320 wide, two megabytes up), the scissor (320 by 240),
     fill mode, a fill colour that holds n, a rectangle over the whole image in that colour, the
     fill colour white, a rectangle of 32 by 16 pixels whose corner follows from n, a full sync.
   Before a frame's list is handed over, the probe writes n into the word of memory just below
   the image, straight to memory. So the memory a recorder took before frame n's first command
   holds n in that word, and frame n - 1 in the image.

   The colour of frame n: the 16-bit pixel (n << 1) | 1, taken modulo 32,768 frames.
   The corner of its small rectangle: x = 8 n modulo 256, y = 4 n modulo 200.

   The probe says one line when the film starts and one line after every 256 frames, so that a
   console's log shows it running. The film has no end.

   Care for the console: everything here is ordinary. Fill-mode rectangles into a 16-bit image,
   each list ended by a full sync, the VI left as the boot code left it. */

#include "../cart-lib/say.h"

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_STATUS REG32(0xA410000Cu)
#define MI_INTR REG32(0xA4300008u)

#define IMAGE 0x00200000u
#define MARK REG32(0xA0000000u + IMAGE - 4u)
#define LISTS 0x00280000u
#define WIDTH 320u
#define HEIGHT 240u

static volatile u64 *list_at;
static u32 list_words;

static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }
static void set_fill(u32 pixel) { put(0x37000000u, (pixel << 16) | pixel); }
/* A rectangle in fill mode takes its last pixel and its last line in. */
static void fill_rect(u32 x, u32 y, u32 w, u32 h) { put(0x36000000u | ((x + w - 1u) << 14) | ((y + h - 1u) << 2), (x << 14) | (y << 2)); }

static void frame(u32 n) {
    list_at = (volatile u64 *)(0xA0000000u + LISTS);
    list_words = 0;
    put(0x3F000000u | (2u << 19) | (WIDTH - 1u), IMAGE);        /* the colour image: 16 bits a pixel */
    put(0x2D000000u, (WIDTH << 14) | (HEIGHT << 2));            /* the scissor */
    put(0x2F3000F0u, 0x00000000u);                              /* fill mode */
    set_fill(((n << 1) | 1u) & 0xFFFFu);
    fill_rect(0, 0, WIDTH, HEIGHT);
    set_fill(0xFFFFu);
    fill_rect((n * 8u) % 256u, (n * 4u) % 200u, 32, 16);
    put(0x29000000u, 0u);                                       /* full sync */
    MARK = n;
    DP_STATUS = 0x0015u;                                        /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                          /* takes back the DP's interrupt */
    DP_START = LISTS;
    DP_END = LISTS + list_words * 8u;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    MI_MODE = 0x0800u;
}

void probe_main(void) {
    if (0) say_tail("FRAMES");                                  /* the film has no end: its last line is never said */
    say_head("FRAMES");
    for (u32 n = 0; ; n++) {
        frame(n);
        if ((n & 255u) == 255u) { say_text("FRAMES drawn"); say_hex(n + 1u, 8); say_flush(); }
    }
}
