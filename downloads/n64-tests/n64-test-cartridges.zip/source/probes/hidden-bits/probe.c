/* The hidden bits probe: a small test cartridge for a real console.

   Every byte of main memory has a ninth bit beside it. The RDP keeps a pixel's coverage in
   them and the VI reads it back. This probe asks what a write by anything else leaves in them,
   and how fast the DP's clock runs. Each answer is a line of text through the debug text window
   a flash cartridge shows on the computer beside the console. Run on this core, the same lines
   show what the core does.

   A hidden value is one hex digit for a 32-bit word: the hidden bits of its four bytes, the
   first byte's in bit 3. All values are in hex.

     H  16-bit stores: a word's two halves, each with its lowest bit clear or set (four ways)
     B  one byte stored alone: over hidden bits all clear, then all set; at each of a word's
        four places; with the byte's lowest bit clear, then set (sixteen ways)
     W  32-bit stores (four ways), then 64-bit stores (four ways, two digits each)
     L  stores through the data cache, a byte among them, then the line written back: the
        line's four words
     R  one store with the memory interface's repeat mode armed for 16 bytes: those four words
        and the next
     P  16 bytes brought from the cartridge by the PI: over hidden bits all clear, then all set;
        each time the four hidden values, then the four words brought
     S  the same from the RSP's data memory
     J  the same for the first 16 of the 64 bytes the SI brings from the PIF
     K  how far the DP's clock runs while COUNT steps at least 100,000 times: the clock's
        steps, then COUNT's

   Care for the console: the memory interface's test mode is on for one read at a time, with
   the instruction cache filled first (hidden_of in start.S), as the RDP test set that found
   these bits does it. Nothing else here is out of the ordinary: plain stores, one line of the
   data cache written back, the repeat mode a common library uses to clear memory, and three
   short transfers. */

#include "../cart-lib/say.h"

u32 hidden_of(const volatile u32 *word);

#define AREA 0x00200000u                                    /* two megabytes up: nothing else is there */
#define UNCACHED(offset) (0xA0000000u + AREA + (offset))
#define CACHED(offset) (0x80000000u + AREA + (offset))
#define U8(offset) (*(volatile u8 *)UNCACHED(offset))
#define U16(offset) (*(volatile u16 *)UNCACHED(offset))
#define U32(offset) (*(volatile u32 *)UNCACHED(offset))
#define U64(offset) (*(volatile u64 *)UNCACHED(offset))

#define SP_DATA_MEMORY ((volatile u32 *)0xA4000000u)
#define SP_MEM_ADDR REG32(0xA4040000u)
#define SP_DRAM_ADDR REG32(0xA4040004u)
#define SP_WR_LEN REG32(0xA404000Cu)
#define SP_DMA_BUSY REG32(0xA4040018u)
#define SI_DRAM_ADDR REG32(0xA4800000u)
#define SI_PIF_READ REG32(0xA4800004u)
#define SI_STATUS REG32(0xA4800018u)
#define DP_CLOCK REG32(0xA4100010u)

static void say_hidden(u32 offset, u32 words) { for (u32 i = 0; i < words; i++) say_hex(hidden_of((const volatile u32 *)UNCACHED(offset + i * 4)), 1); }

/* Sixteen bytes whose hidden bits are all clear or all set, by the two writes a console is known
   for: a 16-bit store of an even or an odd value, then the word's second byte stored again alone. */
static void lay(u32 offset, u32 set) { for (u32 i = 0; i < 16; i += 2) { U16(offset + i) = (u16)(0x0100u | set); U8(offset + i + 1) = (u8)set; } }

static void sixteen_bit_stores(void) {
    say_text("H");
    for (u32 way = 0; way < 4; way++) {
        U16(0) = (u16)(0x1234u | (way >> 1));
        U16(2) = (u16)(0x5678u | (way & 1u));
        say_hidden(0, 1);
    }
    say_flush();
}

static void byte_stores(void) {
    say_text("B");
    for (u32 set = 0; set < 2; set++) for (u32 place = 0; place < 4; place++) for (u32 low = 0; low < 2; low++) {
        lay(0x20, set);
        U8(0x20 + place) = (u8)(0x40u | low);
        say_hidden(0x20, 1);
    }
    say_flush();
}

static void wide_stores(void) {
    say_text("W");
    for (u32 way = 0; way < 4; way++) {
        lay(0x40, (way & 1u) ^ 1u);
        U32(0x40) = ((0x1234u | (way >> 1)) << 16) | 0x5678u | (way & 1u);
        say_hidden(0x40, 1);
    }
    for (u32 way = 0; way < 4; way++) {
        const u32 bits = way * 5u;                          /* 0000, 0101, 1010, 1111 */
        lay(0x60, (way & 1u) ^ 1u);
        U64(0x60) = ((u64)(0x1110u | (bits >> 3)) << 48) | ((u64)(0x2220u | ((bits >> 2) & 1u)) << 32) | ((u64)(0x3330u | ((bits >> 1) & 1u)) << 16) | (0x4440u | (bits & 1u));
        say_hidden(0x60, 2);
    }
    say_flush();
}

static void cache_line(void) {
    volatile u32 *line = (volatile u32 *)CACHED(0x100);
    lay(0x100, 1);
    line[0] = 0x11102220u;                                  /* the line is read into the cache, and changed there */
    line[1] = 0x33314444u;
    *(volatile u8 *)CACHED(0x109) = 0x54;
    __asm__ volatile("cache 0x19, 0(%0)" : : "r"(line));    /* written back to memory, if it is in the cache */
    say_text("L"); say_hidden(0x100, 4); say_flush();
}

static void repeat_mode(void) {
    lay(0x200, 1); lay(0x210, 1);
    MI_MODE = 0x0100u | 15u;                                /* armed, for 16 bytes */
    U32(0x200) = 0x11102221u;
    say_text("R"); say_hidden(0x200, 5); say_flush();
}

static void say_brought(const char *tag, u32 offset) { say_text(tag); say_hidden(offset, 4); for (u32 i = 0; i < 4; i++) say_hex(U32(offset + i * 4), 8); say_flush(); }

static void transfers(void) {
    for (u32 set = 0; set < 2; set++) {
        lay(0x300, set);
        bus_free();
        PI_DRAM_ADDR = AREA + 0x300u; PI_CART_ADDR = 0x10000000u; PI_WR_LEN = 15u;
        bus_free();
        say_brought("P", 0x300);
    }
    for (u32 set = 0; set < 2; set++) {
        lay(0x400, set);
        SP_DATA_MEMORY[0] = 0x11102221u; SP_DATA_MEMORY[1] = 0x33314440u; SP_DATA_MEMORY[2] = 0x55506661u; SP_DATA_MEMORY[3] = 0x77718880u;
        SP_MEM_ADDR = 0u; SP_DRAM_ADDR = AREA + 0x400u; SP_WR_LEN = 15u;
        while (SP_DMA_BUSY & 1u) { }
        say_brought("S", 0x400);
    }
    for (u32 set = 0; set < 2; set++) {
        for (u32 i = 0; i < 64; i += 16) lay(0x500 + i, set);
        SI_DRAM_ADDR = AREA + 0x500u; SI_PIF_READ = 0x1FC007C0u;
        while (SI_STATUS & 3u) { }
        SI_STATUS = 0u;                                     /* takes back the SI's interrupt */
        say_brought("J", 0x500);
    }
}

static void clock_rate(void) {
    const u32 count_from = count_now(), clock_from = DP_CLOCK;
    u32 count_to;
    do count_to = count_now(); while (count_to - count_from < 100000u);
    const u32 clock_to = DP_CLOCK;
    say_text("K"); say_hex((clock_to - clock_from) & 0xFFFFFFu, 6); say_hex(count_to - count_from, 6); say_flush();
}

void probe_main(void) {
    say_head("HBPROBE");
    sixteen_bit_stores();
    byte_stores();
    wide_stores();
    cache_line();
    repeat_mode();
    transfers();
    clock_rate();
    say_tail("HBPROBE");
}
