/* A probe is one flat block that the open boot code copies from the cartridge
   to 0x80000400 and jumps to. The boot code clears all of main memory first,
   so zero-filled data needs no bytes in the file. */
ENTRY(_start)
SECTIONS
{
  . = 0x80000400;
  .text : { KEEP(*(.text.entry)) *(.text .text.*) }
  .rodata : { *(.rodata .rodata.*) }
  .data : { *(.data .data.*) *(.sdata .sdata.*) *(.lit8) *(.lit4) }
  . = ALIGN(8);
  __bss_start = .;
  .bss : { *(.sbss .sbss.*) *(.scommon) *(.bss .bss.*) *(COMMON) }
  __bss_end = .;
  /DISCARD/ : { *(.reginfo) *(.MIPS.abiflags) *(.MIPS.options) *(.pdr) *(.comment) *(.gnu.attributes) *(.mdebug*) *(.note*) *(.eh_frame*) }
}
