/* The 4-bit load probe (../load-4/probe.c says what it asks), built so that a palette load is the
   first load from a 4-bit image the console is given. */
#define FIRST_OF_THE_SIX 10u
#include "../load-4/probe.c"
