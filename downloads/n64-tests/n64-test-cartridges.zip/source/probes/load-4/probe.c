/* The 4-bit load probe: a small test cartridge for a real console.

   What reaches texture memory when a load command is given while the texture image is set to
   4 bits a texel? The two public renderers this core is held against refuse the command (one
   stops, one passes it over), and no document says what a console does. So the probe gives such
   loads and reads texture memory back.

   Reading texture memory: the CPU cannot. The probe draws from it, in copy mode, with a tile
   of 16-bit texels, into a 16-bit colour image 64 pixels wide and 32 lines high, one line for
   each 16 words of 64 bits, and each line through a tile of its own that begins at those 16
   words, so that every line is the tile's first row. Copy mode writes a 16-bit texel as it is.
   The 2,048 pixels are then texture memory's 2,048 words of 16 bits in order.

   Before each load all of texture memory is laid with the word 0xEEEE, by a load of the usual
   kind from a 16-bit image. The texture image a case loads from is a stretch of main memory in
   which the 16-bit word number k holds 0x0100 + k: whatever turns up in texture memory says
   which bytes of the image it came from.

   Lines, each through the debug text window a flash cartridge shows on the computer beside the
   console. The id is the case's place in the list below, from 1.
     L id came              the load's list was run and ended by a full sync: whether the full
                            sync's interrupt came (1) or the wait ran out (0)
     B id status clock buf pipe tmem   the DP's status and its four counters after that list
                            (how long it was busy: a reading of the console's own time, held to
                            no figure)
     D id came              the read-out's list was run: whether its full sync came
     T id first count value step   a run of texture memory that is not the ground: `count` words
                            of 16 bits from word `first`, the first holding `value`, each later
                            one `step` more (16 bits, wrapping)
     N id runs words fold   how many runs, how many words not the ground, and a fold of all
                            2,048 words
     R came                 after a list whose full sync did not come: whether a plain list's does
   When a full sync does not come the probe says so and tries one plain list. If that one's does
   not come either the probe ends: the RDP has to be taken as hung, and nothing after it could
   be believed.

   The cases: first no load at all and loads of the usual kind, whose outcome is known (they hold
   the read-out and the pattern to what this core already does), then loads from a 4-bit image: a
   tile load, a block load, loads into tiles of other sizes, a palette load, and one whose
   corners and image width are odd.

   A console's RDP hangs on the first load from a 4-bit image it is given (three runs of this
   probe), so one run can ask about one such load only. The probe is therefore built three
   times: as it stands the tile load comes first of the six, and two small files beside it name
   another case to come first (FIRST_OF_THE_SIX: a block load, a palette load). The ids stay.

   No line depends on the console's television type: the VI is not used, nor the sound output.

   Care for the console: a load from a 4-bit image is what one game of the library does on its
   way to its first screens, so a console has run such a command many times. Should the RDP hang
   on one here, nothing is harmed: it draws nothing until the power is cycled, and the probe
   stops there. Nothing else here is unusual: short lists ended by a full sync, loads, copy-mode
   rectangles. */

#include "../cart-lib/say.h"

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_STATUS REG32(0xA410000Cu)
#define DP_CLOCK REG32(0xA4100010u)
#define DP_BUFBUSY REG32(0xA4100014u)
#define DP_PIPEBUSY REG32(0xA4100018u)
#define DP_TMEM REG32(0xA410001Cu)
#define MI_INTR REG32(0xA4300008u)

#define AREA 0x00200000u                                    /* two megabytes up: nothing else is there */
#define IMAGE AREA                                          /* 8,192 bytes of the pattern */
#define GROUND (AREA + 0x4000u)                             /* 4,096 bytes of the ground */
#define OUT (AREA + 0x8000u)                                /* the colour image of the read-out */
#define LISTS 0x00280000u
#define AT16(base, i) (*(volatile u16 *)(0xA0000000u + (base) + 2u * (i)))
#define GROUND_WORD 0xEEEEu
#define UNDRAWN 0x7777u
#define GUARD 4000000u

enum { FMT_RGBA = 0, FMT_YUV, FMT_CI, FMT_IA, FMT_I };
enum { BLOCK = 0, TILE, PALETTE, NO_LOAD };

static volatile u64 *list_at;
static u32 list_words;
static void begin(void) { list_at = (volatile u64 *)(0xA0000000u + LISTS); list_words = 0; }
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }

/* Runs the list in hand, which ends in a full sync. 1 when the full sync's interrupt came. */
static u32 run(void) {
    DP_STATUS = 0x03D5u;                                    /* not frozen, not flushing, commands from main memory, the four counters cleared */
    MI_MODE = 0x0800u;                                      /* takes back the DP's interrupt */
    DP_START = LISTS;
    DP_END = LISTS + list_words * 8u;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < GUARD) guard++;
    const u32 came = (MI_INTR & 0x20u) ? 1u : 0u;
    MI_MODE = 0x0800u;
    return came;
}

static void set_image(u32 format, u32 size, u32 width, u32 address) { put(0x3D000000u | (format << 21) | (size << 19) | (width - 1u), address); }
static void set_tile(u32 tile, u32 format, u32 size, u32 line, u32 tmem, u32 palette) { put(0x35000000u | (format << 21) | (size << 19) | (line << 9) | tmem, (tile << 24) | (palette << 20)); }

struct load_case {
    u8 image_format, image_size; u16 image_width, image_offset;
    u8 tile, tile_format, tile_size; u16 tile_line, tile_tmem;
    u8 kind; u16 sl, tl, sh, th;                            /* as the command carries them: 10.2 for a tile or a palette; for a block sh is the last texel and th the step of t */
};

static const struct load_case CASES[] = {
    { FMT_RGBA, 2, 64, 0,   0, FMT_RGBA, 2, 0, 0,     NO_LOAD, 0, 0, 0, 0 },                /* 1: no load: the ground alone */
    /* Loads of the usual kind. */
    { FMT_RGBA, 2, 32, 0,   0, FMT_RGBA, 2, 0, 0,     BLOCK, 0, 0, 127, 0x100 },            /* a block of 16-bit texels, four rows of 8 words */
    { FMT_I, 1, 32, 0,      0, FMT_I, 1, 4, 64,       TILE, 0, 0, 31 << 2, 3 << 2 },        /* a tile of 8-bit texels, four rows of 4 words */
    { FMT_RGBA, 2, 16, 0,   7, FMT_RGBA, 0, 0, 256,   PALETTE, 0, 0, 15 << 2, 0 },          /* a palette of 16 colours */
    { FMT_CI, 2, 1, 0,      7, FMT_CI, 2, 0, 0,       BLOCK, 0, 0, 255, 0x200 },            /* 4-bit texels loaded as a block the usual way, from an image said to be 16-bit */
    /* Loads from a 4-bit image. */
    { FMT_I, 0, 64, 0,      0, FMT_I, 0, 4, 0,        TILE, 0, 0, 63 << 2, 3 << 2 },        /* a tile of 4-bit texels, 64 by 4 */
    { FMT_CI, 0, 64, 0,     0, FMT_CI, 0, 0, 0,       BLOCK, 0, 0, 255, 0x200 },            /* a block of 256 texels into a 4-bit tile */
    { FMT_RGBA, 0, 64, 0,   0, FMT_RGBA, 2, 0, 0,     BLOCK, 0, 0, 127, 0x100 },            /* a block into a 16-bit tile */
    { FMT_I, 0, 64, 0,      0, FMT_I, 1, 8, 0,        TILE, 0, 0, 63 << 2, 3 << 2 },        /* a tile load into an 8-bit tile */
    { FMT_CI, 0, 16, 0,     7, FMT_RGBA, 0, 0, 256,   PALETTE, 0, 0, 15 << 2, 0 },          /* a palette load */
    { FMT_I, 0, 13, 0,      0, FMT_I, 0, 2, 32,       TILE, 5 << 2, 3 << 2, 36 << 2, 5 << 2 }, /* odd corners, an image 13 texels wide */
};
#define CASE_COUNT (sizeof CASES / sizeof CASES[0])
#ifndef FIRST_OF_THE_SIX
#define FIRST_OF_THE_SIX 6u                                 /* the id of the load from a 4-bit image that is given first */
#endif

/* Lays all of texture memory with the ground, then gives the case's load. */
static u32 load(const struct load_case *c) {
    begin();
    set_image(FMT_RGBA, 2, 64, GROUND);
    set_tile(1, FMT_RGBA, 2, 0, 0, 0);
    put(0x26000000u, 0u);                                                           /* load sync */
    put(0x33000000u, (1u << 24) | (2047u << 12));                                   /* a block of 2,048 texels along one row: every word of texture memory */
    put(0x28000000u, 0u);                                                           /* tile sync */
    set_image(c->image_format, c->image_size, c->image_width, IMAGE + c->image_offset);
    set_tile(c->tile, c->tile_format, c->tile_size, c->tile_line, c->tile_tmem, 0);
    put(0x26000000u, 0u);
    if (c->kind != NO_LOAD) put((c->kind == BLOCK ? 0x33000000u : c->kind == TILE ? 0x34000000u : 0x30000000u) | ((u32)c->sl << 12) | c->tl, ((u32)c->tile << 24) | ((u32)c->sh << 12) | c->th);
    put(0x28000000u, 0u);
    put(0x29000000u, 0u);                                                           /* full sync */
    return run();
}

/* Draws texture memory out, 16 words of 64 bits a line. */
static u32 read_out(void) {
    for (u32 i = 0; i < 2048u; i++) AT16(OUT, i) = UNDRAWN;
    begin();
    put(0x3F000000u | (FMT_RGBA << 21) | (2u << 19) | 63u, OUT);                    /* the colour image: 16 bits a pixel, 64 wide */
    put(0x2D000000u, (64u << 14) | (32u << 2));                                     /* the scissor: all of it */
    put(0x2F200000u, 0u);                                                           /* copy mode, nothing else switched on */
    for (u32 r = 0; r < 32u; r++) {
        set_tile(2, FMT_RGBA, 2, 16, 16u * r, 0);
        put(0x32000000u, (2u << 24) | ((63u << 2) << 12));                          /* the tile's corners: 0,0 to 63,0 */
        put(0x24000000u | ((63u << 2) << 12) | (r << 2), (2u << 24) | (r << 2));    /* a textured rectangle: line r, pixels 0 to 63 */
        put(0u, (0x1000u << 16) | 0x0400u);                                         /* from s 0, t 0; four texels a step, as copy mode takes them */
        put(0x27000000u, 0u);                                                       /* pipe sync: the next tile is for the next line */
    }
    put(0x29000000u, 0u);
    return run();
}

/* One case and its lines. 0 when a full sync did not come. */
static u32 say_case(u32 id, const struct load_case *c) {
    const u32 came = load(c);
    const u32 status = DP_STATUS, clock = DP_CLOCK, buf = DP_BUFBUSY, pipe = DP_PIPEBUSY, tmem = DP_TMEM;
    say_text("L"); say_hex(id, 2); say_hex(came, 1); say_flush();
    say_text("B"); say_hex(id, 2); say_hex(status, 4); say_hex(clock, 6); say_hex(buf, 6); say_hex(pipe, 6); say_hex(tmem, 6); say_flush();
    if (!came) return 0;
    const u32 drawn = read_out();
    say_text("D"); say_hex(id, 2); say_hex(drawn, 1); say_flush();
    if (!drawn) return 0;
    u32 runs = 0, words = 0, fold = 0x811C9DC5u;
    for (u32 i = 0; i < 2048u; i++) fold = (fold ^ AT16(OUT, i)) * 0x01000193u;
    for (u32 i = 0; i < 2048u; ) {
        const u32 v = AT16(OUT, i);
        if (v == GROUND_WORD) { i++; continue; }
        u32 n = 1, step = 0;
        if (i + 1u < 2048u && AT16(OUT, i + 1u) != GROUND_WORD) {
            step = (AT16(OUT, i + 1u) - v) & 0xFFFFu; n = 2;
            while (i + n < 2048u && AT16(OUT, i + n) != GROUND_WORD && ((AT16(OUT, i + n) - AT16(OUT, i + n - 1u)) & 0xFFFFu) == step) n++;
        }
        if (runs < 160u) { say_text("T"); say_hex(id, 2); say_hex(i, 3); say_hex(n, 3); say_hex(v, 4); say_hex(step, 4); say_flush(); }
        runs++; words += n; i += n;
    }
    say_text("N"); say_hex(id, 2); say_hex(runs, 3); say_hex(words, 3); say_hex(fold, 8); say_flush();
    return 1;
}

void probe_main(void) {
    say_head("LOAD4PROBE");
    for (u32 k = 0; k < 4096u; k++) AT16(IMAGE, k) = (u16)(0x0100u + k);
    for (u32 k = 0; k < 2048u; k++) AT16(GROUND, k) = GROUND_WORD;
    for (u32 k = 0; k < CASE_COUNT; k++) {
        /* The cases in their order, but for the one of the six that is asked to come first of them. */
        const u32 i = k < 5u ? k : k == 5u ? FIRST_OF_THE_SIX - 1u : k - 1u < FIRST_OF_THE_SIX - 1u ? k - 1u : k;
        if (say_case(i + 1u, &CASES[i])) continue;
        /* A full sync that did not come: one plain list, and the end if that one's does not come either. */
        begin(); put(0x29000000u, 0u);
        const u32 back = run();
        say_text("R"); say_hex(back, 1); say_flush();
        if (!back) break;
    }
    say_tail("LOAD4PROBE");
}
