/* The pad film probe: a small test cartridge that shows a film whose every frame is known, reads
   controller 1 as a game does, once for each field, and plays a tone while A is held.

   A page that shows a machine's picture and feeds it a controller needs a program whose picture
   and whose answer to every press are known in advance, and that is nobody's game. This is that
   program (the project's play page is held to it). It asks nothing of a console that a
   game does not ask.

   It ends the boot first, as every game does (a console's start-up chip holds a program that does
   not), sets the VI to the usual picture of the console's television type (320 by 240 pixels of 16
   bits, resampled to the screen's width and nothing more: no anti-aliasing, no gamma; with the
   resampling off too a console shows a picture this narrow wrongly), and then, once for each field:

     1. asks controller 1 for its state through the joybus: one exchange, command 1, four bytes back
        (the button word, then the stick's two counts);
     2. draws frame n, counted from 0, by plain stores:
          lines 16 to 23, all 320 pixels: the 16-bit pixel (n << 1) | 1, so every frame differs;
          lines 4 to 11: sixteen blocks of 12 by 8 pixels, the i-th from the left white when bit
          15 - i of the button word is set and grey when it is not;
          a white block of 16 by 16 pixels whose top left corner is at (152 + x, 112 - y) for the
          stick's counts x and y, kept between lines 32 and 223: where the stick is;
     3. when the state is not the one last printed, prints it: "PAD bbbb xx yy", in hexadecimal;
     4. while A is held, keeps the AI fed with a square wave of 64 frames to the cycle, an eighth of
        full level, the same on both sides: 1,024 frames at a time, queued behind the ones playing.
        The DAC rate setting is 1521, so on an NTSC console the tone is 499.8 Hz and on a PAL one
        509.8 Hz. With A let go nothing more is queued, and what was queued plays out.

   A field starts where the VI's line counter starts again. The picture is written through the
   uncached window, because the VI reads memory and not the CPU's data cache.

   A program on a console has no way to wait but to go round a loop. This one waits for the next
   field by looking at the VI's line counter, and between two looks it reads a word of the
   cartridge, which takes the bus a long while. So its wait is a few thousand instructions a field
   where a loop that reads nothing runs more than a million, and a machine that runs instructions
   slower than a console can still keep a console's pace on this program: which is what lets a
   page be tried at full speed, sound and all, before the core is fast enough for a game.

   Care for the console: everything here is ordinary. Nothing is written to a pak or to save memory;
   the tone's buffer does not end at an 8 KiB boundary of memory. */

#include "../si-lib/lib.h"

#define VI ((volatile u32 *)0xA4400000u)
#define TV_TYPE (*(volatile u32 *)0xA0000300u)
#define CARTRIDGE (*(volatile u32 *)0xB0000000u)
#define PICTURE 0x00200000u                 /* the third megabyte */
#define WIDTH 320u
#define HEIGHT 240u
#define PIXEL(x, y) (((volatile u16 *)(0xA0000000u + PICTURE))[(y) * WIDTH + (x)])

enum { CTRL, ORIGIN, VI_WIDTH, V_INTR, V_CURRENT, BURST, V_TOTAL, H_TOTAL, LEAP, H_VIDEO, V_VIDEO, V_BURST, X_SCALE, Y_SCALE };

/* The usual register values of each television type (0 PAL, 1 NTSC, 2 MPAL), as the VI's own probe has them. */
struct usual { u32 burst, v_total, h_total, leap, h_video, v_video, v_burst; };
static const struct usual usual[3] = {
    { 0x0404233Au, 625u, 0x00150C69u, 0x0C6F0C6Eu, 0x00800300u, 0x005F0239u, 0x0009026Bu },
    { 0x03E52239u, 525u, 0x00000C15u, 0x0C150C15u, 0x006C02ECu, 0x002501FFu, 0x000E0204u },
    { 0x04651E39u, 525u, 0x00000C12u, 0x0C190C19u, 0x006C02ECu, 0x002501FFu, 0x000E0204u },
};

#define AI_ADDR (*(volatile u32 *)0xA4500000u)
#define AI_LEN (*(volatile u32 *)0xA4500004u)
#define AI_CONTROL (*(volatile u32 *)0xA4500008u)
#define AI_STATUS (*(volatile u32 *)0xA450000Cu)
#define AI_DACRATE (*(volatile u32 *)0xA4500010u)
#define AI_BITRATE (*(volatile u32 *)0xA4500014u)
#define AI_FULL 0x80000001u
#define TONE 0x00300000u                    /* the fourth megabyte */
#define TONE_FRAMES 1024u
#define TONE_CYCLE 64u
#define TONE_LEVEL 4096

#define GROUND 0x0015u                      /* a dark blue */
#define GREY 0x4211u
#define WHITE 0xFFFFu

static void block(u32 x0, u32 y0, u32 w, u32 h, u16 pixel) {
    for (u32 y = y0; y < y0 + h; y++) for (u32 x = x0; x < x0 + w; x++) PIXEL(x, y) = pixel;
}

/* Waits for the line counter to start again: the next field has begun. A read of the cartridge
   between two looks makes the wait long in time and short in instructions. */
static void next_field(void) {
    u32 last = VI[V_CURRENT];
    for (u32 cap = 400000u; cap; cap--) { (void)CARTRIDGE; u32 now = VI[V_CURRENT]; if (now < last) return; last = now; }
}

/* Controller 1's state: the button word and the stick's counts, or 0 when nothing answers. */
static u32 controller(void) {
    frame_clear(0x00);
    block_out[0] = 1; block_out[1] = 4; block_out[2] = 0x01;
    block_out[3] = 0xFF; block_out[4] = 0xFF; block_out[5] = 0xFF; block_out[6] = 0xFF;
    block_out[7] = 0xFE;
    block_out[63] = 0x01;
    si_exchange();
    if (block_in[1] & 0xC0u) return 0xFFFFFFFFu;
    return ((u32)block_in[3] << 24) | ((u32)block_in[4] << 16) | ((u32)block_in[5] << 8) | block_in[6];
}

void probe_main(void) {
    lib_start();
    /* The end of the boot: the word 0x00000008 written over the PIF's last four bytes. */
    PIF_MEMORY[15] = 0x00000008u;
    while (SI_STATUS & 3u) { }
    SI_STATUS = 0;

    u32 tv = TV_TYPE & 3u;
    if (tv > 2u) tv = 1u;
    block(0, 0, WIDTH, HEIGHT, GROUND);
    const struct usual *u = &usual[tv];
    VI[CTRL] = 0;
    VI[ORIGIN] = PICTURE; VI[VI_WIDTH] = WIDTH; VI[V_INTR] = 0x3FFu; VI[BURST] = u->burst;
    VI[V_TOTAL] = u->v_total; VI[H_TOTAL] = u->h_total; VI[LEAP] = u->leap;
    VI[H_VIDEO] = u->h_video; VI[V_VIDEO] = u->v_video; VI[V_BURST] = u->v_burst; VI[X_SCALE] = 0x200u; VI[Y_SCALE] = 0x400u;
    VI[V_CURRENT] = 0;
    VI[CTRL] = 0x3202u;                      /* 16 bits a pixel, resampled only */

    /* The tone: whole cycles of a square wave, left and right the same, written straight to memory. */
    {
        volatile short *tone = (volatile short *)(0xA0000000u + TONE);
        for (u32 i = 0; i < TONE_FRAMES; i++) { short v = (short)((i % TONE_CYCLE) < TONE_CYCLE / 2u ? TONE_LEVEL : -TONE_LEVEL); tone[i * 2u] = v; tone[i * 2u + 1u] = v; }
    }
    AI_CONTROL = 1; AI_DACRATE = 1521u; AI_BITRATE = 15u; AI_STATUS = 0;

    put("PADFILM 2 TV "); put_hex(tv, 1); end_line();

    u32 n = 0, printed = 0xFFFFFFFEu, at_x = 152, at_y = 112;
    for (;;) {
        next_field();
        u32 state = controller();
        u32 buttons = state == 0xFFFFFFFFu ? 0 : state >> 16;
        int x = state == 0xFFFFFFFFu ? 0 : (signed char)(state >> 8), y = state == 0xFFFFFFFFu ? 0 : (signed char)state;

        block(0, 16, WIDTH, 8, (u16)((n << 1) | 1u));
        for (u32 i = 0; i < 16; i++) block(8 + 19 * i, 4, 12, 8, (buttons >> (15 - i)) & 1u ? WHITE : GREY);
        int top = 112 - y;
        if (top < 32) top = 32;
        if (top > 208) top = 208;
        block(at_x, at_y, 16, 16, GROUND);
        at_x = (u32)(152 + x); at_y = (u32)top;
        block(at_x, at_y, 16, 16, WHITE);

        if (buttons & 0x8000u) for (u32 k = 0; k < 2u && !(AI_STATUS & AI_FULL); k++) { AI_ADDR = TONE; AI_LEN = TONE_FRAMES * 4u; }

        if (state != printed) {
            printed = state;
            if (state == 0xFFFFFFFFu) put("PAD none");
            else { put("PAD "); put_hex(buttons, 4); put(" "); put_hex((u32)x & 0xFFu, 2); put(" "); put_hex((u32)y & 0xFFu, 2); }
            end_line();
        }
        n++;
    }
}
