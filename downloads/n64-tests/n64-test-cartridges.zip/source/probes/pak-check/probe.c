/* The pak check: a small test cartridge that reads the whole of the Controller Pak in the controller
   in port 1 and prints what it finds as verdicts and checksums, never the pak's own bytes.

   IT SENDS NO WRITE. The only commands it sends are the identity command (0x00) and the pak read
   command (0x02); no frame it builds holds any other command, and there is no routine in it that
   could send a pak write (0x03). Nothing a player has saved can change by running it.

   A Controller Pak is 32,768 bytes: 128 pages of 256 bytes, read as 1,024 blocks of 32. A block
   whose check code does not come right is read again, up to four times in all. The layout the
   verdicts hold the pak to (the n64brew wiki's pages on the Controller Pak and its file system,
   in our own words): page 0 holds the identity block at 0x20 and its copies at 0x60, 0x80 and 0xC0;
   in each, the first checksum is the sum of its first fourteen big-endian 16-bit words and the
   second is 0xFFF2 less the first. Page 1 is the index table and page 2 its copy: two bytes for
   each page, 1 the last page of a note, 3 a free page, 5 to 127 the next page of a note; its byte 1
   is the sum of its bytes 2 to 255, kept to eight bits. Pages 3 and 4 are the note table: 16 notes
   of 32 bytes, the start page in bytes 6 and 7, a note that is all zeros is not in use.

   Each line starts with a short name; every line is in the fold of the last line.

     I   the identity command, asked twice: the count byte and the status byte of each
     B   the reads: blocks read whole, blocks read again, blocks never whole, the count byte of the
         first read that did not come whole (00 if none)
     D   the identity block, one line for each of its four places (D0 at 0x20, D1 0x60, D2 0x80,
         D3 0xC0): the first checksum right (1) or not (0), the second right, the block the same as
         at 0x20, the device bit (bit 0 of byte 0x19), the bank count (byte 0x1A), and a checksum
         of the block
     T   the index tables: T0 the table and T1 its copy, each with its stored check right (1) or not,
         its reserved entries (pages 0 to 4) all zero, and how many of pages 5 to 127 are free (3),
         end a note (1), lead on (5 to 127) and hold anything else; T2 whether the two tables are
         the same, byte for byte
     N   the notes: N0 how many of the 16 are in use, and a mask of which; then for each note in
         use, its slot, whether its start page lies in 5 to 127, how many pages its chain through
         the index table holds, how it ends (1 at a page that ends a note, 2 at a free page, 3 at
         anything else, 4 on a page met twice), and a checksum of its pages in chain order
     F   the pages: pages free in the table, pages the notes' chains hold, pages neither free nor
         held by a note (lost), pages held by two notes
     G   a checksum of every page, eight to a line (G00 for pages 0 to 7 ... G0f for 120 to 127),
         so that two runs set side by side show any page that changed

   The checksums are this probe's own: FNV-1a of 32 bits over the bytes in order. */

#include "../si-lib/lib.h"

#define PAGES 128u
#define BLOCKS 1024u

static u8 pak[PAGES * 256u] __attribute__((aligned(16)));

/* Builds a frame with one exchange for port 1: the two counts, the bytes to send, room filled with
   0x55, the end mark, the command bit. Only the two commands below are ever given to it. */
static void build(const u8 *tx, u32 tx_len, u32 rx_len) {
    u32 at = 0;
    frame_clear(0x00);
    block_out[at++] = (u8)tx_len; block_out[at++] = (u8)rx_len;
    for (u32 i = 0; i < tx_len; i++) block_out[at++] = tx[i];
    for (u32 i = 0; i < rx_len; i++) block_out[at++] = 0x55;
    block_out[at] = 0xFE;
    block_out[63] = 0x01;
}

/* The five-bit check of a pak address, from the table. */
static u32 with_check(u32 addr) {
    static const u8 value[11] = { 0x15, 0x1F, 0x0B, 0x16, 0x19, 0x07, 0x0E, 0x1C, 0x0D, 0x1A, 0x01 };
    u32 check = 0;
    for (u32 bit = 5; bit < 16; bit++) if (addr & (1u << bit)) check ^= value[bit - 5];
    return (addr & 0xFFE0u) | check;
}

/* The check code of 32 bytes: an eight-bit cyclic code, polynomial 0x85, from zero. */
static u8 code_of(const u8 *data) {
    u32 c = 0;
    for (u32 i = 0; i < 32; i++) {
        c ^= data[i];
        for (u32 k = 0; k < 8; k++) c = (c & 0x80u) ? ((c << 1) ^ 0x85u) & 0xFFu : (c << 1) & 0xFFu;
    }
    return (u8)c;
}

static u32 fnv(const u8 *b, u32 n, u32 h) { for (u32 i = 0; i < n; i++) { h ^= b[i]; h *= 0x01000193u; } return h; }
#define FNV_START 0x811C9DC5u

/* The identity command (0x00). */
static void identity(u32 number) {
    static const u8 IDENTITY[1] = { 0x00 };
    build(IDENTITY, 1, 3);
    si_exchange();
    put("I"); put_hex(number, 1); put(" "); put_hex(block_in[1], 2); put(" "); put_hex((block_in[1] & 0x80u) ? 0xFFu : block_in[5], 2); end_line();
}

/* One pak read (0x02) of the block at addr. Returns 1 when the 32 bytes came with their right check
   code, and keeps them; the count byte is left in *count. */
static u32 pak_read(u32 addr, u8 *into, u32 *count) {
    u8 tx[3] = { 0x02, 0, 0 };
    u32 word = with_check(addr);
    tx[1] = (u8)(word >> 8); tx[2] = (u8)word;
    build(tx, 3, 33);
    si_exchange();
    *count = block_in[1];
    if (block_in[1] & 0xC0u) return 0;
    if (block_in[37] != code_of(block_in + 5)) return 0;
    for (u32 i = 0; i < 32; i++) into[i] = block_in[5 + i];
    return 1;
}

static u32 be16(const u8 *b) { return ((u32)b[0] << 8) | b[1]; }

void probe_main(void) {
    lib_start();
    put("PAKCHECK 1"); end_line();

    /* The program ends the boot, as every program must. */
    PIF_MEMORY[15] = 0x00000008u;
    si_idle();
    SI_STATUS = 0;

    identity(0);
    identity(1);

    /* The whole pak. */
    {
        u32 whole = 0, again = 0, never = 0, first_bad = 0;
        for (u32 b = 0; b < BLOCKS; b++) {
            u32 count = 0, ok = 0;
            for (u32 t = 0; t < 4u && !ok; t++) {
                ok = pak_read(b * 32u, pak + b * 32u, &count);
                if (!ok && !first_bad) first_bad = count | 0x100u;
                if (!ok && t == 0) again++;
            }
            if (ok) whole++; else { never++; for (u32 i = 0; i < 32; i++) pak[b * 32u + i] = 0; }
        }
        put("B "); put_hex(whole, 4); put(" "); put_hex(again, 4); put(" "); put_hex(never, 4); put(" "); put_hex(first_bad & 0xFFu, 2); end_line();
    }

    /* The identity block in its four places. */
    {
        static const u8 at[4] = { 0x20, 0x60, 0x80, 0xC0 };
        for (u32 c = 0; c < 4; c++) {
            const u8 *id = pak + at[c];
            u32 sum = 0;
            for (u32 i = 0; i < 28; i += 2) sum += be16(id + i);
            sum &= 0xFFFFu;
            u32 one = be16(id + 28) == sum, two = be16(id + 30) == ((0xFFF2u - sum) & 0xFFFFu), same = 1;
            for (u32 i = 0; i < 32; i++) if (id[i] != pak[0x20 + i]) same = 0;
            put("D"); put_hex(c, 1); put(" "); put_hex(one, 1); put(" "); put_hex(two, 1); put(" "); put_hex(same, 1);
            put(" "); put_hex(id[0x19] & 1u, 1); put(" "); put_hex(id[0x1A], 2); put(" "); put_hex(fnv(id, 32, FNV_START), 8); end_line();
        }
    }

    /* The index table and its copy. */
    for (u32 t = 0; t < 2; t++) {
        const u8 *tab = pak + (1u + t) * 256u;
        u32 sum = 0, reserved = 1, free = 0, ends = 0, links = 0, other = 0;
        for (u32 i = 2; i < 256; i++) sum += tab[i];
        for (u32 i = 0; i < 10; i++) if (i != 1 && tab[i]) reserved = 0;
        for (u32 p = 5; p < PAGES; p++) {
            u32 v = be16(tab + p * 2u);
            if (v == 3) free++; else if (v == 1) ends++; else if (v >= 5 && v < PAGES) links++; else other++;
        }
        put("T"); put_hex(t, 1); put(" "); put_hex(tab[1] == (sum & 0xFFu), 1); put(" "); put_hex(reserved, 1);
        put(" "); put_hex(free, 2); put(" "); put_hex(ends, 2); put(" "); put_hex(links, 2); put(" "); put_hex(other, 2); end_line();
    }
    {
        u32 same = 1;
        for (u32 i = 0; i < 256; i++) if (pak[256u + i] != pak[512u + i]) same = 0;
        put("T2 "); put_hex(same, 1); end_line();
    }

    /* The notes, followed through the index table. */
    {
        const u8 *tab = pak + 256u, *notes = pak + 3u * 256u;
        static u8 holder[PAGES];
        u32 used = 0, mask = 0, held = 0, twice = 0;
        for (u32 p = 0; p < PAGES; p++) holder[p] = 0;
        for (u32 n = 0; n < 16; n++) { for (u32 i = 0; i < 32; i++) if (notes[n * 32u + i]) { used++; mask |= 1u << n; break; } }
        put("N0 "); put_hex(used, 2); put(" "); put_hex(mask, 4); end_line();
        for (u32 n = 0; n < 16; n++) {
            if (!(mask & (1u << n))) continue;
            u32 start = be16(notes + n * 32u + 6), valid = start >= 5 && start < PAGES, pages = 0, end = 3;
            u32 h = FNV_START;
            if (valid) {
                static u8 seen[PAGES];
                for (u32 p = 0; p < PAGES; p++) seen[p] = 0;
                u32 page = start;
                for (;;) {
                    if (seen[page]) { end = 4; break; }
                    seen[page] = 1; pages++;
                    if (holder[page]) twice++; else { holder[page] = (u8)(n + 1); held++; }
                    h = fnv(pak + page * 256u, 256, h);
                    u32 v = be16(tab + page * 2u);
                    if (v == 1) { end = 1; break; }
                    if (v == 3) { end = 2; break; }
                    if (v < 5 || v >= PAGES) { end = 3; break; }
                    page = v;
                }
            }
            put("N"); put_hex(n + 1, 2); put(" "); put_hex(valid, 1); put(" "); put_hex(pages, 2); put(" "); put_hex(end, 1); put(" "); put_hex(h, 8); end_line();
        }
        u32 free = 0, lost = 0;
        for (u32 p = 5; p < PAGES; p++) {
            u32 v = be16(tab + p * 2u);
            if (v == 3) { free++; if (holder[p]) twice++; }
            else if (!holder[p]) lost++;
        }
        put("F "); put_hex(free, 2); put(" "); put_hex(held, 2); put(" "); put_hex(lost, 2); put(" "); put_hex(twice, 2); end_line();
    }

    /* Every page's checksum. */
    for (u32 line = 0; line < PAGES / 8u; line++) {
        put("G"); put_hex(line, 2);
        for (u32 p = line * 8u; p < line * 8u + 8u; p++) { put(" "); put_hex(fnv(pak + p * 256u, 256, FNV_START), 8); }
        end_line();
    }

    last_line("PAKCHECK");
}
