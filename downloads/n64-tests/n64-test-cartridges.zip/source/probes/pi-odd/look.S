# One look at the PI after a counted wait: the transfer is started, so many
# single-cycle instructions run, and the status is read once. No loop asks
# the PI anything, so what comes back does not hang on how long a turn of a
# waiting loop takes.
#
#   u32 look_after(u32 instructions, u32 length_less_one)
#
# The two address registers are set by the caller. `instructions` is 0 to
# 1023: how many instructions of the slide run between the store that starts
# the transfer and the read of the status.
    .set noreorder
    .text
    .globl look_after
look_after:
    lui   $t0, 0xA460
    lui   $t1, %hi(slide_end)
    addiu $t1, $t1, %lo(slide_end)
    sll   $t2, $a0, 2
    subu  $t1, $t1, $t2
    sw    $a1, 0x0C($t0)
    jr    $t1
    nop
    .rept 1023
    nop
    .endr
slide_end:
    lw    $v0, 0x10($t0)
    jr    $ra
    nop

# A reset after a counted wait: the transfer is started, a loop of three
# cycles runs so many turns, so many single-cycle instructions run, the PI
# is reset through its status register, and the bus address register is
# read at once.
#
#   u32 reset_after(u32 instructions, u32 length_less_one, u32 turns)
#
# The two address registers are set by the caller. `instructions` is 0 to
# 511: how many instructions of the slide run before the store that resets
# the PI. `turns` is how many turns the loop makes before the slide.
    .globl reset_after
reset_after:
    lui   $t0, 0xA460
    lui   $t1, %hi(reset_slide_end)
    addiu $t1, $t1, %lo(reset_slide_end)
    sll   $t2, $a0, 2
    subu  $t1, $t1, $t2
    addiu $t3, $zero, 1
    sw    $a1, 0x0C($t0)
    beqz  $a2, 2f
    nop
1:  addiu $a2, $a2, -1
    bnez  $a2, 1b
    nop
2:  jr    $t1
    nop
    .rept 511
    nop
    .endr
reset_slide_end:
    sw    $t3, 0x10($t0)
    lw    $v0, 0x04($t0)
    jr    $ra
    nop
