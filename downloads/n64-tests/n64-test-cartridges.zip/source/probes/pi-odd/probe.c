/* The PI's odd cases: a small test cartridge for a real console, run from a flash cartridge whose
   save memory is set to SRAM (the probe needs something on the cartridge bus that can be
   written). It overwrites the first 8 KiB of the save memory.

   The PI probe showed three things on a console that one case each could not explain: a short
   DMA out of memory from a misaligned address left the place's last bytes as they were, the bus
   address register read a value of its own after a reset during a DMA, and a DMA out of memory
   took longer than the same DMA into it. This probe asks each of them over a table of cases.

   All values are in hex.

   T  the eight timing registers as found

   M m l w f e s o r b g
      A DMA out of memory of l bytes, from a memory address m bytes past a doubleword, to the save
      memory; then the place is read back. Before it the place was made 0xEE and the PI's buffer
      was filled with 0x77 by a DMA of 128 such bytes to another place, so that a byte the PI
      sends from its buffer without having taken it from memory can be told from a byte it never
      sent. w: how many of the 512 bytes of the place are not what a transfer in order would
      leave (the l bytes, then 0xEE); f and e: the first and the last of them (all ones when
      none); s: how many of them hold 0x77; o: how many of them, inside the l bytes, still hold
      0xEE; r and b: how far the memory address and the bus address moved; g: what the length
      register reads.
   N d l w f e s o r b g
      The same from d bytes before the end of a 2 KiB row of memory.

   W l a b c
      Times, in steps of the CPU's counter (the least of 32 tries, as in the PI probe), of a DMA
      of l bytes with one timing for all three: a out of memory to the save memory, b out of
      memory to an address where nothing answers, c into memory from the save memory.

   E l a b c
      One look at the PI's status after a counted wait, with no loop that asks: a DMA of l bytes
      into memory is started, so many instructions of one CPU cycle each are run, and the status
      is read once. The wait is tried at every count from 0 to 1023. a, b, c: the least count at
      which the look found the transfer ended, with the start set one and two CPU cycles later
      for b and c (the two clocks stand three to two, so the three cover every way they can
      meet). A waiting loop sees the end late by up to one of its own turns, and where its looks
      fall hangs on how long a turn takes; this line does not.

   K n s a i r x y z
      A DMA of 4 KiB into memory is reset through the status register after a wait that grows
      with n. s: the status after the reset; a: bytes that had arrived; i: the PI's interrupt
      line; r: how far the memory address had moved; x, y, z: the bus address register read three
      times straight after the reset, as it reads.
   J n p q u v
      After the same reset: p the bus address register after a further wait; q the register read
      back after 0x10002468 is written to it; u the register after a second reset with nothing
      running; v the memory address register as it then reads, less the address of the
      memory the transfer filled (so that the word does not hang on where a build put it).
   K fe, K ff
      The same three reads after a reset that follows a DMA that had ended (fe), and after a
      reset with nothing begun since an address was written (ff); s, a, i and r read zero.

   X t p l a b c
      The times of line W again with another timing for the save memory's part of the bus: t the
      latch time written and p the pulse width written; the page size and the release stay as in
      W. If a DMA out of memory sends the address again for each block, its time beyond the same
      DMA into memory grows with the latch time; if the time is spent taking the bytes out of
      memory, it does not.
   K 03 to K 0f, J 03 to J 0f
      The reset of lines K 00 to K 02 at thirteen more moments of the transfer, the last of them
      after its end. They are printed after the lines of the probe's first build, so that those
      stand where a run of that build has them.

   EC l h a b n
      Line E's look made sixteen times over for a DMA of l bytes with the start set h CPU cycles
      later: a the least and b the greatest of the sixteen answers, n how many of them gave the
      least. If the end of a transfer itself moves, the sixteen differ.
   KR p a b x
      A reset after a counted wait, as line E waits: a DMA of 4 KiB into memory is started, so
      many single-cycle instructions run, the PI is reset through its status register, and the
      bus address register is read at once. The wait is tried at every count from 0 to 511, in
      two stretches p: 0 straight after the start, and 1 after a loop of 720 turns of three
      cycles first, which lies about the end of the transfer's first block. Each line is a run
      of counts, a to b, that gave the same word x. How many there are hangs on what the
      register reads.

   The fourth build's lines follow those, so that the others stand where a run of the third
   build has them:

   VF c o w v h
      The VI as the probe found it: its control register, origin, width, and the two registers
      that hold a field's and a line's length.
   EV v l e r c0 .. cf
      Where a DMA of l bytes into memory ends, with the picture in state v: 9 as the probe found
      it; 0 switched off (the VI's control register cleared, the usual line and field times of
      the console's television type set); 2 those times with nothing shown, so that no pixel is
      fetched from memory; 1 a 16-bit picture of 320 pixels a line shown from the third megabyte.
      e is the least wait at which any of sixteen scans as line EC's found the transfer over.
      Line E's look is then made 255 times at each of 128 waits, from 8 before e: a line holds
      sixteen waits, r the first of them less e (a signed byte), and c0 to cf how many of the 255
      looks at each still found the PI busy. If the end itself moves with what else uses
      memory, the counts differ with the picture.
   KT m g t n1 .. n6 np x1 x6 xp
      The bus address register after a reset during a DMA of 4 KiB into memory, the reset made
      after m turns of a waiting loop. The first read of the register is the 14th instruction after
      the store that resets, put off by g single-cycle instructions more and by t turns of a
      loop; then it is read five times more back to back, then once after 4,000 turns of a loop. All of it is done sixteen times: n1 to n6 and np say in how
      many of the sixteen each read gave a place on the bus (its upper half 0x1000), and x1, x6
      and xp are the words of the last time. If the register settles with time, a longer wait
      shows at the first read what the later reads show without one. */

#include "../cart-lib/say.h"

#define MI_INTR REG32(0xA4300008u)
#define DOM(n) REG32(0xA4600014u + (n) * 4u)
#define CART 0x10000000u
#define SAVE 0x08000000u
#define SOURCE (CART + 0x1000u)             /* this program's own first bytes on the cartridge: something known to read */
#define NOWHERE 0x0F000000u                 /* in the save memory's part of the bus, where no save memory of 128 KiB or less answers */
#define SCRATCH (SAVE + 0x1E00u)            /* where the DMA that fills the PI's buffer goes */

static u8 ram_a[0x1100] __attribute__((aligned(2048)));     /* on a 2 KiB row of memory, so that nothing printed depends on where the linker put it */
static u8 ram_b[0x1100] __attribute__((aligned(2048)));
#define A ((volatile u8 *)((u32)ram_a | 0xA0000000u))
#define B ((volatile u8 *)((u32)ram_b | 0xA0000000u))
#define PHYS(p) ((u32)(p) & 0x00FFFFFFu)

static void fill(volatile u8 *p, u32 n, u8 v) { for (u32 i = 0; i < n; i++) p[i] = v; }
/* A pattern with no byte of 0x77 or 0xEE in it. */
static void pattern(volatile u8 *p, u32 n, u32 seed) {
    for (u32 i = 0; i < n; i++) {
        seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5;
        u8 v = (u8)seed;
        p[i] = (v == 0x77u || v == 0xEEu) ? (u8)(v ^ 0x01u) : v;
    }
}

#define VI ((volatile u32 *)0xA4400000u)
#define TV_TYPE REG32(0xA0000300u)
/* The usual register values of each television standard, 0 PAL, 1 NTSC, 2 MPAL, as the probe of the
   VI's lines has them: burst, lines in a field, a line's length, the leap, and the picture's place. */
struct usual_vi { u32 burst, v_total, h_total, leap, h_video, v_video, v_burst; };
static const struct usual_vi usual_vi[3] = {
    { 0x0404233Au, 625u, 0x00150C69u, 0x0C6F0C6Eu, 0x00800300u, 0x005F0239u, 0x0009026Bu },
    { 0x03E52239u, 525u, 0x00000C15u, 0x0C150C15u, 0x006C02ECu, 0x002501FFu, 0x000E0204u },
    { 0x04651E39u, 525u, 0x00000C12u, 0x0C190C19u, 0x006C02ECu, 0x002501FFu, 0x000E0204u },
};
/* The picture: 0 off with the usual times set, 1 a picture shown from the third megabyte, 2 the
   usual times with nothing shown. Then a field or two go by before anything is measured. */
static void picture(u32 how) {
    const struct usual_vi *u = &usual_vi[TV_TYPE < 3u ? TV_TYPE : 1u];
    VI[0] = 0;
    VI[1] = 0x00200000u; VI[2] = 320u; VI[3] = 0x3FFu; VI[5] = u->burst; VI[6] = u->v_total; VI[7] = u->h_total; VI[8] = u->leap;
    VI[9] = how == 1u ? u->h_video : 0u; VI[10] = u->v_video; VI[11] = u->v_burst; VI[12] = 0x200u; VI[13] = 0x400u;
    VI[4] = 0;
    if (how) VI[0] = 0x3202u;
    for (volatile u32 spin = 0; spin < 400000; spin++) { }
}

u32 look_after(u32 instructions, u32 length_less_one);      /* look.S */
u32 reset_after(u32 instructions, u32 length_less_one, u32 turns);     /* look.S: the bus address register, read straight after the reset */

static void usual_timing(void) { DOM(0) = 0x40; DOM(1) = 0x12; DOM(2) = 0x07; DOM(3) = 0x03; }
static void save_timing(void) { DOM(4) = 0x05; DOM(5) = 0x0C; DOM(6) = 0x0D; DOM(7) = 0x02; }

static inline void shift_by(u32 cycles) {
    if (cycles & 1u) __asm__ volatile("nop");
    if (cycles & 2u) { __asm__ volatile("nop"); __asm__ volatile("nop"); }
    if (cycles & 4u) { __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); }
    if (cycles & 8u) for (u32 i = 0; i < 2; i++) { __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); }
    if (cycles & 16u) for (u32 i = 0; i < 4; i++) { __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); }
}

/* Starts a DMA and waits for its end. Returns the steps between the two clock readings. */
static u32 dma_shifted(volatile u32 *length_register, u32 ram, u32 bus, u32 bytes, u32 shift) {
    bus_free();
    PI_STATUS = 2u;
    PI_DRAM_ADDR = ram;
    PI_CART_ADDR = bus;
    shift_by(shift);
    *length_register = bytes - 1u;
    u32 t0 = count_now();
    while (PI_STATUS & 1u) { }
    u32 t1 = count_now();
    return t1 - t0;
}
static u32 dma(volatile u32 *length_register, u32 ram, u32 bus, u32 bytes) { return dma_shifted(length_register, ram, bus, bytes, 0); }
static u32 least_dma(volatile u32 *length_register, u32 ram, u32 bus, u32 bytes) {
    u32 least = 0xFFFFFFFFu;
    for (u32 i = 0; i < 33; i++) { u32 t = dma_shifted(length_register, ram, bus, bytes, i); if (i && t < least) least = t; }
    return least;
}

/* One transfer out of memory to the save memory, and what arrived there. */
static void out_case(const char *tag, u32 first_word, u32 ram_offset, u32 bytes) {
    fill(B, 0x200, 0xEE);
    (void)dma(&PI_RD_LEN, PHYS(B), SAVE, 0x200);                /* the place is made 0xEE */
    fill(B, 0x80, 0x77);
    (void)dma(&PI_RD_LEN, PHYS(B), SCRATCH, 0x80);              /* the PI's buffer is left full of 0x77 */
    PI_STATUS = 2u;
    (void)dma(&PI_RD_LEN, PHYS(A) + ram_offset, SAVE, bytes);
    u32 moved_ram = PI_DRAM_ADDR - (PHYS(A) + ram_offset), moved_bus = PI_CART_ADDR - SAVE, length = PI_RD_LEN;
    fill(B, 0x200, 0x11);
    (void)dma(&PI_WR_LEN, PHYS(B), SAVE, 0x200);
    u32 wrong = 0, first = 0xFFFFFFFFu, last = 0xFFFFFFFFu, stale = 0, old = 0;
    for (u32 i = 0; i < 0x200; i++) {
        u8 want = i < bytes ? A[ram_offset + i] : 0xEE, got = B[i];
        if (got == want) continue;
        if (!wrong) first = i;
        last = i; wrong++;
        if (got == 0x77u) stale++;
        if (got == 0xEEu && i < bytes) old++;
    }
    say_text(tag); say_hex(first_word, 2); say_hex(bytes, 4); say_hex(wrong, 4); say_hex(first, 8); say_hex(last, 8); say_hex(stale, 4); say_hex(old, 4);
    say_hex(moved_ram, 8); say_hex(moved_bus, 8); say_hex(length, 8); say_flush();
}

/* The three reads of the bus address register after a reset, and what follows. */
static void after_reset(u32 number, u32 status, u32 arrived, u32 line, u32 moved) {
    u32 x = PI_CART_ADDR, y = PI_CART_ADDR, z = PI_CART_ADDR;
    for (volatile u32 spin = 0; spin < 4000; spin++) { }
    u32 p = PI_CART_ADDR;
    PI_CART_ADDR = 0x10002468u;
    u32 q = PI_CART_ADDR;
    PI_STATUS = 1u;
    u32 u = PI_CART_ADDR, v = PI_DRAM_ADDR - PHYS(A);
    say_text("K"); say_hex(number, 2); say_hex(status, 2); say_hex(arrived, 8); say_hex(line, 2); say_hex(moved, 8); say_hex(x, 8); say_hex(y, 8); say_hex(z, 8); say_flush();
    say_text("J"); say_hex(number, 2); say_hex(p, 8); say_hex(q, 8); say_hex(u, 8); say_hex(v, 8); say_flush();
    PI_STATUS = 3u;
}

/* A DMA of 4 KiB into memory, reset through the status register after `wait` turns of a loop. */
static void reset_during(u32 n, u32 wait) {
    fill(A, 0x1000, 0x55);
    bus_free();
    PI_STATUS = 3u;
    PI_DRAM_ADDR = PHYS(A); PI_CART_ADDR = SOURCE; PI_WR_LEN = 0xFFFu;
    for (volatile u32 spin = 0; spin < wait; spin++) { }
    PI_STATUS = 1u;
    u32 status = PI_STATUS, ram = PI_DRAM_ADDR - PHYS(A), line = MI_INTR & 0x10u;
    u32 x = PI_CART_ADDR, y = PI_CART_ADDR, z = PI_CART_ADDR;
    for (volatile u32 spin = 0; spin < 4000; spin++) { }
    u32 p = PI_CART_ADDR;
    PI_CART_ADDR = 0x10002468u;
    u32 q = PI_CART_ADDR;
    PI_STATUS = 1u;
    u32 u = PI_CART_ADDR, v = PI_DRAM_ADDR - PHYS(A);
    u32 arrived = 0; for (u32 i = 0; i < 0x1000; i++) if (A[i] != 0x55) arrived++;
    say_text("K"); say_hex(n, 2); say_hex(status, 2); say_hex(arrived, 8); say_hex(line, 2); say_hex(ram, 8); say_hex(x, 8); say_hex(y, 8); say_hex(z, 8); say_flush();
    say_text("J"); say_hex(n, 2); say_hex(p, 8); say_hex(q, 8); say_hex(u, 8); say_hex(v, 8); say_flush();
    PI_STATUS = 3u;
}

/* Lines EV: where a DMA of `length` bytes into memory ends, by 255 looks at each of 128 waits. */
static void end_by_picture(u32 v, u32 length) {
    u32 low = 0xFFFFu;
    for (u32 scan = 0; scan < 16; scan++) {
        u32 least = 0xFFFFu;
        for (u32 wait = 1023; wait < 1024; wait--) {
            bus_free(); PI_STATUS = 2u; PI_DRAM_ADDR = PHYS(B); PI_CART_ADDR = SOURCE;
            u32 status = look_after(wait, length - 1u);
            if (!(status & 1u)) least = wait; else break;
        }
        if (least < low) low = least;
    }
    u32 first = low >= 8u ? low - 8u : 0u;
    for (u32 row = 0; row < 8; row++) {
        u8 busy[16];
        for (u32 k = 0; k < 16; k++) {
            u32 wait = first + row * 16u + k, n = 0;
            for (u32 t = 0; t < 255 && wait < 1024u; t++) {
                bus_free(); PI_STATUS = 2u; PI_DRAM_ADDR = PHYS(B); PI_CART_ADDR = SOURCE;
                if (look_after(wait, length - 1u) & 1u) n++;
            }
            busy[k] = (u8)n;
        }
        bus_free(); PI_STATUS = 2u;
        say_text("EV"); say_hex(v, 1); say_hex(length, 4); say_hex(low, 4); say_hex((first + row * 16u - low) & 0xFFu, 2);
        for (u32 k = 0; k < 16; k++) say_hex(busy[k], 2);
        say_flush();
    }
}

/* Lines KT: seven reads of the bus address register after a reset during a DMA, sixteen times over. */
static void reads_after_reset(u32 turns, u32 gap, u32 more, u32 say) {
    u32 places[7] = { 0, 0, 0, 0, 0, 0, 0 }, x[7] = { 0, 0, 0, 0, 0, 0, 0 };
    for (u32 again = 0; again < 16; again++) {
        bus_free(); PI_STATUS = 3u;
        PI_DRAM_ADDR = PHYS(A); PI_CART_ADDR = SOURCE; PI_WR_LEN = 0xFFFu;
        for (volatile u32 spin = 0; spin < turns; spin++) { }
        PI_STATUS = 1u;
        shift_by(gap);
        for (volatile u32 spin = 0; spin < more; spin++) { }
        x[0] = PI_CART_ADDR; x[1] = PI_CART_ADDR; x[2] = PI_CART_ADDR; x[3] = PI_CART_ADDR; x[4] = PI_CART_ADDR; x[5] = PI_CART_ADDR;
        for (volatile u32 spin = 0; spin < 4000; spin++) { }
        x[6] = PI_CART_ADDR;
        PI_STATUS = 3u;
        for (u32 i = 0; i < 7; i++) if ((x[i] >> 16) == 0x1000u) places[i]++;
    }
    if (!say) return;
    say_text("KT"); say_hex(turns, 4); say_hex(gap, 2); say_hex(more, 2);
    for (u32 i = 0; i < 7; i++) say_hex(places[i], 2);
    say_hex(x[0], 8); say_hex(x[5], 8); say_hex(x[6], 8); say_flush();
}

void probe_main(void) {
    say_head("PIODD");
    say_text("T"); for (u32 r = 0; r < 8; r++) say_hex(DOM(r), 2); say_flush();
    usual_timing();
    save_timing();
    pattern(A, 0x1100, 0xC0FFEE01u);

    /* Out of memory, by misalignment and length. */
    {
        static const u16 lengths[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 15, 16, 17, 18, 20, 22, 24, 26, 32, 40, 64, 118, 120, 122, 124, 126, 127, 128, 129, 130, 132, 134, 136, 200, 300 };
        for (u32 m = 0; m < 8; m += 2)
            for (u32 i = 0; i < sizeof lengths / sizeof lengths[0]; i++) out_case("M", m, 0x100u + m, lengths[i]);
    }
    /* Near the end of a 2 KiB row of memory. */
    {
        static const u16 before[] = { 100, 100, 100, 100, 102, 10, 10, 6 }, lengths[] = { 90, 100, 108, 200, 16, 16, 6, 16 };
        for (u32 i = 0; i < sizeof before / sizeof before[0]; i++) out_case("N", before[i], 0x800u - before[i], lengths[i]);
    }

    /* Times, with one timing for both parts of the bus. */
    {
        static const u16 lengths[] = { 8, 64, 128, 136, 256, 512, 1024 };
        DOM(4) = 0x40; DOM(5) = 0x12; DOM(6) = 0x07; DOM(7) = 0x03;
        for (u32 i = 0; i < sizeof lengths / sizeof lengths[0]; i++) {
            u32 out_save = least_dma(&PI_RD_LEN, PHYS(A), SAVE + 0x1000u, lengths[i]);
            u32 out_nowhere = least_dma(&PI_RD_LEN, PHYS(A), NOWHERE, lengths[i]);
            u32 in_save = least_dma(&PI_WR_LEN, PHYS(B), SAVE + 0x1000u, lengths[i]);
            say_text("W"); say_hex(lengths[i], 4); say_hex(out_save, 8); say_hex(out_nowhere, 8); say_hex(in_save, 8); say_flush();
        }
        save_timing();
    }

    /* When a transfer ends, by one look after a counted wait. */
    {
        static const u16 lengths[] = { 8, 16, 32 };
        usual_timing();
        (void)look_after(1023, 7);                              /* once, so that the slide is in the cache */
        bus_free(); PI_STATUS = 2u;
        for (u32 i = 0; i < sizeof lengths / sizeof lengths[0]; i++) {
            u32 least[3];
            for (u32 shift = 0; shift < 3; shift++) {
                least[shift] = 0xFFFFu;
                for (u32 wait = 1023; wait < 1024; wait--) {
                    bus_free();
                    PI_STATUS = 2u;
                    PI_DRAM_ADDR = PHYS(B);
                    PI_CART_ADDR = SOURCE;
                    shift_by(shift);
                    u32 status = look_after(wait, lengths[i] - 1u);
                    if (!(status & 1u)) least[shift] = wait; else break;
                }
            }
            bus_free(); PI_STATUS = 2u;
            say_text("E"); say_hex(lengths[i], 4); say_hex(least[0], 4); say_hex(least[1], 4); say_hex(least[2], 4); say_flush();
        }
        save_timing();
    }

    /* A reset through the status register while a transfer runs, at three moments. */
    {
        static const u16 wait[3] = { 300, 1000, 2000 };
        for (u32 n = 0; n < 3; n++) {
            fill(A, 0x1000, 0x55);
            bus_free();
            PI_STATUS = 3u;
            PI_DRAM_ADDR = PHYS(A); PI_CART_ADDR = SOURCE; PI_WR_LEN = 0xFFFu;
            for (volatile u32 spin = 0; spin < wait[n]; spin++) { }
            PI_STATUS = 1u;
            u32 status = PI_STATUS, ram = PI_DRAM_ADDR - PHYS(A), line = MI_INTR & 0x10u;
            /* The count of what arrived is taken after the reads that must come straight after the reset. */
            u32 x = PI_CART_ADDR, y = PI_CART_ADDR, z = PI_CART_ADDR;
            for (volatile u32 spin = 0; spin < 4000; spin++) { }
            u32 p = PI_CART_ADDR;
            PI_CART_ADDR = 0x10002468u;
            u32 q = PI_CART_ADDR;
            PI_STATUS = 1u;
            u32 u = PI_CART_ADDR, v = PI_DRAM_ADDR - PHYS(A);
            u32 arrived = 0; for (u32 i = 0; i < 0x1000; i++) if (A[i] != 0x55) arrived++;
            say_text("K"); say_hex(n, 2); say_hex(status, 2); say_hex(arrived, 8); say_hex(line, 2); say_hex(ram, 8); say_hex(x, 8); say_hex(y, 8); say_hex(z, 8); say_flush();
            say_text("J"); say_hex(n, 2); say_hex(p, 8); say_hex(q, 8); say_hex(u, 8); say_hex(v, 8); say_flush();
            PI_STATUS = 3u;
        }
        /* After a transfer that ended by itself. */
        (void)dma(&PI_WR_LEN, PHYS(A), SOURCE, 0x100);
        PI_STATUS = 1u;
        after_reset(0xFE, 0, 0, 0, 0);
        /* With nothing begun since an address was written. */
        bus_free();
        PI_CART_ADDR = 0x10001234u;
        PI_STATUS = 1u;
        after_reset(0xFF, 0, 0, 0, 0);
    }

    /* The times of line W at two more latch times and at a second pulse width. */
    {
        static const u16 lengths[] = { 8, 64, 128, 136, 256, 512, 1024 };
        static const u8 timing[3][2] = { { 0x10, 0x12 }, { 0x80, 0x12 }, { 0x40, 0x24 } };
        for (u32 k = 0; k < 3; k++) {
            DOM(4) = timing[k][0]; DOM(5) = timing[k][1]; DOM(6) = 0x07; DOM(7) = 0x03;
            for (u32 i = 0; i < sizeof lengths / sizeof lengths[0]; i++) {
                u32 out_save = least_dma(&PI_RD_LEN, PHYS(A), SAVE + 0x1000u, lengths[i]);
                u32 out_nowhere = least_dma(&PI_RD_LEN, PHYS(A), NOWHERE, lengths[i]);
                u32 in_save = least_dma(&PI_WR_LEN, PHYS(B), SAVE + 0x1000u, lengths[i]);
                say_text("X"); say_hex(timing[k][0], 2); say_hex(timing[k][1], 2); say_hex(lengths[i], 4); say_hex(out_save, 8); say_hex(out_nowhere, 8); say_hex(in_save, 8); say_flush();
            }
        }
        save_timing();
    }

    /* The reset during a transfer at thirteen more moments. */
    {
        static const u16 wait[13] = { 60, 150, 450, 600, 1500, 2600, 3300, 4500, 6000, 7000, 7700, 7900, 8200 };
        for (u32 n = 0; n < 13; n++) reset_during(3u + n, wait[n]);
    }

    /* Line E's look, sixteen times over for each length and each start. */
    {
        static const u16 lengths[] = { 8, 16, 32 };
        usual_timing();
        for (u32 i = 0; i < sizeof lengths / sizeof lengths[0]; i++)
            for (u32 shift = 0; shift < 3; shift++) {
                u32 low = 0xFFFFu, high = 0, at_low = 0;
                for (u32 scan = 0; scan < 16; scan++) {
                    u32 least = 0xFFFFu;
                    for (u32 wait = 1023; wait < 1024; wait--) {
                        bus_free();
                        PI_STATUS = 2u;
                        PI_DRAM_ADDR = PHYS(B);
                        PI_CART_ADDR = SOURCE;
                        shift_by(shift);
                        u32 status = look_after(wait, lengths[i] - 1u);
                        if (!(status & 1u)) least = wait; else break;
                    }
                    if (least < low) { low = least; at_low = 1; } else if (least == low) at_low++;
                    if (least > high) high = least;
                }
                bus_free(); PI_STATUS = 2u;
                say_text("EC"); say_hex(lengths[i], 4); say_hex(shift, 1); say_hex(low, 4); say_hex(high, 4); say_hex(at_low, 2); say_flush();
            }
        save_timing();
    }

    /* A reset after a counted wait, at every count of two stretches of a transfer. */
    {
        static const u16 turns[2] = { 0, 720 };
        usual_timing();
        bus_free();
        PI_STATUS = 3u;
        PI_DRAM_ADDR = PHYS(A); PI_CART_ADDR = SOURCE;
        (void)reset_after(511, 0xFFFu, 0);                      /* once, so that the slide is in the cache */
        for (u32 part = 0; part < 2; part++) {
            u32 first = 0, word = 0;
            for (u32 n = 0; n < 512; n++) {
                bus_free();
                PI_STATUS = 3u;
                PI_DRAM_ADDR = PHYS(A); PI_CART_ADDR = SOURCE;
                u32 w = reset_after(n, 0xFFFu, turns[part]);
                if (n == 0) word = w;
                else if (w != word) {
                    say_text("KR"); say_hex(part, 1); say_hex(first, 4); say_hex(n - 1u, 4); say_hex(word, 8); say_flush();
                    first = n; word = w;
                }
            }
            say_text("KR"); say_hex(part, 1); say_hex(first, 4); say_hex(511, 4); say_hex(word, 8); say_flush();
            PI_STATUS = 3u;
        }
        save_timing();
    }

    /* The fourth build's lines. The VI as found, then where a transfer ends with the picture as
       found, off, timed with nothing shown, and shown; the picture is left off. */
    {
        static const u16 lengths[] = { 8, 32 };
        static const u8 states[] = { 9, 0, 2, 1 };
        say_text("VF"); say_hex(VI[0], 8); say_hex(VI[1], 8); say_hex(VI[2], 8); say_hex(VI[6], 8); say_hex(VI[7], 8); say_flush();
        usual_timing();
        for (u32 v = 0; v < sizeof states; v++) {
            if (states[v] != 9u) picture(states[v]);
            (void)look_after(1023, 7);
            for (u32 i = 0; i < sizeof lengths / sizeof lengths[0]; i++) end_by_picture(states[v], lengths[i]);
        }
        picture(0);
        save_timing();
    }

    /* The bus address register after a reset: by how long after it the first read comes. */
    {
        static const u16 moments[] = { 150, 600, 1500 };
        static const u8 waits[][2] = { { 0, 0 }, { 1, 0 }, { 2, 0 }, { 4, 0 }, { 8, 0 }, { 16, 0 }, { 31, 0 }, { 0, 8 }, { 0, 32 }, { 0, 128 } };
        usual_timing();
        reads_after_reset(150, 0, 0, 0);                        /* once unsaid, so that its code is in the cache */
        for (u32 m = 0; m < sizeof moments / sizeof moments[0]; m++)
            for (u32 w = 0; w < sizeof waits / sizeof waits[0]; w++) reads_after_reset(moments[m], waits[w][0], waits[w][1], 1);
        save_timing();
    }

    say_tail("PIODD");
}
