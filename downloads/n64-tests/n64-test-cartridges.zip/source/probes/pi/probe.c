/* The PI probe: a small test cartridge for a real console, run from a flash cartridge whose save
   memory is set to SRAM (the probe needs something on the cartridge bus that can be written).

   It asks the console the things about the PI that no test set here answers: how a DMA from
   memory to the cartridge bus behaves, how the time of a transfer follows the timing registers,
   what a busy PI does with a second transfer, what its two address registers show while a
   transfer runs, and which timing the disk drive's registers use. It overwrites the first 4 KiB
   of the save memory.

   Times are in ticks of the CPU's clock register (one tick is two CPU cycles), measured by
   reading the clock, starting the thing, asking the PI in a loop whether it is busy, and reading
   the clock again. Each time printed is the least of 32 tries, each begun one CPU cycle later
   than the one before, so that the least depends neither on where the program happened to stand
   against the RCP's clock nor on where the loop's looks happened to fall. One more try comes
   first and is not counted: the first time through, the measuring instructions themselves are
   fetched into the cache, inside the time being measured.

   T   the eight timing registers as found
   R   which read, its time: 01 the game file, 02 the save memory window, 05 the disk drive's
       registers with the first timing fast and the second slow, 06 the same the other way round
   WT  time until the PI is no longer busy after the CPU's own write to the game file's addresses
   D   bytes, time of a DMA into memory with the usual timing
   DT  latch, pulse, release, page size, time of a DMA of 256 bytes into memory with that timing
   O   case, bytes that arrived wrong, then the first two words at the place written, how far the
       memory address and the bus address moved, and what the length register reads:
       00 64 bytes  01 5 bytes  02 16 bytes from a memory address 2 past a doubleword
       03 300 bytes from such an address  04 200 bytes from 100 before the end of a 2 KiB row of memory
   OT  time of a DMA out of memory of 64 bytes and of 512, and of the same two into memory
   L   during a DMA of 4 KiB into memory: the status, how far the bus address and the memory
       address have got (four samples, a few hundred cycles apart)
   E   a second transfer started during the first: the status just after, the status at the end,
       bytes the second one put in its own target, bytes of the first that are wrong, and where
       the two address registers stand
   X   during a DMA: the word the CPU read from the game file, the word it should be, and the save
       memory word the CPU tried to write (read afterwards)
   K   a reset through the status register during a DMA: the status after, the bytes that had
       arrived, the PI's interrupt line, and how far the two address registers had got
   Z   a DMA from where nothing answers, across a page of the bus: four words */

#include "../cart-lib/say.h"

#define MI_INTR REG32(0xA4300008u)
#define DOM(n) REG32(0xA4600014u + (n) * 4u)
#define CART 0x10000000u
#define SAVE 0x08000000u
#define SOURCE (CART + 0x1000u)             /* this program's own first bytes on the cartridge: something known to read */

static u8 ram_a[0x1100] __attribute__((aligned(2048)));     /* on a 2 KiB row of memory, so that nothing printed depends on where the linker put it */
static u8 ram_b[0x1100] __attribute__((aligned(2048)));
#define A ((volatile u8 *)((u32)ram_a | 0xA0000000u))
#define B ((volatile u8 *)((u32)ram_b | 0xA0000000u))
#define PHYS(p) ((u32)(p) & 0x00FFFFFFu)

static u32 word_at(volatile u8 *p) { return ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3]; }
static void fill(volatile u8 *p, u32 n, u8 v) { for (u32 i = 0; i < n; i++) p[i] = v; }
static void pattern(volatile u8 *p, u32 n, u32 seed) { for (u32 i = 0; i < n; i++) { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; p[i] = (u8)seed; } }

static void usual_timing(void) { DOM(0) = 0x40; DOM(1) = 0x12; DOM(2) = 0x07; DOM(3) = 0x03; }
static void save_timing(void) { DOM(4) = 0x05; DOM(5) = 0x0C; DOM(6) = 0x0D; DOM(7) = 0x02; }

/* Lets 0 to 31 CPU cycles pass, by the low five bits of the try's number. */
static inline void shift_by(u32 cycles) {
    if (cycles & 1u) __asm__ volatile("nop");
    if (cycles & 2u) { __asm__ volatile("nop"); __asm__ volatile("nop"); }
    if (cycles & 4u) { __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); }
    if (cycles & 8u) for (u32 i = 0; i < 2; i++) { __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); }
    if (cycles & 16u) for (u32 i = 0; i < 4; i++) { __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); __asm__ volatile("nop"); }
}

/* Starts a DMA and waits for its end. Returns the ticks between the two clock readings. */
static u32 dma_shifted(volatile u32 *length_register, u32 ram, u32 bus, u32 bytes, u32 shift) {
    bus_free();
    PI_STATUS = 2u;
    PI_DRAM_ADDR = ram;
    PI_CART_ADDR = bus;
    shift_by(shift);
    *length_register = bytes - 1u;
    u32 t0 = count_now();
    while (PI_STATUS & 1u) { }
    u32 t1 = count_now();
    return t1 - t0;
}
static u32 dma(volatile u32 *length_register, u32 ram, u32 bus, u32 bytes) { return dma_shifted(length_register, ram, bus, bytes, 0); }
static u32 least_dma(volatile u32 *length_register, u32 ram, u32 bus, u32 bytes) {
    u32 least = 0xFFFFFFFFu;
    for (u32 i = 0; i < 33; i++) { u32 t = dma_shifted(length_register, ram, bus, bytes, i); if (i && t < least) least = t; }
    return least;
}
static u32 least_read(u32 address) {
    u32 least = 0xFFFFFFFFu;
    for (u32 i = 0; i < 33; i++) {
        bus_free();
        shift_by(i);
        u32 t0 = count_now();
        (void)REG32(0xA0000000u | address);
        u32 t = count_now() - t0;
        if (i && t < least) least = t;
    }
    return least;
}

/* One transfer out of memory to the save memory, then what arrived there, read back by a DMA the other way. */
static void out_case(u32 number, u32 ram_offset, u32 bytes, u32 save_offset) {
    fill(B, 0x400, 0xEE);
    (void)dma(&PI_RD_LEN, PHYS(B), SAVE + save_offset, 0x200);         /* the place is made 0xEE first */
    pattern(A, 0x1000, 0xC0FFEE00u + number);
    PI_STATUS = 2u;
    (void)dma(&PI_RD_LEN, PHYS(A) + ram_offset, SAVE + save_offset, bytes);
    u32 moved_ram = PI_DRAM_ADDR - (PHYS(A) + ram_offset), moved_bus = PI_CART_ADDR - (SAVE + save_offset), length = PI_RD_LEN;
    fill(B, 0x400, 0x11);
    (void)dma(&PI_WR_LEN, PHYS(B), SAVE + save_offset, 0x200);
    u32 wrong = 0;
    for (u32 i = 0; i < 0x200; i++) { u8 want = i < bytes ? A[ram_offset + i] : 0xEE; if (B[i] != want) wrong++; }
    u32 last = bytes & ~3u;
    say_text("O"); say_hex(number, 2); say_hex(wrong, 8); say_hex(word_at(B), 8); say_hex(word_at(B + last), 8);
    say_hex(moved_ram, 8); say_hex(moved_bus, 8); say_hex(length, 8); say_flush();
}

void probe_main(void) {
    say_head("PIPROBE");
    say_text("T"); for (u32 r = 0; r < 8; r++) say_hex(DOM(r), 2); say_flush();
    usual_timing();

    /* The CPU's own reads. */
    say_text("R"); say_hex(1, 2); say_hex(least_read(SOURCE), 8); say_flush();
    say_text("R"); say_hex(2, 2); say_hex(least_read(SAVE), 8); say_flush();
    DOM(4) = 0xFF; DOM(5) = 0xFF; DOM(6) = 0x0F; DOM(7) = 0x03;
    say_text("R"); say_hex(5, 2); say_hex(least_read(0x05000000u), 8); say_flush();
    DOM(0) = 0xFF; DOM(1) = 0xFF; save_timing();
    say_text("R"); say_hex(6, 2); say_hex(least_read(0x05000000u), 8); say_flush();
    usual_timing();

    {
        u32 least = 0xFFFFFFFFu;
        for (u32 i = 0; i < 33; i++) {
            bus_free();
            shift_by(i);
            REG32(0xA0000000u | (CART + 0x400u)) = 0x12345678u;
            u32 t0 = count_now();
            while (PI_STATUS & 2u) { }
            u32 t = count_now() - t0;
            if (i && t < least) least = t;
        }
        say_text("WT"); say_hex(least, 8); say_flush();
    }

    /* A DMA into memory: by size, then by timing. */
    for (u32 i = 0; i < 4; i++) {
        static const u32 sizes[4] = { 8, 128, 512, 4096 };
        say_text("D"); say_hex(sizes[i], 4); say_hex(least_dma(&PI_WR_LEN, PHYS(A), SOURCE, sizes[i]), 8); say_flush();
    }
    for (u32 i = 0; i < 6; i++) {
        static const u8 timing[6][4] = { { 0x40, 0x12, 0x03, 0x07 }, { 0x20, 0x12, 0x03, 0x07 }, { 0x40, 0x24, 0x03, 0x07 }, { 0x40, 0x12, 0x01, 0x07 }, { 0x40, 0x12, 0x03, 0x04 }, { 0x80, 0x12, 0x03, 0x04 } };
        DOM(0) = timing[i][0]; DOM(1) = timing[i][1]; DOM(3) = timing[i][2]; DOM(2) = timing[i][3];
        u32 t = least_dma(&PI_WR_LEN, PHYS(A), SOURCE, 256);
        say_text("DT"); for (u32 k = 0; k < 4; k++) say_hex(timing[i][k], 2); say_hex(t, 8); say_flush();
    }
    usual_timing();

    /* A DMA out of memory, to the save memory. */
    save_timing();
    out_case(0, 0, 64, 0x000);
    out_case(1, 0, 5, 0x200);
    out_case(2, 2, 16, 0x400);
    out_case(3, 2, 300, 0x600);
    out_case(4, (0x800u - 100u - (PHYS(A) & 0x7FFu)) & 0x7FFu, 200, 0x800);
    {
        /* The same timing for both directions, so that the two can be compared. */
        DOM(4) = 0x40; DOM(5) = 0x12; DOM(6) = 0x07; DOM(7) = 0x03;
        u32 out64 = least_dma(&PI_RD_LEN, PHYS(A), SAVE + 0xA00u, 64), out512 = least_dma(&PI_RD_LEN, PHYS(A), SAVE + 0xA00u, 512);
        u32 in64 = least_dma(&PI_WR_LEN, PHYS(B), SAVE + 0xA00u, 64), in512 = least_dma(&PI_WR_LEN, PHYS(B), SAVE + 0xA00u, 512);
        say_text("OT"); say_hex(out64, 8); say_hex(out512, 8); say_hex(in64, 8); say_hex(in512, 8); say_flush();
        save_timing();
    }

    /* A long transfer into memory, looked at while it runs; then a second one started during it. */
    {
        u32 status[4], bus[4], ram[4];
        fill(A, 0x1000, 0x55); fill(B, 0x100, 0x66);
        bus_free();
        PI_STATUS = 3u;
        PI_DRAM_ADDR = PHYS(A); PI_CART_ADDR = SOURCE; PI_WR_LEN = 0xFFFu;
        for (u32 i = 0; i < 4; i++) {
            status[i] = PI_STATUS; bus[i] = PI_CART_ADDR - SOURCE; ram[i] = PI_DRAM_ADDR - PHYS(A);
            for (volatile u32 spin = 0; spin < 600; spin++) { }
        }
        PI_DRAM_ADDR = PHYS(B); PI_CART_ADDR = SOURCE + 0x2000u; PI_WR_LEN = 0x3Fu;
        u32 during = PI_STATUS;
        while (PI_STATUS & 1u) { }
        u32 after = PI_STATUS, ram_end = PI_DRAM_ADDR - PHYS(A), bus_end = PI_CART_ADDR - SOURCE;
        for (u32 i = 0; i < 4; i++) { say_text("L"); say_hex(i, 2); say_hex(status[i], 2); say_hex(bus[i], 8); say_hex(ram[i], 8); say_flush(); }
        u32 second = 0; for (u32 i = 0; i < 0x40; i++) if (B[i] != 0x66) second++;
        PI_STATUS = 3u;
        (void)dma(&PI_WR_LEN, PHYS(B) + 0x100u, SOURCE, 0x1000);
        u32 wrong = 0; for (u32 i = 0; i < 0x1000; i++) if (A[i] != B[0x100 + i]) wrong++;
        say_text("E"); say_hex(during, 2); say_hex(after, 2); say_hex(second, 8); say_hex(wrong, 8); say_hex(ram_end, 8); say_hex(bus_end, 8); say_flush();
        PI_STATUS = 3u;
    }

    /* The CPU's own read and write while a transfer runs. */
    {
        (void)dma(&PI_RD_LEN, PHYS(B), SAVE + 0xC00u, 8);              /* a known word in the save memory first */
        u32 expected = REG32(0xA0000000u | SOURCE);
        bus_free();
        PI_STATUS = 3u;
        PI_DRAM_ADDR = PHYS(A); PI_CART_ADDR = SOURCE; PI_WR_LEN = 0xFFFu;
        u32 seen = REG32(0xA0000000u | SOURCE);
        REG32(0xA0000000u | (SAVE + 0xC00u)) = 0xDEADBEEFu;
        while (PI_STATUS & 1u) { }
        bus_free();
        PI_STATUS = 3u;
        say_text("X"); say_hex(seen, 8); say_hex(expected, 8); say_hex(REG32(0xA0000000u | (SAVE + 0xC00u)), 8); say_flush();
    }

    /* A reset through the status register while a transfer runs. */
    {
        fill(A, 0x1000, 0x55);
        bus_free();
        PI_STATUS = 3u;
        PI_DRAM_ADDR = PHYS(A); PI_CART_ADDR = SOURCE; PI_WR_LEN = 0xFFFu;
        for (volatile u32 spin = 0; spin < 1000; spin++) { }
        PI_STATUS = 1u;
        u32 status = PI_STATUS, ram = PI_DRAM_ADDR - PHYS(A), bus = PI_CART_ADDR - SOURCE;
        for (volatile u32 spin = 0; spin < 4000; spin++) { }
        u32 arrived = 0; for (u32 i = 0; i < 0x1000; i++) if (A[i] != 0x55) arrived++;
        say_text("K"); say_hex(status, 2); say_hex(PI_STATUS, 2); say_hex(arrived, 8); say_hex(MI_INTR & 0x10u, 2); say_hex(ram, 8); say_hex(bus, 8); say_flush();
        PI_STATUS = 3u;
    }

    /* Where nothing answers: eight bytes before the end of a page of the bus, eight after. */
    fill(A, 0x20, 0x55);
    (void)dma(&PI_WR_LEN, PHYS(A), 0x200001F8u, 16);
    say_text("Z"); say_hex(word_at(A), 8); say_hex(word_at(A + 4), 8); say_hex(word_at(A + 8), 8); say_hex(word_at(A + 12), 8); say_flush();

    say_tail("PIPROBE");
}
