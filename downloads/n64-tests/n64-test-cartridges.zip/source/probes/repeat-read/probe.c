/* The repeat-read probe: a small test cartridge for a real console.

   On two consoles the hidden bits probe's line for the MI's repeat mode arrived without its
   first letter, in every run (runs c1-12, c1-13, c2-05). That probe armed the repeat mode,
   stored one word into main memory, and in its very next instruction loaded the length of its
   line of text from the data cache; had the load given 140 or more, the probe would have left
   the letter out exactly as the logs show. This probe asks directly what a read gives straight
   after a store in the repeat mode. All values are in hex. Nothing is printed between a store
   and the read that follows it.

     C k v   the control: no repeat mode. A word that holds 5, in the data cache, loaded k idle
             instructions after an ordinary store elsewhere (k = 0, 1, 2, 4, 8): what came back
     A k v   the same with the repeat mode armed for the store: a load from the data cache
     U k v   the same, the load made without the cache, straight from main memory
     N k v   the same, the load from a line that is not in the data cache when it is asked for
     G l t w the hidden bits probe's own three instructions behind the store: the length it
             loaded, the length as it stands afterwards, and whether the letter was stored
     M m     the MI's mode register read straight after the store: is the repeat mode still on
     S a b   the 16 bytes at the store and the 16 bytes behind them, as four words each read
             back afterwards, folded: was the store repeated over 16 bytes and no further
     T a     a second store 64 bytes on, with the mode not armed again: its 16 bytes folded: was
             that one repeated too
     H h...  the hidden bits of the 16 repeated bytes' four words and of the word behind them,
             as the hidden bits probe printed them in the line that lost its letter

   No line depends on the console's television type: the probe uses neither the VI nor the
   sound output.

   Care for the console: the repeat mode is the one a common library uses to clear memory, armed
   here for 16 bytes at a time in a part of memory nothing else uses; everything else is plain
   loads and stores. */

#include "../cart-lib/say.h"

u32 load_after_0(volatile u32 *store_at, const volatile u32 *load_from, u32 armed);
u32 load_after_1(volatile u32 *store_at, const volatile u32 *load_from, u32 armed);
u32 load_after_2(volatile u32 *store_at, const volatile u32 *load_from, u32 armed);
u32 load_after_4(volatile u32 *store_at, const volatile u32 *load_from, u32 armed);
u32 load_after_8(volatile u32 *store_at, const volatile u32 *load_from, u32 armed);
u32 guard_after(volatile u32 *store_at, volatile u32 *length, volatile u8 *letter_at);
u32 mode_after(volatile u32 *store_at);
u32 hidden_of(const volatile u32 *word);

#define AREA 0x00200000u                                    /* two megabytes up: nothing else is there */
#define UNCACHED(offset) ((volatile u32 *)(0xA0000000u + AREA + (offset)))
#define CACHED(offset) ((volatile u32 *)(0x80000000u + AREA + (offset)))

typedef u32 (*loader)(volatile u32 *, const volatile u32 *, u32);
static const loader LOADERS[5] = { load_after_0, load_after_1, load_after_2, load_after_4, load_after_8 };
static const u32 IDLE[5] = { 0, 1, 2, 4, 8 };

static u32 fold16(u32 offset) { u32 f = 0; for (u32 i = 0; i < 4; i++) f = (f << 5 | f >> 27) ^ UNCACHED(offset)[i]; return f; }

/* Each case in a fresh part of the area: the store goes to `at`, the word read lies 0x800 on. */
static void loads(const char *tag, u32 base, u32 armed, u32 kind) {
    for (u32 i = 0; i < 5; i++) {
        const u32 at = base + i * 0x40u, word = at + 0x800u;
        *UNCACHED(word) = 5u;
        volatile u32 *from = kind == 1 ? UNCACHED(word) : CACHED(word);
        if (kind == 0) (void)*CACHED(word);                 /* brought into the data cache beforehand */
        if (kind == 2) __asm__ volatile("cache 0x11, 0(%0)" : : "r"(CACHED(word)));    /* put out of the data cache, not written back */
        const u32 v = LOADERS[i](UNCACHED(at), from, armed);
        say_text(tag); say_hex(IDLE[i], 1); say_hex(v, 8); say_flush();
    }
}

void probe_main(void) {
    say_head("RRPROBE");
    loads("C", 0x0000, 0, 0);
    loads("A", 0x0200, 1, 0);
    loads("U", 0x0400, 1, 1);
    loads("N", 0x0600, 1, 2);
    {
        volatile u32 *length = CACHED(0x1800); volatile u8 *letter = (volatile u8 *)CACHED(0x1804);
        *length = 0u; *letter = 0u;                          /* both in the data cache, as the other probe's were */
        const u32 loaded = guard_after(UNCACHED(0x1000), length, letter);
        say_text("G"); say_hex(loaded, 8); say_hex(*length, 8); say_hex(*letter, 2); say_flush();
    }
    {
        const u32 m = mode_after(UNCACHED(0x1100));
        say_text("M"); say_hex(m, 8); say_flush();
    }
    {
        for (u32 i = 0; i < 16; i++) UNCACHED(0x1200)[i] = 0xEEEE0000u | i;
        (void)load_after_8(UNCACHED(0x1200), UNCACHED(0x1FF0), 1);
        say_text("S"); say_hex(fold16(0x1200), 8); say_hex(fold16(0x1210), 8); say_flush();
        *UNCACHED(0x1240) = 0x33334444u;                    /* not armed again */
        say_text("T"); say_hex(fold16(0x1240), 8); say_flush();
    }
    {
        for (u32 i = 0; i < 16; i += 2) { *(volatile u16 *)((u32)UNCACHED(0x1300) + i * 2u) = 0x0101u; *(volatile u8 *)((u32)UNCACHED(0x1300) + i * 2u + 1u) = 1u; }
        (void)load_after_8(UNCACHED(0x1300), UNCACHED(0x1FF0), 1);
        say_text("H"); for (u32 i = 0; i < 5; i++) say_hex(hidden_of(UNCACHED(0x1300 + i * 4u)), 1); say_flush();
    }
    say_tail("RRPROBE");
}
