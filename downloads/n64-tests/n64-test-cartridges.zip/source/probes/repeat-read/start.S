# The repeat-read probe's first instruction and its measuring routines. Each routine arms the
# MI's repeat mode for 16 bytes, stores one 32-bit word into main memory without the cache, and
# then, with a chosen number of idle instructions between, reads or stores once more. Nothing is
# printed in between: the routine hands back what it saw.
    .set noreorder
    .section .text.entry, "ax"
    .globl _start
_start:
    lui   $sp, 0x803F
    jal   probe_main
    addiu $sp, $sp, -32
1:  b     1b
    nop

    .section .text, "ax"

# u32 load_after_k(u32 *store_at, const u32 *load_from, u32 armed): the word loaded from
# `load_from`, k idle instructions after the store to `store_at`. With `armed` zero the repeat
# mode is not armed: the control.
    .macro LOAD_AFTER name, idle
    .globl \name
    .balign 32
\name:
    lui   $t0, 0xA430               # the MI's mode register
    beqz  $a2, 1f
    lui   $t1, 0x1110
    addiu $t2, $zero, 0x010F        # the repeat mode, for 16 bytes
    sw    $t2, 0($t0)
1:  addiu $t1, $t1, 0x2221
    sw    $t1, 0($a0)               # the store that is repeated
    .rept \idle
    nop
    .endr
    lw    $v0, 0($a1)               # the read that follows it
    jr    $ra
    nop
    .endm

    LOAD_AFTER load_after_0, 0
    LOAD_AFTER load_after_1, 1
    LOAD_AFTER load_after_2, 2
    LOAD_AFTER load_after_4, 4
    LOAD_AFTER load_after_8, 8

# u32 guard_after(u32 *store_at, const u32 *length, u8 *letter_at): the three instructions the
# hidden bits probe ran behind its repeat-mode store, as it ran them: load a length, and if it is
# below 140 store the length plus one and a letter. Hands back the length it loaded.
    .globl guard_after
    .balign 32
guard_after:
    lui   $t0, 0xA430
    addiu $t2, $zero, 0x010F
    sw    $t2, 0($t0)
    lui   $t1, 0x1110
    addiu $t1, $t1, 0x2221
    sw    $t1, 0($a0)
    lw    $v0, 0($a1)
    sltiu $t3, $v0, 140
    beqz  $t3, 1f
    addiu $t8, $v0, 1
    addiu $t9, $zero, 0x52
    sw    $t8, 0($a1)
    sb    $t9, 0($a2)
1:  jr    $ra
    nop

# u32 mode_after(u32 *store_at): the MI's mode register read straight after the store.
    .globl mode_after
    .balign 32
mode_after:
    lui   $t0, 0xA430
    addiu $t2, $zero, 0x010F
    sw    $t2, 0($t0)
    lui   $t1, 0x1110
    addiu $t1, $t1, 0x2221
    sw    $t1, 0($a0)
    lw    $v0, 0($t0)
    jr    $ra
    nop

# u32 hidden_of(const u32 *word): the four hidden bits of a 32-bit word of main memory, the first
# byte's in bit 3, read through the MI's test mode as the hidden bits probe reads them: the two
# lines of the instruction cache this routine lies in are filled first, and between the write
# that turns the mode on and the write that turns it off nothing is read but the one word.
    .globl hidden_of
    .balign 32
hidden_of:
    lui   $t0, %hi(hidden_of)
    addiu $t0, $t0, %lo(hidden_of)
    cache 0x14, 0($t0)
    cache 0x14, 32($t0)
    lui   $t1, 0xA430
    addiu $t2, $zero, 0x0400
    addiu $t3, $zero, 0x0200
    sw    $t2, 0($t1)
    lw    $v0, 0($a0)
    sw    $t3, 0($t1)
    jr    $ra
    nop
