/* The rsp-behind probe: what the rest of the machine sees of an RSP that is in the middle of a
   long run of its own instructions.

   The probe was written for the emulator's own use. A faster road keeps the RSP behind the
   machine's time while it runs instructions nothing else can see, and brings it up whenever
   something looks: the CPU through the bus, a word of the SP's DMA, the DP reading its list from
   the RSP's data memory, the host. These are the cases that road has to get right, each with the
   CPU standing well away from the RSP's side until the moment it looks. The probe asks a console
   nothing new and has no console record.

   Each line is one case, in hex:

     P  the CPU reads the RSP's program counter six times while the RSP counts, each after a wait
        of its own, then a word of the data memory, then halts the RSP and reads both again.
     S  single step: the RSP is let go seven times with the single-step bit set; the program
        counter and the status after each. Then a program that sets the bit itself.
     D  a DMA into the data memory that the RSP asks for and does not wait for: after so many
        instructions the RSP loads the transfer's first and last word. The line gives the two
        words as the RSP found them, for ten counts of instructions around the transfer's time.
     W  a DMA out of the data memory, with the RSP storing over its first and last word so many
        instructions after asking: what reached main memory.
     M  the same transfer with the RSP running on for long: main memory as the CPU finds it
        after a wait of its own, never having touched the RSP's side.
     X  the DP reads a list from the RSP's data memory while the RSP keeps storing a count into
        the list's fill colour: the pixels the rectangle got, the DP's status and how far it
        read. Then a list whose colour behind the rectangle the RSP keeps storing.
     H  the CPU writes a word of the instruction memory ahead of the running RSP, and again
        after halting it: the count the RSP reached.
     I  a DMA into the instruction memory over instructions the RSP is about to run: the count
        it reached, for eight places of the transfer.
     V  a block with vector and scalar instructions side by side, loads, stores, a move from
        the SP's status behind a vector instruction, a move from the DP's status with an
        instruction behind it that must wait for the value, a subroutine, a loop: what it
        stored; and the program counter after ten waits of the CPU, a run each.
     B  a jump in the delay slot of a jump.
     L  the RSP counts for three stretches of two and a half fields each, the CPU waiting
        without a look: the program counter after each, and the count at the end.

   Nothing here can harm a console: every wait has an end, and the picture stays off. */

typedef unsigned int u32;

#define REG(a) (*(volatile u32 *)(a))
#define SP_STATUS REG(0xA4040010u)
#define SP_PC REG(0xA4080000u)
#define DMEM ((volatile u32 *)0xA4000000u)
#define IMEM ((volatile u32 *)0xA4001000u)
#define DP_START REG(0xA4100000u)
#define DP_END REG(0xA4100004u)
#define DP_CURRENT REG(0xA4100008u)
#define DP_STATUS REG(0xA410000Cu)
#define RAM(a) ((volatile u32 *)(0xA0000000u | (a)))    /* main memory, never through the data cache */

/* Main memory this probe uses, by physical address: nothing else lies there. */
#define FROM_RAM 0x00320000u            /* what a DMA brings in */
#define TO_RAM 0x00320100u              /* where a DMA out goes */
#define CODE_RAM 0x00320200u            /* instructions a DMA brings into the instruction memory */
#define PICTURE 0x00330000u             /* the image the DP draws into */

/* ---- Printing ---------------------------------------------------------------------- */

static char line[240];
static char *at;

#include "../debug-text.h"

static void put(const char *s) { while (*s) *at++ = *s++; }
static void hex(u32 v, u32 digits) { for (u32 i = 0; i < digits; i++) { u32 d = (v >> ((digits - 1u - i) * 4u)) & 15u; *at++ = (char)(d < 10u ? '0' + d : 'a' + d - 10u); } }
static void num(u32 v) { *at++ = ' '; hex(v, 8); }
static void small(u32 v) { *at++ = ' '; hex(v, 4); }
static void begin(const char *tag) { at = line; put(tag); }
static void end(void) { *at++ = '\n'; debug_text(line, (u32)(at - line)); }

/* ---- The RSP's instructions, as words ------------------------------------------------- */

#define ADDIU(rt, rs, imm) (0x24000000u | ((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(imm) & 0xFFFFu))
#define ORI(rt, rs, imm) (0x34000000u | ((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(imm) & 0xFFFFu))
#define LUI(rt, imm) (0x3C000000u | ((u32)(rt) << 16) | ((u32)(imm) & 0xFFFFu))
#define ADDU(rd, rs, rt) (((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(rd) << 11) | 0x21u)
#define LW(rt, off, base) (0x8C000000u | ((u32)(base) << 21) | ((u32)(rt) << 16) | ((u32)(off) & 0xFFFFu))
#define SW(rt, off, base) (0xAC000000u | ((u32)(base) << 21) | ((u32)(rt) << 16) | ((u32)(off) & 0xFFFFu))
#define J(word) (0x08000000u | ((u32)(word) & 0x3FFu))                  /* to the instruction with this number */
#define JAL(word) (0x0C000000u | ((u32)(word) & 0x3FFu))
#define JR(rs) (((u32)(rs) << 21) | 0x08u)
#define BEQ(rs, rt, off) (0x10000000u | ((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(off) & 0xFFFFu))     /* so many instructions on from the delay slot */
#define BNE(rs, rt, off) (0x14000000u | ((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(off) & 0xFFFFu))
#define MFC0(rt, reg) (0x40000000u | ((u32)(rt) << 16) | ((u32)(reg) << 11))
#define MTC0(rt, reg) (0x40800000u | ((u32)(rt) << 16) | ((u32)(reg) << 11))
#define BREAK 0x0000000Du
#define VECTOR(fn, vd, vs, vt) (0x4A000000u | ((u32)(vt) << 16) | ((u32)(vs) << 11) | ((u32)(vd) << 6) | (u32)(fn))
#define VMULF 0x00u
#define VADD 0x10u
#define VSUB 0x11u
#define VXOR 0x2Cu
#define LQV(vt, off, base) (0xC8002000u | ((u32)(base) << 21) | ((u32)(vt) << 16) | (((u32)(off) >> 4) & 0x7Fu))
#define SQV(vt, off, base) (0xE8002000u | ((u32)(base) << 21) | ((u32)(vt) << 16) | (((u32)(off) >> 4) & 0x7Fu))
#define MFC2(rt, vs, lane) (0x48000000u | ((u32)(rt) << 16) | ((u32)(vs) << 11) | ((u32)(lane) << 8))

static u32 prog[400];
static u32 words;
static void w(u32 word) { prog[words++] = word; }
static void fresh(void) { words = 0; }
/* The program goes to the instruction memory, with a BREAK behind it. */
static void load(void) { for (u32 i = 0; i < words; i++) IMEM[i] = prog[i]; IMEM[words] = BREAK; IMEM[words + 1u] = 0; }

static void go(void) { SP_PC = 0; SP_STATUS = 0x0085u; }       /* not halted, not stopped by BREAK, no interrupt asked of BREAK */
static void halt(void) { SP_STATUS = 0x0002u; }

/* The CPU stands away from everything for so many turns of three instructions. */
static void spin(u32 turns) {
    __asm__ volatile(".set push\n.set noreorder\n1: addiu %0, %0, -1\n bnez %0, 1b\n nop\n.set pop" : "+r"(turns));
}

/* The RSP counts: register 1 goes up by `unit` sixty times a round, is stored at 0x100 of the
   data memory, and the round begins again. */
static void counting(u32 unit) {
    fresh();
    w(ADDIU(1, 0, 0));
    for (u32 i = 0; i < 60u; i++) w(ADDIU(1, 1, unit));
    w(SW(1, 0x100, 0));
    w(J(1));
    w(0);
}

/* ---- The cases ---------------------------------------------------------------------- */

static void pc_reads(void) {
    u32 pc[6];
    counting(1); load(); go();
    for (u32 i = 0; i < 6u; i++) { spin(7u + 5u * i); pc[i] = SP_PC; }
    u32 count = DMEM[0x40];
    halt();
    u32 stopped = SP_PC, status = SP_STATUS, count_stopped = DMEM[0x40];
    begin("P");
    for (u32 i = 0; i < 6u; i++) small(pc[i]);
    num(count); small(stopped); small(status); num(count_stopped); end();
}

static void single_step(void) {
    u32 pc[7], st[7];
    counting(1); load();
    SP_PC = 0; SP_STATUS = 0x00C5u;                     /* let go, with the single-step bit */
    for (u32 i = 0; i < 7u; i++) { spin(12); pc[i] = SP_PC; st[i] = SP_STATUS; SP_STATUS = 0x0001u; }
    spin(12);
    SP_STATUS = 0x0022u;                                /* halted, single step off */
    begin("S");
    for (u32 i = 0; i < 7u; i++) { small(pc[i]); small(st[i]); }
    small(SP_PC); end();

    /* A program that sets the bit itself and goes on. */
    fresh();
    w(ORI(2, 0, 0x0040)); w(ADDIU(1, 0, 0)); w(ADDIU(1, 1, 1)); w(MTC0(2, 4));
    for (u32 i = 0; i < 12u; i++) w(ADDIU(1, 1, 1));
    w(SW(1, 0x104, 0));
    load(); go();
    for (u32 i = 0; i < 4u; i++) { spin(20); pc[i] = SP_PC; st[i] = SP_STATUS; SP_STATUS = 0x0001u; }
    SP_STATUS = 0x0022u;
    begin("S self");
    for (u32 i = 0; i < 4u; i++) { small(pc[i]); small(st[i]); }
    small(SP_PC); end();
}

/* A DMA the RSP asks for: `reg` 2 brings 64 bytes from main memory into the data memory at 0x200,
   3 takes them out. */
static void asks_for_dma(u32 reg, u32 ram) {
    w(ORI(1, 0, 0x0200)); w(MTC0(1, 0));
    w(LUI(2, ram >> 16)); w(ORI(2, 2, ram & 0xFFFFu)); w(MTC0(2, 1));
    w(ORI(3, 0, 63)); w(ADDIU(4, 0, 0)); w(LUI(7, 0xBEEF));
    w(MTC0(3, reg));
}

static void dma_in(void) {
    static const u32 AFTER[10] = { 8, 17, 18, 19, 20, 24, 25, 26, 27, 30 };
    for (u32 i = 0; i < 16u; i++) RAM(FROM_RAM)[i] = 0xA0000000u + i;
    for (u32 n = 0; n < 10u; n++) {
        for (u32 i = 0; i < 16u; i++) DMEM[0x80u + i] = 0xD0000000u + (n << 8) + i;
        fresh();
        asks_for_dma(2, FROM_RAM);
        for (u32 i = 0; i < AFTER[n]; i++) w(ADDIU(4, 4, 1));
        w(LW(5, 0x200, 0)); w(LW(6, 0x23C, 0));
        w(SW(5, 0x300, 0)); w(SW(6, 0x304, 0)); w(SW(4, 0x308, 0));
        load(); go();
        spin(150);
        begin("D"); small(AFTER[n]); num(DMEM[0xC0]); num(DMEM[0xC1]); num(DMEM[0xC2]); small(SP_STATUS); num(DMEM[0x80]); num(DMEM[0x8F]); end();
    }
}

static void dma_out(void) {
    static const u32 AFTER[10] = { 2, 8, 9, 10, 11, 12, 16, 17, 18, 22 };
    for (u32 n = 0; n < 10u; n++) {
        for (u32 i = 0; i < 16u; i++) { DMEM[0x80u + i] = 0xD1000000u + (n << 8) + i; RAM(TO_RAM)[i] = 0; }
        fresh();
        asks_for_dma(3, TO_RAM);
        for (u32 i = 0; i < AFTER[n]; i++) w(ADDIU(4, 4, 1));
        w(SW(7, 0x200, 0)); w(SW(7, 0x23C, 0));
        load(); go();
        spin(150);
        begin("W"); small(AFTER[n]); num(RAM(TO_RAM)[0]); num(RAM(TO_RAM)[1]); num(RAM(TO_RAM)[14]); num(RAM(TO_RAM)[15]); small(SP_STATUS); end();
    }
    /* The RSP runs thirty instructions before the request and on for long behind it; the CPU looks at
       main memory only. */
    static const u32 WAITS[8] = { 4, 8, 10, 12, 13, 14, 15, 16 };
    for (u32 n = 0; n < 8u; n++) {
        for (u32 i = 0; i < 16u; i++) { DMEM[0x80u + i] = 0xD2000000u + (n << 8) + i; RAM(TO_RAM)[i] = 0; }
        fresh();
        for (u32 i = 0; i < 30u; i++) w(ADDIU(5, 5, 1));
        asks_for_dma(3, TO_RAM);
        u32 round = words;
        for (u32 i = 0; i < 50u; i++) w(ADDIU(4, 4, 1));
        w(J(round)); w(0);
        load(); go();
        spin(WAITS[n]);
        u32 first = RAM(TO_RAM)[0], middle = RAM(TO_RAM)[8], last = RAM(TO_RAM)[15];
        spin(40);
        u32 later = RAM(TO_RAM)[15];
        halt();
        begin("M"); small(WAITS[n]); num(first); num(middle); num(last); num(later); small(SP_PC); end();
    }
}

/* A list for the DP in the data memory at `at`: an image of 32-bit pixels, the whole of it open,
   fill mode, a fill colour, a rectangle of eight pixels in the first line, and a full sync, with a
   colour of the surroundings behind the rectangle when `behind` is set. Returns the list's end. */
static u32 dp_list(u32 at, u32 colour, u32 behind) {
    volatile u32 *d = DMEM + at / 4u;
    u32 n = 0;
    d[n++] = 0xFF18013Fu; d[n++] = PICTURE;
    d[n++] = 0xED000000u; d[n++] = 0x005003C0u;
    d[n++] = 0xEF300000u; d[n++] = 0;
    d[n++] = 0xF7000000u; d[n++] = colour;
    d[n++] = 0xF601C000u; d[n++] = 0;
    if (behind) { d[n++] = 0xFB000000u; d[n++] = 0x11223344u; }
    d[n++] = 0xE9000000u; d[n++] = 0;
    return at + n * 4u;
}

static void dp_reads_dmem(void) {
    static const u32 WAITS[4] = { 5, 9, 14, 20 };
    DP_STATUS = 0x0002u;                                /* the DP's lists come from the RSP's data memory */
    for (u32 behind = 0; behind < 2u; behind++) for (u32 n = 0; n < 4u; n++) {
        for (u32 i = 0; i < 8u; i++) RAM(PICTURE)[i] = 0;
        u32 list = 0x400u + behind * 0x80u, end_at = dp_list(list, 0x01010101u, behind);
        u32 stored_at = list + (behind ? 0x2Cu : 0x1Cu);                /* the colour word the RSP keeps storing */
        fresh();
        w(LUI(1, 0x5A00 + (n << 4)));
        u32 round = words;
        for (u32 i = 0; i < 28u; i++) { w(ADDIU(1, 1, 1)); w(SW(1, stored_at, 0)); }
        w(J(round)); w(0);
        load(); go();
        spin(WAITS[n]);
        DP_START = list; DP_END = end_at;
        spin(4000);
        u32 status = DP_STATUS, current = DP_CURRENT;
        halt();
        begin(behind ? "X behind" : "X"); small(WAITS[n]); num(RAM(PICTURE)[0]); num(RAM(PICTURE)[7]); num(RAM(PICTURE)[8]); num(status); num(current); num(DMEM[stored_at / 4u]); end();
    }
    DP_STATUS = 0x0001u;
}

static void imem_written(void) {
    counting(1); load(); go();
    spin(40);
    IMEM[30] = ADDIU(1, 1, 0x100);                      /* a word the RSP comes by in every round */
    spin(40);
    u32 count = DMEM[0x40], pc = SP_PC;
    halt();
    u32 stopped = SP_PC;
    IMEM[((stopped >> 2) + 2u) & 0x3Fu] = ADDIU(1, 1, 0x1000);
    SP_STATUS = 0x0001u;
    spin(60);
    u32 later = DMEM[0x40];
    halt();
    begin("H"); num(count); small(pc); small(stopped); num(later); small(SP_PC); end();
}

static void dma_into_imem(void) {
    static const u32 PLACE[8] = { 12, 20, 22, 24, 26, 28, 30, 44 };
    for (u32 i = 0; i < 8u; i++) RAM(CODE_RAM)[i] = ADDIU(4, 4, 0x100);
    for (u32 n = 0; n < 8u; n++) {
        fresh();
        w(ORI(1, 0, 0x1000u | (PLACE[n] * 4u))); w(MTC0(1, 0));
        w(LUI(2, CODE_RAM >> 16)); w(ORI(2, 2, CODE_RAM & 0xFFFFu)); w(MTC0(2, 1));
        w(ORI(3, 0, 31)); w(ADDIU(4, 0, 0));
        w(MTC0(3, 2));
        while (words < 70u) w(ADDIU(4, 4, 1));
        w(SW(4, 0x310, 0));
        load(); go();
        spin(150);
        begin("I"); small(PLACE[n]); num(DMEM[0xC4]); small(SP_STATUS); small(SP_PC); num(IMEM[PLACE[n]]); num(IMEM[PLACE[n] + 7u]); end();
    }
}

static void block(void) {
    fresh();
    w(LQV(1, 0x00, 0)); w(LQV(2, 0x10, 0));
    w(VECTOR(VADD, 3, 1, 2)); w(ADDIU(1, 0, 5));
    w(VECTOR(VMULF, 4, 3, 1)); w(ADDIU(2, 1, 7));
    w(VECTOR(VSUB, 5, 4, 2));
    w(SQV(5, 0x20, 0));
    w(LW(3, 0x20, 0)); w(SW(3, 0x30, 0));
    w(MFC2(4, 5, 2)); w(ADDU(5, 4, 3));
    w(VECTOR(VXOR, 6, 6, 6)); w(MFC0(6, 4));            /* a move from the SP's status behind a vector instruction */
    w(ADDU(7, 6, 5));
    u32 call = words;
    w(0); w(SW(7, 0x34, 0));                            /* the call, filled in below, and its delay slot */
    w(MFC0(8, 11)); w(ADDU(9, 8, 8));                   /* the DP's status, and at once an instruction that must wait for it */
    w(BEQ(0, 0, 2)); w(SW(9, 0x38, 0));
    w(ADDIU(5, 5, 0x7000));                             /* passed over */
    w(SW(5, 0x3C, 0));
    w(VECTOR(VADD, 3, 3, 1)); w(ADDIU(1, 1, -1));       /* five rounds */
    w(BNE(1, 0, -3)); w(SQV(3, 0x40, 0));
    w(BREAK);
    prog[call] = JAL(words);
    w(LW(9, 0x20, 0)); w(JR(31)); w(ADDU(5, 5, 9));     /* the subroutine */
    for (u32 i = 0; i < 8u; i++) DMEM[i] = 0x01020304u * (i + 1u) + 0x00100000u;
    for (u32 i = 8; i < 20u; i++) DMEM[i] = 0;
    load(); go();
    spin(200);
    begin("V"); for (u32 i = 8; i < 14u; i++) num(DMEM[i]); small(SP_STATUS); small(SP_PC); end();
    begin("V more"); for (u32 i = 14; i < 20u; i++) num(DMEM[i]); end();
    begin("V at");
    for (u32 k = 0; k < 10u; k++) { load(); go(); spin(2u + 3u * k); small(SP_PC); halt(); }
    end();
}

static void jump_in_a_delay_slot(void) {
    fresh();
    w(ADDIU(1, 0, 0));
    w(J(5)); w(J(7));                                   /* a jump, and a jump in its delay slot */
    w(ADDIU(1, 1, 1)); w(ADDIU(1, 1, 2));
    w(ADDIU(1, 1, 4)); w(ADDIU(1, 1, 8));
    w(ADDIU(1, 1, 16)); w(ADDIU(1, 1, 32));
    w(SW(1, 0x140, 0));
    load(); go();
    spin(60);
    begin("B"); num(DMEM[0x50]); small(SP_STATUS); small(SP_PC); end();
}

static void long_run(void) {
    u32 pc[3];
    counting(3); load(); go();
    for (u32 i = 0; i < 3u; i++) { spin(1300000u); pc[i] = SP_PC; }
    halt();
    begin("L"); for (u32 i = 0; i < 3u; i++) small(pc[i]); num(DMEM[0x40]); small(SP_PC); small(SP_STATUS); end();
}

void probe_main(void) {
    SP_STATUS = 0x0002u;
    begin("RSPBEHIND 1"); end();
    pc_reads();
    single_step();
    dma_in();
    dma_out();
    dp_reads_dmem();
    imem_written();
    dma_into_imem();
    block();
    jump_in_a_delay_slot();
    long_run();
    begin("RSPBEHIND END"); end();
}
