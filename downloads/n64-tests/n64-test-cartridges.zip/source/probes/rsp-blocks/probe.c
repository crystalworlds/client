/* The rsp-blocks probe: an RSP that comes to the same instructions again and again, not always in
   the same state and not always before the same words.

   The probe was written for the emulator's own use. A faster road keeps a straight run of the
   RSP's instructions, once its timing is worked out, as a block, and takes the block again
   wherever the RSP stands at the same place. These are the cases in which the same place is not
   the same run. The probe asks a console nothing new and has no console record.

   Each line is one case, in hex:

     R  the RSP goes round a loop twenty times, then asks for a DMA that brings other words into
        the instruction memory over the loop's own body, and goes round forty times more: the
        sum the loop made, the program counter and the status. Three places of the loop.
     C  the same loop with the CPU writing one word of its body while it runs: the sum, for
        four waits of the CPU.
     E  three calls, each by turns to a subroutine with a load in the delay slot of its return
        and to one without: behind the first call stands an instruction that reads the register
        just loaded, behind the second a vector instruction that reads the vector register just
        loaded, behind the third a store, which waits behind a load two cycles back. The second
        leaves carries in a flag register of the vector unit, which an addition behind the last
        call takes in.
        How many rounds the RSP made while the CPU stood away for a fixed time, for three such
        times, and what it left.

   Nothing here can harm a console: every wait has an end, and the picture stays off. */

typedef unsigned int u32;

#define REG(a) (*(volatile u32 *)(a))
#define SP_STATUS REG(0xA4040010u)
#define SP_PC REG(0xA4080000u)
#define DMEM ((volatile u32 *)0xA4000000u)
#define IMEM ((volatile u32 *)0xA4001000u)
#define RAM(a) ((volatile u32 *)(0xA0000000u | (a)))    /* main memory, never through the data cache */

/* Main memory this probe uses, by physical address: nothing else lies there. */
#define CODE_RAM 0x00320200u            /* instructions a DMA brings into the instruction memory */

/* ---- Printing ---------------------------------------------------------------------- */

static char line[240];
static char *at;

#include "../debug-text.h"

static void put(const char *s) { while (*s) *at++ = *s++; }
static void hex(u32 v, u32 digits) { for (u32 i = 0; i < digits; i++) { u32 d = (v >> ((digits - 1u - i) * 4u)) & 15u; *at++ = (char)(d < 10u ? '0' + d : 'a' + d - 10u); } }
static void num(u32 v) { *at++ = ' '; hex(v, 8); }
static void small(u32 v) { *at++ = ' '; hex(v, 4); }
static void begin(const char *tag) { at = line; put(tag); }
static void end(void) { *at++ = '\n'; debug_text(line, (u32)(at - line)); }

/* ---- The RSP's instructions, as words ------------------------------------------------- */

#define ADDIU(rt, rs, imm) (0x24000000u | ((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(imm) & 0xFFFFu))
#define ORI(rt, rs, imm) (0x34000000u | ((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(imm) & 0xFFFFu))
#define LUI(rt, imm) (0x3C000000u | ((u32)(rt) << 16) | ((u32)(imm) & 0xFFFFu))
#define ADDU(rd, rs, rt) (((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(rd) << 11) | 0x21u)
#define LW(rt, off, base) (0x8C000000u | ((u32)(base) << 21) | ((u32)(rt) << 16) | ((u32)(off) & 0xFFFFu))
#define SW(rt, off, base) (0xAC000000u | ((u32)(base) << 21) | ((u32)(rt) << 16) | ((u32)(off) & 0xFFFFu))
#define J(word) (0x08000000u | ((u32)(word) & 0x3FFu))                  /* to the instruction with this number */
#define JR(rs) (((u32)(rs) << 21) | 0x08u)
#define JALR(rd, rs) (((u32)(rs) << 21) | ((u32)(rd) << 11) | 0x09u)
#define ANDI(rt, rs, imm) (0x30000000u | ((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(imm) & 0xFFFFu))
#define SLL(rd, rt, sa) (((u32)(rt) << 16) | ((u32)(rd) << 11) | ((u32)(sa) << 6))
#define BNE(rs, rt, off) (0x14000000u | ((u32)(rs) << 21) | ((u32)(rt) << 16) | ((u32)(off) & 0xFFFFu))     /* so many instructions on from the delay slot */
#define MTC0(rt, reg) (0x40800000u | ((u32)(rt) << 16) | ((u32)(reg) << 11))
#define BREAK 0x0000000Du
#define VECTOR(fn, vd, vs, vt) (0x4A000000u | ((u32)(vt) << 16) | ((u32)(vs) << 11) | ((u32)(vd) << 6) | (u32)(fn))
#define VADD 0x10u
#define VADDC 0x14u
#define LQV(vt, off, base) (0xC8002000u | ((u32)(base) << 21) | ((u32)(vt) << 16) | (((u32)(off) >> 4) & 0x7Fu))
#define SQV(vt, off, base) (0xE8002000u | ((u32)(base) << 21) | ((u32)(vt) << 16) | (((u32)(off) >> 4) & 0x7Fu))

static u32 prog[200];
static u32 words;
static void w(u32 word) { prog[words++] = word; }
static void fresh(void) { words = 0; }
/* The program goes to the instruction memory, with a BREAK behind it. */
static void load(void) { for (u32 i = 0; i < words; i++) IMEM[i] = prog[i]; IMEM[words] = BREAK; IMEM[words + 1u] = 0; }

static void go(void) { SP_PC = 0; SP_STATUS = 0x0085u; }       /* not halted, not stopped by BREAK, no interrupt asked of BREAK */
static void halt(void) { SP_STATUS = 0x0002u; }

/* The CPU stands away from everything for so many turns of three instructions. */
static void spin(u32 turns) {
    __asm__ volatile(".set push\n.set noreorder\n1: addiu %0, %0, -1\n bnez %0, 1b\n nop\n.set pop" : "+r"(turns));
}

/* A loop whose body is eight instructions that each add one to register 4, sixty rounds; when
   forty rounds are left the RSP does what `at_forty` is (a move to a coprocessor 0 register, or
   nothing). The body begins at the instruction `body` says, an even number. */
static u32 body;
static void looping(u32 at_forty) {
    fresh();
    w(ORI(1, 0, 0)); w(MTC0(1, 0));                     /* filled in below: where the transfer goes */
    w(LUI(2, CODE_RAM >> 16)); w(ORI(2, 2, CODE_RAM & 0xFFFFu)); w(MTC0(2, 1));
    w(ORI(3, 0, 31)); w(ADDIU(4, 0, 0)); w(ADDIU(5, 0, 60));
    w(ORI(6, 0, 40)); w(0);
    body = words;
    for (u32 i = 0; i < 8u; i++) w(ADDIU(4, 4, 1));
    w(ADDIU(5, 5, -1));
    w(BNE(5, 6, 2)); w(0);
    w(at_forty);
    w(BNE(5, 0, (u32)(body - (words + 1u)))); w(0);
    w(SW(4, 0x100, 0));
}

static void reload_over_a_loop(void) {
    static const u32 OVER[3] = { 0, 2, 4 };              /* how many instructions into the body the transfer begins */
    for (u32 i = 0; i < 8u; i++) RAM(CODE_RAM)[i] = ADDIU(4, 4, 0x100);
    for (u32 n = 0; n < 3u; n++) {
        looping(MTC0(3, 2));
        prog[0] = ORI(1, 0, 0x1000u | ((body + OVER[n]) * 4u));
        prog[5] = ORI(3, 0, (8u - OVER[n]) * 4u - 1u);  /* the transfer ends with the body's last adding instruction */
        load(); go();
        spin(900);
        halt();
        begin("R"); small(OVER[n]); num(DMEM[0x40]); small(SP_PC); small(SP_STATUS); num(IMEM[body + OVER[n]]); end();
    }
}

static void cpu_writes_the_loop(void) {
    static const u32 WAITS[4] = { 12, 30, 55, 90 };
    begin("C");
    for (u32 n = 0; n < 4u; n++) {
        looping(0);
        load(); go();
        spin(WAITS[n]);
        IMEM[body + 3u] = ADDIU(4, 4, 0x1000);
        spin(900);
        halt();
        num(DMEM[0x40]);
    }
    small(SP_PC); small(SP_STATUS);
    end();
}

static void head_of_a_block(void) {
    static const u32 TIMES[3] = { 300, 1000, 2500 };
    u32 calls[3], round;
    fresh();
    w(ADDIU(1, 0, 0)); w(ADDIU(2, 0, 0));
    round = words;
    /* Each call goes to one of two subroutines by the round's number, and comes back to the same
       place: the second of the two has a load in the delay slot of its return. */
    for (u32 i = 0; i < 3u; i++) {
        w(ANDI(21, 1, 1)); w(SLL(21, 21, 3));
        calls[i] = words; w(0);                         /* filled in below: the address of the pair of subroutines */
        w(JALR(31, 20)); w(0);
        if (i == 0) { w(ADDU(7, 3, 3)); w(ADDU(8, 7, 7)); }                     /* reads the register just loaded */
        else if (i == 1) { w(VECTOR(VADDC, 3, 1, 1)); w(SQV(3, 0x40, 0)); }     /* reads the vector register just loaded, and leaves carries */
        else { w(SW(1, 0x104, 0)); w(ADDU(10, 9, 1)); }                         /* a store two cycles behind the load */
    }
    w(VECTOR(VADD, 4, 3, 3)); w(SQV(4, 0x50, 0));       /* takes in the carries */
    w(ADDIU(1, 1, 1));
    w(J(round)); w(SW(1, 0x100, 0));
    for (u32 i = 0; i < 3u; i++) {
        prog[calls[i]] = ADDIU(20, 21, words * 4u);
        w(JR(31)); w(ADDIU(2, 2, 1));
        w(JR(31)); w(i == 0 ? LW(3, 0x20, 0) : i == 1 ? LQV(1, 0x00, 0) : LW(9, 0x24, 0));
    }
    for (u32 i = 0; i < 12u; i++) DMEM[i] = 0x9000A000u + 0x00010002u * (i + 1u);
    for (u32 n = 0; n < 3u; n++) {
        load(); go();
        spin(TIMES[n]);
        halt();
        begin("E"); small(TIMES[n]); num(DMEM[0x40]); num(DMEM[0x41]); num(DMEM[0x10]); num(DMEM[0x14]); small(SP_PC); small(SP_STATUS); end();
    }
}

void probe_main(void) {
    SP_STATUS = 0x0002u;
    begin("RSPBLOCKS 1"); end();
    reload_over_a_loop();
    cpu_writes_the_loop();
    head_of_a_block();
    begin("RSPBLOCKS END"); end();
}
