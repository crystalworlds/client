/* The probe for how long an SP DMA is busy, read by the RSP itself, and for what asking for one
   costs the main CPU.

   The figures this core uses for an SP DMA's time were chosen to meet a bench that polls the busy
   mark from the main CPU, which moves in steps of about 15 cycles. This probe asks more finely.

   First part, the transfer's own time. The RSP asks for a transfer and then reads the busy mark
   once in every one of its own cycles, 28 times, starting a chosen number of cycles after the
   instruction that asked. The same transfer is asked for again and again with the 28 reads moved
   on by 14 cycles each time, so every cycle after the first 14 is read twice and the cycle in which
   the mark drops is found to the cycle. The main CPU takes no part in what is read.

   The transfers: one to four rows of one word (the start, and the wait before a row); one row of
   2 and of 8 words (a word); one row of 63, 64, 65, 127, 128 and 129 words (what happens at 64
   words); two rows of 64 and of 65 words. Each both ways. The RSP's side is the upper half of its
   data memory; main memory's side is at 2 MiB, where nothing of the probe lies.

   Each line: T <R or W> <rows> <words> <cycles waited> <the 28 reads>, in hex; R is a transfer
   that reads main memory. The first read is the highest of the 28 bits, and is made in the cycle
   after the cycles waited. A bit is 1 while the transfer is busy.

   Second part, the CPU's side. The bench's console figures for the shortest transfers are met only
   if the CPU's first read after it asks for a transfer comes back some nine cycles later than a
   read after any other store does. Whether a console holds the CPU up there, this part asks: the
   CPU makes a store and then a read, with 0, 8, 16 or 24 empty instructions between them, and
   times the pair with its own count register. The store goes to a register that asks for nothing
   (main memory's address register, P), or to a length register and so asks for a transfer of one
   word (R reads main memory, W writes it). The read is of the SP's status (S) or of a register
   outside the SP (the MI's version, M). Each pair is timed five times.

   Each line: H <P, R or W> <S or M> <empty instructions> <five times in ticks of the count
   register>, in hex. A tick is two CPU cycles.

   The first line ends with the television type the boot code left for the program (0 PAL, 1 NTSC,
   2 MPAL), so that a log says which console it is from. Nothing else in the probe uses it. */

typedef unsigned int u32;
typedef unsigned char u8;

#define PI_STATUS (*(volatile u32 *)0xA4600010u)
#define TEXT_LENGTH (*(volatile u32 *)0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)
#define SP_MEM_ADDR (*(volatile u32 *)0xA4040000u)
#define SP_DRAM_ADDR (*(volatile u32 *)0xA4040004u)
#define SP_STATUS (*(volatile u32 *)0xA4040010u)
#define SP_PC (*(volatile u32 *)0xA4080000u)
#define DMEM ((volatile u32 *)0xA4000000u)
#define IMEM ((volatile u32 *)0xA4001000u)

#define MAIN_MEMORY_AT 0x00200000u
#define READS 28u
#define STEP 14u

#include "../debug-text.h"


static void say(const char *s, u32 n) {
    debug_text(s, n);
}

static char *hex(char *p, u32 v, u32 digits) {
    for (u32 i = 0; i < digits; i++) { u32 d = (v >> ((digits - 1 - i) * 4)) & 15u; *p++ = (char)(d < 10 ? '0' + d : 'a' + d - 10); }
    return p;
}

/* Runs the RSP from the start of its instruction memory until it halts. */
static void run_rsp(void) {
    SP_PC = 0;
    SP_STATUS = 0xADu;                      /* clear halt, broke and the interrupt; no single step, no interrupt on break */
    while (!(SP_STATUS & 1u)) { }
}

/* One run. The RSP's program: take the two addresses and the length from its data memory, write
   them to the DMA's registers (the write of the length asks for the transfer), do nothing for
   `waited` cycles, read the busy mark into 28 registers in 28 cycles, wait for the transfer to
   end, store the 28 registers, stop. Returns the 28 reads, the first in the highest bit. */
static u32 one_run(u32 reads_main_memory, u32 length, u32 waited) {
    u32 n = 0;
    IMEM[n++] = 0x8C0107F0u;                /* register 1: the address in the RSP's memory */
    IMEM[n++] = 0x8C0207F4u;                /* register 2: the address in main memory */
    IMEM[n++] = 0x8C0307F8u;                /* register 3: the length */
    IMEM[n++] = 0; IMEM[n++] = 0; IMEM[n++] = 0;
    IMEM[n++] = 0x40810000u;                /* the RSP's address register */
    IMEM[n++] = 0x40820800u;                /* main memory's address register */
    IMEM[n++] = reads_main_memory ? 0x40831000u : 0x40831800u;     /* a length register: the transfer is asked for */
    for (u32 i = 0; i < waited; i++) IMEM[n++] = 0;
    for (u32 i = 0; i < READS; i++) IMEM[n++] = 0x40003000u | ((4u + i) << 16);       /* the busy mark into register 4 + i */
    IMEM[n++] = 0x40013000u;                /* the busy mark into register 1 ... */
    IMEM[n++] = 0x1420FFFEu;                /* ... and again while it is set */
    IMEM[n++] = 0;
    for (u32 i = 0; i < READS; i++) IMEM[n++] = 0xAC000000u | ((4u + i) << 16) | (i * 4u);  /* store register 4 + i */
    IMEM[n++] = 0x0000000Du;                /* BREAK */
    DMEM[0x7F0 / 4] = 0x800u; DMEM[0x7F4 / 4] = MAIN_MEMORY_AT; DMEM[0x7F8 / 4] = length;
    run_rsp();
    u32 bits = 0;
    for (u32 i = 0; i < READS; i++) bits = (bits << 1) | (DMEM[i] & 1u);
    return bits;
}

static const u8 SHAPE[14][2] = {            /* rows, words in a row */
    { 1, 1 }, { 2, 1 }, { 3, 1 }, { 4, 1 }, { 1, 2 }, { 1, 8 }, { 1, 63 }, { 1, 64 }, { 1, 65 }, { 1, 127 }, { 1, 128 }, { 1, 129 }, { 2, 64 }, { 2, 65 },
};

/* The count register before a store and after the read that follows it, with `EMPTY` empty
   instructions between the two. Nothing else stands between the two readings of the count. */
#define STORE_THEN_READ(EMPTY) \
    __asm__ volatile(".set push\n\t.set noreorder\n\tmfc0 %0, $9\n\tsw %3, 0(%2)\n\t.rept " #EMPTY "\n\tnop\n\t.endr\n\tlw $0, 0(%4)\n\tmfc0 %1, $9\n\t.set pop" \
        : "=&r"(before), "=&r"(after) : "r"(store_at), "r"(value), "r"(read_at))

static u32 store_then_read(volatile u32 *store_at, u32 value, volatile u32 *read_at, u32 gap) {
    u32 before, after;
    /* No transfer under way, both addresses as a transfer of one word needs them, and no store of
       ours still on its way: the read of the status waits for the stores before it. */
    SP_MEM_ADDR = 0x800u; SP_DRAM_ADDR = MAIN_MEMORY_AT;
    while (SP_STATUS & 0xCu) { }
    if (gap == 0) STORE_THEN_READ(0);
    else if (gap == 1) STORE_THEN_READ(8);
    else if (gap == 2) STORE_THEN_READ(16);
    else STORE_THEN_READ(24);
    return after - before;
}

void probe_main(void) {
    { char head[24] = "RSP DMA PROBE 2 TV ", *p = head + 19; p = hex(p, *(volatile u32 *)0x80000300u, 1); *p++ = '\n'; say(head, (u32)(p - head)); }
    for (u32 way = 0; way < 2; way++) for (u32 s = 0; s < 14; s++) {
        u32 rows = SHAPE[s][0], words = SHAPE[s][1];
        u32 length = ((rows - 1u) << 12) | (words * 8u - 1u);
        /* Far enough for a transfer that takes a cycle a word and 32 more for every row, and 64 over. */
        u32 last = rows * words + rows * 32u + 64u;
        for (u32 waited = 0; waited < last; waited += STEP) {
            u32 bits = one_run(way == 0, length, waited);
            char line[40], *p = line;
            *p++ = 'T'; *p++ = ' '; *p++ = way == 0 ? 'R' : 'W'; *p++ = ' ';
            p = hex(p, rows, 2); *p++ = ' '; p = hex(p, words, 2); *p++ = ' '; p = hex(p, waited, 3); *p++ = ' '; p = hex(p, bits, 7);
            *p++ = '\n';
            say(line, (u32)(p - line));
        }
    }
    /* The CPU's side. The store goes to main memory's address register (which asks for nothing) or
       to one of the two length registers; the read is of the SP's status or of the MI's version. */
    static const u32 STORE_AT[3] = { 0xA4040004u, 0xA4040008u, 0xA404000Cu };
    static const u32 READ_AT[2] = { 0xA4040010u, 0xA4300004u };
    for (u32 st = 0; st < 3; st++) for (u32 rd = 0; rd < 2; rd++) for (u32 gap = 0; gap < 4; gap++) {
        char line[48], *p = line;
        *p++ = 'H'; *p++ = ' '; *p++ = "PRW"[st]; *p++ = ' '; *p++ = "SM"[rd]; *p++ = ' '; p = hex(p, gap * 8u, 2);
        for (u32 k = 0; k < 5; k++) {
            u32 ticks = store_then_read((volatile u32 *)STORE_AT[st], st == 0 ? MAIN_MEMORY_AT : 7u, (volatile u32 *)READ_AT[rd], gap);
            *p++ = ' '; p = hex(p, ticks, 3);
        }
        *p++ = '\n';
        say(line, (u32)(p - line));
    }
    say("END\n", 4);
    /* Something that prints through a buffer may hold the last lines back: a few lines of padding push them out. */
    for (u32 i = 0; i < 160; i++) say("..............................................................\n", 63);
    for (;;) { }
}
