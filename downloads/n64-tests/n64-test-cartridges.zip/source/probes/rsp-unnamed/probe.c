/* The probe for the RSP's vector operations that have no name.

   Twelve of them, in six pairs, each run on four pairs of inputs right after the two loads of its
   sources, as the screen programs for them do: the two loads, the operation, a store of the
   result, then the three parts of the accumulator and the three flag registers. Two test sets say
   different things about four of the first eight (0x3C, 0x3D, 0x3E and 0x3F): whether the first
   three see the loaded values or the registers as they were before the loads, and whether the low
   part of the accumulator reads zero after the last. This probe asks a console, or anything else
   that runs it, and prints what came out as text through the debug text window.

   The last two pairs are a control. Of their four codes, three (0x1C, 0x1E, 0x1F) are known to see
   their sources as they were before the loads on a console, and one (0x1B) the loaded values.
   Whatever runs this probe and shows the loaded values for those three does not have that effect
   at all, and what it shows for the disputed four then says nothing either way.

   Before each pair of operations the two registers, the accumulator and the flags are cleared, so
   that every pair starts as the screen programs start after power-on.

   Each line: R <code> <case> <result> <upper> <middle> <low> <vco> <vcc> <vce>, in hex; the
   vectors as 32 digits.

   The first line ends with the television type the boot code left for the program (0 PAL, 1 NTSC,
   2 MPAL), so that a log says which console it is from. Nothing else in the probe uses it. */

typedef unsigned int u32;
typedef unsigned char u8;

#define PI_STATUS (*(volatile u32 *)0xA4600010u)
#define TEXT_LENGTH (*(volatile u32 *)0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)
#define SP_STATUS (*(volatile u32 *)0xA4040010u)
#define SP_PC (*(volatile u32 *)0xA4080000u)
#define DMEM ((volatile u32 *)0xA4000000u)
#define IMEM ((volatile u32 *)0xA4001000u)

#include "../debug-text.h"


static void say(const char *s, u32 n) {
    debug_text(s, n);
}

static char *hex(char *p, u32 v, u32 digits) {
    for (u32 i = 0; i < digits; i++) { u32 d = (v >> ((digits - 1 - i) * 4)) & 15u; *p++ = (char)(d < 10 ? '0' + d : 'a' + d - 10); }
    return p;
}

/* Runs the RSP from the start of its instruction memory until it halts. */
static void run_rsp(void) {
    SP_PC = 0;
    SP_STATUS = 0xADu;                      /* clear halt, broke and the interrupt; no single step, no interrupt on break */
    while (!(SP_STATUS & 1u)) { }
}

/* The RSP program around one operation: load the two sources, the operation, store the result,
   then the accumulator's three parts through the same register, then the three flag registers. */
static void load_program(u32 operation) {
    static const u32 AFTER[14] = {
        0xE8002000u,                        /* store register 0 at 0x00 */
        0x4B00001Du, 0xE8002001u,           /* the accumulator's upper part, stored at 0x10 */
        0x4B20001Du, 0xE8002002u,           /* its middle part, at 0x20 */
        0x4B40001Du, 0xE8002003u,           /* its low part, at 0x30 */
        0x48480000u, 0xA4080040u,           /* VCO, two bytes at 0x40 */
        0x48480800u, 0xA4080042u,           /* VCC, two bytes at 0x42 */
        0x48481000u, 0xA0080044u,           /* VCE, one byte at 0x44 */
        0x0000000Du,                        /* BREAK */
    };
    IMEM[0] = 0xC8002000u;                  /* load register 0 from 0x00 */
    IMEM[1] = 0xC8012001u;                  /* load register 1 from 0x10 */
    IMEM[2] = operation;
    for (u32 i = 0; i < 14; i++) IMEM[3 + i] = AFTER[i];
}

/* Clears registers 0 and 1, the accumulator (a multiply of zeros loads all of it) and the flags. */
static void clear_vector_unit(void) {
    for (u32 i = 0; i < 8; i++) DMEM[i] = 0;
    IMEM[0] = 0xC8002000u; IMEM[1] = 0xC8012001u;
    IMEM[2] = 0x4A010087u;                  /* VMUDH register 2 = register 0 times register 1 */
    IMEM[3] = 0x48C00000u; IMEM[4] = 0x48C00800u; IMEM[5] = 0x48C01000u;      /* the three flag registers from scalar register 0 */
    IMEM[6] = 0x0000000Du;
    run_rsp();
}

static const u32 VALUE[3][4] = {
    { 0x00000000u, 0x00000000u, 0x00000000u, 0x00000000u },
    { 0x00112233u, 0x44556677u, 0x8899AABBu, 0xCCDDEEFFu },
    { 0xFFEEDDCCu, 0xBBAA9988u, 0x77665544u, 0x33221100u },
};
/* Which two values each of the four cases loads. */
static const u8 CASE[4][2] = { { 0, 1 }, { 1, 1 }, { 1, 2 }, { 2, 2 } };

static void one(u32 code, u32 which) {
    /* The operation with register 0 as destination and first source, register 1 as second source;
       the last code is written with every field zero, as the screen program writes it. */
    load_program(code == 0x3Fu ? 0x4A00003Fu : 0x4A010000u | code);
    for (u32 i = 0; i < 4; i++) { DMEM[i] = VALUE[CASE[which][0]][i]; DMEM[4 + i] = VALUE[CASE[which][1]][i]; }
    run_rsp();
    char line[200], *p = line;
    *p++ = 'R'; *p++ = ' '; p = hex(p, code, 2); *p++ = ' '; *p++ = (char)('A' + which);
    for (u32 part = 0; part < 4; part++) { *p++ = ' '; for (u32 i = 0; i < 4; i++) p = hex(p, DMEM[part * 4 + i], 8); }
    u32 flags = DMEM[16], last = DMEM[17];
    *p++ = ' '; p = hex(p, flags >> 16, 4); *p++ = ' '; p = hex(p, flags & 0xFFFFu, 4); *p++ = ' '; p = hex(p, last >> 24, 2);
    *p++ = '\n';
    say(line, (u32)(p - line));
}

void probe_main(void) {
    static const u8 PAIRS[6][2] = { { 0x38, 0x3C }, { 0x39, 0x3D }, { 0x3A, 0x3E }, { 0x3B, 0x3F }, { 0x1B, 0x1C }, { 0x1E, 0x1F } };
    { char head[28] = "RSP UNNAMED PROBE 3 TV ", *p = head + 23; p = hex(p, *(volatile u32 *)0x80000300u, 1); *p++ = '\n'; say(head, (u32)(p - head)); }
    for (u32 pair = 0; pair < 6; pair++) {
        clear_vector_unit();
        for (u32 half = 0; half < 2; half++) for (u32 which = 0; which < 4; which++) one(PAIRS[pair][half], which);
    }
    say("END\n", 4);
    /* Something that prints through a buffer may hold the last lines back: a few lines of padding push them out. */
    for (u32 i = 0; i < 160; i++) say("..............................................................\n", 63);
    for (;;) { }
}
