/* The save step probe: a small test cartridge for a real console, or rather for the flash cartridge
   it is run from, with its save memory set to SRAM.

   On a console the save probe stopped at its first DMA out of SRAM (runs c1-34 and c1-36, with the
   cartridge tool's save writeback on and off): it had set the second domain's timing to latch 05,
   pulse 0C, page 0F, release 02 and asked for 16 bytes at 0x08007FF0, and the line after that DMA
   never came. With the cartridge set to be FlashRAM the same DMA worked (c1-33). This probe asks the
   same read again, one step at a time, saying each step before it takes it, and gives up on a step
   that does not end. It only reads: nothing is written to the save memory.

   All values are in hex. A timing is the second domain's four registers: latch, pulse, page, release.

     T l p g r      the timing as the probe found it
     B n l p g r    said before step n's DMA: the timing it is about to use
     A n t c s w x  step n's DMA of 16 bytes at 0x08007FF0: t is 1 if it was given up on (the bus still
                    busy after about 50 ms), c how long it took in steps of the CPU's counter, s the PI's
                    status after it, w and x the first two words it brought in (all ones if none came)
     R n t v        step n's read of one word at 0x08000000 by the CPU itself: t as above for the bus
                    being free first, v the word

   The steps: 0 the timing as found; 1 the maker's library's timing for save memory (05 0C 0D 02);
   2 the save probe's (05 0C 0F 02); 3 the timing as found again. A step that is given up on resets
   the PI through its status register before the next one. At the end the timing is put back as
   found.

   No line depends on the console's television type. */

#include "../cart-lib/say.h"

#define SAVE 0x08000000u
#define DOM2(n) REG32(0xA4600024u + (n) * 4u)
#define GIVE_UP 2343750u            /* about 50 ms of the CPU's counter, which steps at half the clock */

static u8 in_bytes[64] __attribute__((aligned(16)));
#define IN ((volatile u8 *)((u32)in_bytes | 0xA0000000u))
static u32 in_word(u32 at) { return ((u32)IN[at] << 24) | ((u32)IN[at + 1] << 16) | ((u32)IN[at + 2] << 8) | IN[at + 3]; }

/* Waits for the bus to be free, but not for ever. Returns 1 if it was given up on. */
static u32 free_or_give_up(void) {
    u32 t0 = count_now();
    while (PI_STATUS & 3u) if (count_now() - t0 > GIVE_UP) return 1u;
    return 0u;
}

static void step(u32 n, u32 latch, u32 pulse, u32 page, u32 release) {
    say_text("B"); say_hex(n, 2); say_hex(latch, 2); say_hex(pulse, 2); say_hex(page, 2); say_hex(release, 2); say_flush();
    DOM2(0) = latch; DOM2(1) = pulse; DOM2(2) = page; DOM2(3) = release;
    for (u32 i = 0; i < 16; i++) IN[i] = 0xFFu;
    u32 gave_up = free_or_give_up();
    u32 t0 = count_now();
    if (!gave_up) {
        PI_STATUS = 2u;
        PI_DRAM_ADDR = (u32)IN & 0x00FFFFFFu;
        PI_CART_ADDR = SAVE + 0x7FF0u;
        PI_WR_LEN = 15u;
        while (PI_STATUS & 1u) if (count_now() - t0 > GIVE_UP) { gave_up = 1u; break; }
    }
    u32 took = count_now() - t0, status = PI_STATUS;
    if (gave_up) PI_STATUS = 3u;            /* reset the PI and clear its interrupt */
    else PI_STATUS = 2u;
    say_text("A"); say_hex(n, 2); say_hex(gave_up, 1); say_hex(took, 8); say_hex(status, 8); say_hex(in_word(0), 8); say_hex(in_word(4), 8); say_flush();

    u32 busy = free_or_give_up(), v = 0xFFFFFFFFu;
    if (!busy) v = REG32(0xA0000000u | SAVE);
    say_text("R"); say_hex(n, 2); say_hex(busy, 1); say_hex(v, 8); say_flush();
}

void probe_main(void) {
    say_head("SSPROBE");
    u32 l = DOM2(0) & 0xFFu, p = DOM2(1) & 0xFFu, g = DOM2(2) & 0xFu, r = DOM2(3) & 0x3u;
    say_text("T"); say_hex(l, 2); say_hex(p, 2); say_hex(g, 2); say_hex(r, 2); say_flush();
    step(0, l, p, g, r);
    step(1, 0x05, 0x0C, 0x0D, 0x02);
    step(2, 0x05, 0x0C, 0x0F, 0x02);
    step(3, l, p, g, r);
    DOM2(0) = l; DOM2(1) = p; DOM2(2) = g; DOM2(3) = r;
    say_tail("SSPROBE");
}
