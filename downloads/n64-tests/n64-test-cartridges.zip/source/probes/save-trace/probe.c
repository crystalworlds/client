/* The save probe, built to say each step as it takes it: a small test cartridge for a real console.

   On a console the save probe with SRAM printed its first line and then nothing (runs c1-34 and
   c1-36). The DMA it was then making works on a console (c1-44, the save step probe), so the stop
   is somewhere else. This build is the save probe itself (probes/save/probe.c, included whole) with
   four kinds of line added, so that a console's log shows the last step that was begun and whether
   it ended:

     >  o b n    a DMA is about to start: o 1 out of memory, 0 into it; b the bus address; n bytes
     <  s        it ended, and the PI's status after it
     !  s        it was given up on after about 50 ms, with the PI's status; the PI is then reset
     w  b v      a write by the CPU itself is about to be made: the bus address and the value
     W  s        the bus was free again after it, and the PI's status (! as above if it never was)
     .  c        a step of the probe's own, as its letter's code: 74 (t) the timing set, 70 (p) the
                 mark read, 6b (k) the old pattern looked for, 6a (j) the identity read

   Every other line is the save probe's. Its run overwrites the cartridge's save, as the save probe's
   does. */

#define SAVE_TRACE 1
#include "../save/text-window.h"
#include "../cart-lib/say.h"

static void trace_begin(u32 out, u32 bus, u32 bytes) { say_text(">"); say_hex(out, 1); say_hex(bus, 8); say_hex(bytes, 8); say_flush(); }
static void trace_wait(void) {
    u32 t0 = count_now();
    while (PI_STATUS & 1u) if (count_now() - t0 > 2343750u) { say_text("!"); say_hex(PI_STATUS, 8); say_flush(); PI_STATUS = 3u; return; }
}
static void trace_end(void) { say_text("<"); say_hex(PI_STATUS, 8); say_flush(); }
/* A write by the CPU itself to the cartridge bus: said before, and after it the bus waited for, not for ever. */
static void trace_io_begin(u32 bus, u32 v) { say_text("w"); say_hex(bus, 8); say_hex(v, 8); say_flush(); }
static void trace_io_end(void) {
    u32 t0 = count_now();
    while (PI_STATUS & 3u) if (count_now() - t0 > 2343750u) { say_text("!"); say_hex(PI_STATUS, 8); say_flush(); PI_STATUS = 3u; return; }
    say_text("W"); say_hex(PI_STATUS, 8); say_flush();
}
static void trace_step(char c) { say_text("."); say_hex((u32)(unsigned char)c, 2); say_flush(); }

#define TRACE_DMA_BEGIN(out, bus, bytes) trace_begin((out) ? 1u : 0u, (bus), (bytes))
#define TRACE_DMA_WAIT() trace_wait()
#define TRACE_DMA_END() trace_end()
#define TRACE_STEP(letter) trace_step(letter)
#define TRACE_IO_BEGIN(bus, v) trace_io_begin((bus), (v))
#define TRACE_IO_END() trace_io_end()

#include "../save/probe.c"
