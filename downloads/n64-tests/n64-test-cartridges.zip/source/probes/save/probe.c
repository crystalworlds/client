/* The save probe: a small test cartridge for a real console, or rather for the flash cartridge it
   is run from, whose save memory is set to one kind before the probe starts.

   It finds out which kind of save memory is there, tries what the chapter says of that kind, and
   leaves a pattern behind. Run a second time, after the console has been switched off and on, it
   finds the pattern and says how much of it survived. Run here twice, in two machines with the
   save's bytes carried from one to the other by the host, it proves the same of this core.

   It erases and overwrites the save memory: never run it over a save that matters.

   T   the second bus timing's four registers, as found
   PS  the two words where a pattern on SRAM keeps its mark, read before anything is written
   V   (only when a mark is there) part, bytes of the pattern that did not survive, the first of them
   I   eight bytes read after the FlashRAM identity command; J  the CPU's own two reads then

   SRAM:
   A  bytes wrong after 32 KiB written and read back, and the first of them
   M  one word read at 0x100 in the chip, 32 KiB further on, in the second bank's place, and near the window's end
   B  bank, bytes wrong after that bank is written and read back, bytes of the first bank changed by it
   W  a read across the end of the second bank: the word before the end, the word after, the bank's first word
   D  a word written and read back by the CPU itself
   C  a word before and after one byte of it is written by the CPU

   FlashRAM:
   F  the maker and device        Q  bytes 8 to 15 of a sixteen-byte read of the identity
   PF the two words where a pattern on FlashRAM keeps its mark (then V as above)
   S  two reads of the status     U  a status read in the upper half of the window, one at the start after it, one after a new command
   E  status during a sector erase, how long it took (clock ticks, in units of 4096), status after (the status register's 16 bits)
   G  the same for a page program
   R  bytes wrong after page 0 is programmed and read back
   N  bytes wrong after it is programmed again: against both patterns ANDed, against the second alone
   K  the page buffer after 0xA5A5A5A5 and then 0x5A5A5A5A are written to it
   X  a read across the end of the first quarter: the word before the end, the word after, the chip's first word
   O  bytes of page 0 changed by an erase command with nothing set up
   Z  pages written at the end, and every status seen while doing it OR-ed together */

#include "text-window.h"
#include "../cart-lib/say.h"

#define SAVE 0x08000000u
#define COMMAND (SAVE + 0x10000u)
#define DOM2(n) REG32(0xA4600024u + (n) * 4u)
#define MARK_A 0x53565052u      /* "SVPR" */
#define MARK_B 0x4F424531u      /* "OBE1" */

static u8 out_bytes[0x8000] __attribute__((aligned(16)));
static u8 in_bytes[0x8000] __attribute__((aligned(16)));
/* The buffers are reached through the uncached window, so that what a DMA moved is what is seen. */
#define OUT ((volatile u8 *)((u32)out_bytes | 0xA0000000u))
#define IN ((volatile u8 *)((u32)in_bytes | 0xA0000000u))

/* A build that says each step as it is taken (probes/save-trace) defines these; this probe's own build
   leaves them empty, so its program is what it was. */
#ifndef TRACE_DMA_BEGIN
#define TRACE_DMA_BEGIN(out, bus, bytes)
#define TRACE_DMA_WAIT() while (PI_STATUS & 1u) { }
#define TRACE_DMA_END()
#define TRACE_STEP(letter)
#define TRACE_IO_BEGIN(bus, v)
#define TRACE_IO_END()
#endif

static void dma(volatile u32 *length_register, volatile u8 *ram, u32 bus, u32 bytes) {
    TRACE_DMA_BEGIN(length_register == &PI_RD_LEN, bus, bytes);
    bus_free();
    PI_DRAM_ADDR = (u32)ram & 0x00FFFFFFu;
    PI_CART_ADDR = bus;
    *length_register = bytes - 1u;
    TRACE_DMA_WAIT();
    PI_STATUS = 2u;
    TRACE_DMA_END();
}
static void dma_in(u32 bus, u32 bytes) { dma(&PI_WR_LEN, IN, bus, bytes); }
static void dma_out(u32 bus, u32 bytes) { dma(&PI_RD_LEN, OUT, bus, bytes); }
static u32 io_read(u32 bus) { bus_free(); return REG32(0xA0000000u | bus); }
static void io_write(u32 bus, u32 v) { TRACE_IO_BEGIN(bus, v); bus_free(); REG32(0xA0000000u | bus) = v; TRACE_IO_END(); }

static u32 in_word(u32 at) { return ((u32)IN[at] << 24) | ((u32)IN[at + 1] << 16) | ((u32)IN[at + 2] << 8) | IN[at + 3]; }

static u32 seed_state;
static u8 next_byte(void) { u32 s = seed_state; s ^= s << 13; s ^= s >> 17; s ^= s << 5; seed_state = s; return (u8)s; }
static void fill_out(u32 seed, u32 bytes) { seed_state = seed; for (u32 i = 0; i < bytes; i++) OUT[i] = next_byte(); }

/* Compares what was read in with the pattern of a seed, the bytes passed through `through` first
   (all ones leaves them as they are). Returns how many differ; `first` gets the first that does. */
static u32 wrong_in(u32 seed, u32 bytes, u32 *first) {
    u32 n = 0;
    seed_state = seed;
    *first = 0xFFFFFFFFu;
    for (u32 i = 0; i < bytes; i++) { u8 want = next_byte(); if (IN[i] != want) { if (!n) *first = i; n++; } }
    return n;
}

/* ---- SRAM -------------------------------------------------------------------------------------- */

#define BANK(n) (SAVE + ((u32)(n) << 18))
#define KEPT_SEED(bank) (0x2468ACE1u + (bank) * 0x01010101u)

/* The pattern a run before this one left on SRAM: three banks' worth if they are there, with the
   mark in the first. Looked for before the probe writes anything at all. */
static void sram_kept(void) {
    u32 first, wrong;
    dma_in(SAVE + 0x7FF0u, 16);
    TRACE_STEP('p');
    u32 mark_a = in_word(0), mark_b = in_word(4);
    say_text("PS"); say_hex(mark_a, 8); say_hex(mark_b, 8); say_flush();
    if (mark_a != MARK_A || mark_b != MARK_B) return;
    for (u32 bank = 0; bank < 3; bank++) {
        dma_in(BANK(bank), 0x8000);
        wrong = wrong_in(KEPT_SEED(bank), bank == 0 ? 0x7FF0u : 0x8000u, &first);
        say_text("V"); say_hex(bank, 2); say_hex(wrong, 8); say_hex(first, 8); say_flush();
    }
}

static void sram(void) {
    u32 first, wrong, changed;

    fill_out(0x13579BDFu, 0x8000);
    dma_out(SAVE, 0x8000);
    dma_in(SAVE, 0x8000);
    wrong = wrong_in(0x13579BDFu, 0x8000, &first);
    say_text("A"); say_hex(wrong, 8); say_hex(first, 8); say_flush();

    say_text("M"); say_hex(io_read(SAVE + 0x100u), 8); say_hex(io_read(SAVE + 0x8100u), 8); say_hex(io_read(BANK(1) + 0x100u), 8); say_hex(io_read(SAVE + 0x7FF8100u), 8); say_flush();

    for (u32 bank = 1; bank < 4; bank++) {
        fill_out(0x0F1E2D3Cu + bank, 0x8000);
        dma_out(BANK(bank), 0x8000);
        dma_in(BANK(bank), 0x8000);
        wrong = wrong_in(0x0F1E2D3Cu + bank, 0x8000, &first);
        dma_in(SAVE, 0x8000);
        changed = wrong_in(0x13579BDFu, 0x8000, &first);
        say_text("B"); say_hex(bank, 2); say_hex(wrong, 8); say_hex(changed, 8); say_flush();
        if (changed) { fill_out(0x13579BDFu, 0x8000); dma_out(SAVE, 0x8000); }
    }

    dma_in(BANK(1) + 0x7FF0u, 32);
    say_text("W"); say_hex(in_word(12), 8); say_hex(in_word(16), 8); say_hex(io_read(BANK(1)), 8); say_flush();

    io_write(SAVE + 0x200u, 0x12345678u);
    say_text("D"); say_hex(io_read(SAVE + 0x200u), 8); say_flush();

    io_write(SAVE + 0x304u, 0xCCCCCCCCu);
    u32 before = io_read(SAVE + 0x304u);
    bus_free();
    /* One byte stored from a register that holds more than a byte: the bus carries the register shifted to the byte's place. */
    __asm__ volatile("sb %0, 1(%1)" : : "r"(0x12345678u), "r"(0xA0000000u | (SAVE + 0x304u)));
    say_text("C"); say_hex(before, 8); say_hex(io_read(SAVE + 0x304u), 8); say_flush();

    /* What the next run looks for. */
    for (u32 bank = 0; bank < 3; bank++) {
        fill_out(KEPT_SEED(bank), 0x8000);
        if (bank == 0) { for (u32 i = 0; i < 4; i++) { OUT[0x7FF0u + i] = (u8)(MARK_A >> (24 - 8 * i)); OUT[0x7FF4u + i] = (u8)(MARK_B >> (24 - 8 * i)); } }
        dma_out(BANK(bank), 0x8000);
        if (bank == 0) { dma_in(BANK(1) + 0x7FF0u, 16); if (in_word(0) == MARK_A) break; }      /* one chip only: the other banks are this one again */
    }
    say_text("Z"); say_hex(3, 8); say_hex(0, 8); say_flush();
}

/* ---- FlashRAM ----------------------------------------------------------------------------------- */

static u32 by_word;             /* this chip counts its addresses in 16-bit words */
static u32 array_at(u32 byte_offset) { return SAVE + (by_word ? byte_offset / 2u : byte_offset); }
static u32 seen_status;

/* Waits for an erase or a program to end, but not for ever: a chip that never says it is done is
   given up on after two million looks. Returns how long it took, in clock ticks. */
static u32 until_ready(u32 busy_bit, u32 *during, u32 *after) {
    u32 t0 = count_now(), status = io_read(SAVE) & 0xFFFFu;        /* the low half: one maker's chip starts its first answer with something else */
    *during = status;
    for (u32 looks = 0; (status & busy_bit) && looks < 2000000u; looks++) status = io_read(SAVE) & 0xFFFFu;
    u32 took = count_now() - t0;
    *after = status;
    seen_status |= *during | status;
    io_write(SAVE, 0);                                      /* clears the status, as a program should */
    return took;
}

static void program_page(u32 page) {
    io_write(COMMAND, 0xB4000000u);
    dma_out(SAVE, 128);
    io_write(COMMAND, 0xA5000000u | page);
}

static void flash(u32 identity) {
    u32 first, wrong, during, after, took;
    by_word = identity == 0x00C20000u || identity == 0x00C20001u || identity == 0x00C2001Eu;
    say_text("F"); say_hex(identity, 8); say_flush();

    dma_in(SAVE, 16);
    say_text("Q"); say_hex(in_word(8), 8); say_hex(in_word(12), 8); say_flush();

    io_write(COMMAND, 0xD2000000u);
    u32 s1 = io_read(SAVE), s2 = io_read(SAVE);
    say_text("S"); say_hex(s1, 8); say_hex(s2, 8); say_flush();
    u32 u1 = io_read(SAVE + 0x11234u), u2 = io_read(SAVE);
    io_write(COMMAND, 0xD2000000u);
    (void)io_read(SAVE);
    say_text("U"); say_hex(u1, 8); say_hex(u2, 8); say_hex(io_read(SAVE), 8); say_flush();

    /* The pattern a run before this one left: every page, with the mark at the start of the last. */
    io_write(COMMAND, 0xF0000000u);
    dma_in(array_at(0x1FF80u), 8);
    u32 mark_a = in_word(0), mark_b = in_word(4);
    say_text("PF"); say_hex(mark_a, 8); say_hex(mark_b, 8); say_flush();
    if (mark_a == MARK_A && mark_b == MARK_B) {
        for (u32 quarter = 0; quarter < 4; quarter++) {
            dma_in(array_at(quarter * 0x8000u), 0x8000);
            wrong = wrong_in(0x600DF00Du + quarter, quarter == 3 ? 0x7F80u : 0x8000u, &first);
            say_text("V"); say_hex(quarter, 2); say_hex(wrong, 8); say_hex(first, 8); say_flush();
        }
    }

    io_write(COMMAND, 0x4B000000u); io_write(COMMAND, 0x78000000u);
    took = until_ready(2u, &during, &after);
    say_text("E"); say_hex(during, 8); say_hex((took + 2048u) >> 12, 8); say_hex(after, 8); say_flush();

    fill_out(0x0BADBEEFu, 128);
    program_page(0);
    took = until_ready(1u, &during, &after);
    say_text("G"); say_hex(during, 8); say_hex((took + 2048u) >> 12, 8); say_hex(after, 8); say_flush();

    io_write(COMMAND, 0xF0000000u);
    dma_in(array_at(0), 128);
    wrong = wrong_in(0x0BADBEEFu, 128, &first);
    say_text("R"); say_hex(wrong, 8); say_flush();

    /* The same page again, with another pattern and no erase between. */
    static u8 both[128];
    seed_state = 0x0BADBEEFu; for (u32 i = 0; i < 128; i++) both[i] = next_byte();
    fill_out(0x5EEDF00Du, 128);
    for (u32 i = 0; i < 128; i++) both[i] &= OUT[i];
    program_page(0);
    (void)until_ready(1u, &during, &after);
    io_write(COMMAND, 0xF0000000u);
    dma_in(array_at(0), 128);
    u32 wrong_both = 0; for (u32 i = 0; i < 128; i++) if (IN[i] != both[i]) wrong_both++;
    wrong = wrong_in(0x5EEDF00Du, 128, &first);
    say_text("N"); say_hex(wrong_both, 8); say_hex(wrong, 8); say_flush();

    io_write(COMMAND, 0xB4000000u);
    io_write(SAVE, 0xA5A5A5A5u); io_write(SAVE, 0x5A5A5A5Au);
    say_text("K"); say_hex(io_read(SAVE), 8); say_flush();

    /* Sector 1 gets a pattern, so that the read across the first quarter's end has something to find. */
    io_write(COMMAND, 0x4B000080u); io_write(COMMAND, 0x78000000u);
    (void)until_ready(2u, &during, &after);
    fill_out(0x77777777u, 128);
    program_page(255);
    (void)until_ready(1u, &during, &after);
    io_write(COMMAND, 0xF0000000u);
    dma_in(array_at(0x7FF0u), 32);
    u32 before_end = in_word(12), after_end = in_word(16);
    dma_in(array_at(0), 8);
    say_text("X"); say_hex(before_end, 8); say_hex(after_end, 8); say_hex(in_word(0), 8); say_flush();

    io_write(COMMAND, 0x78000000u);
    io_write(COMMAND, 0xF0000000u);
    dma_in(array_at(0), 128);
    wrong_both = 0; for (u32 i = 0; i < 128; i++) if (IN[i] != both[i]) wrong_both++;
    say_text("O"); say_hex(wrong_both, 8); say_flush();

    /* What the next run looks for: the whole chip erased and every page programmed. */
    seen_status = 0;
    io_write(COMMAND, 0x3C000000u); io_write(COMMAND, 0x78000000u);
    (void)until_ready(2u, &during, &after);
    u32 pages = 0;
    for (u32 quarter = 0; quarter < 4; quarter++) {
        seed_state = 0x600DF00Du + quarter;
        for (u32 page = 0; page < 256; page++) {
            for (u32 i = 0; i < 128; i++) OUT[i] = next_byte();
            if (quarter == 3 && page == 255) { for (u32 i = 0; i < 4; i++) { OUT[i] = (u8)(MARK_A >> (24 - 8 * i)); OUT[4 + i] = (u8)(MARK_B >> (24 - 8 * i)); } }
            program_page(quarter * 256u + page);
            (void)until_ready(1u, &during, &after);
            pages++;
        }
    }
    io_write(COMMAND, 0xF0000000u);
    say_text("Z"); say_hex(pages, 8); say_hex(seen_status, 8); say_flush();
}

void probe_main(void) {
    say_head("SVPROBE");
    say_text("T"); for (u32 r = 0; r < 4; r++) say_hex(DOM2(r), 2); say_flush();
    /* The timing the maker's library uses for save memory, with pages as long as the bus allows. */
    DOM2(0) = 0x05; DOM2(1) = 0x0C; DOM2(2) = 0x0F; DOM2(3) = 0x02;
    TRACE_STEP('t');

    sram_kept();
    TRACE_STEP('k');
    io_write(COMMAND, 0xE1000000u);
    dma_in(SAVE, 8);
    u32 type = in_word(0), identity = in_word(4);
    say_text("I"); say_hex(type, 8); say_hex(identity, 8); say_flush();
    say_text("J"); say_hex(io_read(SAVE), 8); say_hex(io_read(SAVE + 4u), 8); say_flush();

    TRACE_STEP('j');
    if (type == 0x11118001u) flash(identity); else sram();
    say_tail("SVPROBE");
}
