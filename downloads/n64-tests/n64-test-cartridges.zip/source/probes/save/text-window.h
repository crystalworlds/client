/* Where the save probe keeps its debug text window: a megabyte below the usual place.

   The probe runs from a flash cartridge that keeps every kind of save memory in the last 128 KiB
   of its own memory, and the usual window lies in the upper half of that block. Set to be SRAM
   the cartridge takes the whole of those 128 KiB at the save memory's addresses, so the probe's
   write of the FlashRAM identity command to 0x08010000 landed on the window's mark, and the
   cartridge stopped passing the probe's text on; set to be FlashRAM, the erase of the whole chip
   wiped the window. Here no save memory reaches it.

   Whatever listens must be told the same place: the probe's file of runs names it for the tools
   (probe.json, "textWindow"), and the console runner passes it to the cartridge's listener. */
#ifndef SAVE_PROBE_TEXT_WINDOW_H
#define SAVE_PROBE_TEXT_WINDOW_H
#define DBG_BASE 0xB3F00000u
#endif
