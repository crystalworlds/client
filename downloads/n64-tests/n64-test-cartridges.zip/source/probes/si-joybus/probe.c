/* The joybus probe: a small test cartridge that talks to the SI and the PIF and prints what comes
   back, as text, through the debug text window. Run on a console it is the answer sheet for the
   rules this core follows; run here, the same lines show what this core does, and the two logs are
   compared line by line.

   It only reads from paks and from the EEPROM: nothing a player has saved is changed. One thing it
   leaves behind on a console until power-off: the SI's error mark, from the test that asks for a
   transfer while another runs.

   Each line starts with a short name. Lines that may differ from one run to the next (times, in
   steps of the CPU's counter, and whatever the player's hands do to a controller) start with T, C
   or H and are left out of the fold in the last line.

     H   the five registers and the stack pointer the boot code handed over
     S   the SI's status and the MI's interrupt marks
     P   the PIF's 64 bytes, read by the CPU, 16 to a line
     E   the end-of-boot command: status at once, status and interrupts when the SI is idle again
     G   the SI's registers read back; G2: the memory address after a write and after a read
     I J the identity command, and the reset command, on each channel: count byte, then the room
     C   a controller's state
     U L exchanges that go wrong: an unknown command; too many and too few bytes asked for
     F   the rules of a frame: padding, the end mark, a line reset, the skip mark, an exchange that
         does and does not fit, and one frame read twice
     Q   the command byte after a frame was written, and after it was run
     R   a read by the CPU from the PIF's memory right after a 64-byte read was started
     K   the pak in port 1: a read with the right and with a wrong address check, the status after
     M   the EEPROM: a read of block 0
     X   a transfer asked for while another runs
     W   the SI's two 4-byte registers
     T   times */

#include "../si-lib/lib.h"

static void show_pif(const char *name) {
    u8 b[64];
    for (u32 i = 0; i < 16; i++) { u32 w = PIF_MEMORY[i]; b[i * 4] = (u8)(w >> 24); b[i * 4 + 1] = (u8)(w >> 16); b[i * 4 + 2] = (u8)(w >> 8); b[i * 4 + 3] = (u8)w; }
    for (u32 row = 0; row < 4; row++) { put(name); put_hex(row, 1); put(" "); put_bytes(b + row * 16, 16); end_line(); }
}

/* Builds a frame with one exchange: `before` bytes in front (each `lead`), the two counts, the
   bytes to send, room filled with 0x55, the end mark, the command bit. Returns where the exchange
   starts. */
static u32 build(u32 before, u8 lead, const u8 *tx, u32 tx_len, u32 rx_len) {
    u32 at = 0;
    frame_clear(0x00);
    for (u32 i = 0; i < before; i++) block_out[at++] = lead;
    u32 start = at;
    block_out[at++] = (u8)tx_len; block_out[at++] = (u8)rx_len;
    for (u32 i = 0; i < tx_len; i++) block_out[at++] = tx[i];
    for (u32 i = 0; i < rx_len; i++) block_out[at++] = 0x55;
    if (at < 63) block_out[at] = 0xFE;
    block_out[63] = 0x01;
    return start;
}

/* Prints what came back for the exchange that starts at `start`: its count byte and its room. */
static void came(const char *name, u32 number, u32 start, u32 tx_len, u32 rx_len, int loose) {
    put(name); put_hex(number, 1); put(" "); put_hex(block_in[start + 1], 2); put(" ");
    put_bytes(block_in + start + 2 + tx_len, rx_len);
    if (loose) end_loose_line(); else end_line();
}

static void one(const char *name, u32 number, u32 channel, const u8 *tx, u32 tx_len, u32 rx_len, int loose) {
    u32 start = build(channel, 0x00, tx, tx_len, rx_len);
    si_exchange();
    came(name, number, start, tx_len, rx_len, loose);
}

static const u8 IDENTITY[1] = { 0x00 }, RESET[1] = { 0xFF }, STATE[1] = { 0x01 }, UNKNOWN[1] = { 0x09 };

/* The five-bit check of a pak address, from the table. */
static u32 with_check(u32 addr) {
    static const u8 value[11] = { 0x15, 0x1F, 0x0B, 0x16, 0x19, 0x07, 0x0E, 0x1C, 0x0D, 0x1A, 0x01 };
    u32 check = 0;
    for (u32 bit = 5; bit < 16; bit++) if (addr & (1u << bit)) check ^= value[bit - 5];
    return (addr & 0xFFE0u) | check;
}

static void pak_read(const char *name, u32 number, u32 word) {
    u8 tx[3] = { 0x02, (u8)(word >> 8), (u8)word };
    u32 start = build(0, 0x00, tx, 3, 33);
    si_exchange();
    put(name); put_hex(number, 1); put(" "); put_hex(block_in[start + 1], 2); put(" ");
    put_bytes(block_in + start + 5, 4); put(" .. "); put_hex(block_in[start + 5 + 32], 2);
    end_line();
}

/* Times one frame the way a console bench does: the second of two writes running, and the read
   that follows a write at once. */
static void time_frame(u32 number) {
    si_send();
    u32 write = si_send();
    si_send();
    u32 read = si_fetch();
    put("T"); put_hex(number, 1); put(" "); put_hex(write, 8); put(" "); put_hex(read, 8); end_loose_line();
}

void probe_main(void) {
    lib_start();
    put("SIPROBE 1"); end_line();
    put("H");
    for (u32 i = 0; i < 6; i++) { put(" "); put_hex(handed_over[i], 16); }
    end_loose_line();
    put("S0 "); put_hex(SI_STATUS, 8); put(" "); put_hex(MI_INTERRUPTS, 8); end_line();
    show_pif("P0");

    /* The end of the boot: the word 0x00000008 written over the PIF's last four bytes. */
    {
        u32 t0 = count_now();
        PIF_MEMORY[15] = 0x00000008u;
        u32 at_once = SI_STATUS;
        while (SI_STATUS & 3u) { }
        u32 steps = count_now() - t0;
        put("E0 "); put_hex(at_once, 8); put(" "); put_hex(SI_STATUS, 8); put(" "); put_hex(MI_INTERRUPTS, 8); end_line();
        SI_STATUS = 0;
        put("E1 "); put_hex(SI_STATUS, 8); put(" "); put_hex(MI_INTERRUPTS, 8); end_line();
        put("T0 "); put_hex(steps, 8); end_loose_line();
    }
    show_pif("P1");

    /* The SI's registers. */
    SI_DRAM_ADDR = 0xFFFFFFFFu;
    put("G0 "); put_hex(SI_DRAM_ADDR, 8); put(" "); put_hex(SI_READ64, 8); put(" "); put_hex(SI_WRITE64, 8); end_line();
    put("G1 "); put_hex(*(volatile u32 *)0xA480000Cu, 8); put(" "); put_hex(*(volatile u32 *)0xA480001Cu, 8); put(" "); put_hex(*(volatile u32 *)0xA4800020u, 8); put(" "); put_hex(*(volatile u32 *)0xA4800040u, 8); end_line();

    /* Every channel's identity; the reset command; the controllers' state. */
    for (u32 ch = 0; ch < 5; ch++) one("I", ch, ch, IDENTITY, 1, 3, 0);
    for (u32 ch = 0; ch < 5; ch++) one("J", ch, ch, RESET, 1, 3, 0);
    for (u32 ch = 0; ch < 4; ch++) one("C", ch, ch, STATE, 1, 4, 1);

    /* Exchanges that go wrong, on port 1. */
    one("U", 0, 0, UNKNOWN, 1, 3, 0);
    one("L", 0, 0, IDENTITY, 1, 5, 0);
    one("L", 1, 0, STATE, 1, 2, 1);

    /* The rules of a frame, each with the identity command for port 1. */
    {
        u32 start = build(3, 0xFF, IDENTITY, 1, 3);                 /* padding in front: still port 1 */
        si_exchange(); came("F", 0, start, 1, 3, 0);
        start = build(1, 0xFE, IDENTITY, 1, 3);                     /* the end mark in front: nothing is run */
        si_exchange(); came("F", 1, start, 1, 3, 0);
        start = build(1, 0xFD, IDENTITY, 1, 3);                     /* a line reset in front: the exchange is port 2's */
        si_exchange(); came("F", 2, start, 1, 3, 0);
        start = build(0, 0x00, IDENTITY, 1, 3);                     /* read once... */
        si_send();
        block_out[0] = 0x81; block_out[63] = 0x00;                  /* ...then marked to be skipped, with no command bit */
        si_exchange(); came("F", 3, start, 1, 3, 0);
        start = build(57, 0xFF, IDENTITY, 1, 3);                    /* ends at byte 62: fits */
        si_exchange(); came("F", 4, start, 1, 3, 0);
        frame_clear(0xFF);                                          /* would end at the command byte: does not fit */
        block_out[58] = 0x01; block_out[59] = 0x03; block_out[60] = 0x00; block_out[61] = 0x55; block_out[62] = 0x55; block_out[63] = 0x01;
        si_exchange();
        put("F5 "); put_hex(block_in[59], 2); put(" "); put_bytes(block_in + 61, 3); end_line();
        start = build(0, 0x00, IDENTITY, 1, 3);                     /* one frame, read twice */
        si_exchange();
        PIF_MEMORY[1] = 0x7777FE00u;                                /* the CPU spoils two bytes of the reply in the PIF itself */
        si_idle();
        si_fetch(); came("F", 6, start, 1, 3, 0);
    }

    /* The command byte: after a frame is written, and after it is run. */
    {
        build(0, 0x00, IDENTITY, 1, 3);
        si_send();
        u32 after_write = PIF_MEMORY[15];
        si_fetch();
        put("Q0 "); put_hex(after_write, 8); put(" "); put_hex(block_in[63], 2); put(" "); put_hex(PIF_MEMORY[15], 8); end_line();
    }

    /* The memory address register after a write and after a read, each as a distance from where
       the transfer started; and the two address registers read back. */
    {
        build(0, 0x00, IDENTITY, 1, 3);
        si_send();
        u32 after_send = SI_DRAM_ADDR - ((u32)block_out & 0x1FFFFFFFu);
        si_fetch();
        u32 after_fetch = SI_DRAM_ADDR - ((u32)block_in & 0x1FFFFFFFu);
        put("G2 "); put_hex(after_send, 8); put(" "); put_hex(after_fetch, 8); put(" "); put_hex(SI_READ64, 8); put(" "); put_hex(SI_WRITE64, 8); end_line();
    }

    /* A read by the CPU from the PIF's memory right after a 64-byte read is started: does it get the
       reply of this read or what was there before, and is the SI still busy when it comes back? */
    {
        build(0, 0x00, IDENTITY, 1, 3);
        si_exchange();
        PIF_MEMORY[1] = 0x7777FE00u;                                /* two bytes of the reply spoiled in the PIF itself */
        si_idle();
        SI_STATUS = 0;
        SI_DRAM_ADDR = (u32)block_in & 0x1FFFFFFFu;
        u32 t0 = count_now();
        SI_READ64 = PIF_MEMORY_ADDRESS;
        u32 word = PIF_MEMORY[1];
        u32 status = SI_STATUS;
        u32 steps = count_now() - t0;
        si_idle();
        put("R0 "); put_hex(word, 8); put(" "); put_hex(status, 8); end_line();
        put("T9 "); put_hex(steps, 8); end_loose_line();
    }

    /* The pak in port 1. */
    pak_read("K", 0, with_check(0x8000));
    pak_read("K", 1, with_check(0x8000) ^ 0x01u);
    one("K", 2, 0, IDENTITY, 1, 3, 0);
    pak_read("K", 3, with_check(0x0000));
    one("K", 4, 0, IDENTITY, 1, 3, 0);

    /* The EEPROM: block 0. */
    {
        static const u8 read0[2] = { 0x04, 0x00 };
        one("M", 0, 4, read0, 2, 8, 0);
    }

    /* A 64-byte read asked for while a 64-byte write runs. */
    {
        frame_clear(0x00);
        block_out[0] = 0xFE; block_out[1] = 0x11; block_out[2] = 0x22; block_out[3] = 0x33;
        for (u32 i = 0; i < 4; i++) block_in[i] = 0x99;
        si_idle();
        SI_STATUS = 0;
        SI_DRAM_ADDR = (u32)block_out & 0x1FFFFFFFu;
        SI_WRITE64 = PIF_MEMORY_ADDRESS;
        SI_DRAM_ADDR = (u32)block_in & 0x1FFFFFFFu;
        SI_READ64 = PIF_MEMORY_ADDRESS;
        u32 at_once = SI_STATUS;
        while (SI_STATUS & 3u) { }
        u32 idle = SI_STATUS;
        SI_STATUS = 0;
        put("X0 "); put_hex(at_once, 8); put(" "); put_hex(idle, 8); put(" "); put_hex(SI_STATUS, 8); put(" "); put_bytes(block_in, 4); end_line();
        put("X1 "); put_hex(PIF_MEMORY[0], 8); end_line();
    }

    /* The two 4-byte registers. */
    {
        u32 before = PIF_MEMORY[8];                                 /* makes byte 0x20 the SI's own address */
        SI_WRITE4 = 0xA1B2C3D4u;
        u32 at_once = SI_STATUS;
        si_idle();
        put("W0 "); put_hex(before, 8); put(" "); put_hex(at_once, 8); put(" "); put_hex(PIF_MEMORY[8], 8); end_line();
        PIF_MEMORY[10] = 0x0BADBEEFu;                               /* now byte 0x28, with a word of its own */
        si_idle();
        SI_READ4 = 0x12345678u;
        at_once = SI_STATUS;
        u32 data_at_once = SI_READ4;
        si_idle();
        put("W1 "); put_hex(at_once, 8); put(" "); put_hex(data_at_once, 8); put(" "); put_hex(SI_READ4, 8); put(" "); put_hex(SI_WRITE4, 8); put(" "); put_hex(PIF_MEMORY[10], 8); end_line();
        SI_STATUS = 0;
    }

    /* Times, in steps of the CPU's counter. */
    {
        u32 t0 = count_now();
        (void)PIF_MEMORY[0];
        u32 t1 = count_now();
        PIF_MEMORY[1] = 0;
        while (SI_STATUS & 3u) { }
        u32 t2 = count_now();
        put("T1 "); put_hex(t1 - t0, 8); put(" "); put_hex(t2 - t1, 8); end_loose_line();
        frame_clear(0x00);
        put("T2 "); put_hex(si_send(), 8); end_loose_line();
        frame_clear(0x00); block_out[0] = 0xFE; block_out[63] = 1;                       /* an empty frame */
        time_frame(3);
        build(0, 0x00, STATE, 1, 4);                                                     /* one controller's state */
        time_frame(4);
        frame_clear(0x00);                                                               /* four controllers' state, as the maker's library lays it out */
        for (u32 ch = 0; ch < 4; ch++) { u8 *e = block_out + ch * 8; e[0] = 0xFF; e[1] = 0x01; e[2] = 0x04; e[3] = 0x01; e[4] = e[5] = e[6] = e[7] = 0xFF; }
        block_out[32] = 0xFE; block_out[63] = 1;
        time_frame(5);
        build(0, 0x00, IDENTITY, 1, 3);
        time_frame(6);
        { static const u8 read0[2] = { 0x04, 0x00 }; build(4, 0x00, read0, 2, 8); }
        time_frame(7);
        { u8 tx[3] = { 0x02, 0x80, 0x01 }; build(0, 0x00, tx, 3, 33); }                 /* a pak read at 0x8000 */
        time_frame(8);
    }

    last_line("SIPROBE");
}
