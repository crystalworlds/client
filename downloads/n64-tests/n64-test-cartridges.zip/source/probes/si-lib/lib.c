/* The shared part of the probes of the SI and PIF. */

#include "lib.h"

#define PI_STATUS (*(volatile u32 *)0xA4600010u)
#define TEXT_LENGTH (*(volatile u32 *)0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)

u64 handed_over[6];

/* The two memory routines the compiler may call by itself. */
void *memset(void *dst, int v, unsigned int n) { unsigned char *d = dst; while (n--) *d++ = (unsigned char)v; return dst; }
void *memcpy(void *dst, const void *src, unsigned int n) { unsigned char *d = dst; const unsigned char *s = src; while (n--) *d++ = *s++; return dst; }

#include "../debug-text.h"


static void say(const char *s, u32 n) {
    debug_text(s, n);
}

static char line[240];
static u32 line_len, lines;
static u64 fold = 0xCBF29CE484222325ull;

static void put_char(char c) { if (line_len < sizeof line - 1) line[line_len++] = c; }
void put(const char *s) { while (*s) put_char(*s++); }
void put_hex(u64 v, u32 digits) {
    for (u32 i = 0; i < digits; i++) { u32 d = (u32)(v >> ((digits - 1 - i) * 4)) & 15u; put_char((char)(d < 10 ? '0' + d : 'a' + d - 10)); }
}
void put_bytes(const u8 *b, u32 n) { for (u32 i = 0; i < n; i++) { if (i) put_char(' '); put_hex(b[i], 2); } }

static void send_line(int folded) {
    put_char(10);
    if (folded) for (u32 i = 0; i < line_len; i++) { fold ^= (unsigned char)line[i]; fold *= 0x100000001B3ull; }
    say(line, line_len);
    line_len = 0;
    lines++;
}
void end_line(void) { send_line(1); }
void end_loose_line(void) { send_line(0); }
void last_line(const char *name) {
    u32 n = lines; u64 f = fold;
    put(name); put(" END "); put_hex(n, 8); put(" "); put_hex(f, 16);
    put_char(10);
    say(line, line_len);
    line_len = 0;
}

u32 count_now(void) { u32 v; __asm__ volatile("mfc0 %0, $9" : "=r"(v)); return v; }

/* Two blocks of 64 bytes, each on an 8-byte boundary, reached through the uncached window: the SI
   moves them to and from memory itself, not through the CPU's cache. */
static u8 blocks[128] __attribute__((aligned(16)));
u8 *block_out, *block_in;
void lib_start(void) {
    block_out = (u8 *)(((u32)blocks & 0x1FFFFFFFu) | 0xA0000000u);
    block_in = block_out + 64;
}

u32 si_idle(void) { u32 looks = 0; while (SI_STATUS & 3u) looks++; return looks; }

void frame_clear(u8 fill) { for (u32 i = 0; i < 63; i++) block_out[i] = fill; block_out[63] = 0; }

u32 si_send(void) {
    si_idle();
    SI_STATUS = 0;
    SI_DRAM_ADDR = (u32)block_out & 0x1FFFFFFFu;
    u32 t0 = count_now();
    SI_WRITE64 = PIF_MEMORY_ADDRESS;
    while (SI_STATUS & 3u) { }
    return count_now() - t0;
}

u32 si_fetch(void) {
    si_idle();
    SI_STATUS = 0;
    SI_DRAM_ADDR = (u32)block_in & 0x1FFFFFFFu;
    u32 t0 = count_now();
    SI_READ64 = PIF_MEMORY_ADDRESS;
    while (SI_STATUS & 3u) { }
    return count_now() - t0;
}

void si_exchange(void) { si_send(); si_fetch(); }
