/* What the probes of the SI and PIF share: text out through the debug window, and the SI's
   registers with the few moves a program makes on them. A probe runs with interrupts off and
   watches the SI's busy marks itself. */
#ifndef SI_PROBE_LIB_H
#define SI_PROBE_LIB_H

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

#define SI_DRAM_ADDR (*(volatile u32 *)0xA4800000u)
#define SI_READ64 (*(volatile u32 *)0xA4800004u)
#define SI_WRITE4 (*(volatile u32 *)0xA4800008u)
#define SI_WRITE64 (*(volatile u32 *)0xA4800010u)
#define SI_READ4 (*(volatile u32 *)0xA4800014u)
#define SI_STATUS (*(volatile u32 *)0xA4800018u)
#define MI_INTERRUPTS (*(volatile u32 *)0xA4300008u)
#define PIF_MEMORY ((volatile u32 *)0xBFC007C0u)
#define PIF_MEMORY_ADDRESS 0x1FC007C0u

extern u64 handed_over[6];          /* s3, s4, s5, s6, s7 and sp as the boot code left them */

/* Text. A line is built piece by piece and sent when it ends. */
void put(const char *s);
void put_hex(u64 v, u32 digits);
void put_bytes(const u8 *b, u32 n);
void end_line(void);
void end_loose_line(void);          /* a line that may differ from one run to the next (a time, a button): left out of the fold */
void last_line(const char *name);   /* "<name> END <lines> <fold of all text>" */

/* Time, in steps of the CPU's counter (one for every two CPU cycles). */
u32 count_now(void);

/* The SI. The two blocks are in main memory and are reached without the cache. */
extern u8 *block_out;               /* 64 bytes to send */
extern u8 *block_in;                /* 64 bytes that came back */
void lib_start(void);               /* call first */
u32 si_idle(void);                  /* waits until the SI is not busy; returns how many looks it took */
void frame_clear(u8 fill);          /* fills block_out, command byte zero */
u32 si_send(void);                  /* block_out to the PIF; returns counter steps until the SI was idle */
u32 si_fetch(void);                 /* the PIF's 64 bytes to block_in; the same */
void si_exchange(void);             /* send, then fetch */

#endif
