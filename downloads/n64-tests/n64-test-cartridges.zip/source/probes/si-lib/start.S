# The first instruction of a probe of the SI and PIF. It keeps the registers
# the boot code handed over (for the probe to print), sets a stack well below
# the top of the smallest memory a console has, and goes to the C code. It
# never returns.
    .set noreorder
    .section .text.entry, "ax"
    .globl _start
_start:
    lui   $t0, %hi(handed_over)
    addiu $t0, $t0, %lo(handed_over)
    sd    $s3, 0($t0)
    sd    $s4, 8($t0)
    sd    $s5, 16($t0)
    sd    $s6, 24($t0)
    sd    $s7, 32($t0)
    sd    $sp, 40($t0)
    lui   $sp, 0x803F
    jal   probe_main
    addiu $sp, $sp, -32
1:  b     1b
    nop
