/* The pak probe: a small test cartridge that asks the controller in port 1 about the pak in it,
   and prints what comes back through the debug text window. It is for a console with one
   standard controller in port 1: with a Controller Pak in it, with a Rumble Pak, and with none.

   It only reads. It sends the identity command, the pak read command and one command no device
   knows; it never sends a pak write, so nothing a player has saved can change.

   Each line starts with a short name. Lines that start with T are times, in steps of the CPU's
   counter, and lines that start with C hang on what a hand does to the controller; both are left
   out of the fold in the last line.

     Q   a pak read at 0x8000 with the right address check, sent before the controller has been
         asked anything: the count byte, the check code that came, and the probe's own code of the
         32 bytes. It says whether a pak that is in from power-on answers before the first
         identity command
     S   the identity command, asked twice: the count byte, then the three bytes of the reply
     R   a pak read with the right address check: the count byte, the 32 bytes that came, the check
         code that came with them, and the check code of those 32 bytes as this probe works it out.
         R0 at 0x8000, R1 at 0x8020, R2 at 0xC000, R3 at 0xFFE0, R4 at 0x8000 again: none of these
         is a Controller Pak's memory
     P   a pak read at address 0, the start of a Controller Pak's memory: the count byte, the check
         code that came, and the probe's own code of the 32 bytes. The bytes are not printed
     X   a pak read with a wrong address check: the count byte, the first four bytes of the room,
         its last byte, and the status byte of an identity command asked straight after.
         X0 0x8000 with the lowest check bit turned, X1 0x8000 with the highest, X2 address 0
         with the lowest, X3 address 0 with all five, X4 0x7FE0 with the second, X5 0xFFE0 with
         the third
     T   times, each for a frame written twice and read straight after: T0 a pak read at 0x8000
         with the right check, T1 the same read with a wrong check, T2 a command no device knows,
         T3 the identity command
     W   a pak write, sent only when the controller has just said that no pak is in it (bit 0 of
         its status clear), so that a pak is never written: 32 zero bytes to 0x8000, which is no
         part of a Controller Pak's memory. The line gives the status asked just before, then
         the write's count byte, the byte that came back, and the status asked straight after.
         The check code of 32 zero bytes is 00, and ff when turned over. With a pak in, or with
         nothing answering, the line says that the write was not sent. It is the probe's last
         line, so that every line before it stands where a run without it has it
     Y   a pak read with a wrong address check, then the identity asked twice in a row, then a
         read with its right check and the identity once more: the three status bytes. It says
         whether asking the identity takes the mark of the wrong check (bit 2) off the status, or
         only the next pak command does. Y1 then asks the other half: a read with a wrong check,
         a read with its right check straight after, and the identity once: the one status byte
         says whether a good pak command takes the mark off too. Reads only. They come after
         line W, for the same reason
     C   the watch. For five seconds, and for five more after each change, the probe asks a pak
         read at 0x8000 and then the identity, over and over, and prints a line whenever the
         answers change: the time in milliseconds since the watch began, the read's count byte,
         what kind of answer it was (0 none, 1 bytes with their right check code, 2 bytes with the
         code turned over, 3 anything else), the identity's count byte and its status byte. A
         hand that pulls the pak out and pushes it back in while the watch runs shows what the
         controller says of a pak taken out and of one put in. Left alone it prints one line */

#include "../si-lib/lib.h"

/* Builds a frame with one exchange for port 1: the two counts, the bytes to send, room filled with
   0x55, the end mark, the command bit. */
static void build(const u8 *tx, u32 tx_len, u32 rx_len) {
    u32 at = 0;
    frame_clear(0x00);
    block_out[at++] = (u8)tx_len; block_out[at++] = (u8)rx_len;
    for (u32 i = 0; i < tx_len; i++) block_out[at++] = tx[i];
    for (u32 i = 0; i < rx_len; i++) block_out[at++] = 0x55;
    block_out[at] = 0xFE;
    block_out[63] = 0x01;
}

static const u8 IDENTITY[1] = { 0x00 }, UNKNOWN[1] = { 0x09 };

/* The five-bit check of a pak address, from the table. */
static u32 with_check(u32 addr) {
    static const u8 value[11] = { 0x15, 0x1F, 0x0B, 0x16, 0x19, 0x07, 0x0E, 0x1C, 0x0D, 0x1A, 0x01 };
    u32 check = 0;
    for (u32 bit = 5; bit < 16; bit++) if (addr & (1u << bit)) check ^= value[bit - 5];
    return (addr & 0xFFE0u) | check;
}

/* The check code of 32 bytes: an eight-bit cyclic code, polynomial 0x85, from zero. */
static u8 code_of(const u8 *data) {
    u32 c = 0;
    for (u32 i = 0; i < 32; i++) {
        c ^= data[i];
        for (u32 k = 0; k < 8; k++) c = (c & 0x80u) ? ((c << 1) ^ 0x85u) & 0xFFu : (c << 1) & 0xFFu;
    }
    return (u8)c;
}

/* One pak read. Afterwards the count byte is block_in[1] and the room is block_in[5] to [37]. */
static void pak_read(u32 word) {
    u8 tx[3] = { 0x02, (u8)(word >> 8), (u8)word };
    build(tx, 3, 33);
    si_exchange();
}
/* The identity command. Returns the status byte, or 0xFF when nothing answered. */
static u32 identity(void) {
    build(IDENTITY, 1, 3);
    si_exchange();
    return (block_in[1] & 0x80u) ? 0xFFu : block_in[5];
}
/* What kind of answer the last pak read got. */
static u32 kind_of_answer(void) {
    if (block_in[1] & 0xC0u) return (block_in[1] & 0x80u) ? 0u : 3u;
    u8 own = code_of(block_in + 5);
    return block_in[37] == own ? 1u : block_in[37] == (u8)(own ^ 0xFFu) ? 2u : 3u;
}

static void time_frame(u32 number) {
    si_send();
    u32 write = si_send();
    si_send();
    u32 read = si_fetch();
    put("T"); put_hex(number, 1); put(" "); put_hex(write, 8); put(" "); put_hex(read, 8); end_loose_line();
}

#define STEPS_A_MILLISECOND 46875u
#define WATCH_STEPS (5u * 1000u * STEPS_A_MILLISECOND)

void probe_main(void) {
    lib_start();
    put("PAKPROBE 1"); end_line();

    /* The program ends the boot, as every program must. */
    PIF_MEMORY[15] = 0x00000008u;
    si_idle();
    SI_STATUS = 0;

    pak_read(with_check(0x8000));
    put("Q0 "); put_hex(block_in[1], 2); put(" "); put_hex(block_in[37], 2); put(" "); put_hex(code_of(block_in + 5), 2); end_line();

    for (u32 i = 0; i < 2; i++) {
        build(IDENTITY, 1, 3);
        si_exchange();
        put("S"); put_hex(i, 1); put(" "); put_hex(block_in[1], 2); put(" "); put_bytes(block_in + 3, 3); end_line();
    }

    /* Whole reads where a Controller Pak has no memory. */
    {
        static const u16 at[5] = { 0x8000, 0x8020, 0xC000, 0xFFE0, 0x8000 };
        for (u32 i = 0; i < 5; i++) {
            pak_read(with_check(at[i]));
            put("R"); put_hex(i, 1); put(" "); put_hex(block_in[1], 2); put(" "); put_bytes(block_in + 5, 32);
            put(" "); put_hex(block_in[37], 2); put(" "); put_hex(code_of(block_in + 5), 2);
            end_line();
        }
    }
    pak_read(with_check(0x0000));
    put("P0 "); put_hex(block_in[1], 2); put(" "); put_hex(block_in[37], 2); put(" "); put_hex(code_of(block_in + 5), 2); end_line();

    /* Reads with a wrong address check, and the status after each. */
    {
        static const u16 at[6] = { 0x8000, 0x8000, 0x0000, 0x0000, 0x7FE0, 0xFFE0 };
        static const u8 turned[6] = { 0x01, 0x10, 0x01, 0x1F, 0x02, 0x04 };
        for (u32 i = 0; i < 6; i++) {
            pak_read(with_check(at[i]) ^ turned[i]);
            u8 count = block_in[1], first[4] = { block_in[5], block_in[6], block_in[7], block_in[8] }, last = block_in[37];
            u32 status = identity();
            put("X"); put_hex(i, 1); put(" "); put_hex(count, 2); put(" "); put_bytes(first, 4); put(" .. "); put_hex(last, 2);
            put(" "); put_hex(status, 2);
            end_line();
        }
    }

    /* Times. */
    { u8 tx[3] = { 0x02, 0x80, 0x01 }; build(tx, 3, 33); }
    time_frame(0);
    { u8 tx[3] = { 0x02, 0x80, 0x00 }; build(tx, 3, 33); }
    time_frame(1);
    build(UNKNOWN, 1, 3);
    time_frame(2);
    build(IDENTITY, 1, 3);
    time_frame(3);

    /* The watch. */
    {
        u32 began = count_now(), changed = began, was = 0xFFFFFFFFu, said = 0;
        for (;;) {
            pak_read(with_check(0x8000));
            u32 read_count = block_in[1], kind = kind_of_answer();
            build(IDENTITY, 1, 3);
            si_exchange();
            u32 identity_count = block_in[1], status = (identity_count & 0x80u) ? 0xFFu : block_in[5];
            u32 is = (read_count << 24) | (kind << 16) | (identity_count << 8) | status;
            u32 now = count_now();
            if (is != was) {
                put("C"); put_hex(said, 1); put(" "); put_hex((now - began) / STEPS_A_MILLISECOND, 8); put(" "); put_hex(read_count, 2); put(" "); put_hex(kind, 1);
                put(" "); put_hex(identity_count, 2); put(" "); put_hex(status, 2);
                end_loose_line();
                was = is; said++;
                changed = count_now();
                if (said == 16) break;
            }
            if (count_now() - changed > WATCH_STEPS) break;
        }
    }

    /* A write to a pak that is not there. */
    {
        u32 before = identity();
        put("W0 "); put_hex(before, 2);
        if (before != 0xFFu && !(before & 1u)) {
            u8 tx[35];
            u32 word = with_check(0x8000);
            tx[0] = 0x03; tx[1] = (u8)(word >> 8); tx[2] = (u8)word;
            for (u32 i = 0; i < 32; i++) tx[3 + i] = 0x00;
            build(tx, 35, 1);
            si_exchange();
            u32 count = block_in[1], came = block_in[37];
            u32 after = identity();
            put(" "); put_hex(count, 2); put(" "); put_hex(came, 2); put(" "); put_hex(after, 2);
        } else put(" not sent");
        end_loose_line();
    }

    /* Whether asking the identity takes the mark of a wrong address check off the status. */
    {
        pak_read(with_check(0x8000) ^ 1u);
        u32 first = identity(), second = identity();
        pak_read(with_check(0x8000));
        u32 third = identity();
        put("Y0 "); put_hex(first, 2); put(" "); put_hex(second, 2); put(" "); put_hex(third, 2);
        end_loose_line();
        pak_read(with_check(0x8000) ^ 1u);
        pak_read(with_check(0x8000));
        u32 after_good = identity();
        put("Y1 "); put_hex(after_good, 2);
        end_loose_line();
    }

    last_line("PAKPROBE");
}
