/* The save probe: a small test cartridge that shows whether what is written to the cartridge's
   EEPROM and to a Controller Pak is still there at the next start.

   Each run prints what it finds, writes something new that depends on a run number it keeps in the
   EEPROM's first block, and prints what is there afterwards. Run twice with the power off in
   between, the "before" lines of the second run must be the "after" lines of the first.

   The EEPROM is the probe's own save, so every block of it is written. A Controller Pak may hold a
   player's saves, so only its first 32 bytes are written (a place the pak's file system does not
   use), unless Z is held on controller 1 at the start: then every byte of the pak is overwritten.

     I4  the EEPROM's identity (count byte, three bytes)
     EB  the EEPROM before: a block number, then that block and the three after it
     N   the run number found, and the one this run writes
     EW  block writes taken, and refused because the chip was still busy
     T0  the longest wait for the chip to stop being busy, in steps of the CPU's counter (and the
         shortest); left out of the fold in the last line, as it differs from run to run
     EA  the EEPROM after
     C0  controller 1's state at the start (left out of the fold)
     K0  controller 1's identity
     KL  the pak's first 32 bytes before
     KB  the pak before: a page number and a fold of its 256 bytes
     KW  what was written: 0 the first 32 bytes only, 1 everything; blocks written; check codes that
         did not come back right
     KM  the pak's first 32 bytes after
     KA  the pak after */

#include "../si-lib/lib.h"

static u32 with_check(u32 addr) {
    static const u8 value[11] = { 0x15, 0x1F, 0x0B, 0x16, 0x19, 0x07, 0x0E, 0x1C, 0x0D, 0x1A, 0x01 };
    u32 check = 0;
    for (u32 bit = 5; bit < 16; bit++) if (addr & (1u << bit)) check ^= value[bit - 5];
    return (addr & 0xFFE0u) | check;
}

static u8 data_check(const u8 *d) {
    u32 c = 0;
    for (u32 i = 0; i < 32; i++) { c ^= d[i]; for (u32 k = 0; k < 8; k++) c = (c & 0x80u) ? ((c << 1) ^ 0x85u) & 0xFFu : (c << 1) & 0xFFu; }
    return (u8)c;
}

/* The byte a run writes at a place: `kind` 1 for the EEPROM, 2 for the pak. */
static u8 pattern(u32 run, u32 kind, u32 index) {
    u32 h = run * 0x9E3779B1u + kind * 0x7F4A7C15u + index * 0x85EBCA6Bu;
    h ^= h >> 15; h *= 0x2C1B3C6Du; h ^= h >> 12; h *= 0x297A2D39u; h ^= h >> 15;
    return (u8)(h >> 24);
}

/* One exchange on a channel; the reply is left in block_in. Returns where the exchange starts. */
static u32 exchange(u32 channel, const u8 *tx, u32 tx_len, u32 rx_len) {
    u32 at = 0;
    frame_clear(0x00);
    for (u32 i = 0; i < channel; i++) block_out[at++] = 0x00;
    u32 start = at;
    block_out[at++] = (u8)tx_len; block_out[at++] = (u8)rx_len;
    for (u32 i = 0; i < tx_len; i++) block_out[at++] = tx[i];
    for (u32 i = 0; i < rx_len; i++) block_out[at++] = 0x55;
    block_out[at] = 0xFE;
    block_out[63] = 0x01;
    si_exchange();
    return start;
}

static u32 eeprom_identity(void) {
    static const u8 tx[1] = { 0x00 };
    u32 s = exchange(4, tx, 1, 3);
    return ((u32)block_in[s + 1] << 24) | ((u32)block_in[s + 3] << 16) | ((u32)block_in[s + 4] << 8) | block_in[s + 5];
}

static void eeprom_read(u32 block, u8 *out) {
    u8 tx[2] = { 0x04, (u8)block };
    u32 s = exchange(4, tx, 2, 8);
    for (u32 i = 0; i < 8; i++) out[i] = block_in[s + 4 + i];
}

static u8 eeprom_write(u32 block, const u8 *data) {
    u8 tx[10] = { 0x05, (u8)block };
    for (u32 i = 0; i < 8; i++) tx[2 + i] = data[i];
    u32 s = exchange(4, tx, 10, 1);
    return block_in[s + 12];
}

static void eeprom_show(const char *name, u32 blocks) {
    u8 row[32];
    for (u32 b = 0; b < blocks; b += 4) {
        for (u32 k = 0; k < 4; k++) eeprom_read(b + k, row + k * 8);
        put(name); put(" "); put_hex(b, 2); put(" "); put_bytes(row, 32); end_line();
    }
}

static u8 pak_read(u32 addr, u8 *out) {
    u32 word = with_check(addr);
    u8 tx[3] = { 0x02, (u8)(word >> 8), (u8)word };
    u32 s = exchange(0, tx, 3, 33);
    for (u32 i = 0; i < 32; i++) out[i] = block_in[s + 5 + i];
    return block_in[s + 37];
}

static u8 pak_write(u32 addr, const u8 *data) {
    u32 word = with_check(addr);
    u8 tx[35] = { 0x03, (u8)(word >> 8), (u8)word };
    for (u32 i = 0; i < 32; i++) tx[3 + i] = data[i];
    u32 s = exchange(0, tx, 35, 1);
    return block_in[s + 37];
}

static void pak_show(const char *name) {
    u8 block[32];
    for (u32 page = 0; page < 128; page++) {
        u64 fold = 0xCBF29CE484222325ull;
        for (u32 k = 0; k < 8; k++) {
            pak_read(page * 256 + k * 32, block);
            for (u32 i = 0; i < 32; i++) { fold ^= block[i]; fold *= 0x100000001B3ull; }
        }
        put(name); put(" "); put_hex(page, 2); put(" "); put_hex(fold, 16); end_line();
    }
}

void probe_main(void) {
    lib_start();
    put("SAVEPROBE 1"); end_line();
    PIF_MEMORY[15] = 0x00000008u;                   /* the boot is over */
    si_idle();
    SI_STATUS = 0;

    /* Controller 1 at the start: Z held asks for the whole pak to be overwritten. */
    u32 held_z;
    {
        static const u8 tx[1] = { 0x01 };
        u32 s = exchange(0, tx, 1, 4);
        held_z = !(block_in[s + 1] & 0xC0u) && (block_in[s + 3] & 0x20u);
        put("C0 "); put_hex(block_in[s + 1], 2); put(" "); put_bytes(block_in + s + 3, 4); end_loose_line();
    }

    /* The EEPROM. */
    u32 identity = eeprom_identity();
    put("I4 "); put_hex(identity >> 24, 2); put(" "); put_hex(identity & 0xFFFFFFu, 6); end_line();
    u32 run = 0;
    if (!(identity & 0xC0000000u)) {
        u32 blocks = ((identity >> 8) & 0xFFu) == 0xC0u ? 256u : 64u;
        u8 first[8], data[8];
        eeprom_show("EB", blocks);
        eeprom_read(0, first);
        if (first[0] == 'S' && first[1] == 'V' && first[2] == 'P' && first[3] == 'B') run = ((u32)first[4] << 24) | ((u32)first[5] << 16) | ((u32)first[6] << 8) | first[7];
        put("N "); put_hex(run, 8); put(" "); put_hex(run + 1, 8); end_line();
        run++;
        u32 taken = 0, refused = 0, longest = 0, shortest = 0xFFFFFFFFu;
        for (u32 b = 0; b < blocks; b++) {
            if (b == 0) { data[0] = 'S'; data[1] = 'V'; data[2] = 'P'; data[3] = 'B'; data[4] = (u8)(run >> 24); data[5] = (u8)(run >> 16); data[6] = (u8)(run >> 8); data[7] = (u8)run; }
            else for (u32 i = 0; i < 8; i++) data[i] = pattern(run, 1, b * 8 + i);
            u32 t0 = count_now();
            while (eeprom_write(b, data) & 0x80u) refused++;      /* refused while busy: ask again */
            taken++;
            while (eeprom_identity() & 0x80u) { }                 /* wait until the chip says it is done */
            u32 took = count_now() - t0;
            if (took > longest) longest = took;
            if (took < shortest) shortest = took;
        }
        put("EW "); put_hex(taken, 4); put(" "); put_hex(refused, 4); end_line();
        put("T0 "); put_hex(longest, 8); put(" "); put_hex(shortest, 8); end_loose_line();
        eeprom_show("EA", blocks);
    }

    /* The Controller Pak in controller 1. */
    {
        static const u8 tx[1] = { 0x00 };
        u8 block[32];
        u32 s = exchange(0, tx, 1, 3);
        u32 count = block_in[s + 1], kind = ((u32)block_in[s + 3] << 8) | block_in[s + 4], status = block_in[s + 5];
        put("K0 "); put_hex(count, 2); put(" "); put_hex(kind, 4); put(" "); put_hex(status, 2); end_line();
        if (!(count & 0xC0u) && kind == 0x0500u && (status & 1u)) {
            u8 check = pak_read(0x0000, block);
            put("KL "); put_hex(check, 2); put(" "); put_bytes(block, 32); end_line();
            pak_show("KB");
            u32 written = 0, wrong = 0;
            if (run == 0) run = 1;
            for (u32 addr = 0; addr < (held_z ? 0x8000u : 32u); addr += 32) {
                for (u32 i = 0; i < 32; i++) block[i] = pattern(run, 2, addr + i);
                if (pak_write(addr, block) != data_check(block)) wrong++;
                written++;
            }
            put("KW "); put_hex(held_z ? 1 : 0, 1); put(" "); put_hex(written, 4); put(" "); put_hex(wrong, 4); end_line();
            check = pak_read(0x0000, block);
            put("KM "); put_hex(check, 2); put(" "); put_bytes(block, 32); end_line();
            pak_show("KA");
        }
    }

    last_line("SAVEPROBE");
}
