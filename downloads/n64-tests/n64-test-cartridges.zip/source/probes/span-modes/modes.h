/* The modes of the core's list of RDP modes as the commands that set them, for the span modes
   probe. Written by a generator from that list: do not change it by hand. A line: the two other-modes words (the first
   without its cycle type), the combine command's two words, whether the mode is two-cycle, the
   colour image's pixel size, whether its loop is made for one kind of texel over every tile the
   level of detail can reach, and the format and size of the tile a primitive names and of the next. */
struct span_mode { u32 hi, lo, combine_hi, combine_lo; u8 two_cycle, color_size, one_kind, format0, size0, format1, size1; };
#define SPAN_MODES 30u
static const struct span_mode span_modes[SPAN_MODES] = {
    { 0x00082CF0u, 0x0F0A4000u, 0x00887F10u, 0x88FE793Cu, 0, 2, 0, 0, 0, 0, 0 },
    { 0x00082C30u, 0x00552078u, 0x00127E24u, 0x88FFF9FCu, 0, 2, 0, 0, 2, 0, 2 },
    { 0x00082C00u, 0x00552048u, 0x00887F10u, 0x88FCFC7Eu, 0, 2, 0, 0, 2, 0, 2 },
    { 0x000D2C20u, 0xC8102078u, 0x0026E404u, 0x18FCFFFCu, 1, 2, 1, 4, 0, 4, 0 },
    { 0x0008AC00u, 0x00552230u, 0x00127E24u, 0x88FFF9FCu, 0, 2, 0, 2, 0, 2, 0 },
    { 0x00082C00u, 0xC81049D8u, 0x00127E03u, 0x880FF3FFu, 1, 2, 0, 0, 2, 0, 0 },
    { 0x00082C30u, 0x0F0A4000u, 0x00127E24u, 0x88FFF9FCu, 0, 2, 0, 0, 2, 0, 2 },
    { 0x00082C00u, 0x00552230u, 0x00127E24u, 0x88FFF9FCu, 0, 2, 0, 0, 2, 0, 2 },
    { 0x00082CF0u, 0x00552078u, 0x00121824u, 0x8833FFFFu, 0, 2, 0, 0, 2, 0, 2 },
    { 0x00082C30u, 0x00552048u, 0x0040FE81u, 0x55FEF97Cu, 0, 2, 0, 3, 1, 3, 1 },
    { 0x00092C20u, 0xC8102078u, 0x0026A004u, 0x18FC93FCu, 1, 2, 1, 4, 1, 4, 1 },
    { 0x00082C00u, 0x00552078u, 0x00121824u, 0x8833FFFFu, 0, 2, 0, 0, 2, 0, 2 },
    { 0x00082C00u, 0x00504B50u, 0x00119623u, 0x882FFFFFu, 0, 2, 0, 3, 1, 3, 1 },
    { 0x00092C00u, 0x0C192078u, 0x0011FE04u, 0x8813F3FFu, 1, 2, 1, 0, 2, 0, 2 },
    { 0x00082C30u, 0x00552078u, 0x00887F10u, 0x88FE7B3Du, 0, 2, 0, 0, 0, 0, 0 },
    { 0x0008ACF0u, 0x00553078u, 0x0060B2C1u, 0x5565FEFFu, 0, 2, 0, 2, 1, 2, 1 },
    { 0x00082C00u, 0x00504A50u, 0x00121824u, 0x8833FFFFu, 0, 2, 0, 3, 1, 3, 1 },
    { 0x00082C00u, 0x00504A50u, 0x00121824u, 0x8833FFFFu, 0, 2, 0, 0, 3, 0, 3 },
    { 0x00082C30u, 0x00553078u, 0x00887F10u, 0x88FCF279u, 0, 2, 0, 0, 2, 0, 2 },
    { 0x00092C20u, 0xC8102078u, 0x0026A004u, 0x18FC93FCu, 1, 2, 1, 4, 0, 4, 0 },
    { 0x00082C00u, 0xC8112078u, 0x00127F10u, 0x88FFF238u, 1, 2, 0, 0, 2, 0, 0 },
    { 0x00082CF0u, 0x00504B50u, 0x00309661u, 0x552EFF7Fu, 0, 2, 0, 4, 1, 4, 1 },
    { 0x00082C30u, 0x005045D8u, 0x00121824u, 0x8833FFFFu, 0, 2, 0, 0, 2, 0, 2 },
    { 0x0009AC60u, 0xC4112048u, 0x0026A004u, 0x181093FFu, 1, 2, 1, 2, 1, 2, 1 },
    { 0x0009AC20u, 0xC8102078u, 0x0026A004u, 0x181093FFu, 1, 2, 1, 2, 1, 2, 1 },
    { 0x0000ACA0u, 0x00504340u, 0x00887F10u, 0x88FDF6FBu, 0, 2, 0, 0, 0, 0, 0 },
    { 0x00000CF0u, 0x00504240u, 0x00881710u, 0x882DFEFFu, 0, 2, 0, 4, 0, 4, 0 },
    { 0x00082CA0u, 0x00504B50u, 0x00121824u, 0x8833FFFFu, 0, 2, 0, 3, 1, 3, 1 },
    { 0x00092C20u, 0xC8102078u, 0x00887F10u, 0x88FE7838u, 1, 2, 1, 0, 0, 0, 0 },
    { 0x00082C60u, 0x00504B50u, 0x00121824u, 0x8833FFFFu, 0, 2, 0, 3, 1, 3, 1 },
};
