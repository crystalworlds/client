/* The span modes probe: a small test cartridge that draws in every mode a span loop is made for.

   It is written for the gate that holds a faster build of this core to the plain build
   (a check of the emulator, not of a console): the made span loops are taken only
   for the modes of the core's list of RDP modes, which are modes of games, and no other probe of ours draws
   in one. This one draws in each: its table of modes (modes.h) is written by the tool that
   writes the core's table, from the same count. It asks a console nothing, has no console
   record, and nobody has asked whether a console takes its lists: the triangles' coefficients
   are made up, as a fuzzer's are, and are not those of real shapes.

   A pass is one list for each mode of the table. A list stands by itself:
     the colour image (16 bits a pixel unless the mode says otherwise, 96 wide), the depth image
     and the scissor (96 by 72); texture memory filled by two loads from a block of made-up
     texels; four tiles from the one the primitives name, of the kinds the mode's line names;
     the combiner as the mode has it; fog, blend, primitive and environment colours, a primitive
     depth, key and convert values; the mode's two other-modes words;
     twelve primitives: ten triangles with and without shade, texture and depth, most of them
     small and inside the image and lying over one another, a textured rectangle, and a plain
     rectangle with an environment colour behind it;
     then three ways of standing beside the mode, each with two more triangles, which no made
     loop may take: one combiner input changed; with the level of detail on, a tile it can reach
     given another kind; and the colour image made 8 bits a pixel, which reads back the hidden
     bits the lines before left behind. Before the last of them, two triangles with the tile
     just beyond the primitives' levels of another kind: the level of detail reaches that tile
     only where the detail texture is on, so elsewhere the mode's loop is taken all the same;
     a full sync.
   Everything made up comes from one sequence of numbers, started from the pass and the mode, so
   every pass draws other primitives over what the passes before left.

   The probe says one line when it starts and one after every pass, with the pass's number and a
   sum of each image. It has no end.

   Care for the console: not written for one, and not to be run on one unasked. */

#include "../cart-lib/say.h"
#include "modes.h"

#define DP_START REG32(0xA4100000u)
#define DP_END REG32(0xA4100004u)
#define DP_STATUS REG32(0xA410000Cu)
#define MI_INTR REG32(0xA4300008u)

#define IMAGE 0x00200000u
#define DEPTH 0x00208000u
#define TEXELS 0x00210000u
#define LIST 0x00280000u
#define WIDTH 96u
#define HEIGHT 72u

static volatile u64 *list_at;
static u32 list_words;
static void put(u32 hi, u32 lo) { list_at[list_words++] = ((u64)hi << 32) | lo; }

static u32 seed;
static u32 next(void) { seed = seed * 1664525u + 1013904223u; return seed >> 8; }
static u32 below(u32 n) { return next() % n; }
static int around(int centre, int spread) { return centre + (int)below((u32)spread * 2u + 1u) - spread; }

/* A triangle with made-up coefficients: its top and its major edge inside the image, the other
   two edges up to forty pixels to the side the command names, every block it carries. */
static void triangle(u32 blocks, u32 tile, u32 levels) {
    const u32 id = 0x08u | blocks, left = below(2);
    const int yh = (int)below(HEIGHT << 2), ym = yh + (int)below(40), yl = ym + (int)below(40);
    const int across = (int)(1u + below(40)) << 16;
    const int xh = (int)((below(WIDTH) << 16) | below(0x10000u)), xm = left ? xh + (int)below((u32)across) : xh - (int)below((u32)across), xl = left ? xh + across : xh - across;
    const int lean = around(0, 0x20000);
    u32 w[44];
    u32 n = 8;
    w[0] = (id << 24) | (left << 23) | (levels << 19) | (tile << 16) | ((u32)yl & 0x3FFFu);
    w[1] = (((u32)ym & 0x3FFFu) << 16) | ((u32)yh & 0x3FFFu);
    w[2] = (u32)xl & 0x0FFFFFFFu; w[3] = (u32)around(0, 0x30000) & 0x3FFFFFFFu;
    w[4] = (u32)xh & 0x0FFFFFFFu; w[5] = ((u32)lean & 0x3FFFFFFFu) | (lean < 0 ? 0x80000000u : 0u);
    w[6] = (u32)xm & 0x0FFFFFFFu; w[7] = (u32)around(0, 0x30000) & 0x3FFFFFFFu;
    if (blocks & 4u) {
        /* Shade: where it starts, and small steps along a line, along the edge and down. */
        for (u32 i = 0; i < 16u; i++) w[n + i] = next() << 8 | below(256);
        for (u32 i = 0; i < 16u; i++) if (i == 2 || i == 3 || (i >= 8 && i <= 11)) w[n + i] = (((u32)around(0, 3) & 0xFFFFu) << 16) | ((u32)around(0, 3) & 0xFFFFu);
        n += 16;
    }
    if (blocks & 2u) {
        /* Texture: steps of up to three texels a pixel, so that the level of detail moves; a w that stays positive. */
        for (u32 i = 0; i < 16u; i++) w[n + i] = next() << 8 | below(256);
        w[n + 2] = (((u32)around(0, 96) & 0xFFFFu) << 16) | ((u32)around(0, 96) & 0xFFFFu);
        w[n + 8] = (((u32)around(0, 96) & 0xFFFFu) << 16) | ((u32)around(0, 96) & 0xFFFFu);
        w[n + 10] = (((u32)around(0, 96) & 0xFFFFu) << 16) | ((u32)around(0, 96) & 0xFFFFu);
        w[n + 1] = (w[n + 1] & 0xFFFFu) | ((0x1000u + below(0x6000u)) << 16);
        w[n + 3] = ((u32)around(0, 3) & 0xFFFFu) << 16; w[n + 9] = ((u32)around(0, 3) & 0xFFFFu) << 16; w[n + 11] = ((u32)around(0, 3) & 0xFFFFu) << 16;
        n += 16;
    }
    if (blocks & 1u) { w[n] = next() << 8; w[n + 1] = (u32)around(0, 0x200000); w[n + 2] = (u32)around(0, 0x200000); w[n + 3] = (u32)around(0, 0x200000); n += 4; }
    for (u32 i = 0; i < n; i += 2) put(w[i], w[i + 1]);
}

static void set_tile(u32 tile, u32 format, u32 size, u32 line, u32 at) {
    put(0x35000000u | (format << 21) | (size << 19) | (line << 9) | at,
        (tile << 24) | (below(16) << 20) | (below(2) << 19) | (below(2) << 18) | ((3u + below(4)) << 14) | (below(3) << 10) | (below(2) << 9) | (below(2) << 8) | ((3u + below(4)) << 4) | below(3));
    put(0x32000000u, (tile << 24) | ((31u << 2) << 12) | (31u << 2));
}

static void modes_words(const struct span_mode *k, u32 hi_xor, u32 combine_lo_xor) {
    put(0x3C000000u | k->combine_hi, k->combine_lo ^ combine_lo_xor);
    put(0x2F000000u | (k->hi ^ hi_xor) | ((u32)k->two_cycle << 20) | (below(2) << 23), k->lo);
}

static void one_list(const struct span_mode *k, u32 pass, u32 number) {
    const u32 tile = pass & 7u, levels = 2;
    seed = pass * 0x9E3779B9u + number * 0x85EBCA6Bu + 1u;
    list_at = (volatile u64 *)(0xA0000000u + LIST); list_words = 0;
    put(0x3F000000u | ((u32)k->color_size << 19) | (WIDTH - 1u), IMAGE);
    put(0x3E000000u, DEPTH);
    put(0x2D000000u, ((WIDTH << 2) << 12) | (HEIGHT << 2));
    /* Texture memory: its low half and its high half from the made-up texels, as 16-bit ones. */
    put(0x3D000000u | (2u << 19) | 63u, TEXELS);
    put(0x35000000u | (2u << 19) | (16u << 9), 7u << 24);
    put(0x33000000u, (7u << 24) | (1023u << 12));
    put(0x3D000000u | (2u << 19) | 63u, TEXELS + 2048u);
    put(0x35000000u | (2u << 19) | (16u << 9) | 256u, 6u << 24);
    put(0x33000000u, (6u << 24) | (1023u << 12));
    for (u32 i = 0; i < 4u; i++) {
        const int second = i == 1 && k->two_cycle && !k->one_kind;
        set_tile((tile + i) & 7u, second ? k->format1 : k->format0, second ? k->size1 : k->size0, 2u + below(4), below(64));
    }
    put(0x38000000u, next() << 8 | below(256)); put(0x39000000u, next() << 8 | below(256));
    put(0x3A000000u | (below(32) << 8) | below(256), next() << 8 | below(256)); put(0x3B000000u, next() << 8 | below(256));
    put(0x2E000000u, (below(0x8000u) << 16) | (1u << below(16)));
    put(0x2C000000u | below(0x400000u), next() << 8); put(0x2A000000u | below(0x1000000u), next() << 8); put(0x2B000000u, below(0x10000000u));
    modes_words(k, 0, 0);
    for (u32 i = 0; i < 10u; i++) triangle(i < 6u ? 7u : below(8), tile, levels);
    put(0x24000000u | (((40u + below(40)) << 2) << 12) | ((30u + below(30)) << 2), (tile << 24) | ((below(30) << 2) << 12) | (below(24) << 2));
    put(next() << 8, (((u32)around(0x400, 0x300) & 0xFFFFu) << 16) | ((u32)around(0x400, 0x300) & 0xFFFFu));
    put(0x36000000u | (((50u + below(40)) << 2) << 12) | ((40u + below(30)) << 2), ((below(40) << 2) << 12) | (below(30) << 2));
    put(0x3B000000u, next() << 8 | below(256));

    /* Beside the mode: another input in the second cycle's colour (its D taken from the other end of its list). */
    put(0x27000000u, 0u);
    modes_words(k, 0, 7u << 6);
    triangle(7u, tile, levels); triangle(7u, tile, levels);
    /* Beside the mode: a tile the level of detail can reach is of another kind. */
    put(0x27000000u, 0u);
    set_tile((tile + 2u) & 7u, k->format0 ^ 2u, k->size0 ^ 1u, 3u, 8u);
    modes_words(k, 0, 0);
    triangle(7u, tile, levels); triangle(7u, tile, levels);
    /* The tile just beyond the primitives' levels of another kind, and the one before it the mode's again. */
    put(0x27000000u, 0u);
    set_tile((tile + 2u) & 7u, k->format0, k->size0, 3u, 8u);
    set_tile((tile + 3u) & 7u, k->format0 ^ 2u, k->size0 ^ 1u, 3u, 16u);
    modes_words(k, 0, 0);
    triangle(7u, tile, levels); triangle(7u, tile, levels);
    /* Beside the mode: an image of 8 bits a pixel, which takes up the hidden bits last written at a place. */
    put(0x27000000u, 0u);
    put(0x3F000000u | (1u << 19) | (WIDTH - 1u), IMAGE);
    triangle(7u, tile, levels); triangle(5u, tile, levels);
    put(0x29000000u, 0u);

    DP_STATUS = 0x0015u;                                        /* not frozen, not flushing, commands from main memory */
    MI_MODE = 0x0800u;                                          /* takes back the DP's interrupt */
    DP_START = LIST;
    DP_END = LIST + list_words * 8u;
    u32 guard = 0;
    while (!(MI_INTR & 0x20u) && guard < 20000000u) guard++;
    MI_MODE = 0x0800u;
}

static u32 sum_of(u32 at, u32 bytes) {
    u32 sum = 0;
    for (u32 i = 0; i < bytes; i += 4) sum = (sum << 1 | sum >> 31) ^ REG32(0xA0000000u + at + i);
    return sum;
}

void probe_main(void) {
    if (0) say_tail("SPANS");                                   /* the probe has no end: its last line is never said */
    say_head("SPANS");
    /* The images and the texels start as made-up bytes, so that depths pass and fail and colours blend from the first pass. */
    seed = 1;
    for (u32 i = 0; i < WIDTH * HEIGHT * 2u; i += 4) { REG32(0xA0000000u + IMAGE + i) = next() << 8 | below(256); REG32(0xA0000000u + DEPTH + i) = next() << 8 | below(256); }
    for (u32 i = 0; i < 4096u; i += 4) REG32(0xA0000000u + TEXELS + i) = next() << 8 | below(256);
    for (u32 pass = 0; ; pass++) {
        for (u32 n = 0; n < SPAN_MODES; n++) one_list(&span_modes[n], pass, n);
        say_text("SPANS pass"); say_hex(pass, 8); say_hex(sum_of(IMAGE, WIDTH * HEIGHT * 2u), 8); say_hex(sum_of(DEPTH, WIDTH * HEIGHT * 2u), 8); say_flush();
    }
}
