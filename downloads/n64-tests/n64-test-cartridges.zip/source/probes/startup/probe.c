/* The start-up probe: a small test cartridge for a real console.

   A boot code has to set the memory chips up before main memory answers at all: reset them, set
   their delays, give each its place, enable it, and find the output current at which its data
   comes back whole. This probe runs after the open boot code has done that, and prints what the
   boot code left behind: the RI's registers, every register of every memory chip, and what main
   memory answers megabyte by megabyte. It writes nothing to the chips' registers.

   Run here, the same lines show what this core holds after the same boot code. Where the two
   logs differ, the core's picture of the chips is wrong.

   V  the MI's version
   S  the memory size the boot code stored
   I  the RI's eight registers
   M  megabyte, the word read back there after writing a mark, the word read with nothing written
   C  place, the chip's registers 0 to 9, the odd-numbered ones read through the MI's upper mode
   N  place, the same ten read plainly
   W  place, the words at 0x200, 0x204, 0x240 and 0x40 of the chip's window, and registers 10 to 15 OR-ed
   B  two reads from the window that writes to every chip at once
   E  the RI's error register: after a write to it, after a read from a place no chip is at, after a read a chip answers
   X  three reads from places above main memory where consoles are known to show stray values
   L  a 64-bit read of a chip's first register */

#include "../cart-lib/say.h"

#define MI_VERSION REG32(0xA4300004u)
#define RI_REG(n) REG32(0xA4700000u + (n) * 4u)
#define CHIP_WORD(place, offset) REG32(0xA3F00000u + ((place) << 10) + (offset))
#define MEMORY(address) REG32(0xA0000000u + (address))

/* A chip sends a register in the first half of a 64-bit bus word. A 32-bit read of an
   odd-numbered register takes the other half unless the MI is told to hand over the first. */
static u32 chip_read(u32 place, u32 offset, int through_upper_mode) {
    if (through_upper_mode) MI_MODE = 0x2000u;
    u32 v = CHIP_WORD(place, offset);
    if (through_upper_mode) MI_MODE = 0x1000u;
    return v;
}

void probe_main(void) {
    say_head("RIPROBE");

    say_text("V"); say_hex(MI_VERSION, 8); say_flush();
    say_text("S"); say_hex(REG32(0x80000318u), 8); say_flush();
    say_text("I"); for (u32 r = 0; r < 8; r++) say_hex(RI_REG(r), 8); say_flush();

    /* Main memory, megabyte by megabyte, well away from this program and its stack. */
    for (u32 mb = 0; mb < 16; mb++) {
        u32 at = (mb << 20) + 0xE0000u;
        u32 before = MEMORY(at);
        MEMORY(at) = 0xA5C30000u | mb;
        u32 after = MEMORY(at);
        MEMORY(at) = before;
        say_text("M"); say_hex(mb, 2); say_hex(after, 8); say_hex(before, 8); say_flush();
    }

    /* The chips: four of 2 MiB at most, each answering at two places because it does not look at
       the lowest bit of its place. Places 8 and 9 have no chip behind them. */
    for (u32 place = 0; place < 10; place++) {
        say_text("C"); say_hex(place, 2);
        for (u32 r = 0; r < 10; r++) say_hex(chip_read(place, r * 4, r & 1), 8);
        say_flush();
        say_text("N"); say_hex(place, 2);
        for (u32 r = 0; r < 10; r++) say_hex(chip_read(place, r * 4, 0), 8);
        say_flush();
    }
    for (u32 place = 0; place < 8; place += 2) {
        u32 rest = 0;
        for (u32 r = 10; r < 16; r++) rest |= chip_read(place, r * 4, r & 1);
        say_text("W"); say_hex(place, 2);
        say_hex(chip_read(place, 0x200, 0), 8); say_hex(chip_read(place, 0x204, 1), 8);
        say_hex(chip_read(place, 0x240, 0), 8); say_hex(chip_read(place, 0x40, 0), 8); say_hex(rest, 8);
        say_flush();
    }
    say_text("B"); say_hex(REG32(0xA3F80000u), 8); say_hex(REG32(0xA3F80008u), 8); say_flush();

    {
        RI_REG(6) = 0;
        u32 after_write = RI_REG(6);
        (void)chip_read(20, 0, 0);
        u32 after_miss = RI_REG(6);
        (void)chip_read(0, 0, 0);
        u32 after_hit = RI_REG(6);
        say_text("E"); say_hex(after_write, 8); say_hex(after_miss, 8); say_hex(after_hit, 8); say_flush();
    }

    say_text("X"); say_hex(MEMORY(0x00801400u), 8); say_hex(MEMORY(0x00880000u), 8); say_hex(MEMORY(0x02001400u), 8); say_flush();

    {
        u64 wide = *(volatile u64 *)0xA3F00000u;
        say_text("L"); say_hex(wide, 16); say_flush();
    }

    say_tail("RIPROBE");
}
