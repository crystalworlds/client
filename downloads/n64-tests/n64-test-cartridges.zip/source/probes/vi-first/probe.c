/* The VI's first interrupt probe: a small test cartridge for a real console.

   How long after the VI is turned on does its interrupt line show in the MI, when the VI is set
   to interrupt at half-line 2? One program was seen to turn the VI on, with the registers below,
   and to run on into a stretch of its own code that must not be interrupted too late: on this
   core the interrupt's line and the store that masks it fall four ticks apart. Only a console
   can say on which side they fall.

   A trial: the VI is switched off and left off for a while; its registers are written as that
   program writes them (a PAL console's low-resolution mode); the interrupt is taken back; then,
   in one stretch of instructions that is the same in every trial, the control register is
   written (the VI is on), a loop of three instructions runs k times, n more instructions that do
   nothing follow (n is 0, 1 or 2), and the MI's interrupt register is read once. The trial says
   whether the VI's line was up in that read. COUNT is read just before the store and just after
   the read.

   For each n the probe looks for the smallest k at which the line is up, three times over. A step
   of k is three CPU cycles and a step of n one, so the three answers together place the moment to
   one CPU cycle, in units a console and this core count alike: the same instructions from the
   same cached place.

   Lines, each through the debug text window a flash cartridge shows on the computer beside the
   console:
     V n r k count     for n and the r-th try: the smallest k at which the line was up, and
                       COUNT's steps over that trial
     U n r k count     the trial one k below it (the line not yet up), and its COUNT's steps
     VIFIRST END       the last line, with the count of lines and their fold

   The registers are a PAL console's; on a console of another television type the VI runs them
   as given, and the answer is that console's for these registers. The sound output is not used.

   Care for the console: ordinary register values of a mode games use; the VI is switched on and
   off some two hundred times, a few lines each; no interrupt is let through to the CPU. */

#include "../cart-lib/say.h"

#define VI ((volatile u32 *)0xA4400000u)

static void wait_a_while(void) { for (volatile u32 i = 0; i < 40000u; i++) { } }

static void set_up(void) {
    VI[0] = 0u;                                             /* off */
    wait_a_while();
    VI[1] = 0x0000027Fu; VI[2] = 0x00000140u;               /* origin, width */
    VI[5] = 0x0404233Au; VI[6] = 0x00000271u; VI[7] = 0x00150C69u; VI[8] = 0x0C6F0C6Eu;
    VI[9] = 0x00000000u; VI[10] = 0x005F0239u; VI[11] = 0x0009026Bu;
    VI[3] = 0x00000002u;                                    /* interrupt at half-line 2 */
    VI[12] = 0x00000200u; VI[13] = 0x00000400u;
    VI[4] = 0u;                                             /* takes the interrupt back */
}

/* One trial with n instructions that do nothing behind the loop. 1 when the VI's line was up. */
#define TRIAL(name, nops) \
    static u32 __attribute__((noinline, aligned(32))) name(u32 k, u32 *count) { \
        u32 v, c0, c1; \
        __asm__ volatile(".set push\n.set noreorder\n" \
            "mfc0 %[c0], $9\n" "sw %[ctrl], 0(%[vi])\n" \
            "1: addiu %[k], %[k], -1\n" "bnez %[k], 1b\n" "nop\n" nops \
            "lw %[v], 8(%[mi])\n" "mfc0 %[c1], $9\n" ".set pop" \
            : [v] "=&r"(v), [c0] "=&r"(c0), [c1] "=&r"(c1), [k] "+r"(k) \
            : [ctrl] "r"(0x0000311Eu), [vi] "r"(0xA4400000u), [mi] "r"(0xA4300000u)); \
        *count = c1 - c0; \
        return (v >> 3) & 1u; \
    }
TRIAL(trial_0, "")
TRIAL(trial_1, "nop\n")
TRIAL(trial_2, "nop\nnop\n")

static u32 trial(u32 n, u32 k, u32 *count) {
    set_up();
    const u32 up = n == 0 ? trial_0(k, count) : n == 1 ? trial_1(k, count) : trial_2(k, count);
    VI[0] = 0u; VI[4] = 0u;
    return up;
}

void probe_main(void) {
    say_head("VIFIRST");
    u32 count = 0;
    for (u32 n = 0; n < 3; n++) (void)trial(n, 100, &count);           /* the three stretches are in the cache from here on */
    for (u32 n = 0; n < 3; n++) for (u32 r = 0; r < 3; r++) {
        u32 low = 500, high = 4000;                                     /* not up at low, up at high */
        while (high - low > 1u) { const u32 mid = (low + high) / 2u; if (trial(n, mid, &count)) high = mid; else low = mid; }
        const u32 up = trial(n, high, &count);
        say_text(up ? "V" : "V?"); say_hex(n, 1); say_hex(r, 1); say_hex(high, 4); say_hex(count, 6); say_flush();
        const u32 below = trial(n, high - 1u, &count);
        say_text(below ? "U?" : "U"); say_hex(n, 1); say_hex(r, 1); say_hex(high - 1u, 4); say_hex(count, 6); say_flush();
    }
    say_tail("VIFIRST");
}
