# Timed loops for the VI probe. Each runs for a stretch of time measured by the
# COUNT register and returns how many turns it made, so the length of one turn
# can be worked out. A turn is: some idle instructions, one read over the bus
# (or none, as a control), a look at COUNT, and the test for the end.
#
#   u32 name(volatile u32 *read_here, u32 count_steps)
#
# Registers are named by number: 4 and 5 are the two arguments, 2 the result.
    .set noreorder
    .set noat
    .text

    .macro timed name, idle, reads
    .globl \name
    .ent \name
\name:
    mfc0  $12, $9
    move  $2, $0
1:
    .rept \idle
    nop
    .endr
    .if \reads
    lw    $13, 0($4)
    .endif
    mfc0  $14, $9
    subu  $15, $14, $12
    sltu  $24, $15, $5
    bnez  $24, 1b
    addiu $2, $2, 1
    jr    $31
    nop
    .end \name
    .endm

    timed vi_turns_read_0, 0, 1
    timed vi_turns_read_1, 1, 1
    timed vi_turns_read_2, 2, 1
    timed vi_turns_read_3, 3, 1
    timed vi_turns_read_4, 4, 1
    timed vi_turns_read_5, 5, 1
    timed vi_turns_read_6, 6, 1
    timed vi_turns_read_7, 7, 1
    timed vi_turns_idle_0, 0, 0
    timed vi_turns_idle_1, 1, 0
    timed vi_turns_idle_2, 2, 0
    timed vi_turns_idle_3, 3, 0
    timed vi_turns_idle_4, 4, 0
    timed vi_turns_idle_5, 5, 0
    timed vi_turns_idle_6, 6, 0
    timed vi_turns_idle_7, 7, 0
