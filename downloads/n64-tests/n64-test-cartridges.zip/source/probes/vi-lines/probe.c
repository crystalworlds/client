/* The VI probe: a small test cartridge for a real console.

   It asks the video chip the questions that no document settles, and prints
   every answer as a line of text through the debug text window a flash
   cartridge shows on the computer beside the console. Run on this core, the
   same lines show what the core does; the two logs are then compared line by
   line.

   What it asks:
     R  what the registers hold when a program starts
     M  which bits of each register can be written and read back
     L  how long a line lasts, counted by the CPU's COUNT register
     P  what the line counter reads across the end of a field, 526 half-lines
     Q  the same with 525 half-lines, where the fields take turns
     S  whether the field bit stays at one after a change from 525 to 526
     T  what the counter does when the field's length is set below it
     O  where the counter stands when the VI is turned on
     I  what the counter reads, and how far into a line it is, when the line
        interrupt comes
     N  whether an interrupt comes at all with the VI off, or with its line
        set beyond the field's length
     B  how many turns of a small loop fit in a fixed time, with the VI off,
        blanked, and sending pictures of several kinds: for a loop that reads
        a VI register, one that reads main memory, and one that reads nothing
     U  how long single reads of main memory take, near the picture and away

   Care for the console: the control register's bit 5 is never set (it is said
   to be able to damage a console), nor its two diagnostic bits; every change
   of mode is made with the VI turned off; the line length is never set to an
   extreme; and every wait has an end. A television will lose and find the
   picture several times while this runs.

   A value with a tilde before it is a time or a count that need not come out
   the same to the last digit. All values are in hex. */

typedef unsigned int u32;

#define PI_STATUS (*(volatile u32 *)0xA4600010u)
#define TEXT_LENGTH (*(volatile u32 *)0xB3FF0014u)
#define TEXT_WINDOW ((volatile u32 *)0xB3FF0020u)
#define VI ((volatile u32 *)0xA4400000u)
#define MI_INTR (*(volatile u32 *)0xA4300008u)
#define MI_MASK (*(volatile u32 *)0xA430000Cu)
#define TV_TYPE (*(volatile u32 *)0xA0000300u)
#define FRAME 0x00200000u                   /* where the pictures are read from: the third megabyte */

enum { CTRL, ORIGIN, WIDTH, V_INTR, V_CURRENT, BURST, V_TOTAL, H_TOTAL, LEAP, H_VIDEO, V_VIDEO, V_BURST, X_SCALE, Y_SCALE };

/* The usual register values of each television standard: 0 PAL, 1 NTSC, 2 MPAL. */
struct usual { u32 burst, v_total, h_total, leap, h_video, v_video, v_burst; };
static const struct usual usual[3] = {
    { 0x0404233Au, 625u, 0x00150C69u, 0x0C6F0C6Eu, 0x00800300u, 0x005F0239u, 0x0009026Bu },
    { 0x03E52239u, 525u, 0x00000C15u, 0x0C150C15u, 0x006C02ECu, 0x002501FFu, 0x000E0204u },
    { 0x04651E39u, 525u, 0x00000C12u, 0x0C190C19u, 0x006C02ECu, 0x002501FFu, 0x000E0204u },
};
static u32 tv;

/* ---- Printing ---------------------------------------------------------------------- */

static char line[200];
static char *at;
static u32 lines, fold;

#include "../debug-text.h"


static void put(const char *s) { while (*s) *at++ = *s++; }
static void hex(u32 v, u32 digits) { for (u32 i = 0; i < digits; i++) { u32 d = (v >> ((digits - 1u - i) * 4u)) & 15u; *at++ = (char)(d < 10u ? '0' + d : 'a' + d - 10u); } }
static void num(u32 v) { *at++ = ' '; hex(v, 8); }
static void about(u32 v) { *at++ = ' '; *at++ = '~'; hex(v, 8); }
static void begin(const char *tag) { at = line; put(tag); }
static void end(void) {
    *at++ = '\n';
    u32 n = (u32)(at - line);
    for (u32 i = 0; i < n; i++) fold = (fold << 5 | fold >> 27) ^ (u32)(unsigned char)line[i];
    debug_text(line, n);
    lines++;
}

/* ---- The VI ------------------------------------------------------------------------ */

static u32 count(void) { u32 v; __asm__ volatile("mfc0 %0, $9" : "=r"(v)); return v; }

static void idle(u32 turns) { for (volatile u32 i = 0; i < turns; i++) { } }

/* Sets a mode with the VI off and then turns it on. `h_video` zero gives a blank picture. */
static void mode(int interlaced, u32 ctrl, u32 h_video, u32 width, u32 x_scale, u32 y_scale) {
    const struct usual *u = &usual[tv];
    VI[CTRL] = 0;
    VI[ORIGIN] = FRAME; VI[WIDTH] = width; VI[V_INTR] = 0x3FFu; VI[BURST] = u->burst;
    VI[V_TOTAL] = interlaced ? u->v_total - 1u : u->v_total; VI[H_TOTAL] = u->h_total; VI[LEAP] = u->leap;
    VI[H_VIDEO] = h_video; VI[V_VIDEO] = u->v_video; VI[V_BURST] = u->v_burst; VI[X_SCALE] = x_scale; VI[Y_SCALE] = y_scale;
    VI[V_CURRENT] = 0;
    VI[CTRL] = ctrl;
}
static void blank(int interlaced) { mode(interlaced, 0x3303u, 0, 320u, 0x200u, 0x400u); }

/* Waits until the line counter reads `value`. Returns 0 if it never does. */
static int until(u32 value) { for (u32 cap = 4000000u; cap; cap--) if (VI[V_CURRENT] == value) return 1; return 0; }

/* Notes the next `n` changes of the line counter. Returns how many it saw before giving up. */
static u32 seq[1500];
static u32 changes(u32 n) {
    u32 last = VI[V_CURRENT], got = 0;
    for (u32 cap = 12000000u; cap && got < n; cap--) { u32 v = VI[V_CURRENT]; if (v != last) { seq[got++] = v; last = v; } }
    return got;
}

/* Prints what the counter read on either side of the places where it went down: up to `wraps` of them. */
static void around_wraps(const char *tag, u32 got, u32 wraps) {
    u32 seen = 0, last_wrap = 0, highest = 0;
    for (u32 i = 0; i < got; i++) if (seq[i] > highest) highest = seq[i];
    for (u32 i = 3; i + 3 <= got && seen < wraps; i++) {
        if (seq[i] >= seq[i - 1]) continue;
        begin(tag); num(seen); num(seq[i - 3]); num(seq[i - 2]); num(seq[i - 1]); num(seq[i]); num(seq[i + 1]); num(seq[i + 2]);
        num(seen ? i - last_wrap : 0);              /* line starts since the wrap before */
        end();
        last_wrap = i; seen++;
    }
    begin(tag); put(" end"); num(seen); num(got); num(highest); end();
}

/* ---- The timed loops (loops.S) -------------------------------------------------------- */

typedef u32 (*turns_fn)(volatile u32 *read_here, u32 count_steps);
u32 vi_turns_read_0(volatile u32 *, u32); u32 vi_turns_read_1(volatile u32 *, u32); u32 vi_turns_read_2(volatile u32 *, u32); u32 vi_turns_read_3(volatile u32 *, u32);
u32 vi_turns_read_4(volatile u32 *, u32); u32 vi_turns_read_5(volatile u32 *, u32); u32 vi_turns_read_6(volatile u32 *, u32); u32 vi_turns_read_7(volatile u32 *, u32);
u32 vi_turns_idle_0(volatile u32 *, u32); u32 vi_turns_idle_1(volatile u32 *, u32); u32 vi_turns_idle_2(volatile u32 *, u32); u32 vi_turns_idle_3(volatile u32 *, u32);
u32 vi_turns_idle_4(volatile u32 *, u32); u32 vi_turns_idle_5(volatile u32 *, u32); u32 vi_turns_idle_6(volatile u32 *, u32); u32 vi_turns_idle_7(volatile u32 *, u32);
static const turns_fn with_read[8] = { vi_turns_read_0, vi_turns_read_1, vi_turns_read_2, vi_turns_read_3, vi_turns_read_4, vi_turns_read_5, vi_turns_read_6, vi_turns_read_7 };
static const turns_fn without[8] = { vi_turns_idle_0, vi_turns_idle_1, vi_turns_idle_2, vi_turns_idle_3, vi_turns_idle_4, vi_turns_idle_5, vi_turns_idle_6, vi_turns_idle_7 };

/* One read of main memory without the cache, timed by COUNT (a step of which is two CPU cycles). */
static u32 one_read(volatile u32 *here) {
    u32 a, b;
    __asm__ volatile(".set push\n\t.set noreorder\n\tmfc0 %0, $9\n\tlw $0, 0(%2)\n\tmfc0 %1, $9\n\t.set pop" : "=&r"(a), "=&r"(b) : "r"(here));
    return b - a;
}

/* The five ways the VI is set for the loops: off; on and blank; and three pictures. */
static void setting(u32 which) {
    switch (which) {
    case 0: blank(0); VI[CTRL] = 0; break;
    case 1: blank(0); break;
    case 2: mode(0, 0x311Eu, usual[tv].h_video, 320u, 0x200u, 0x400u); break;      /* 16 bits, anti-aliased, divot, gamma and its dither: the usual game mode */
    case 3: mode(0, 0x3203u, usual[tv].h_video, 320u, 0x200u, 0x400u); break;      /* 32 bits, 320 wide, resampled only */
    default: mode(0, 0x3203u, usual[tv].h_video, 640u, 0x400u, 0x800u); break;     /* 32 bits, 640 wide */
    }
}

void probe_main(void) {
    u32 prid;
    __asm__ volatile("mfc0 %0, $15" : "=r"(prid));
    MI_MASK = 0x555u;                           /* no interrupt of the RCP reaches the CPU: the probe looks at the lines itself */
    tv = TV_TYPE & 3u;
    if (tv > 2u) tv = 1u;
    begin("VIPROBE 1 TV"); num(tv); put(" PRID"); num(prid); end();

    /* R: the registers as a program finds them. */
    for (u32 r = 0; r < 14u; r++) { begin("V R"); num(r); num(VI[r]); end(); }

    /* M: what can be written. With the VI off. The control register is given only bits the documents
       name, with its pixel type at zero and its three bits that are never to be set clear; the others
       are given every bit; the line length is never left short. */
    VI[CTRL] = 0;
    {
        static const unsigned char regs[12] = { 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13 };
        VI[CTRL] = 0x0001F35Cu; u32 a = VI[CTRL]; VI[CTRL] = 0x0001A200u; u32 b = VI[CTRL]; VI[CTRL] = 0;
        begin("V M"); num(0); num(a); num(b); end();
        for (u32 i = 0; i < 12u; i++) {
            u32 r = regs[i], old = VI[r];
            VI[r] = 0xFFFFFFFFu; a = VI[r];
            VI[r] = r == H_TOTAL ? 0x00150C69u : 0xA5A5A5A5u; b = VI[r];
            VI[r] = old;
            begin("V M"); num(r); num(a); num(b); end();
        }
    }

    /* A picture to read: stripes, written past the cache. */
    for (u32 y = 0; y < 482u; y++) for (u32 x = 0; x < 640u; x++)
        *(volatile u32 *)(0xA0000000u + FRAME + (y * 640u + x) * 4u) = (((x >> 3) ^ (y >> 3)) & 1u) ? 0x808080FFu : 0x202040FFu;

    /* L: sixteen lines, in steps of COUNT. */
    blank(0);
    if (until(0x20u)) {
        u32 got = changes(1); u32 t0 = count(); got += changes(16); u32 t1 = count();
        begin("V L"); num(got); about(t1 - t0); end();
    } else { begin("V L none"); end(); }

    /* P: across the end of a field of 526 half-lines (626 for PAL). */
    if (until(0x20u)) around_wraps("V P", changes(usual[tv].v_total + 80u), 2); else { begin("V P none"); end(); }

    /* Q: across the end of a field of 525 half-lines (625), where the fields take turns. */
    blank(1);
    if (until(0x20u) || until(0x21u)) around_wraps("V Q", changes(usual[tv].v_total + 80u < 1500u ? usual[tv].v_total + 80u : 1500u), 3); else { begin("V Q none"); end(); }

    /* S: in the field with odd readings, back to 526 half-lines: do the readings stay odd? */
    if (until(0x101u)) {
        VI[V_TOTAL] = usual[tv].v_total;
        u32 got = changes(usual[tv].v_total + 40u), odd = 0;
        for (u32 i = 0; i < got; i++) odd += seq[i] & 1u;
        around_wraps("V S", got, 2);
        begin("V S odd"); num(odd); num(got); end();
    } else { begin("V S none"); end(); }

    /* T: the field's length set below the counter. */
    blank(0);
    if (until(300u)) {
        VI[V_TOTAL] = 199u;
        u32 got = changes(600u), wrap = 0;
        for (u32 i = 1; i < got && !wrap; i++) if (seq[i] < seq[i - 1]) wrap = i;
        begin("V T"); num(got > 3u ? seq[0] : 0); num(got > 3u ? seq[1] : 0); num(got > 3u ? seq[2] : 0); num(got > 3u ? seq[3] : 0);
        num(wrap ? seq[wrap - 1] : 0xFFFFFFFFu); num(wrap ? seq[wrap] : 0xFFFFFFFFu); num(wrap); end();
    } else { begin("V T none"); end(); }

    /* O: off, the counter stands; turned on, where does it start and when does it first move? */
    VI[CTRL] = 0;
    {
        u32 a = VI[V_CURRENT]; idle(20000u); u32 b = VI[V_CURRENT];
        blank(0);
        u32 t0 = count(), v0 = VI[V_CURRENT], v1 = v0, v2, t1 = t0, t2;
        for (u32 cap = 400000u; cap && v1 == v0; cap--) { v1 = VI[V_CURRENT]; t1 = count(); }
        v2 = v1; t2 = t1;
        for (u32 cap = 400000u; cap && v2 == v1; cap--) { v2 = VI[V_CURRENT]; t2 = count(); }
        begin("V O"); num(a); num(b); num(v0); num(v1); about(t1 - t0); num(v2); about(t2 - t1); end();
    }

    /* I: the line interrupt. For each case, four interrupts: what the counter reads, how many steps of
       COUNT since the counter was last seen to change, and whether it had changed again by the time
       the interrupt was seen. */
    for (u32 interlaced = 0; interlaced < 2u; interlaced++) {
        static const u32 at_line[4] = { 0x00Eu, 0x00Fu, 0x000u, 0x002u };
        for (u32 c = 0; c < 4u; c++) {
            u32 v[4], dt[4], moved[4], got = 0;
            blank((int)interlaced);
            VI[V_INTR] = at_line[c];
            VI[V_CURRENT] = 0;
            u32 last = VI[V_CURRENT], t_line = count();
            for (u32 cap = 6000000u; cap && got < 4u; cap--) {
                u32 now = VI[V_CURRENT];
                if (now != last) { last = now; t_line = count(); }
                if (MI_INTR & 8u) {
                    u32 t = count(), then = VI[V_CURRENT];
                    v[got] = then; dt[got] = t - t_line; moved[got] = then != last; got++;
                    VI[V_CURRENT] = 0;
                    if (then != last) { last = then; t_line = t; }
                }
            }
            begin("V I"); num(interlaced); num(at_line[c]); num(got);
            for (u32 i = 0; i < got; i++) { num(v[i]); about(dt[i]); num(moved[i]); }
            end();
        }
    }

    /* N: for a little over two fields' time, does the interrupt show? With the VI off and its line at
       zero; with the VI on and its line beyond the field; and, as a control, with the line in reach. */
    for (u32 c = 0; c < 3u; c++) {
        blank(0);
        if (c == 0) { VI[CTRL] = 0; VI[V_INTR] = 0; } else VI[V_INTR] = c == 1 ? 0x3FFu : 0x100u;
        VI[V_CURRENT] = 0;
        u32 seen = 0, t0 = count();
        while (count() - t0 < 1600000u) seen |= MI_INTR & 8u;
        begin("V N"); num(c); num(seen); end();
        VI[V_CURRENT] = 0;
    }

    /* B: turns of a loop in 750,000 steps of COUNT (about 256 lines), for each setting of the VI, each
       kind of read, and from none to seven idle instructions in a turn. */
    for (u32 k = 0; k < 8u; k++) { with_read[k](&VI[V_INTR], 1u); without[k](&VI[V_INTR], 1u); }       /* once each, so that no timed run is the first to bring its loop into the cache */
    for (u32 s = 0; s < 5u; s++) {
        setting(s);
        idle(200000u);
        for (u32 kind = 0; kind < 4u; kind++) {
            volatile u32 *here = kind == 0 ? &VI[V_INTR] : kind == 1 ? (volatile u32 *)(0xA0000000u + FRAME + 0x1000u) : (volatile u32 *)0xA0100000u;
            for (u32 k = 0; k < 8u; k++) {
                u32 turns = (kind == 3 ? without[k] : with_read[k])(here, 750000u);
                begin("V B"); num(s); num(kind); num(k); about(turns); end();
            }
        }
    }

    /* U: two hundred single reads of main memory without the cache, each timed: the least, the middle
       one, the most, and their sum, in steps of COUNT. Near the picture and a megabyte away; at the
       start of a field (where no picture is being sent) and well into it. */
    for (u32 s = 0; s < 5u; s++) {
        setting(s);
        idle(200000u);
        for (u32 where = 0; where < 2u; where++) for (u32 when = 0; when < (s ? 2u : 1u); when++) {
            volatile u32 *here = where ? (volatile u32 *)0xA0100000u : (volatile u32 *)(0xA0000000u + FRAME + 0x1000u);
            static u32 seen[256];
            u32 least = 0xFFFFFFFFu, most = 0, sum = 0, middle = 0, reached = 1;
            for (u32 i = 0; i < 256u; i++) seen[i] = 0;
            if (s) reached = (u32)until(when ? 0x100u : 0x004u);
            for (u32 i = 0; i < 200u; i++) { u32 d = one_read(here); if (d < least) least = d; if (d > most) most = d; sum += d; seen[d < 255u ? d : 255u]++; }
            for (u32 d = 0, n = 0; d < 256u; d++) { n += seen[d]; if (n >= 100u) { middle = d; break; } }
            begin("V U"); num(s); num(where); num(when); num(reached); about(least); about(middle); about(most); about(sum); end();
        }
    }

    VI[CTRL] = 0;
    begin("VIPROBE END"); num(lines); num(fold); end();
}
