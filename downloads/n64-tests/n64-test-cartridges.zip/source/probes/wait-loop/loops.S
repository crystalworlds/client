# The wait-loop probe's assembly: the exception stub and the loops that wait.

    .set noreorder
    .set noat
    .text

# ---- The exception stub ---------------------------------------------------------
# Copied to the three exception vectors. It notes COUNT before anything else, then
# where and why it was called and the register the loops count their turns in, puts
# the timer's next request far away (which also takes back the one that may have
# brought it here), shuts every interrupt out, and goes on at the address the probe
# left in resume_at.
    .globl vector_stub
    .globl vector_stub_end
vector_stub:
    mfc0  $k1, $9
    lui   $k0, %hi(stamp)
    sw    $k1, %lo(stamp)($k0)
    mfc0  $k1, $14
    lui   $k0, %hi(seen_epc)
    sw    $k1, %lo(seen_epc)($k0)
    mfc0  $k1, $13
    lui   $k0, %hi(seen_cause)
    sw    $k1, %lo(seen_cause)($k0)
    lui   $k0, %hi(seen_turns)
    sw    $t0, %lo(seen_turns)($k0)
    mfc0  $k1, $9
    addiu $k1, $k1, -1
    mtc0  $k1, $11
    lui   $k0, %hi(resume_at)
    lw    $k1, %lo(resume_at)($k0)
    nop
    mtc0  $k1, $14
    mfc0  $k1, $12
    srl   $k1, $k1, 1
    sll   $k1, $k1, 1
    mtc0  $k1, $12
    nop
    nop
    eret
vector_stub_end:

# ---- The loops that wait ----------------------------------------------------------
# u32 wait_X(u32 status_bits, u32 one_more): the bits are set in Status (the interrupts to let
# through, and the bit that lets any through), then the loop turns until an interrupt takes the
# CPU away; the stub comes back behind the loop. With one_more not zero, one instruction more
# runs before the loop, so that the loop's two instructions fall on the other cycles. Returns
# the turns counted in the delay slot, for the loop that counts.
    .macro wait_head name
    .globl \name
    .globl \name\()_loop
    .globl \name\()_back
\name:
    mfc0  $t2, $12
    or    $t2, $t2, $a0
    li    $t0, 0
    li    $t3, 7
    beqz  $a1, 1f
    nop
    nop
1:  mtc0  $t2, $12
    .endm

    .macro wait_tail name
\name\()_back:
    jr    $ra
    move  $v0, $t0
    .endm

# A branch to itself, written as the assembler writes "b": a register compared with itself.
    wait_head wait_b
wait_b_loop:
    b     wait_b_loop
    nop
    wait_tail wait_b

# A jump to its own address.
    wait_head wait_j
wait_j_loop:
    j     wait_j_loop
    nop
    wait_tail wait_j

# A branch on a register other than the one that is always zero, compared with itself.
    wait_head wait_r
wait_r_loop:
    beq   $t3, $t3, wait_r_loop
    nop
    wait_tail wait_r

# A loop that does not only wait: its delay slot counts the turns.
    wait_head wait_count
wait_count_loop:
    b     wait_count_loop
    addiu $t0, $t0, 1
    wait_tail wait_count

# A loop of three instructions: a branch back over an empty instruction, and its delay slot.
    wait_head wait_three
wait_three_loop:
    nop
    b     wait_three_loop
    nop
    wait_tail wait_three

# ---- The TLB ------------------------------------------------------------------------
# void tlb_load(u32 index, u32 entry_hi, u32 entry_lo0, u32 entry_lo1): the four registers an
# entry is written from, with the page size of 4 KiB. Nothing is written to the TLB.
    .globl tlb_load
tlb_load:
    mtc0  $a0, $0
    mtc0  $a1, $10
    mtc0  $a2, $2
    mtc0  $a3, $3
    mtc0  $zero, $5
    nop
    jr    $ra
    nop

# void tlb_write_indexed(void): the entry the index register names is written from them.
    .globl tlb_write_indexed
tlb_write_indexed:
    nop
    tlbwi
    nop
    nop
    jr    $ra
    nop
