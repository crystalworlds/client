/* The wait-loop probe: what a program sees when it waits for an interrupt in a loop of two
   instructions, a branch to itself and an empty delay slot, as games do when they have nothing
   to do.

   The probe was written for the emulator's own use: a faster road through such a loop must
   leave the machine exactly as the loop leaves it turn by turn, and these are the cases that
   road has to get right. It asks a console nothing new and has no console record (it leaves
   the TLB's other entries as it finds them, which only the emulator's start makes safe).

   Each line is one wait, in hex:

     T  the timer's interrupt ends the wait. The loop's form (b: a branch as the assembler
        writes it; j: a jump to its own address; r: a branch on another register compared with
        itself; c: a loop whose delay slot counts its turns; 3: a loop of three instructions;
        m: a loop on a page reached through the TLB), whether one instruction more ran before
        the loop, and how far ahead COMPARE was set; then COUNT in the handler's first
        instruction less COMPARE, where the handler was called away from (less the loop's
        address), the mark that this was a delay slot, the interrupt lines in Cause, and the
        turns the counting loop counted.
     S  the RSP's interrupt ends it: the RSP counts down in a loop of its own and stops.
     P  the cartridge bus's interrupt ends it: a DMA from the cartridge.
     I  the SI's interrupt ends it: a read of the PIF's 64 bytes.
     D  the RDP's interrupt ends it: a list of a few syncs of the pipe and a full sync.
     U  the AI's interrupt ends it: a short buffer of silence handed to it.
     V  the VI's interrupt at a line ends it, or the timer after two fields if none comes: twice
        with the video chip's picture off, three times with a picture on.
     B  an interrupt ends it while the RSP runs on beside (the SI's, then the cartridge bus's).
     A  whichever comes first of four that are under way at once.
     M  a routine on a page reached through the TLB writes the TLB entry of its own page, so
        that the page maps other memory from its next fetch on: what the routine returns says
        which memory each of its later instructions came from.

   Nothing here can harm a console: the picture's timing is an NTSC console's own, and every
   wait has an end. */

typedef unsigned int u32;

#define REG(a) (*(volatile u32 *)(a))
#define MI_MODE REG(0xA4300000u)
#define MI_INTR REG(0xA4300008u)
#define MI_MASK REG(0xA430000Cu)
#define SP_STATUS REG(0xA4040010u)
#define SP_PC REG(0xA4080000u)
#define IMEM ((volatile u32 *)0xA4001000u)
#define DP_START REG(0xA4100000u)
#define DP_END REG(0xA4100004u)
#define DP_STATUS REG(0xA410000Cu)
#define VI ((volatile u32 *)0xA4400000u)        /* control, origin, width, the interrupt's line, the current line, burst, lines, line length, leap, and the picture's place and scale */
#define VI_CTRL VI[0]
#define AI_ADDR REG(0xA4500000u)
#define AI_LEN REG(0xA4500004u)
#define AI_CONTROL REG(0xA4500008u)
#define AI_STATUS REG(0xA450000Cu)
#define AI_DACRATE REG(0xA4500010u)
#define AI_BITRATE REG(0xA4500014u)
#define PI_DRAM_ADDR REG(0xA4600000u)
#define PI_CART_ADDR REG(0xA4600004u)
#define PI_WR_LEN REG(0xA460000Cu)
#define PI_STATUS REG(0xA4600010u)
#define SI_DRAM_ADDR REG(0xA4800000u)
#define SI_PIF_AD_RD64B REG(0xA4800004u)
#define SI_STATUS REG(0xA4800018u)
#define PIF_LAST_WORD REG(0xBFC007FCu)
#define UNCACHED(a) ((volatile u32 *)((a) | 0x20000000u))

/* What the exception stub leaves (loops.S). */
volatile u32 stamp, seen_epc, seen_cause, seen_turns, resume_at;

extern char vector_stub[], vector_stub_end[];
extern u32 wait_b(u32, u32), wait_j(u32, u32), wait_r(u32, u32), wait_count(u32, u32), wait_three(u32, u32);
extern char wait_b_loop[], wait_b_back[], wait_j_loop[], wait_j_back[], wait_r_loop[], wait_r_back[], wait_count_loop[], wait_count_back[], wait_three_loop[], wait_three_back[];
extern void tlb_load(u32 index, u32 entry_hi, u32 entry_lo0, u32 entry_lo1), tlb_write_indexed(void);

/* ---- Printing ---------------------------------------------------------------------- */

static char line[200];
static char *at;

#include "../debug-text.h"

static void put(const char *s) { while (*s) *at++ = *s++; }
static void hex(u32 v, u32 digits) { for (u32 i = 0; i < digits; i++) { u32 d = (v >> ((digits - 1u - i) * 4u)) & 15u; *at++ = (char)(d < 10u ? '0' + d : 'a' + d - 10u); } }
static void num(u32 v) { *at++ = ' '; hex(v, 8); }
static void small(u32 v) { *at++ = ' '; hex(v, 4); }
static void begin(const char *tag) { at = line; put(tag); }
static void end(void) { *at++ = '\n'; debug_text(line, (u32)(at - line)); }

/* ---- The waits ----------------------------------------------------------------------- */

struct loop { const char *tag; u32 (*run)(u32, u32); char *turns_at, *back; };
static const struct loop LOOPS[5] = {
    { "b", wait_b, wait_b_loop, wait_b_back }, { "j", wait_j, wait_j_loop, wait_j_back }, { "r", wait_r, wait_r_loop, wait_r_back },
    { "c", wait_count, wait_count_loop, wait_count_back }, { "3", wait_three, wait_three_loop, wait_three_back },
};
#define TIMER 0x8001u           /* the timer's interrupt, and interrupts at all */
#define RCP 0x0401u             /* the RCP's line */

static u32 count(void) { u32 v; __asm__ volatile("mfc0 %0, $9" : "=r"(v)); return v; }
static void compare(u32 v) { __asm__ volatile("mtc0 %0, $11" : : "r"(v)); }

static u32 wait_in(const struct loop *l, u32 status_bits, u32 one_more) { resume_at = (u32)l->back; return l->run(status_bits, one_more); }
static void say(const char *what, const struct loop *l, u32 one_more, u32 setting, u32 base, u32 returned) {
    begin(what); put(" "); put(l->tag); small(one_more); num(setting); num(stamp - base); num(seen_epc - (u32)l->turns_at); small(seen_cause >> 31); small((seen_cause >> 8) & 0xFFu); num(seen_turns); num(returned); end();
}

/* The RSP counts down from `turns` in a loop of its own and stops, with or without its interrupt. */
static void rsp_counts(u32 turns, u32 with_interrupt) {
    IMEM[0] = 0x3C010000u | (turns >> 16);              /* LUI   r1, the upper half */
    IMEM[1] = 0x34210000u | (turns & 0xFFFFu);          /* ORI   r1, r1, the lower half */
    IMEM[2] = 0x1420FFFFu;                              /* BNE   r1, r0, itself */
    IMEM[3] = 0x2021FFFFu;                              /* ADDI  r1, r1, -1 */
    IMEM[4] = 0x0000000Du;                              /* BREAK */
    IMEM[5] = 0;
    SP_PC = 0;
    SP_STATUS = with_interrupt ? 0x0105u : 0x0085u;     /* not halted, not stopped by BREAK, and BREAK asks for the interrupt or does not */
}
static void rsp_stops(void) { SP_STATUS = 0x000Au; }    /* halted, and its interrupt taken back */

static void cart_dma(u32 bytes) { PI_DRAM_ADDR = 0x00300000u; PI_CART_ADDR = 0x10001000u; PI_WR_LEN = bytes - 1u; }
static void pif_read(void) { SI_DRAM_ADDR = 0x00308000u; SI_PIF_AD_RD64B = 0x1FC007C0u; }

/* ---- The page reached through the TLB --------------------------------------------------- */

#define PAGE_ONE 0x00310000u            /* two pages of memory nothing else uses, by their physical addresses */
#define PAGE_TWO 0x00312000u
#define MAPPED 0x00400000u              /* where the TLB shows one of them */
#define ENTRY_LO(page) ((((page) >> 12) << 6) | 0x1Fu)      /* cached, writable, valid, for every address space */

/* The same routine goes to both pages, but for what three of its instructions add:
     +0x00  the result starts at nothing        +0x04  the TLB entry is written
     +0x08, +0x0c, +0x10  three sums            +0x14  return
   and a loop that waits, at +0x40: Status is written, the branch to itself, its delay slot, and
   at +0x4c the return the stub comes back to. */
static void fill_page(u32 page, u32 one, u32 two, u32 three) {
    volatile u32 *p = UNCACHED(page | 0x80000000u);
    for (u32 i = 0; i < 32; i++) p[i] = 0;
    p[0] = 0x24020000u; p[1] = 0x42000002u;
    p[2] = 0x24420000u | one; p[3] = 0x24420000u | two; p[4] = 0x24420000u | three;
    p[5] = 0x03E00008u; p[6] = 0;
    p[16] = 0x40846000u; p[17] = 0x1000FFFFu; p[18] = 0; p[19] = 0x03E00008u; p[20] = 0;
}

void probe_main(void) {
    u32 status;
    while (SI_STATUS & 3u) { }
    PIF_LAST_WORD = 8u;
    while (SI_STATUS & 3u) { }
    MI_MASK = 0x555u;                           /* no interrupt of the RCP reaches the CPU yet */
    VI_CTRL = 0;
    __asm__ volatile("mtc0 %0, $12" : : "r"(0x34000000u));
    __asm__ volatile("mfc0 %0, $12" : "=r"(status));

    /* The stub goes to the three vectors, written without the cache, and their instruction lines are thrown out. */
    for (u32 v = 0; v < 3; v++) {
        u32 to = v == 0 ? 0x80000000u : v == 1 ? 0x80000080u : 0x80000180u;
        const u32 *from = (const u32 *)vector_stub;
        u32 words = (u32)(vector_stub_end - vector_stub) / 4u;
        for (u32 i = 0; i < words; i++) UNCACHED(to)[i] = from[i];
        for (u32 a = to; a < to + words * 4u; a += 32u) __asm__ volatile("cache 0x10, 0(%0)" : : "r"(a));
        __asm__ volatile("cache 0x10, 0(%0)" : : "r"(to + words * 4u - 4u));
    }
    begin("WAITPROBE 1"); num((u32)(vector_stub_end - vector_stub)); end();

    /* T: the timer. Every form of loop, on either cycle, with COMPARE a few steps of COUNT further each time. */
    static const u32 AHEAD[6] = { 80, 81, 82, 83, 600, 5001 };
    for (u32 l = 0; l < 5; l++) for (u32 more = 0; more < 2; more++) for (u32 a = 0; a < 6; a++) {
        u32 to = count() + AHEAD[a];
        compare(to);
        u32 back = wait_in(&LOOPS[l], TIMER, more);
        say("T", &LOOPS[l], more, AHEAD[a], to, back);
    }

    /* S: the RSP's own interrupt, after a few turns and after many. The timer stands behind every wait from here on. */
    static const u32 TURNS[5] = { 40, 41, 42, 300, 5000 };
    for (u32 more = 0; more < 2; more++) for (u32 t = 0; t < 5; t++) {
        u32 from = count();
        compare(from + 3000000u);
        MI_MASK = 0x0002u;
        rsp_counts(TURNS[t], 1);
        u32 back = wait_in(&LOOPS[more], RCP | TIMER, more);
        rsp_stops(); MI_MASK = 0x0001u;
        say("S", &LOOPS[more], more, TURNS[t], from, back);
    }

    /* P: the end of a DMA from the cartridge. */
    static const u32 BYTES[4] = { 0x10, 0x200, 0x201, 0x1000 };
    for (u32 more = 0; more < 2; more++) for (u32 b = 0; b < 4; b++) {
        u32 from = count();
        compare(from + 3000000u);
        MI_MASK = 0x0200u;
        cart_dma(BYTES[b]);
        u32 back = wait_in(&LOOPS[0], RCP | TIMER, more);
        while (PI_STATUS & 3u) { }
        PI_STATUS = 2u; MI_MASK = 0x0100u;
        say("P", &LOOPS[0], more, BYTES[b], from, back);
    }

    /* I: the end of a read of the PIF. */
    for (u32 more = 0; more < 2; more++) for (u32 l = 0; l < 2; l++) {
        u32 from = count();
        compare(from + 3000000u);
        MI_MASK = 0x0008u;
        pif_read();
        u32 back = wait_in(&LOOPS[l], RCP | TIMER, more);
        while (SI_STATUS & 3u) { }
        SI_STATUS = 0; MI_MASK = 0x0004u;
        say("I", &LOOPS[l], more, 0, from, back);
    }

    /* B: an interrupt comes while the RSP runs on beside: the SI's, then the cartridge bus's. */
    for (u32 n = 0; n < 12; n++) {
        u32 from = count();
        compare(from + 3000000u);
        rsp_counts(400000u + n, 0);
        for (u32 i = 0; i < n; i++) __asm__ volatile("nop");
        if (n & 1u) { MI_MASK = 0x0200u; cart_dma(0x400u + n); } else { MI_MASK = 0x0008u; pif_read(); }
        u32 back = wait_in(&LOOPS[n % 3u], RCP | TIMER, (n >> 1) & 1u);
        while ((PI_STATUS & 3u) || (SI_STATUS & 3u)) { }
        PI_STATUS = 2u; SI_STATUS = 0; MI_MASK = 0x0104u;
        rsp_stops();
        say("B", &LOOPS[n % 3u], (n >> 1) & 1u, n, from, back);
    }

    /* A: four things under way at once, and whichever asks first. */
    for (u32 n = 0; n < 6; n++) {
        u32 from = count();
        compare(from + 20000u + n * 7001u);
        MI_MASK = 0x020Au;
        rsp_counts(900u + n * 1100u, 1);
        cart_dma(0x100u << n);
        pif_read();
        u32 back = wait_in(&LOOPS[n % 3u], RCP | TIMER, n & 1u);
        u32 lines = MI_INTR;
        MI_MASK = 0x0555u;
        while ((PI_STATUS & 3u) || (SI_STATUS & 3u)) { }
        PI_STATUS = 2u; SI_STATUS = 0; rsp_stops();
        say("A", &LOOPS[n % 3u], n & 1u, lines, from, back);
    }

    /* M: the page reached through the TLB. First the routine as it stands on each page (it writes the
       entry it already has). Then it writes its own page's entry to show the other page. Then the loop
       that waits, on that page. */
    fill_page(PAGE_ONE, 1, 2, 4);
    fill_page(PAGE_TWO, 0x10, 0x20, 0x40);
    for (u32 n = 0; n < 6; n++) {
        u32 first = (n & 1u) ? PAGE_TWO : PAGE_ONE, then = n < 2 ? first : (n & 1u) ? PAGE_ONE : PAGE_TWO;
        tlb_load(0, MAPPED, ENTRY_LO(first), 1u);
        tlb_write_indexed();
        for (u32 i = 0; i < n; i++) __asm__ volatile("nop");
        tlb_load(0, MAPPED, ENTRY_LO(then), 1u);
        u32 got = ((u32 (*)(void))MAPPED)();
        begin("M"); small(n); num(got); end();
    }
    for (u32 n = 0; n < 4; n++) {
        static const struct loop ON_THE_PAGE = { "m", 0, (char *)(MAPPED + 0x44u), (char *)(MAPPED + 0x4Cu) };
        tlb_load(0, MAPPED, ENTRY_LO((n & 1u) ? PAGE_TWO : PAGE_ONE), 1u);
        tlb_write_indexed();
        u32 to = count() + 400u + n;
        compare(to);
        resume_at = MAPPED + 0x4Cu;
        ((void (*)(u32))(MAPPED + 0x40u))(status | TIMER);
        say("T", &ON_THE_PAGE, 0, 400u + n, to, 0);
    }

    /* D: the RDP's interrupt. The list is a few syncs of the pipe, more each time, and a full sync. */
    for (u32 n = 0; n < 6; n++) {
        volatile u32 *list = UNCACHED(0x80320000u);
        u32 words = 0;
        for (u32 i = 0; i < n * 3u; i++) { list[words++] = 0x27000000u; list[words++] = 0; }
        list[words++] = 0x29000000u; list[words++] = 0;
        u32 from = count();
        compare(from + 3000000u);
        MI_MASK = 0x0800u;
        DP_STATUS = 0x0015u;                    /* not frozen, not flushing, commands from main memory */
        DP_START = 0x00320000u;
        DP_END = 0x00320000u + words * 4u;
        u32 back = wait_in(&LOOPS[n % 3u], RCP | TIMER, n & 1u);
        MI_MODE = 0x0800u; MI_MASK = 0x0400u;
        say("D", &LOOPS[n % 3u], n & 1u, n, from, back);
    }

    /* U: the AI's interrupt. A short buffer of silence, a little longer each time. */
    for (u32 i = 0; i < 0x200u; i++) UNCACHED(0x80330000u)[i] = 0;
    AI_CONTROL = 1; AI_DACRATE = 1103u; AI_BITRATE = 15u; AI_STATUS = 0;
    for (u32 n = 0; n < 4; n++) {
        u32 from = count();
        compare(from + 3000000u);
        MI_MASK = 0x0020u;
        AI_ADDR = 0x00330000u;
        AI_LEN = 0x100u + n * 8u;
        u32 back = wait_in(&LOOPS[n % 3u], RCP | TIMER, n & 1u);
        AI_STATUS = 0; MI_MASK = 0x0010u;
        say("U", &LOOPS[n % 3u], n & 1u, n, from, back);
    }
    AI_CONTROL = 0;

    /* V: the VI's interrupt at a line: twice with the video chip's picture off (the timer ends the wait after two
       fields if the interrupt does not come), then with a picture on, of an NTSC console's own timing. */
    VI[6] = 0x20Du; VI[7] = 0x00000C15u; VI[8] = 0x0C150C15u;
    for (u32 n = 0; n < 5; n++) {
        if (n == 2) {
            VI[1] = 0x00200000u; VI[2] = 320u; VI[5] = 0x03E52239u; VI[9] = 0x006C02ECu; VI[10] = 0x002501FFu; VI[11] = 0x000E0204u;
            VI[12] = 0x200u; VI[13] = 0x400u; VI[4] = 0; VI[0] = 0x00003202u;
        }
        u32 from = count();
        compare(from + 1600000u);
        VI[3] = 0x80u + n * 0x61u;
        VI[4] = 0;
        MI_MASK = 0x0080u;
        u32 back = wait_in(&LOOPS[n % 3u], RCP | TIMER, n & 1u);
        MI_MASK = 0x0040u; VI[4] = 0;
        say("V", &LOOPS[n % 3u], n & 1u, 0x80u + n * 0x61u, from, back);
    }
    VI[0] = 0;

    begin("WAITPROBE END"); end();
}
