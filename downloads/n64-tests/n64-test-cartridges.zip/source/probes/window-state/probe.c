/* The window state probe: a small test cartridge for a real console with a flash cartridge.

   A program built with the open library looks for an emulator's debug text window by writing a
   word at the window's start and reading it back, and where the word comes back the library asks
   its allocator for a buffer, which moves everything the program asks for afterwards. So whether
   a flash cartridge's window takes a write decides where such a program's blocks lie, and with
   that whether the RSP's pair test loses the start of its copy (the data cache line probe). This
   probe asks the cartridge itself, and it can be heard in a run that is listened to without the
   window, where every other probe of ours is silent: it first notes what it finds, then turns
   the window on by the cartridge's own setting, and only then prints. All values are in hex.

     I id        the word that names the cartridge's kind, read after its registers were opened
                 (53437632 for the flash cartridge this probe knows; the lines F, S, G and M
                 come only then)
     F w a e     as found: the cartridge's switch for writes to its game memory, the address it
                 has for the debug window (0: none), and whether either question was refused
     L r1 r2     the library's own two steps, as found: the word edcba987 written at the window's
                 start and read back, then 12345678 written and read back. The library takes the
                 window to be there only if both come back
     S p1 p2 e   the probe's two settings: writes to the game memory on, the window at 0x03ff0000;
                 what each setting was before, and whether either was refused
     G w a e     the two settings read again
     M r1 r2     the library's two steps again

   Nothing depends on the console's television type or on the size of main memory.

   Care for the console and the cartridge: two settings of the cartridge are changed, by its own
   commands, to what its PC tool sets them to when it listens at the window; the cartridge
   forgets them when its power is cut. Four words are written at the window's start, where every
   probe of ours writes. */

#include "../cart-lib/say.h"

#define REGISTERS ((volatile u32 *)0xBFFF0000u)     /* the cartridge's own registers: command, two data words, its kind, the key */
#define WINDOW_START ((volatile u32 *)0xB3FF0000u)
#define THE_KIND 0x53437632u

static u32 reg_get(u32 i) { bus_free(); return REGISTERS[i]; }
static void reg_put(u32 i, u32 v) { bus_free(); REGISTERS[i] = v; }

/* One command to the cartridge: its two arguments, its letter, a wait until it is no longer busy,
   and its second answer. Hands back 0 when it was done, 1 when the cartridge refused it, 2 when
   it never ended. */
static u32 command(u32 letter, u32 first, u32 second, u32 *answer) {
    reg_put(1, first); reg_put(2, second); reg_put(0, letter);
    for (u32 tries = 0; tries < 200000u; tries++) {
        const u32 status = reg_get(0);
        if (!(status & 0x80000000u)) { *answer = reg_get(2); return (status & 0x40000000u) ? 1u : 0u; }
    }
    *answer = 0;
    return 2u;
}

/* The library's two steps: what reads back after each of its two writes. */
static void two_steps(u32 *first, u32 *second) {
    bus_free(); *WINDOW_START = 0xEDCBA987u; bus_free(); *first = *WINDOW_START;
    bus_free(); *WINDOW_START = 0x12345678u; bus_free(); *second = *WINDOW_START;
    bus_free();
}

void probe_main(void) {
    /* Everything is noted before the first text: a text needs the window. */
    reg_put(4, 0u); reg_put(4, 0x5F554E4Cu); reg_put(4, 0x4F434B5Fu);      /* the key that opens the cartridge's registers */
    const u32 kind = reg_get(3);
    const u32 known = kind == THE_KIND;
    u32 writes = 0, window = 0, refused = 0, before1 = 0, before2 = 0, refused_set = 0, writes_now = 0, window_now = 0, refused_now = 0;
    u32 r1, r2, m1 = 0, m2 = 0;
    if (known) refused = command('c', 1u, 0u, &writes) | command('c', 4u, 0u, &window) << 4;
    two_steps(&r1, &r2);
    if (known) {
        refused_set = command('C', 1u, 1u, &before1) | command('C', 4u, 0x03FF0000u, &before2) << 4;
        refused_now = command('c', 1u, 0u, &writes_now) | command('c', 4u, 0u, &window_now) << 4;
        two_steps(&m1, &m2);
    }

    say_head("WSPROBE");
    say_text("I"); say_hex(kind, 8); say_flush();
    if (known) { say_text("F"); say_hex(writes, 8); say_hex(window, 8); say_hex(refused, 2); say_flush(); }
    say_text("L"); say_hex(r1, 8); say_hex(r2, 8); say_flush();
    if (known) {
        say_text("S"); say_hex(before1, 8); say_hex(before2, 8); say_hex(refused_set, 2); say_flush();
        say_text("G"); say_hex(writes_now, 8); say_hex(window_now, 8); say_hex(refused_now, 2); say_flush();
        say_text("M"); say_hex(m1, 8); say_hex(m2, 8); say_flush();
    }
    say_tail("WSPROBE");
}
