# The span-modes probe (SPAN MODES PROBE)

**For emulators only.** It draws lists made with made-up triangle coefficients, as a fuzzer's are. It was not written for a console, has never been run on one, and nobody has checked that a console takes its lists: do not run it on a console.

## What it tests

In the words of its source:

> The span modes probe: a small test cartridge that draws in every mode a span loop is made for.
> 
> It is written for the gate that holds a faster build of this core to the plain build
> (a check of the emulator, not of a console): the made span loops are taken only
> for the modes of the core's list of RDP modes, which are modes of games, and no other probe of ours draws
> in one. This one draws in each: its table of modes (modes.h) is written by the tool that
> writes the core's table, from the same count. It asks a console nothing, has no console
> record, and nobody has asked whether a console takes its lists: the triangles' coefficients
> are made up, as a fuzzer's are, and are not those of real shapes.
> 
> A pass is one list for each mode of the table. A list stands by itself:
>   the colour image (16 bits a pixel unless the mode says otherwise, 96 wide), the depth image
>   and the scissor (96 by 72); texture memory filled by two loads from a block of made-up
>   texels; four tiles from the one the primitives name, of the kinds the mode's line names;
>   the combiner as the mode has it; fog, blend, primitive and environment colours, a primitive
>   depth, key and convert values; the mode's two other-modes words;
>   twelve primitives: ten triangles with and without shade, texture and depth, most of them
>   small and inside the image and lying over one another, a textured rectangle, and a plain
>   rectangle with an environment colour behind it;
>   then three ways of standing beside the mode, each with two more triangles, which no made
>   loop may take: one combiner input changed; with the level of detail on, a tile it can reach
>   given another kind; and the colour image made 8 bits a pixel, which reads back the hidden
>   bits the lines before left behind. Before the last of them, two triangles with the tile
>   just beyond the primitives' levels of another kind: the level of detail reaches that tile
>   only where the detail texture is on, so elsewhere the mode's loop is taken all the same;
>   a full sync.
> Everything made up comes from one sequence of numbers, started from the pass and the mode, so
> every pass draws other primitives over what the passes before left.
> 
> The probe says one line when it starts and one after every pass, with the pass's number and a
> sum of each image. It has no end.
> 
> Care for the console: not written for one, and not to be run on one unasked.

## Ground no public suite covers

Draws in every RDP mode a span loop of the emulator is made for, with made-up triangle coefficients, for a check that an emulator's faster build draws as its plain build does. Not a hardware test.

## How it gives its answer

Debug text window: one "SPANS pass" line per pass with checksums of the image and depth image. Nothing judged.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out span-modes` builds it into `out/`. By hand: compile the files under `source/probes/span-modes/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `span-modes-probe.z64`, 16384 bytes, SHA-256 f9a80e369638777626a6c8c793f9cd1d0dfef12242af4afba385736598b00b19.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**For emulators only.** It draws lists made with made-up triangle coefficients, as a fuzzer's are. It was not written for a console, has never been run on one, and nobody has checked that a console takes its lists: do not run it on a console.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

No console run of this probe yet.
