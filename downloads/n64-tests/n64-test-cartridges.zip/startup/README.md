# The startup probe (STARTUP PROBE)

## What it tests

In the words of its source:

> The start-up probe: a small test cartridge for a real console.
> 
> A boot code has to set the memory chips up before main memory answers at all: reset them, set
> their delays, give each its place, enable it, and find the output current at which its data
> comes back whole. This probe runs after the open boot code has done that, and prints what the
> boot code left behind: the RI's registers, every register of every memory chip, and what main
> memory answers megabyte by megabyte. It writes nothing to the chips' registers.
> 
> Run here, the same lines show what this core holds after the same boot code. Where the two
> logs differ, the core's picture of the chips is wrong.
> 
> V  the MI's version
> S  the memory size the boot code stored
> I  the RI's eight registers
> M  megabyte, the word read back there after writing a mark, the word read with nothing written
> C  place, the chip's registers 0 to 9, the odd-numbered ones read through the MI's upper mode
> N  place, the same ten read plainly
> W  place, the words at 0x200, 0x204, 0x240 and 0x40 of the chip's window, and registers 10 to 15 OR-ed
> B  two reads from the window that writes to every chip at once
> E  the RI's error register: after a write to it, after a read from a place no chip is at, after a read a chip answers
> X  three reads from places above main memory where consoles are known to show stray values
> L  a 64-bit read of a chip's first register

## Ground no public suite covers

What the boot code leaves behind: the RI's registers, every register of every memory chip, how much memory answers, what a read above fitted memory gives. n64-systemtest and others test RDRAM from the program's side; the registers after boot are, to this reading, not covered.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out startup` builds it into `out/`. By hand: compile the files under `source/probes/startup/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `startup-probe.z64`, 8192 bytes, SHA-256 a9fa695a4c0dda701a1812893a56d018261b72552a6bab7d57e0b5f0c077b273.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-15 (c1, 2026-11-14T10:45:55): 49 lines; the program is this set's build.
- c1-20 (c1, 2026-11-14T10:54:04): 49 lines; the program is this set's build.
- c2-07 (c2, 2026-11-14T11:11:46): 49 lines; the program is this set's build.
- c2-28 (c2, 2026-11-14T11:47:58): 49 lines; the program is this set's build.
- c1-26 (c1, 2026-11-14T20:26:29): 49 lines; the program is this set's build.
- c1-49 (c1, 2026-11-15T13:42:17): 49 lines; the program is this set's build.
- c1-52 (c1, 2026-11-15T15:51:20): 49 lines; the program is this set's build.
- c1-57 (c1, 2026-11-18T16:38:56): 49 lines; the program is this set's build.
- Both consoles ran build a9fa695a4c0dda70: c1-57 and c2-28 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
