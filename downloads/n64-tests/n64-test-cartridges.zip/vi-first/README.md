# The vi-first probe (VI FIRST PROBE)

## What it tests

In the words of its source:

> The VI's first interrupt probe: a small test cartridge for a real console.
> 
> How long after the VI is turned on does its interrupt line show in the MI, when the VI is set
> to interrupt at half-line 2? One program was seen to turn the VI on, with the registers below,
> and to run on into a stretch of its own code that must not be interrupted too late: on this
> core the interrupt's line and the store that masks it fall four ticks apart. Only a console
> can say on which side they fall.
> 
> A trial: the VI is switched off and left off for a while; its registers are written as that
> program writes them (a PAL console's low-resolution mode); the interrupt is taken back; then,
> in one stretch of instructions that is the same in every trial, the control register is
> written (the VI is on), a loop of three instructions runs k times, n more instructions that do
> nothing follow (n is 0, 1 or 2), and the MI's interrupt register is read once. The trial says
> whether the VI's line was up in that read. COUNT is read just before the store and just after
> the read.
> 
> For each n the probe looks for the smallest k at which the line is up, three times over. A step
> of k is three CPU cycles and a step of n one, so the three answers together place the moment to
> one CPU cycle, in units a console and this core count alike: the same instructions from the
> same cached place.
> 
> Lines, each through the debug text window a flash cartridge shows on the computer beside the
> console:
>   V n r k count     for n and the r-th try: the smallest k at which the line was up, and
>                     COUNT's steps over that trial
>   U n r k count     the trial one k below it (the line not yet up), and its COUNT's steps
>   VIFIRST END       the last line, with the count of lines and their fold
> 
> The registers are a PAL console's; on a console of another television type the VI runs them
> as given, and the answer is that console's for these registers. The sound output is not used.
> 
> Care for the console: ordinary register values of a mode games use; the VI is switched on and
> off some two hundred times, a few lines each; no interrupt is let through to the CPU.

## Ground no public suite covers

How long after the VI is switched on its interrupt line shows in the MI, with a PAL low-resolution mode: the smallest loop count at which it is up, three times over. n64-vi-imagesize is about picture size; this is not in a listed suite to this reading.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out vi-first` builds it into `out/`. By hand: compile the files under `source/probes/vi-first/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `vi-first-probe.z64`, 8192 bytes, SHA-256 3e3f6ee1d4020bd6a0c0c3c4acc524b387e988b6b5ffef696e9665537e38060b.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

Nothing beyond the usual care: it writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-143 (c1, 2026-11-20T22:43:26): 20 lines; the program is this set's build.
- c2-39 (c2, 2026-11-21T09:04:09): 20 lines; the program is this set's build.
- c2-56 (c2, 2026-11-21T09:16:05): 20 lines; the program is this set's build.
- Both consoles ran build 3e3f6ee1d4020bd6: c1-143 and c2-56 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
