# The vi-lines probe (VI PROBE)

## What it tests

In the words of its source:

> The VI probe: a small test cartridge for a real console.
> 
> It asks the video chip the questions that no document settles, and prints
> every answer as a line of text through the debug text window a flash
> cartridge shows on the computer beside the console. Run on this core, the
> same lines show what the core does; the two logs are then compared line by
> line.
> 
> What it asks:
>   R  what the registers hold when a program starts
>   M  which bits of each register can be written and read back
>   L  how long a line lasts, counted by the CPU's COUNT register
>   P  what the line counter reads across the end of a field, 526 half-lines
>   Q  the same with 525 half-lines, where the fields take turns
>   S  whether the field bit stays at one after a change from 525 to 526
>   T  what the counter does when the field's length is set below it
>   O  where the counter stands when the VI is turned on
>   I  what the counter reads, and how far into a line it is, when the line
>      interrupt comes
>   N  whether an interrupt comes at all with the VI off, or with its line
>      set beyond the field's length
>   B  how many turns of a small loop fit in a fixed time, with the VI off,
>      blanked, and sending pictures of several kinds: for a loop that reads
>      a VI register, one that reads main memory, and one that reads nothing
>   U  how long single reads of main memory take, near the picture and away
> 
> Care for the console: the control register's bit 5 is never set (it is said
> to be able to damage a console), nor its two diagnostic bits; every change
> of mode is made with the VI turned off; the line length is never set to an
> extreme; and every wait has an end. A television will lose and find the
> picture several times while this runs.
> 
> A value with a tilde before it is a time or a count that need not come out
> the same to the last digit. All values are in hex.

## Ground no public suite covers

The VI: registers at start, writable bits, line length by COUNT, the line counter across field ends (525 and 526 half-lines), field bit, counter when the VI is turned on, the line interrupt, and how much the picture slows memory reads. n64-vi-imagesize and n64-systemtest's VI tests touch some registers; the timing and memory slowdown are, to this reading, not covered.

## How it gives its answer

Debug text window; figures only. The television loses and finds the picture several times as it changes modes.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out vi-lines` builds it into `out/`. By hand: compile the files under `source/probes/vi-lines/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `vi-lines-probe.z64`, 12288 bytes, SHA-256 eecf05b90f3bf774ddad6c148280dae13370b3797dfc10193f9edaaec9694d4a.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

It switches the video interface off for every change of its settings and never sets bit 5 of its control register, as its own care note says. It writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-23 (c1, 2026-11-14T10:56:57): 231 lines; the program is this set's build.
- c2-08 (c2, 2026-11-14T11:12:08): 231 lines; the program is this set's build.
- c1-40 (c1, 2026-11-14T20:59:28): 231 lines; the program is this set's build.
- c1-50 (c1, 2026-11-15T13:43:49): 231 lines; the program is this set's build.
- c1-106 (c1, 2026-11-20T08:07:08): 231 lines; the program is this set's build.
- Both consoles ran build eecf05b90f3bf774: c1-106 and c2-08 give different lines (both are kept; a probe that measures time can differ from run to run on one console too, so compare with each console's other runs).
