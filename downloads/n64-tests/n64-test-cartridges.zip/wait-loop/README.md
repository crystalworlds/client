# The wait-loop probe (WAIT LOOP PROBE)

**For emulators only.** It leaves the CPU's TLB entries other than its own as it finds them, which only an emulator's start makes safe, and it sets an NTSC picture timing. It has never been run on a console.

## What it tests

In the words of its source:

> The wait-loop probe: what a program sees when it waits for an interrupt in a loop of two
> instructions, a branch to itself and an empty delay slot, as games do when they have nothing
> to do.
> 
> The probe was written for the emulator's own use: a faster road through such a loop must
> leave the machine exactly as the loop leaves it turn by turn, and these are the cases that
> road has to get right. It asks a console nothing new and has no console record (it leaves
> the TLB's other entries as it finds them, which only the emulator's start makes safe).
> 
> Each line is one wait, in hex:
> 
>   T  the timer's interrupt ends the wait. The loop's form (b: a branch as the assembler
>      writes it; j: a jump to its own address; r: a branch on another register compared with
>      itself; c: a loop whose delay slot counts its turns; 3: a loop of three instructions;
>      m: a loop on a page reached through the TLB), whether one instruction more ran before
>      the loop, and how far ahead COMPARE was set; then COUNT in the handler's first
>      instruction less COMPARE, where the handler was called away from (less the loop's
>      address), the mark that this was a delay slot, the interrupt lines in Cause, and the
>      turns the counting loop counted.
>   S  the RSP's interrupt ends it: the RSP counts down in a loop of its own and stops.
>   P  the cartridge bus's interrupt ends it: a DMA from the cartridge.
>   I  the SI's interrupt ends it: a read of the PIF's 64 bytes.
>   D  the RDP's interrupt ends it: a list of a few syncs of the pipe and a full sync.
>   U  the AI's interrupt ends it: a short buffer of silence handed to it.
>   V  the VI's interrupt at a line ends it, or the timer after two fields if none comes: twice
>      with the video chip's picture off, three times with a picture on.
>   B  an interrupt ends it while the RSP runs on beside (the SI's, then the cartridge bus's).
>   A  whichever comes first of four that are under way at once.
>   M  a routine on a page reached through the TLB writes the TLB entry of its own page, so
>      that the page maps other memory from its next fetch on: what the routine returns says
>      which memory each of its later instructions came from.
> 
> Nothing here can harm a console: the picture's timing is an NTSC console's own, and every
> wait has an end.

## Ground no public suite covers

What a program sees when it waits for an interrupt in a two-instruction loop, as games do, for every interrupt source and loop form, including a loop on a page reached through the TLB. For the emulator's own use; asks a console nothing new.

## How it gives its answer

Debug text window; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out wait-loop` builds it into `out/`. By hand: compile the files under `source/probes/wait-loop/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `wait-loop-probe.z64`, 12288 bytes, SHA-256 18b5dcbad1c93d1fd113aa42e1a6cda0d8fd04122b2cc8dbaec8d259ddae2c6b.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**For emulators only.** It leaves the CPU's TLB entries other than its own as it finds them, which only an emulator's start makes safe, and it sets an NTSC picture timing. It has never been run on a console.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

No console run of this probe yet.
