# The window-state probe (WINDOW STATE PROBE)

## What it tests

In the words of its source:

> The window state probe: a small test cartridge for a real console with a flash cartridge.
> 
> A program built with the open library looks for an emulator's debug text window by writing a
> word at the window's start and reading it back, and where the word comes back the library asks
> its allocator for a buffer, which moves everything the program asks for afterwards. So whether
> a flash cartridge's window takes a write decides where such a program's blocks lie, and with
> that whether the RSP's pair test loses the start of its copy (the data cache line probe). This
> probe asks the cartridge itself, and it can be heard in a run that is listened to without the
> window, where every other probe of ours is silent: it first notes what it finds, then turns
> the window on by the cartridge's own setting, and only then prints. All values are in hex.
> 
>   I id        the word that names the cartridge's kind, read after its registers were opened
>               (53437632 for the flash cartridge this probe knows; the lines F, S, G and M
>               come only then)
>   F w a e     as found: the cartridge's switch for writes to its game memory, the address it
>               has for the debug window (0: none), and whether either question was refused
>   L r1 r2     the library's own two steps, as found: the word edcba987 written at the window's
>               start and read back, then 12345678 written and read back. The library takes the
>               window to be there only if both come back
>   S p1 p2 e   the probe's two settings: writes to the game memory on, the window at 0x03ff0000;
>               what each setting was before, and whether either was refused
>   G w a e     the two settings read again
>   M r1 r2     the library's two steps again
> 
> Nothing depends on the console's television type or on the size of main memory.
> 
> Care for the console and the cartridge: two settings of the cartridge are changed, by its own
> commands, to what its PC tool sets them to when it listens at the window; the cartridge
> forgets them when its power is cut. Four words are written at the window's start, where every
> probe of ours writes.

## Ground no public suite covers

The flash cartridge's debug text window: what the cartridge is set to when a test begins, and whether a word written at the window's start reads back (how libdragon decides it has a text sink). It then turns the window on by the cartridge's own setting and prints. Specific to the SummerCart64; no listed suite covers it.

## How it gives its answer

Debug text window, which it switches on itself so that a plain listen hears it; figures only.

Every probe hands its lines of text to the debug text window (a ring of bytes with the mark IS64, at cartridge address 0x13FF0000 unless its source places it elsewhere), which a flash cartridge passes to the computer beside the console and an emulator prints. No probe draws its verdict; the lines are figures, held to the consoles' lines in `expected-answers.json`.

## How to build it

With the compiler for the console (`mips64-elf-gcc`, GCC 16.2.0) and libdragon's open boot code at hand: `IPL3=/path/to/ipl3_compat.z64 bash source/build.sh out window-state` builds it into `out/`. By hand: compile the files under `source/probes/window-state/` in the order its `probe.json` names them with `mips64-elf-gcc -march=vr4300 -mtune=vr4300 -mabi=n32 -O2 -G0 -ffreestanding -fno-builtin -fno-pic -mno-abicalls -mno-check-zero-division -fno-tree-loop-distribute-patterns -nostdlib -Wl,-m,elf32bmipn32 -Wl,-T,source/probes/link.ld -Wl,--build-id=none ... -lgcc`, take the flat block with `objcopy -O binary`, and put it behind libdragon's open boot code (`boot/bin/ipl3_compat.z64` at commit 39d0d6096130836a65710da6730290701d060272, SHA-256 5632e0815adf007fc1589f3a8e05244b5eff21d3624b466dfa3e28138c112188) with three header fields set: the load address 0x80000400 at 0x08, the block's length, rounded up to a whole 8 bytes with zero bytes, at 0x10 (0 at 0x14), and the title from `probe.json` at 0x20; pad to whole 4 KiB.

The built test file here: `window-state-probe.z64`, 8192 bytes, SHA-256 9839ce545e0a10b0cbc78423aab10407c0152b4de2b3b15ae17b3a81321896d2.

## How to run it

- **On a flash cartridge:** send the test file to the cartridge, switch the console off for about two seconds and on, and listen at the cartridge's debug text window (we used a SummerCart64 with its own tool, `sc64deployer`). Each line that arrives is the probe's.
- **On an emulator:** any emulator that prints the debug text window. The reference emulator ares prints it on its standard output.

## Before running it on a real console

**A test of the flash cartridge, not of the console.** It changes two of the cartridge's settings by the cartridge's own commands (the cartridge forgets them when its power is cut) and writes four words at the start of the cartridge's debug text window. It writes nothing to a save chip or a Controller Pak.

## The consoles' answers

In `expected-answers.json`: **PAL consoles only** (two PAL consoles, c1 and c2; an NTSC console has not been run yet). A run is named by its console and its number: c1-88 is console one's 88th run.

- c1-71 (c1, 2026-11-18T17:46:27): 1 lines; the program is this set's build.
- c1-72 (c1, 2026-11-18T17:48:15): 8 lines; the program is this set's build.
