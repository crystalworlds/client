Pokemon mini test cartridges, from the CrystalWorlds.Media project
==================================================================

There is no public test suite for the Pokemon mini, so we wrote these:
twelve small cartridges, each asking the console one question. Each answers
by painting the whole screen solid black or solid white, so the answer can
be read at a glance or from a photograph. Where a cartridge needs you to do
something first, the screen flickers between black and white until it has
what it needs, then stops on the answer. A flickering screen is never an
answer.

All twelve were run on one Pokemon mini through a flash cartridge and
photographed on 30 Sep 2026. The column "Console" below is what that
console painted. One console can show that a behaviour is wrong; it cannot
prove that every console behaves the same way.

How to run them on a console: copy one .min file to a Pokemon mini flash
cartridge with its own writing tool, insert it and switch on. Run T4E
first, before any other cartridge and before playing any game, if you want
its answer to mean anything (see below).

Files
-----
File               What it asks                                   Console
T4A_shock.min      Shake sensor. The screen flickers: give the    Black
                   console one firm shake, then keep it still.
                   Black: one shake gives one signal. White:
                   several.
T4B_cycles.min     Instruction timing. Times a loop against the   White
                   256 Hz counter. Black: the loop took the time
                   predicted when the cartridge was made. White:
                   it did not.
T4C_prcstall.min   Picture chip and processor. Runs the same      Black
                   loop with the picture chip off, then while it
                   draws a full screen of sprites. Black: the
                   processor slows while the picture chip draws.
                   White: no difference.
T4D_mapsize.min    Largest tile map. Black: 24 by 16 tiles.       Black
                   White: 24 by 8. A clean solid screen here
                   also shows that the flash cartridge works.
T4E_eeprom.min     Save memory as shipped. Black: an area of the  White (this console
                   save memory that no game is known to write is  had been played, so
                   still blank. White: it is not. Run it first.   a game may have
                                                                  written there)
T4F_rtc.min        Clock at start-up. Switch the console on and   Black
                   leave it for a minute, switch it off, wait ten
                   seconds, then switch it on with this cartridge.
                   Black: the clock counter is already running.
                   White: it reads zero.
T4G_irq3a.min      Hidden interrupts. The screen flickers for     White
                   about twelve seconds: press every button
                   (A, B, C, the four directions, Power briefly),
                   shake the console and wiggle the cartridge.
                   Black: one of three undocumented interrupts
                   fired. White: none did.
T4H_decimal.min    Decimal arithmetic. Black: decimal mode adds   Black
                   19 and 01 to give 20. White: it does not.
T4I_divzero.min    Divide by zero. Paints white, divides by       White
                   zero, then paints black. Black: the console
                   carried on. White: it stopped. Still white
                   after ten seconds means white.
T4J_spritemsb.min  Sprite position. Black: the top bit of a       Black
                   sprite's position is ignored. White: it
                   counts.
T4K_lcdcol.min     Writing past the last column. Fills the        Black
                   screen black, then writes white past the
                   screen's last column. Black: those writes stay
                   off the screen. White: they wrap onto it.
                   Anything else (a stripe, a blank panel, a
                   change in contrast) is worth a photograph.
T4L_timebase.min   Time base. Times a long loop against the       White
                   256 Hz counter. Black: 40 counts or more.
                   White: fewer.

How emulators do on them is on the site's home page, on the Pokemon mini
card under "How we compare". The same table, with our emulator's answers,
is on the Pokemon mini Emulation tab.

Source
------
The source folder holds the program that writes the cartridges: an
assembler for the console's processor (tools/s1c88.mjs), the twelve
programs (probes/probes.mjs) and a build script. With Node.js installed,
run "node tools/build.mjs" inside the source folder; it writes the twelve
cartridges into source/carts, byte for byte the same as the files here.

Licence: this zip is MIT-licensed (see LICENSE), unlike the rest of the site.
