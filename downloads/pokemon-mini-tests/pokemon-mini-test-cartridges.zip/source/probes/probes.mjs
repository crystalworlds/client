import { Asm, prologue, enter, finish, buildCart, TABLE, OAM, MAPENT, CODE } from "../tools/s1c88.mjs";
const BLACK = 0, WHITE = 1;
function oamTable(yBytes) {
    const t = [];
    for (const y of yBytes)
        for (const x of [16, 32, 48, 64, 80, 96])
            t.push(x, y, 0x00, 0x08);
    return t;
}
const OAM_ONSCREEN = oamTable([16, 32, 48, 64]);
const OAM_MSB = oamTable([144, 160, 176, 192]);
function emitTimeLoop(a, label, outer) {
    a.label(label);
    a.ldbri(0x40, 0x02);
    a.ldbri(0x40, 0x01);
    a.ldIXi(outer);
    a.label(label + "_o");
    a.ldBi(0);
    a.label(label + "_i");
    a.djnz(label + "_i");
    a.decIX().cpIXi(0).jrsNZ(label + "_o");
    a.ldAbr(0x41);
    a.ret();
}
function emitFlicker(a, label, phaseVar) {
    a.label(label);
    a.ldAbr(0x41).andAi(0x20).cpAabs(phaseVar).jrsZ(label + "_x");
    a.ldabsA(phaseVar);
    a.andAi(0x20).jrsZ(label + "_b");
    a.ldAi(WHITE).jrs(label + "_p");
    a.label(label + "_b");
    a.ldAi(BLACK);
    a.label(label + "_p");
    a.carl("paint");
    a.label(label + "_x");
    a.ret();
}
export const PROBES = [
    {
        id: "T4-A", file: "T4A_shock.min", title: "SHOCK TRAIN",
        emit(a) {
            enter(a);
            a.carl("prc_on");
            a.ldbri(0x2A, 0x40);
            a.ldAi(0).ldabsA(0x1F00);
            a.label("A_wait");
            a.ldAbr(0x2A).andAi(0x40).jrsNZ("A_edge");
            a.carl("A_flick");
            a.jrl("A_wait");
            a.label("A_edge");
            a.ldbri(0x2A, 0x40);
            a.ldAbr(0x41).addAi(51).ldBA();
            a.label("A_win");
            a.ldAbr(0x2A).andAi(0x40).jrlNZ("A_multi");
            a.ldAbr(0x41).cpAB().jrsNZ("A_win");
            finish(a, BLACK);
            a.label("A_multi");
            finish(a, WHITE);
            emitFlicker(a, "A_flick", 0x1F00);
        },
    },
    {
        id: "T4-B", file: "T4B_cycles.min", title: "CYCLE COUNT",
        emit(a) {
            enter(a);
            a.carl("prc_on");
            a.ldAi(WHITE).carl("paint");
            a.carl("prc_off");
            a.carl("B_time");
            a.ldabsA(0x1F08);
            a.carl("prc_on");
            a.ldAabs(0x1F08);
            a.cpAi(133).jrlC("B_miss");
            a.cpAi(142).jrlNC("B_miss");
            finish(a, BLACK);
            a.label("B_miss");
            finish(a, WHITE);
            emitTimeLoop(a, "B_time", 1024);
        },
    },
    {
        id: "T4-C", file: "T4C_prcstall.min", title: "PRC STALL",
        emit(a) {
            enter(a);
            a.ldIXi(TABLE).ldHLi(OAM).ldBi(96).carl("copy");
            a.carl("prc_on");
            a.ldAi(WHITE).carl("paint");
            a.carl("prc_off");
            a.carl("C_time");
            a.ldabsA(0x1F00);
            a.carl("prc_on");
            a.ldbri(0x80, 0x0E);
            a.carl("C_time");
            a.ldabsA(0x1F01);
            a.ldbri(0x80, 0x0A);
            a.ldAabs(0x1F00).addAi(2).ldBA();
            a.ldAabs(0x1F01).cpAB().jrlC("C_nostall");
            finish(a, BLACK);
            a.label("C_nostall");
            finish(a, WHITE);
            emitTimeLoop(a, "C_time", 512);
        },
        tables: { [TABLE]: OAM_ONSCREEN },
    },
    {
        id: "T4-D", file: "T4D_mapsize.min", title: "MAP SIZE 3",
        emit(a) {
            enter(a);
            a.ldHLi(MAPENT).ldBi(192).ldAi(WHITE);
            a.label("D_w");
            a.ldhlA().incHL().djnz("D_w");
            a.ldBi(192).ldAi(BLACK);
            a.label("D_b");
            a.ldhlA().incHL().djnz("D_b");
            a.carl("prc_on");
            a.ldbri(0x85, 64);
            a.ldbri(0x80, 0x3A);
            a.jrl("spin");
        },
    },
    {
        id: "T4-E", file: "T4E_eeprom.min", title: "EEPROM FILL",
        emit(a) { emitEeprom(a); },
    },
    {
        id: "T4-F", file: "T4F_rtc.min", title: "RTC EPOCH",
        emit(a) {
            a.ldSPi(0x1FFE).ldBRi(0x20).ldEPi(0);
            a.ldAbr(0x09).orAbr(0x0A).orAbr(0x0B);
            a.ldabsA(0x1F00);
            a.carl("init");
            a.carl("prc_on");
            a.ldAabs(0x1F00).cpAi(0).jrlZ("F_zero");
            finish(a, BLACK);
            a.label("F_zero");
            finish(a, WHITE);
        },
    },
    {
        id: "T4-G", file: "T4G_irq3a.min", title: "IRQ 3A 3C 3E",
        emit(a) {
            enter(a);
            a.carl("prc_on");
            a.ldbri(0x2A, 0x07);
            a.ldbri(0x08, 0x02);
            a.ldbri(0x08, 0x01);
            a.ldAi(0).ldabsA(0x1F00);
            a.label("G_loop");
            a.ldAbr(0x2A).andAi(0x07).jrlNZ("G_hit");
            a.carl("G_flick");
            a.ldAbr(0x09).cpAi(12).jrlC("G_loop");
            finish(a, WHITE);
            a.label("G_hit");
            finish(a, BLACK);
            emitFlicker(a, "G_flick", 0x1F00);
        },
    },
    {
        id: "T4-H", file: "T4H_decimal.min", title: "DECIMAL MODE",
        emit(a) {
            enter(a);
            a.carl("prc_on");
            a.orSCi(0x10);
            a.ldAi(0x19);
            a.addAi(0x01);
            a.andSCi(0xEF);
            a.cpAi(0x20).jrlZ("H_bcd");
            finish(a, WHITE);
            a.label("H_bcd");
            finish(a, BLACK);
        },
    },
    {
        id: "T4-I", file: "T4I_divzero.min", title: "DIV BY ZERO",
        emit(a) {
            enter(a);
            a.carl("prc_on");
            a.ldAi(WHITE).carl("paint");
            a.ldbri(0x40, 0x02).ldbri(0x40, 0x01);
            a.label("I_w");
            a.ldAbr(0x41).cpAi(200).jrsC("I_w");
            a.ldHLi(0x1234);
            a.ldAi(0x00);
            a.div();
            finish(a, BLACK);
        },
    },
    {
        id: "T4-J", file: "T4J_spritemsb.min", title: "SPRITE MSB",
        emit(a) {
            enter(a);
            a.carl("prc_on");
            a.ldAi(WHITE).carl("paint");
            a.ldIXi(TABLE).ldHLi(OAM).ldBi(96).carl("copy");
            a.ldbri(0x80, 0x0E);
            a.jrl("spin");
        },
        tables: { [TABLE]: OAM_MSB },
    },
    {
        id: "T4-K", file: "T4K_lcdcol.min", title: "LCD COLUMN",
        emit(a) {
            enter(a);
            a.carl("prc_off");
            a.ldbri(0xFE, 0xAF);
            a.ldbri(0xFE, 0x40);
            a.ldbri(0xFE, 0xA0);
            a.ldbri(0xFE, 0xA6);
            a.ldbri(0xFE, 0xA4);
            a.ldAi(0xB0).ldabsA(0x1F00);
            a.ldIYi(8);
            a.label("K_p1");
            a.ldAabs(0x1F00).ldbrA(0xFE);
            a.ldbri(0xFE, 0x00).ldbri(0xFE, 0x10);
            a.ldBi(96);
            a.label("K_f1");
            a.ldbri(0xFF, 0xFF).djnz("K_f1");
            a.ldAabs(0x1F00).incA().ldabsA(0x1F00);
            a.decIY().cpIYi(0).jrsNZ("K_p1");
            a.ldAi(0xB0).ldabsA(0x1F00);
            a.ldIYi(8);
            a.label("K_p2");
            a.ldAabs(0x1F00).ldbrA(0xFE);
            a.ldbri(0xFE, 0x04).ldbri(0xFE, 0x18);
            a.ldBi(96);
            a.label("K_f2");
            a.ldbri(0xFF, 0x00).djnz("K_f2");
            a.ldAabs(0x1F00).incA().ldabsA(0x1F00);
            a.decIY().cpIYi(0).jrsNZ("K_p2");
            a.jrl("spin");
        },
    },
    {
        id: "T4-L", file: "T4L_timebase.min", title: "TIME BASE",
        emit(a) {
            enter(a);
            a.carl("prc_on");
            a.ldAi(WHITE).carl("paint");
            a.carl("prc_off");
            a.carl("L_time");
            a.ldabsA(0x1F08);
            a.carl("prc_on");
            a.ldAabs(0x1F08).cpAi(40).jrlC("L_lo");
            finish(a, BLACK);
            a.label("L_lo");
            finish(a, WHITE);
            emitTimeLoop(a, "L_time", 1024);
        },
    },
];
function emitEeprom(a) {
    const BYTE = 0x1F02, ACC = 0x1F04, ACKF = 0x1F05, AND = 0x1F06, ADDR = 0x1F07;
    enter(a);
    a.carl("prc_on");
    a.ldAi(WHITE).carl("paint");
    a.ldAi(0xFF).ldabsA(AND);
    a.ldAi(0x00).ldabsA(ADDR);
    a.ldIXi(64);
    a.label("E_loop");
    a.carl("E_one");
    a.andAabs(AND).ldabsA(AND);
    a.ldAabs(ADDR).incA().ldabsA(ADDR);
    a.decIX().cpIXi(0).jrsNZ("E_loop");
    a.ldAabs(AND).cpAi(0xFF).jrlZ("E_allff");
    finish(a, WHITE);
    a.label("E_allff");
    finish(a, BLACK);
    a.label("E_one");
    a.ldHi(0x0C).ldLi(0x0C).carl("E_put");
    a.carl("E_start");
    a.ldAi(0xA0).carl("E_send");
    a.ldAi(0x1F).carl("E_send");
    a.ldAabs(ADDR).carl("E_send");
    a.andLi(0xF7).orHi(0x04).orLi(0x04).carl("E_put");
    a.carl("E_start");
    a.ldAi(0xA1).carl("E_send");
    a.ldAi(0x00).ldabsA(ACKF);
    a.carl("E_read");
    a.ldabsA(ACC);
    a.carl("E_stop");
    a.ldAabs(ACC);
    a.ret();
    a.label("E_put");
    a.ldAH().ldbrA(0x60).ldAL().ldbrA(0x61).ret();
    a.label("E_start");
    a.orHi(0x04).orLi(0x0C).carl("E_put");
    a.andLi(0xFB).jrs("E_put");
    a.label("E_stop");
    a.orHi(0x04).andLi(0xFB).carl("E_put");
    a.orLi(0x08).carl("E_put");
    a.orLi(0x04).jrs("E_put");
    a.label("E_bit");
    a.andLi(0xF7).pushBA().carl("E_put").popBA();
    a.orHi(0x04);
    a.andAi(0x01).jrsZ("E_bit0");
    a.orLi(0x04).jrs("E_bitw");
    a.label("E_bit0");
    a.andLi(0xFB);
    a.label("E_bitw");
    a.carl("E_put");
    a.orLi(0x08).jrs("E_put");
    a.label("E_send");
    a.ldabsA(BYTE);
    a.ldBi(8);
    a.label("E_send_l");
    a.ldAabs(BYTE).andAi(0x80).jrsZ("E_send_0");
    a.ldAi(1).jrs("E_send_s");
    a.label("E_send_0");
    a.ldAi(0);
    a.label("E_send_s");
    a.carl("E_bit");
    a.ldAabs(BYTE).slaA().ldabsA(BYTE);
    a.djnz("E_send_l");
    a.andLi(0xF7).carl("E_put");
    a.andHi(0xFB).carl("E_put");
    a.orLi(0x08).carl("E_put");
    a.ldAbr(0x61).andAi(0x04);
    a.ret();
    a.label("E_read");
    a.andHi(0xFB).carl("E_put");
    a.ldAi(0).ldabsA(ACC);
    a.ldBi(8);
    a.label("E_read_l");
    a.andLi(0xF7).carl("E_put");
    a.orLi(0x08).carl("E_put");
    a.ldAabs(ACC).slaA().ldabsA(ACC);
    a.ldAbr(0x61).andAi(0x04).jrsZ("E_read_0");
    a.ldAabs(ACC).orAi(0x01).ldabsA(ACC);
    a.label("E_read_0");
    a.djnz("E_read_l");
    a.andLi(0xF7).carl("E_put");
    a.orHi(0x04);
    a.ldAabs(ACKF).andAi(0x01).jrsZ("E_nak");
    a.andLi(0xFB).jrs("E_ackw");
    a.label("E_nak");
    a.orLi(0x04);
    a.label("E_ackw");
    a.carl("E_put");
    a.orLi(0x08).carl("E_put");
    a.ldAabs(ACC);
    a.ret();
}
export function assemble(p) {
    const a = new Asm(CODE);
    prologue(a);
    p.emit(a);
    const code = a.link();
    return { image: buildCart({ code, tables: p.tables || {}, title: p.title }), bytes: code.length };
}
