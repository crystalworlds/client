// Builds the twelve test cartridges into ../carts (run: node tools/build.mjs)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { PROBES, assemble } from "../probes/probes.mjs";
const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "carts");
fs.mkdirSync(OUT, { recursive: true });
for (const p of PROBES) {
  const { image } = assemble(p);
  fs.writeFileSync(path.join(OUT, p.file), image);
  console.log(p.id, p.file);
}
