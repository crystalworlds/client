export class Asm {
    constructor(org) { this.org = org; this.buf = []; this.labels = new Map(); this.patches = []; }
    get pc() { return this.org + this.buf.length; }
    b(...bytes) { for (const x of bytes)
        this.buf.push(x & 0xFF); return this; }
    w(v) { return this.b(v & 0xFF, (v >> 8) & 0xFF); }
    label(n) { if (this.labels.has(n))
        throw new Error("duplicate label " + n); this.labels.set(n, this.pc); return this; }
    rel8(n) { this.patches.push({ idx: this.buf.length, name: n, kind: 8 }); this.buf.push(0); return this; }
    rel16(n) { this.patches.push({ idx: this.buf.length, name: n, kind: 16 }); this.buf.push(0, 0); return this; }
    link() {
        for (const p of this.patches) {
            if (!this.labels.has(p.name))
                throw new Error("undefined label " + p.name);
            const t = this.labels.get(p.name);
            if (p.kind === 8) {
                const base = this.org + p.idx, d = t - base;
                if (d < -128 || d > 127)
                    throw new Error("rel8 out of range to " + p.name + " (" + d + ")");
                this.buf[p.idx] = d & 0xFF;
            }
            else {
                const base = this.org + p.idx + 1, d = t - base;
                if (d < -32768 || d > 32767)
                    throw new Error("rel16 out of range to " + p.name + " (" + d + ")");
                this.buf[p.idx] = d & 0xFF;
                this.buf[p.idx + 1] = (d >> 8) & 0xFF;
            }
        }
        return Uint8Array.from(this.buf);
    }
    ldAi(n) { return this.b(0xB0, n); }
    ldBi(n) { return this.b(0xB1, n); }
    ldLi(n) { return this.b(0xB2, n); }
    ldHi(n) { return this.b(0xB3, n); }
    ldBRi(n) { return this.b(0xB4, n); }
    ldAB() { return this.b(0x41); }
    ldAL() { return this.b(0x42); }
    ldAH() { return this.b(0x43); }
    ldBA() { return this.b(0x48); }
    ldAbr(ll) { return this.b(0x44, ll); }
    ldbrA(ll) { return this.b(0x78, ll); }
    ldbri(ll, n) { return this.b(0xDD, ll, n); }
    ldAhl() { return this.b(0x45); }
    ldhlA() { return this.b(0x68); }
    ldhli(n) { return this.b(0xB5, n); }
    ldAix() { return this.b(0x46); }
    ldAabs(a) { return this.b(0xCE, 0xD0).w(a); }
    ldabsA(a) { return this.b(0xCE, 0xD4).w(a); }
    ldBAi(v) { return this.b(0xC4).w(v); }
    ldHLi(v) { return this.b(0xC5).w(v); }
    ldIXi(v) { return this.b(0xC6).w(v); }
    ldIYi(v) { return this.b(0xC7).w(v); }
    ldSPi(v) { return this.b(0xCF, 0x6E).w(v); }
    incHL() { return this.b(0x91); }
    incIX() { return this.b(0x92); }
    incIY() { return this.b(0x93); }
    decIX() { return this.b(0x9A); }
    decIY() { return this.b(0x9B); }
    cpIXi(v) { return this.b(0xD6).w(v); }
    cpIYi(v) { return this.b(0xD7).w(v); }
    cpHLi(v) { return this.b(0xD5).w(v); }
    addAi(n) { return this.b(0x02, n); }
    subAi(n) { return this.b(0x12, n); }
    andAi(n) { return this.b(0x22, n); }
    orAi(n) { return this.b(0x2A, n); }
    cpAi(n) { return this.b(0x32, n); }
    xorAi(n) { return this.b(0x3A, n); }
    cpAB() { return this.b(0x31); }
    cpAabs(a) { return this.b(0x35).w(a); }
    orAbr(ll) { return this.b(0x2C, ll); }
    andAabs(a) { return this.b(0x25).w(a); }
    orAabs(a) { return this.b(0x2D).w(a); }
    incA() { return this.b(0x80); }
    decA() { return this.b(0x88); }
    andBi(n) { return this.b(0xCE, 0xB0, n); }
    andLi(n) { return this.b(0xCE, 0xB1, n); }
    andHi(n) { return this.b(0xCE, 0xB2, n); }
    orBi(n) { return this.b(0xCE, 0xB4, n); }
    orLi(n) { return this.b(0xCE, 0xB5, n); }
    orHi(n) { return this.b(0xCE, 0xB6, n); }
    cpBi(n) { return this.b(0xCE, 0xBC, n); }
    ldSCi(n) { return this.b(0x9F, n); }
    orSCi(n) { return this.b(0x9D, n); }
    andSCi(n) { return this.b(0x9C, n); }
    ldEPi(n) { return this.b(0xCE, 0xC5, n); }
    ldXPi(n) { return this.b(0xCE, 0xC6, n); }
    ldYPi(n) { return this.b(0xCE, 0xC7, n); }
    slaA() { return this.b(0xCE, 0x80); }
    srlA() { return this.b(0xCE, 0x8C); }
    div() { return this.b(0xCE, 0xD9); }
    mlt() { return this.b(0xCE, 0xD8); }
    halt() { return this.b(0xCE, 0xAE); }
    nop() { return this.b(0xFF); }
    pushBA() { return this.b(0xA0); }
    popBA() { return this.b(0xA8); }
    ret() { return this.b(0xF8); }
    jpHL() { return this.b(0xF4); }
    jrs(n) { return this.b(0xF1).rel8(n); }
    jrl(n) { return this.b(0xF3).rel16(n); }
    cars(n) { return this.b(0xF0).rel8(n); }
    carl(n) { return this.b(0xF2).rel16(n); }
    djnz(n) { return this.b(0xF5).rel8(n); }
    jrsC(n) { return this.b(0xE4).rel8(n); }
    jrsNC(n) { return this.b(0xE5).rel8(n); }
    jrsZ(n) { return this.b(0xE6).rel8(n); }
    jrsNZ(n) { return this.b(0xE7).rel8(n); }
    jrlC(n) { return this.b(0xEC).rel16(n); }
    jrlNC(n) { return this.b(0xED).rel16(n); }
    jrlZ(n) { return this.b(0xEE).rel16(n); }
    jrlNZ(n) { return this.b(0xEF).rel16(n); }
}
export const SIZE = 0x8000;
export const TILEBASE = 0x2200;
export const SPRBASE = 0x2240;
export const TABLE = 0x2300;
export const CODE = 0x2400;
export const TILE_BLACK = 0, TILE_WHITE = 1;
export const OAM = 0x1300, MAPENT = 0x1360, SCRATCH = 0x1F00, STACKTOP = 0x1FFE;
export function buildCart({ code, tables = {}, title }) {
    const image = new Uint8Array(SIZE);
    const str = (a, s) => { for (let i = 0; i < s.length; i++)
        image[a + i] = s.charCodeAt(i); };
    str(0x2100, "MN");
    str(0x21A4, "NINTENDO");
    str(0x21AC, "MPRB");
    str(0x21B0, title.slice(0, 12).padEnd(12, " "));
    const stub = new Asm(0x2102);
    stub.ldHLi(CODE).jpHL();
    const sb = stub.link();
    if (0x2102 + sb.length > 0x21A4)
        throw new Error("stub overran the NINTENDO gate");
    image.set(sb, 0x2102);
    for (let i = 0; i < 8; i++) {
        image[TILEBASE + i] = 0xFF;
        image[TILEBASE + 8 + i] = 0x00;
    }
    for (let sb2 = 0; sb2 < 8; sb2++) {
        const v = (sb2 === 2 || sb2 === 3 || sb2 === 6 || sb2 === 7) ? 0xFF : 0x00;
        for (let i = 0; i < 8; i++)
            image[SPRBASE + sb2 * 8 + i] = v;
    }
    for (const [addr, bytes] of Object.entries(tables))
        image.set(Uint8Array.from(bytes), Number(addr));
    if (code.length > SIZE - CODE)
        throw new Error("code too long");
    image.set(code, CODE);
    return image;
}
export function prologue(a) {
    a.jrs("main");
    a.label("init");
    a.ldBRi(0x20).ldEPi(0).ldXPi(0).ldYPi(0);
    a.ldSCi(0xC0);
    a.ldbri(0x40, 0x02);
    a.ldbri(0x40, 0x01);
    a.ret();
    a.label("paint");
    a.ldHLi(MAPENT).ldBi(192);
    a.label("paint_l");
    a.ldhlA().incHL().djnz("paint_l");
    a.ret();
    a.label("prc_on");
    a.ldbri(0x82, TILEBASE & 0xF8).ldbri(0x83, (TILEBASE >> 8) & 0xFF).ldbri(0x84, 0x00);
    a.ldbri(0x85, 0x00).ldbri(0x86, 0x00);
    a.ldbri(0x87, SPRBASE & 0xC0).ldbri(0x88, (SPRBASE >> 8) & 0xFF).ldbri(0x89, 0x00);
    a.ldbri(0x80, 0x0A);
    a.ldbri(0xFE, 0xAF);
    a.ret();
    a.label("prc_off");
    a.ldbri(0x80, 0x00);
    a.ret();
    a.label("copy");
    a.label("copy_l");
    a.ldAix().ldhlA().incIX().incHL().djnz("copy_l");
    a.ret();
    a.label("spin");
    a.jrs("spin");
    a.label("main");
}
export function enter(a) {
    a.ldSPi(STACKTOP);
    a.carl("init");
}
export function finish(a, idx) {
    a.ldAi(idx);
    a.carl("paint");
    a.jrl("spin");
}
