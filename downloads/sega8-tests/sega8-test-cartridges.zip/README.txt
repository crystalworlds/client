Sega Master System test cartridges, from the CrystalWorlds.Media project
========================================================================

We wrote these three small test programs to ask a real Master System what
the public test programs leave open: whether sprites above and below the
picture can collide, how loud each sound channel gets and how the channels
add up, and whether the picture scrolls one pixel every frame without a
stutter. Each prints its answer, or what to do next, in big letters a phone
photograph can read. The volume and scroll tests wait for button 1 (or
start by themselves after ten seconds), so a recording or a film can be
running first.

They are ordinary 32 KB Master System cartridges with the export header and
a correct checksum, so a Master System II's start-up firmware accepts them.
None writes save memory, and none can hang a console: switching off is
always safe.

How to run them on a console: copy a .sms file to a Master System flash
cartridge with its own tool, insert it and switch on. They also run in
emulators.

What the real console shows: the collision test was run on one PAL Master
System II on 20 Nov 2026 and photographed. The volume and scroll tests have
not been recorded on a console yet; the expected results below are our
emulator's. One console can show that a behaviour is wrong; it cannot prove
that every console behaves the same way.

collide.sms: sprites above and below the picture
------------------------------------------------
Two solid 8 x 8 sprites on top of each other at sprite position X 120, at
five heights (sprite Y): MID 95 (on the screen), EDGE 251 (half on the
screen, lines -4 to 3), LOW1 199 and LOW2 229 (below the picture), TOP 239
(above it). Four pages, one for each way of driving the display: on all
frame, off all frame, on in the picture only (OFF IN BORDER) and on in the
border only (ON IN BORDER). Each case is read over three frames from the
video chip's collision flag: COLLIDE means 3 of 3, NO COLLIDE 0 of 3. Button
1 shows the next page, button 2 runs the test again.

Page              MID         EDGE        LOW1, LOW2   TOP
1 DISPLAY ON      COLLIDE     COLLIDE     NO COLLIDE   NO COLLIDE
2 DISPLAY OFF     NO COLLIDE  NO COLLIDE  NO COLLIDE   NO COLLIDE
3 OFF IN BORDER   COLLIDE     COLLIDE     NO COLLIDE   NO COLLIDE
4 ON IN BORDER    NO COLLIDE  COLLIDE     NO COLLIDE   NO COLLIDE

The PAL Master System II gave exactly this table, all four pages. Our
emulator gives the same on the first Master System and the Master System II,
PAL and NTSC. So sprites in the border never collide, with the display on or
off, and a sprite half on the screen collides on its visible lines.

EDGE on page 4 sits on a knife edge: the display comes on at the start of
line 0 while the sprite covers lines -4 to 3. A reading such as "2 OF 3"
there is a timing result, not a fault of the test.

volume.sms: how loud each channel gets, and how they add up
-----------------------------------------------------------
74 steps, each 2 seconds of sound and a 10-frame gap, timed on the frame
count (110 frames a step at 50 Hz, 130 at 60 Hz); the step number is always
on the screen, and the title page shows the rate the console reports. Tone A
period 254 (about 436 Hz on PAL, 440 on NTSC), B 143 (775 / 782 Hz), C 89
(1245 / 1257 Hz), noise white at the clock / 512.

  step 1        silence
  steps 2-17    tone A at loudness 0 to 15
  steps 18-33   tone B, the same
  steps 34-49   tone C, the same
  steps 50-65   noise, the same
  steps 66-69   A; A + B; A + B + C; all four, at full loudness
  steps 70-73   the same at loudness 12
  step 74       silence

Record it through a line-in (48 kHz WAV is plenty) from the title page to
FINISHED. What our emulator gives for a Master System II, each step's middle
second relative to step 17 (tone A at full loudness):

  loudness 1 to 13 of each channel   even 2 dB steps, -24 dB to 0 dB
  loudness 13, 14, 15                identical: the Master System II
                                     limits its loudest steps, one
                                     channel at a time
  A + B                              +3.0 dB, each tone at its own strength
  A + B + C                          +4.8 dB
  all four                           +6.0 dB
  the same at loudness 12            -2.0, +1.0, +2.8, +4.0 dB

If the console instead limits the sum, step 67 is no louder than step 66
and the tones' own strengths fall in steps 67-69. Our emulator's first
Master System keeps its top steps 2 dB apart.

analyse_volume.py (in source/) reads the steps from such a recording:

    python3 analyse_volume.py wav recording.wav pal levels.tsv

It finds the steps from the 10-frame gaps and writes each step's level. A
line-in is AC-coupled, so compare levels relative to step 17, not absolute.

scroll.sms: one pixel every frame
---------------------------------
A checker pattern of white and blue 8 x 8 squares moves one pixel every
frame: 10 seconds sideways, 10 seconds up, 10 seconds both, and round again.
Four big yellow digits count the frames from the start, with the direction
under them.

Expected: the pattern moves one pixel every frame, no frame missed or
doubled (our emulator: every frame writes the scroll registers once, +1 in
that phase's direction).

Filming a 50 Hz console with a 60 frames-a-second phone repeats one picture
in five by itself; that is the camera, not the console. A real stutter shows
as the frame number jumping by 2 or holding while the camera's own pattern
stays regular. A slow-motion mode avoids the question.

Source
------
The source folder holds everything that makes the cartridges: a small Z80
assembler written for these programs (z80asm.py), our own lettering
(font.py), the programs (common.asm and one .asm for each) and build.py. With
Python 3 installed, run "python3 build.py out" inside the source folder; it
writes the three cartridges into out, byte for byte the same as the files
here. There is no outside code in them.

Licence: this zip is MIT-licensed (see LICENSE), unlike the rest of the site.
