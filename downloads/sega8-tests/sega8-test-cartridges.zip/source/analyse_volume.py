"""Levels of the volume test (volume.sms), from our emulator or a recording.

    python -I analyse_volume.py emu <out.raw> <port.log> <pal|ntsc> <out.tsv>
    python -I analyse_volume.py wav <recording.wav> <pal|ntsc> <out.tsv>

emu: the raw file and port log written by our native sound logger (float stereo pairs, 48 kHz);
     each step's start is the frame of its volume writes in the port log.
wav: a line-in recording of the real console. The steps are found from the
     sound itself: the 10-frame gaps after every step form a fixed comb
     (2 s + 10 frames apart); the start that best fits the comb is taken.

For each of the 74 steps it prints the level over the middle second of the
step: RMS in dB, and for the tone steps the strength of each tone's own
frequency (A, B, C) in dB, so a sum cap (the louder channels squeezed) and a
per-channel cap (each channel at its own level) can be told apart.
Levels are relative to TONE A at loudness 15 (step 17) = 0 dB.
Ours.
"""
import math
import sys
import wave

import numpy as np

CLOCK = {'pal': 3546895.0, 'ntsc': 3579545.0}
FPS = {'pal': 3546895.0 / (228 * 313), 'ntsc': 3579545.0 / (228 * 262)}
PERIODS = (254, 143, 89)
NAMES = ['SILENCE'] + [n for n in ('TONE A', 'TONE B', 'TONE C', 'NOISE') for _ in range(16)] + \
    ['TONE A', 'A + B', 'A + B + C', 'ALL FOUR'] * 2 + ['SILENCE']
LOUD = [None] + list(range(16)) * 4 + [15] * 4 + [12] * 4 + [None]
ATT = []                    # attenuation of A, B, C, noise per step (15 = off)
ATT.append((15, 15, 15, 15))
for ch in range(4):
    for loud in range(16):
        a = [15] * 4
        a[ch] = 15 - loud
        ATT.append(tuple(a))
for att in (0, 3):
    ATT += [(att, 15, 15, 15), (att, att, 15, 15), (att, att, att, 15), (att, att, att, att)]
ATT.append((15, 15, 15, 15))
assert len(NAMES) == len(LOUD) == len(ATT) == 74


def tone_db(x, rate, f):
    n = np.arange(len(x))
    w = np.hanning(len(x))
    c = np.sum(x * w * np.exp(-2j * np.pi * f * n / rate))
    amp = 2 * abs(c) / np.sum(w)
    return 20 * math.log10(max(amp, 1e-9))


def levels(x, rate, starts, region):
    freqs = [CLOCK[region] / (32 * p) for p in PERIODS]
    rows = []
    for k, s in enumerate(starts):
        a = int(s + 0.5 * rate)
        b = int(s + 1.5 * rate)
        seg = x[a:b] - np.mean(x[a:b])
        rms = math.sqrt(float(np.mean(seg * seg))) if len(seg) else 0.0
        rows.append([20 * math.log10(max(rms, 1e-9)), float(seg.max() - seg.min()) if len(seg) else 0.0] +
                    [tone_db(seg, rate, f) for f in freqs])
    ref = rows[16]
    out = []
    for k, r in enumerate(rows):
        out.append((k + 1, NAMES[k], '' if LOUD[k] is None else LOUD[k], '/'.join(str(v) for v in ATT[k]),
                    r[0] - ref[0], r[1] / ref[1] if ref[1] else 0.0, r[2] - ref[2], r[3] - ref[2], r[4] - ref[2]))
    return out


def emu(raw, log, region):
    data = np.fromfile(raw, dtype=np.float32).reshape(-1, 2)[:, 0].astype(np.float64)
    frames = []
    nframes = 0
    psg_off = None
    for line in open(log):
        p = line.split()
        f = int(p[0][1:])
        nframes = max(nframes, f + 1)
        if p[1] == 'out' and p[2] == '$7f':
            v = int(p[3][2:], 16)
            frames.append((f, v, p[5]))
    # the program's first four sound writes (at its start) are the silencing
    # routine's; every other volume write (bit 7 and bit 4 set) is a step's start
    ours = [pc for f, v, pc in frames if int(pc, 16) < 0x4000]
    off_pcs = set(ours[:4])
    starts_f = sorted({f for f, v, pc in frames if v & 0x90 == 0x90 and int(pc, 16) < 0x4000 and pc not in off_pcs})
    spf = len(data) / float(nframes)
    rate = 48000
    assert len(starts_f) == 74, 'found %d steps' % len(starts_f)
    starts = [f * spf for f in starts_f]
    gaps = np.diff(starts_f)
    return data, rate, starts, 'step starts every %s frames (%.4f samples a frame)' % (sorted(set(gaps.tolist())), spf)


def read_wav(path):
    with wave.open(path, 'rb') as w:
        ch, width, rate, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(n)
    if width == 2:
        x = np.frombuffer(raw, dtype='<i2').astype(np.float64) / 32768.0
    elif width == 3:
        b = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
        v = (b[:, 0].astype(np.int32) | b[:, 1].astype(np.int32) << 8 | b[:, 2].astype(np.int32) << 16)
        v = np.where(v >= 1 << 23, v - (1 << 24), v)
        x = v.astype(np.float64) / (1 << 23)
    elif width == 4:
        x = np.frombuffer(raw, dtype='<i4').astype(np.float64) / 2147483648.0
    else:
        raise SystemExit('unsupported WAV sample width %d' % width)
    x = x.reshape(-1, ch).mean(axis=1)
    return x, rate


def wav(path, region):
    x, rate = read_wav(path)
    fps = FPS[region]
    period = (2 * round(fps) + 10) / fps            # seconds from one step to the next
    hop = 0.005
    env = np.array([math.sqrt(float(np.mean(x[i:i + int(hop * rate)] ** 2)) + 1e-12)
                    for i in range(0, len(x) - int(hop * rate), int(hop * rate))])
    env = 20 * np.log10(env)
    gap = 10 / fps
    best = None
    total = period * 74
    for i in range(0, max(1, int((len(x) / rate - total) / hop))):
        t0 = i * hop
        score = 0.0
        for k in range(9, 73):                      # steps 10-73: the louder ones
            on = env[int((t0 + k * period + 0.6) / hop):int((t0 + k * period + 1.4) / hop)]
            off = env[int((t0 + k * period + 2.02) / hop):int((t0 + k * period + 2.0 + gap - 0.02) / hop)]
            if len(on) and len(off):
                score += float(np.median(on) - np.median(off))
        if best is None or score > best[0]:
            best = (score, t0)
    t0 = best[1]
    starts = [(t0 + k * period) * rate for k in range(74)]
    return x, rate, starts, 'step 1 found at %.3f s (fit score %.1f dB over 64 gaps)' % (t0, best[0] / 64)


def main():
    if sys.argv[1] == 'emu':
        x, rate, starts, note = emu(sys.argv[2], sys.argv[3], sys.argv[4])
        region, out = sys.argv[4], sys.argv[5]
    else:
        x, rate, starts, note = wav(sys.argv[2], sys.argv[3])
        region, out = sys.argv[3], sys.argv[4]
    rows = levels(x, rate, starts, region)
    with open(out, 'w', newline='\n') as f:
        f.write('# %s\n' % note)
        f.write('step\twhat\tloudness\tatt_A/B/C/N\trms_dB\tpeak_to_peak_x\ttoneA_dB\ttoneB_dB\ttoneC_dB\n')
        for r in rows:
            f.write('%d\t%s\t%s\t%s\t%.2f\t%.3f\t%.2f\t%.2f\t%.2f\n' % r)
    print(note)


if __name__ == '__main__':
    main()
