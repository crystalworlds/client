; collide.asm: off-screen sprite collision, a test program for a real
; Master System. Two solid sprites on top of each other at five heights (one on
; screen, one half on screen, three in the border above or below the
; picture), with the display on, off, on only in the picture and on only in
; the border. Each case is read over three frames (from line 128 to line 128
; of the next frame, so each height is passed once) from the status flag; the
; result is printed as COLLIDE, NO COLLIDE or "n OF 3". Ours, no outside code.

        .include "common.asm"
        .include "gen_tiles.inc"

page = 0xC020
cmode = 0xC021          ; mode being measured (0-3)
cband = 0xC022          ; height being measured (0-4)
picst = 0xC023          ; register 1 in the picture lines
brdst = 0xC024          ; register 1 in the border lines
results = 0xC030        ; 20 counts, mode * 5 + height
somebuf = 0xC050

SOLID = 127-32          ; the solid small tile

main:
        ld a,0xE0
        ld (r1on),a
        call detect_hz
again:
        xor a
        ld (attr),a
        call cls
        ld hl,txt_testing
        call prlist
        call measure_all
        xor a
        ld (page),a
show:
        call show_page
        ld b,0
        call waitpress
        and 0x20                ; button 2: test again
        jr nz,again
        ld a,(page)
        inc a
        cp 4
        jr nz,sh1
        xor a
sh1:    ld (page),a
        jr show

irq:
        push af
        in a,(VDPC)
        ld a,(frames)
        inc a
        ld (frames),a
        pop af
        ei
        reti

; ---- the 20 cases
measure_all:
        di
        ld a,0xC0               ; display on, no frame interrupt
        ld b,1
        call setreg
        xor a
        ld (cmode),a
ma1:    xor a
        ld (cband),a
ma2:    call run_case
        ld a,(cband)
        inc a
        ld (cband),a
        cp 5
        jr nz,ma2
        ld a,(cmode)
        inc a
        ld (cmode),a
        cp 4
        jr nz,ma1
        call sprites_off
        ld a,(r1on)             ; display and frame interrupt back on
        ld b,1
        call setreg
        in a,(VDPC)
        ei
        ret

run_case:
        ld a,(cmode)            ; the two register 1 values for this mode
        add a,a
        ld l,a
        ld h,0
        ld bc,modes
        add hl,bc
        ld a,(hl)
        ld (picst),a
        inc hl
        ld a,(hl)
        ld (brdst),a
        ld a,(cband)            ; the height
        ld l,a
        ld h,0
        ld bc,bands
        add hl,bc
        ld c,(hl)
        ld hl,0x7F00            ; sprite Y: two sprites, then the end mark
        call ctl2
        ld a,c
        call wrvram
        ld a,c
        call wrvram
        ld a,0xD0
        call wrvram
        ld hl,0x7F80            ; X 120, the solid tile, for both
        call ctl2
        ld a,120
        call wrvram
        ld a,SOLID
        call wrvram
        ld a,120
        call wrvram
        ld a,SOLID
        call wrvram
        call measure            ; one frame to settle, not counted
        ld d,0
        ld e,3
rc1:    push de
        call measure
        pop de
        jr z,rc2
        inc d
rc2:    dec e
        jr nz,rc1
        ld a,(cmode)            ; results[mode * 5 + height] = d
        ld b,a
        add a,a
        add a,a
        add a,b
        ld b,a
        ld a,(cband)
        add a,b
        ld l,a
        ld h,0
        ld bc,results
        add hl,bc
        ld (hl),d
        ret

; one window from line 128 to line 128 of the next frame; nz if the flag was set
measure:
        ld a,(picst)
        ld b,1
        call setreg
        ld b,0x80
        call wait_v
        call wait_not_v
        in a,(VDPC)             ; clear the flags
        ld b,0xBF               ; the last picture line, then the border
        call wait_v
        call wait_not_v
        ld a,(brdst)
        ld b,1
        call setreg
        ld b,0xFF               ; the last line before the picture, then line 0
        call wait_v
        call wait_not_v
        ld a,(picst)
        ld b,1
        call setreg
        ld b,0x80
        call wait_v
        in a,(VDPC)
        and 0x20
        ret

wait_v:                         ; until the line counter reads b
        in a,(VCNT)
        cp b
        jr nz,wait_v
        ret
wait_not_v:                     ; until it no longer reads b
        in a,(VCNT)
        cp b
        jr z,wait_not_v
        ret

modes:                          ; register 1 in the picture, in the border
        .db 0xC0,0xC0           ; DISPLAY ON
        .db 0x80,0x80           ; DISPLAY OFF
        .db 0xC0,0x80           ; OFF IN BORDER
        .db 0x80,0xC0           ; ON IN BORDER
bands:
        .db 95,251,199,229,239  ; sprite Y: MID, EDGE, LOW1, LOW2, TOP (the page's order)

; ---- one result page
show_page:
        xor a
        ld (attr),a
        call cls
        ld hl,txt_page
        call prlist
        ld a,(page)             ; page number
        inc a
        ld c,0
        call num2
        ld hl,numbuf+3
        ld de,0x0105            ; row 1, column 5
        call prs_at
        ld a,8
        ld (attr),a
        ld a,(page)             ; the mode's own lines
        add a,a
        ld l,a
        ld h,0
        ld bc,mode_texts
        add hl,bc
        ld e,(hl)
        inc hl
        ld d,(hl)
        ex de,hl
        call prlist
        ld a,(page)             ; results: hl -> results[page * 5]
        ld b,a
        add a,a
        add a,a
        add a,b
        ld l,a
        ld h,0
        ld bc,results
        add hl,bc
        ld de,0x060A            ; row 6, column 10
        ld b,5
sp1:    push bc
        push hl
        push de
        ld a,(hl)
        or a
        ld hl,txt_no
        jr z,sp2
        cp 3
        ld hl,txt_yes
        jr z,sp2
        add a,0x30              ; "n OF 3", built in work RAM
        ld (somebuf),a
        ld hl,txt_some
        ld de,somebuf+1
        ld bc,6
        ldir
        ld hl,somebuf
        pop de                  ; the position again (ldir moved de)
        push de
sp2:    call prb_at
        pop de
        inc d
        inc d
        pop hl
        inc hl
        pop bc
        djnz sp1
        xor a
        ld (attr),a
        ret

txt_testing:
        .db 1,0,2,"TESTING",0
        .db 0,0,6,"THE SCREEN FLASHES FOR A",0
        .db 0,0,7,"SECOND OR TWO. PLEASE WAIT.",0
        .db 0xFF

txt_page:
        .db 0,0,0,"OFF-SCREEN SPRITES           ",0
        .db 0,0,1,"PAGE   OF 4. PHOTO EACH PAGE.",0
        .db 1,0,6,"MID",0
        .db 1,0,8,"EDGE",0
        .db 1,0,10,"LOW1",0
        .db 1,0,12,"LOW2",0
        .db 1,0,14,"TOP",0
        .db 0,0,17,"MID  = Y 95, ON THE SCREEN",0
        .db 0,0,18,"EDGE = Y 251, HALF ON THE SCREEN",0
        .db 0,0,19,"LOW1 = Y 199, BELOW THE PICTURE",0
        .db 0,0,20,"LOW2 = Y 229, BELOW THE PICTURE",0
        .db 0,0,21,"TOP  = Y 239, ABOVE THE PICTURE",0
        .db 0,0,23,"BUTTON 1: NEXT. 2: TEST AGAIN.",0
        .db 0xFF

mode_texts:
        .dw mt0, mt1, mt2, mt3
mt0:    .db 1,0,3,"DISPLAY ON",0
        .db 0xFF
mt1:    .db 1,0,3,"DISPLAY OFF",0
        .db 0xFF
mt2:    .db 1,0,3,"OFF IN BORDER",0
        .db 0xFF
mt3:    .db 1,0,3,"ON IN BORDER",0
        .db 0xFF

txt_yes:    .db "COLLIDE",0
txt_no:     .db "NO COLLIDE",0
txt_some:   .db " OF 3",0
