; common.asm: the start, the video set-up, lettering and the pad for the
; Master System test programs. Ours, no outside code.
; The including program defines: main (its start), irq (the frame
; interrupt), and may set R1_ON (register 1 with the display on).

VDPD = 0xBE
VDPC = 0xBF
VCNT = 0x7E
PSG = 0x7F
PADA = 0xDC

; work RAM
frames = 0xC000        ; counted by each program's irq
fps = 0xC001           ; 50 or 60, from detect_hz
r1on = 0xC003          ; register 1 with the display on (each program sets it)
attr = 0xC002          ; high byte of each name table entry printed (8 = sprite palette)
numbuf = 0xC004        ; up to 6 bytes: x, y, digits, 0
padlast = 0xC00C
tmpw = 0xC00E

        .org 0x0000
        di
        im 1
        ld sp,0xDFF0
        jp boot

        .org 0x0038
        jp irq

        .org 0x0066
        retn                    ; Pause: ignored

        .org 0x0080
boot:
        ld a,0                  ; Sega mapper: banks 0, 1, 2 (harmless on a plain board)
        ld (0xFFFC),a
        ld (0xFFFD),a
        ld a,1
        ld (0xFFFE),a
        ld a,2
        ld (0xFFFF),a
        ld hl,0xC000            ; clear work RAM below the stack
        ld de,0xC001
        ld bc,0x1F00
        ld (hl),0
        ldir
        call psg_off
        call vdp_init
        jp main

; ---- sound: all four channels silent
psg_off:
        ld a,0x9F
        out (PSG),a
        ld a,0xBF
        out (PSG),a
        ld a,0xDF
        out (PSG),a
        ld a,0xFF
        out (PSG),a
        ret

; ---- video: registers, clear memory, letters and colours; display off
vdp_init:
        ld hl,vdpregs
        ld b,22
        ld c,VDPC
        otir
        ld a,0                  ; clear all 16 KB
        out (VDPC),a
        ld a,0x40
        out (VDPC),a
        ld bc,0x4000
vi1:    ld a,0
        out (VDPD),a
        dec bc
        ld a,b
        or c
        jr nz,vi1
        ld a,0                  ; the tiles from address 0
        out (VDPC),a
        ld a,0x40
        out (VDPC),a
        ld hl,tiledata
        ld bc,TILEBYTES
vi2:    ld a,(hl)
        out (VDPD),a
        inc hl
        dec bc
        ld a,b
        or c
        jr nz,vi2
        ld a,0                  ; colours
        out (VDPC),a
        ld a,0xC0
        out (VDPC),a
        ld hl,palette
        ld b,32
        ld c,VDPD
        otir
        call sprites_off
        ret

vdpregs:
        .db 0x06,0x80           ; mode 4
        .db 0xA0,0x81           ; display off, frame interrupt on
        .db 0xFF,0x82           ; name table 0x3800
        .db 0xFF,0x83
        .db 0xFF,0x84
        .db 0xFF,0x85           ; sprite table 0x3F00
        .db 0xFB,0x86           ; sprite tiles from 0x0000
        .db 0x00,0x87           ; border colour: sprite colour 0 (black)
        .db 0x00,0x88
        .db 0x00,0x89
        .db 0xFF,0x8A           ; no line interrupt

palette:
        ; background: black, white, black (box), white, blue, red, green, yellow, grey
        .db 0x00,0x3F,0x00,0x3F,0x30,0x03,0x0C,0x0F,0x2A,0x00,0x00,0x00,0x00,0x00,0x00,0x00
        ; sprites: black, yellow, black (box), red, white
        .db 0x00,0x0F,0x00,0x03,0x3F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00

; ---- two control-port bytes, l then h, with the interrupt held off between
; them: the frame interrupt reads the status port, which would reset the
; port's byte latch half-way. The interrupt state is kept as it was.
ctl2:
        ld a,i                  ; P/V = interrupts enabled
        di
        ld a,l
        out (VDPC),a
        ld a,h
        out (VDPC),a
        ret po
        ei
        ret

; ---- register write: a = value, b = register number
setreg:
        push hl
        ld l,a
        ld a,b
        or 0x80
        ld h,a
        call ctl2
        pop hl
        ret

display_on:
        ld a,(r1on)
        ld b,1
        jp setreg
display_off:
        ld a,(r1on)
        and 0xBF
        ld b,1
        jp setreg

; ---- one byte to video memory, slow enough for the picture time
wrvram:
        out (VDPD),a
        push af
        pop af
        ret

; ---- no sprites: the first sprite's Y is the end mark 0xD0
sprites_off:
        ld hl,0x7F00
        call ctl2
        ld a,0xD0
        jp wrvram

; ---- write address for the name table at column e, row d
setxy:
        push hl
        push bc
        ld l,d
        ld h,0
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        add hl,hl
        ld a,e
        add a,a
        ld c,a
        ld b,0
        add hl,bc
        ld bc,0x7800
        add hl,bc
        call ctl2
        pop bc
        pop hl
        ret

; ---- clear the whole name table (display may be on)
cls:
        ld de,0
        call setxy
        ld bc,32*28
cls1:   ld a,0
        call wrvram
        ld a,0
        call wrvram
        dec bc
        ld a,b
        or c
        jr nz,cls1
        ret

; ---- small text. prs: hl -> x, y, text, 0. prs_at: de = (row, column), hl -> text, 0
prs:
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
prs_at:
        call setxy
prs1:   ld a,(hl)
        inc hl
        or a
        ret z
        sub 32
        call wrvram
        ld a,(attr)
        call wrvram
        jr prs1

; ---- print a list of small or big texts: hl -> [kind, x, y, text, 0]..., 0xFF
; kind 0 = small, 1 = big
prlist:
        ld a,(hl)
        inc hl
        cp 0xFF
        ret z
        or a
        jr nz,prl1
        call prs
        jr prlist
prl1:   call prb
        jr prlist

; ---- big text (two rows high, two columns a letter)
prb:
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
prb_at:
prb1:   ld a,(hl)
        inc hl
        or a
        ret z
        push hl
        call bigchar
        pop hl
        jr prb1

bigchar:                        ; a = ASCII; d = row, e = column; e += 2
        sub 32
        ld l,a
        ld h,0
        ld bc,bigmap
        add hl,bc
        ld l,(hl)
        ld h,0
        add hl,hl
        add hl,hl
        ld bc,BIG_BASE
        add hl,bc               ; hl = top-left tile
        call setxy
        call puttile            ; top-left
        inc hl
        inc hl
        call puttile            ; top-right
        dec hl                  ; bottom-left
        inc d
        call setxy
        call puttile
        inc hl
        inc hl
        call puttile            ; bottom-right
        dec d
        inc e
        inc e
        ret

puttile:
        ld a,l
        call wrvram
        ld a,(attr)
        or h
        jp wrvram

; ---- numbers: a (0-99) -> two digits in numbuf+2 (leading space if under 10 and c = 1)
num2:
        ld b,0
n2a:    cp 10
        jr c,n2b
        sub 10
        inc b
        jr n2a
n2b:    add a,0x30
        ld (numbuf+3),a
        ld a,b
        add a,0x30
        cp 0x30
        jr nz,n2c
        ld a,c
        or a
        ld a,0x30
        jr z,n2c
        ld a,0x20
n2c:    ld (numbuf+2),a
        xor a
        ld (numbuf+4),a
        ret

; ---- frame waits (the frame interrupt must be on)
wait1:
        ei
        halt
        ret

waitn:                          ; b frames
        ei
        halt
        djnz waitn
        ret

; ---- 50 or 60 Hz: count a fixed loop through one frame (35 cycles a pass;
; PAL about 2040 passes, NTSC about 1700)
detect_hz:
        call display_on
        ei
        halt                    ; the first wake may be a flag left from before
        halt                    ; this one is a real frame start
        ld hl,0
        ld a,(frames)
        ld b,a
dh1:    inc hl
        ld a,(frames)
        cp b
        jr z,dh1
        ld de,0-1870
        add hl,de
        ld a,60
        jr nc,dh2
        ld a,50
dh2:    ld (fps),a
        ret

; ---- pad: z set and a = 1 if button 1 or 2 was newly pressed this call
newpress:
        in a,(PADA)
        cpl
        and 0x30
        ld b,a
        ld a,(padlast)
        cpl
        and b
        ld c,a
        ld a,b
        ld (padlast),a
        ld a,c
        or a
        ret

; ---- wait for button 1 or 2, or b seconds (b = 0: forever). Returns a = the buttons (0 if timed out)
waitpress:
        ld a,b
        ld (tmpw),a
wp0:    ld a,(fps)
        ld c,a
wp1:    push bc
        call wait1
        call newpress
        pop bc
        jr nz,wp9
        dec c
        jr nz,wp1
        ld a,(tmpw)
        or a
        jr z,wp0
        dec a
        ld (tmpw),a
        jr nz,wp0
        xor a
        ret
wp9:    ld a,(padlast)
        ret
