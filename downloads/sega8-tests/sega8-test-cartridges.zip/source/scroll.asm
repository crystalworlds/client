; scroll.asm: the smooth-scroll test for a real Master
; System. A checker pattern moves one pixel every frame: 10 seconds sideways,
; 10 seconds up, 10 seconds both, and round again. Sprites show the frame
; count (four big digits) and the direction, so a phone film shows any
; stutter on the real television. Ours, no outside code.

        .include "common.asm"
        .include "gen_tiles.inc"

xs = 0xC020
ys = 0xC021
cnt = 0xC022            ; frame count, 4 BCD digits (low byte first)
phase = 0xC024
secfr = 0xC025          ; frames into this second
secs = 0xC026           ; seconds into this phase
saty = 0xC030           ; 17 sprite Y bytes (8 digits, up to 8 for the word, the end mark)
satxt = 0xC050          ; 16 sprite (X, tile) pairs

main:
        ld a,0xE0
        ld (r1on),a
        call detect_hz
title:
        xor a
        ld (attr),a
        call cls
        ld hl,txt_title
        call prlist
        ld de,0x1215            ; row 18, column 21
        ld a,(fps)
        ld c,0
        call num2
        ld hl,numbuf+2
        call prs_at
        ld b,10
        call waitpress
start:
        call display_off
        call checker
        ld a,0x26               ; mode 4, left column blanked
        ld b,0
        call setreg
        ld a,0xE2               ; display, frame interrupt, 8 x 16 sprites
        ld (r1on),a
        xor a
        ld (xs),a
        ld (ys),a
        ld (cnt),a
        ld (cnt+1),a
        ld (secfr),a
        ld (secs),a
        ld (phase),a
        ld hl,satxt             ; sprite X: 96, 104, ... for both rows
        ld a,96
        ld b,16
st1:    ld (hl),a
        inc hl
        ld (hl),0
        inc hl
        add a,8
        cp 96+64
        jr nz,st2
        ld a,96
st2:    djnz st1
        call set_phase
        call build_digits
        call wait1
        call write_frame
        call display_on
loop:
        call wait1              ; the frame interrupt: now in the border
        call write_frame
        ld a,(cnt)              ; count one frame
        add a,1
        daa
        ld (cnt),a
        ld a,(cnt+1)
        adc a,0
        daa
        ld (cnt+1),a
        call build_digits
        ld a,(phase)            ; move one pixel
        cp 1
        jr z,mv_up
        ld a,(xs)
        inc a
        ld (xs),a
        ld a,(phase)
        or a
        jr z,mv_done
mv_up:  ld a,(ys)
        inc a
        cp 224
        jr nz,mv1
        xor a
mv1:    ld (ys),a
mv_done:
        ld a,(fps)              ; ten seconds a phase
        ld b,a
        ld a,(secfr)
        inc a
        cp b
        jr nz,tm1
        ld a,(secs)
        inc a
        cp 10
        jr nz,tm2
        ld a,(phase)
        inc a
        cp 3
        jr nz,tm3
        xor a
tm3:    ld (phase),a
        call set_phase
        xor a
tm2:    ld (secs),a
        xor a
tm1:    ld (secfr),a
        jr loop

irq:
        push af
        in a,(VDPC)
        ld a,(frames)
        inc a
        ld (frames),a
        pop af
        ei
        reti

write_frame:                    ; scroll registers and sprite tables, in the border
        ld a,(xs)
        ld b,8
        call setreg
        ld a,(ys)
        ld b,9
        call setreg
        ld hl,0x7F00
        call ctl2
        ld hl,saty
        ld b,17
wf1:    ld a,(hl)
        call wrvram
        inc hl
        djnz wf1
        ld hl,0x7F80
        call ctl2
        ld hl,satxt
        ld b,32
wf2:    ld a,(hl)
        call wrvram
        inc hl
        djnz wf2
        ret

build_digits:                   ; the four digits into sprites 0-7
        ld hl,satxt+1
        ld a,(cnt+1)
        call two_digits
        ld a,(cnt)
two_digits:
        push af
        rrca
        rrca
        rrca
        rrca
        call one_digit
        pop af
one_digit:
        and 0x0F
        add a,a
        add a,a
        add a,BIG_BASE+4        ; glyph 1 is the digit 0
        ld (hl),a
        inc hl
        inc hl
        add a,2
        ld (hl),a
        inc hl
        inc hl
        ret

set_phase:                      ; the direction word under the digits
        ld a,(phase)
        add a,a
        ld l,a
        ld h,0
        ld bc,phase_words
        add hl,bc
        ld e,(hl)
        inc hl
        ld d,(hl)               ; de -> word, 0
        ld hl,saty
        ld b,8
sp1:    ld (hl),7
        inc hl
        djnz sp1
        ld b,9
sp2:    ld (hl),0xD0
        inc hl
        djnz sp2
        ld hl,saty+8
        push hl
        ld hl,satxt+17
sp3:    ld a,(de)
        or a
        jr z,sp9
        inc de
        push de
        sub 32
        ld e,a
        ld d,0
        push hl
        ld hl,bigmap
        add hl,de
        ld a,(hl)
        pop hl
        add a,a
        add a,a
        add a,BIG_BASE
        ld (hl),a
        inc hl
        inc hl
        add a,2
        ld (hl),a
        inc hl
        inc hl
        pop de
        ex (sp),hl              ; the Y bytes
        ld (hl),31
        inc hl
        ld (hl),31
        inc hl
        ex (sp),hl
        jr sp3
sp9:    pop hl
        ret

phase_words:
        .dw w_side, w_up, w_both
w_side: .db "SIDE",0
w_up:   .db "UP",0
w_both: .db "BOTH",0

checker:                        ; name table: plain tiles A and B alternating
        ld de,0
        call setxy
        ld d,0                  ; row
ck1:    ld e,0                  ; column
ck2:    ld a,d
        add a,e
        and 1
        add a,lo(PLAIN_A)
        call wrvram
        ld a,hi(PLAIN_A)
        call wrvram
        inc e
        ld a,e
        cp 32
        jr nz,ck2
        inc d
        ld a,d
        cp 28
        jr nz,ck1
        ret

txt_title:
        .db 0,0,0,"SMOOTH SCROLL TEST       ",0
        .db 1,0,2,"SMOOTH SCROLL",0
        .db 0,0,6,"1. START FILMING THE TV WITH",0
        .db 0,0,7,"   YOUR PHONE.",0
        .db 0,0,9,"2. PRESS BUTTON 1, OR WAIT 10",0
        .db 0,0,10,"   SECONDS AND IT STARTS ITSELF.",0
        .db 0,0,12,"THE SQUARES MOVE 1 PIXEL EVERY",0
        .db 0,0,13,"FRAME: SIDEWAYS 10 SECONDS, UP",0
        .db 0,0,14,"10 SECONDS, THEN BOTH; REPEATS.",0
        .db 0,0,15,"THE BIG NUMBER COUNTS FRAMES.",0
        .db 0,0,18,"THIS CONSOLE RUNS AT    HZ.",0
        .db 0xFF
