; volume.asm: the volume test for a real Master System.
; Each tone channel and the noise channel through all 16 volumes,
; then two, three and four channels together, each step 2 seconds with a short
; gap after it, the step number on the screen. A line-in recording shows
; whether the console holds back each channel on its own or the sum.
; Ours, no outside code.

        .include "common.asm"
        .include "gen_tiles.inc"

stepno = 0xC020
stepptr = 0xC022
stepf = 0xC024          ; frame count at the step's start

main:
        ld a,0xE0               ; display on, frame interrupt on
        ld (r1on),a
        call detect_hz
        call psg_off
        call psg_tones
title:
        call psg_off
        xor a
        ld (attr),a
        call cls
        ld hl,txt_title
        call prlist
        ld de,0x1015            ; row 16, column 21: the console's rate
        call print_hz
        ld b,10
        call waitpress
run:
        call cls
        ld hl,txt_run
        call prlist
        ld de,0x001B            ; row 0, column 27
        call print_hz
        ld hl,steps
        ld (stepptr),hl
        ld a,1
        ld (stepno),a
        call wait1
        ld a,(frames)
        ld (stepf),a
step:
        ld hl,(stepptr)
        ld a,(hl)
        cp 0xFE
        jr z,done
        call show_step
        ld hl,(stepptr)
        call set_vols
        ld a,(fps)              ; sound until 2 seconds after the step began
        add a,a
        call wait_until
        call psg_off            ; then 10 frames of silence
        ld a,(fps)
        add a,a
        add a,10
        call wait_until
        ld b,a                  ; the next step begins exactly 2 s + 10 frames later
        ld a,(stepf)
        add a,b
        ld (stepf),a
        ld hl,(stepptr)
        ld bc,8
        add hl,bc
        ld (stepptr),hl
        ld a,(stepno)
        inc a
        ld (stepno),a
        jr step
done:
        call psg_off
        call cls
        ld hl,txt_done
        call prlist
        ld b,0
        call waitpress
        jp run

wait_until:                     ; until (frames - stepf) >= a; returns a unchanged
        ld c,a
wu1:    ld a,(stepf)
        ld b,a
        ld a,(frames)
        sub b
        cp c
        jr nc,wu2
        call wait1
        jr wu1
wu2:    ld a,c
        ret

irq:
        push af
        in a,(VDPC)
        ld a,(frames)
        inc a
        ld (frames),a
        pop af
        ei
        reti

print_hz:                       ; de = position: "50 HZ" or "60 HZ"
        push de
        ld a,(fps)
        ld c,0
        call num2
        ld hl,numbuf+2
        pop de
        call prs_at
        ret

psg_tones:                      ; A: period 254, B: 143, C: 89; noise white, fastest fixed rate
        ld a,0x8E
        out (PSG),a
        ld a,0x0F
        out (PSG),a
        ld a,0xAF
        out (PSG),a
        ld a,0x08
        out (PSG),a
        ld a,0xC9
        out (PSG),a
        ld a,0x05
        out (PSG),a
        ld a,0xE4
        out (PSG),a
        ret

set_vols:                       ; hl -> attenuation of A, B, C, noise
        ld a,(hl)
        or 0x90
        out (PSG),a
        inc hl
        ld a,(hl)
        or 0xB0
        out (PSG),a
        inc hl
        ld a,(hl)
        or 0xD0
        out (PSG),a
        inc hl
        ld a,(hl)
        or 0xF0
        out (PSG),a
        ret

show_step:
        ld a,8                  ; big lines in yellow
        ld (attr),a
        ld a,(stepno)
        ld c,0
        call num2
        ld hl,numbuf+2
        ld de,0x020A            ; row 2, column 10
        call prb_at
        ld hl,(stepptr)         ; the channel name
        ld bc,6
        add hl,bc
        ld e,(hl)
        inc hl
        ld d,(hl)
        ex de,hl
        ld de,0x0600
        call prb_at
        ld hl,(stepptr)         ; the loudness line
        ld bc,4
        add hl,bc
        ld a,(hl)
        cp 0xFF
        jr nz,ss1
        ld hl,blank16
        ld de,0x0A00
        call prb_at
        jr ss3
ss1:
        ld hl,txt_loud
        ld de,0x0A00
        call prb_at             ; e is now 18
        ld hl,(stepptr)
        ld bc,4
        add hl,bc
        ld a,(hl)
        push de
        ld c,1
        call num2
        pop de
        ld hl,numbuf+2
        call prb_at
        ld hl,(stepptr)
        ld bc,5
        add hl,bc
        ld a,(hl)
        or a
        ld hl,txt_each
        jr nz,ss2
        ld hl,txt_noeach
ss2:    call prb_at
ss3:
        xor a                   ; small line: the four attenuations
        ld (attr),a
        ld hl,(stepptr)
        ld de,0x0E07
        call att_at
        ld de,0x0E0D
        call att_at
        ld de,0x0E13
        call att_at
        ld de,0x0E1D
        call att_at
        ret

att_at:                         ; hl -> attenuation; print it at de; hl += 1
        ld a,(hl)
        inc hl
        push hl
        push de
        ld c,1
        call num2
        pop de
        ld hl,numbuf+2
        call prs_at
        pop hl
        ret

txt_loud:   .db "LOUDNESS ",0
txt_each:   .db " EACH",0
txt_noeach: .db "     ",0
blank16:    .db "                ",0

txt_title:
        .db 0,0,0,"VOLUME TEST       ",0
        .db 1,0,2,"VOLUME TEST",0
        .db 0,0,6,"1. START RECORDING ON THE PC.",0
        .db 0,0,8,"2. PRESS BUTTON 1 TO BEGIN",0
        .db 0,0,9,"   (OR WAIT: IT BEGINS BY ITSELF",0
        .db 0,0,10,"   AFTER 10 SECONDS).",0
        .db 0,0,12,"74 STEPS OF 2 SECONDS, ABOUT",0
        .db 0,0,13,"3 MINUTES. THE STEP NUMBER IS",0
        .db 0,0,14,"ALWAYS ON THE SCREEN.",0
        .db 0,0,16,"THIS CONSOLE RUNS AT    HZ.",0
        .db 0,0,19,"TONE A IS LOW, B MIDDLE, C HIGH.",0
        .db 0,0,20,"NOISE IS A HISS.",0
        .db 0xFF

txt_run:
        .db 0,0,0,"VOLUME TEST       ",0
        .db 0,30,0,"HZ",0
        .db 1,0,2,"STEP",0
        .db 1,14,2," OF 74",0
        .db 0,0,14,"ATT  A     B     C     NOISE",0
        .db 0,0,16,"LOUDNESS 15 IS THE LOUDEST,",0
        .db 0,0,17,"0 IS SILENT.",0
        .db 0,0,19,"TONE A IS LOW, B MIDDLE, C HIGH.",0
        .db 0,0,21,"KEEP RECORDING TO STEP 74.",0
        .db 0xFF

txt_done:
        .db 1,0,2,"FINISHED",0
        .db 0,0,6,"STOP THE RECORDING NOW.",0
        .db 0,0,8,"PRESS BUTTON 1 TO RUN IT AGAIN.",0
        .db 0xFF

        .include "gen_volsteps.inc"
