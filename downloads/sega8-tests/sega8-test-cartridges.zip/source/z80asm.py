"""A small two-pass Z80 assembler for the console-run test programs.

Ours, written for this kit; it covers only the instructions the kit's
programs use. Syntax:
    label:                    a label (alone or before an instruction)
    NAME = expr               a constant
    .org expr | .db a,"txt" | .dw a | .ds n[,fill] | .include "file"
    ; comment
Numbers in Python form (0x1F, 31). Expressions are Python expressions over
the labels and constants, with lo(x), hi(x) and `__pc__` for the current address.
Indirect operands are written (hl), (bc), (de), (sp), (c) or (expr).
"""
import os
import re

R8 = {'b': 0, 'c': 1, 'd': 2, 'e': 3, 'h': 4, 'l': 5, '(hl)': 6, 'a': 7}
R16 = {'bc': 0, 'de': 1, 'hl': 2, 'sp': 3}
R16AF = {'bc': 0, 'de': 1, 'hl': 2, 'af': 3}
CC = {'nz': 0, 'z': 1, 'nc': 2, 'c': 3, 'po': 4, 'pe': 5, 'p': 6, 'm': 7}
ALU = {'add': 0, 'adc': 1, 'sub': 2, 'sbc': 3, 'and': 4, 'xor': 5, 'or': 6, 'cp': 7}
ROT = {'rlc': 0, 'rrc': 1, 'rl': 2, 'rr': 3, 'sla': 4, 'sra': 5, 'srl': 7}
PLAIN = {'nop': [0x00], 'halt': [0x76], 'di': [0xF3], 'ei': [0xFB], 'rlca': [0x07], 'rrca': [0x0F],
         'rla': [0x17], 'rra': [0x1F], 'cpl': [0x2F], 'scf': [0x37], 'ccf': [0x3F], 'daa': [0x27],
         'exx': [0xD9], 'ret': [0xC9], 'reti': [0xED, 0x4D], 'retn': [0xED, 0x45], 'neg': [0xED, 0x44],
         'ldir': [0xED, 0xB0], 'ldi': [0xED, 0xA0], 'lddr': [0xED, 0xB8], 'otir': [0xED, 0xB3],
         'outi': [0xED, 0xA3]}


class AsmError(Exception):
    pass


def split_ops(s):
    out, cur, depth, q = [], '', 0, None
    for ch in s:
        if q:
            cur += ch
            if ch == q:
                q = None
            continue
        if ch in '"\'' and not (ch == "'" and cur.strip().lower() == 'af'):
            q = ch
            cur += ch
        elif ch == '(':
            depth += 1; cur += ch
        elif ch == ')':
            depth -= 1; cur += ch
        elif ch == ',' and depth == 0:
            out.append(cur.strip()); cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


class Asm:
    def __init__(self, size):
        self.size = size
        self.syms = {}

    def ev(self, expr):
        ns = dict(self.syms)
        ns.update(lo=lambda v: v & 0xFF, hi=lambda v: (v >> 8) & 0xFF, __pc__=self.pc)
        try:
            return int(eval(expr, {'__builtins__': {}}, ns))
        except NameError:
            if self.final:
                raise AsmError('undefined symbol in %r' % expr)
            return 0

    def emit(self, *bs):
        for v in bs:
            if self.final:
                if not 0 <= self.pc < self.size:
                    raise AsmError('address out of range')
                if self.used[self.pc]:
                    raise AsmError('overlap at %04X' % self.pc)
                self.used[self.pc] = 1
                self.out[self.pc] = v & 0xFF
            self.pc += 1

    def w(self, v):
        self.emit(v & 0xFF, (v >> 8) & 0xFF)

    def rel(self, expr):
        t = self.ev(expr)
        d = t - (self.pc + 1)
        if self.final and not -128 <= d <= 127:
            raise AsmError('relative jump out of range')
        self.emit(d & 0xFF)

    @staticmethod
    def ind(o):
        return o.startswith('(') and o.endswith(')')

    def ins(self, mn, ops):
        lo_ops = [o.lower() for o in ops]
        if mn in PLAIN and not ops:
            return self.emit(*PLAIN[mn])
        a = lo_ops[0] if ops else None
        b = lo_ops[1] if len(ops) > 1 else None
        if mn == 'im':
            return self.emit(0xED, {0: 0x46, 1: 0x56, 2: 0x5E}[self.ev(ops[0])])
        if mn == 'ld':
            if a in R8 and b in R8:
                if a == '(hl)' and b == '(hl)':
                    raise AsmError('ld (hl),(hl)')
                return self.emit(0x40 | R8[a] << 3 | R8[b])
            if a == 'a' and b == '(bc)': return self.emit(0x0A)
            if a == 'a' and b == '(de)': return self.emit(0x1A)
            if a == '(bc)' and b == 'a': return self.emit(0x02)
            if a == '(de)' and b == 'a': return self.emit(0x12)
            if a == 'a' and b == 'i': return self.emit(0xED, 0x57)
            if a == 'a' and b == 'r': return self.emit(0xED, 0x5F)
            if a == 'i' and b == 'a': return self.emit(0xED, 0x47)
            if a == 'sp' and b == 'hl': return self.emit(0xF9)
            if a == 'a' and self.ind(b):
                self.emit(0x3A); return self.w(self.ev(ops[1][1:-1]))
            if self.ind(a) and b == 'a':
                self.emit(0x32); return self.w(self.ev(ops[0][1:-1]))
            if a == 'hl' and self.ind(b):
                self.emit(0x2A); return self.w(self.ev(ops[1][1:-1]))
            if self.ind(a) and b == 'hl':
                self.emit(0x22); return self.w(self.ev(ops[0][1:-1]))
            if a in R16 and self.ind(b):
                self.emit(0xED, 0x4B | R16[a] << 4); return self.w(self.ev(ops[1][1:-1]))
            if self.ind(a) and b in R16:
                self.emit(0xED, 0x43 | R16[b] << 4); return self.w(self.ev(ops[0][1:-1]))
            if a in R16:
                self.emit(0x01 | R16[a] << 4); return self.w(self.ev(ops[1]))
            if a in R8:
                return self.emit(0x06 | R8[a] << 3, self.ev(ops[1]))
            raise AsmError('bad ld')
        if mn in ALU:
            if mn in ('add', 'adc', 'sbc') and a == 'hl':
                code = {'add': (0x09,), 'adc': (0xED, 0x4A), 'sbc': (0xED, 0x42)}[mn]
                return self.emit(*code[:-1], code[-1] | R16[b] << 4)
            if len(ops) == 2:
                if a != 'a':
                    raise AsmError('alu first operand must be a')
                src, raw = b, ops[1]
            else:
                src, raw = a, ops[0]
            if src in R8:
                return self.emit(0x80 | ALU[mn] << 3 | R8[src])
            return self.emit(0xC6 | ALU[mn] << 3, self.ev(raw))
        if mn in ('inc', 'dec'):
            if a in R16:
                return self.emit((0x03 if mn == 'inc' else 0x0B) | R16[a] << 4)
            return self.emit((0x04 if mn == 'inc' else 0x05) | R8[a] << 3)
        if mn == 'jp':
            if a == '(hl)': return self.emit(0xE9)
            if len(ops) == 2:
                self.emit(0xC2 | CC[a] << 3); return self.w(self.ev(ops[1]))
            self.emit(0xC3); return self.w(self.ev(ops[0]))
        if mn == 'jr':
            if len(ops) == 2:
                if CC[a] > 3: raise AsmError('jr condition')
                self.emit(0x20 | CC[a] << 3); return self.rel(ops[1])
            self.emit(0x18); return self.rel(ops[0])
        if mn == 'djnz':
            self.emit(0x10); return self.rel(ops[0])
        if mn == 'call':
            if len(ops) == 2:
                self.emit(0xC4 | CC[a] << 3); return self.w(self.ev(ops[1]))
            self.emit(0xCD); return self.w(self.ev(ops[0]))
        if mn == 'ret':
            return self.emit(0xC0 | CC[a] << 3)
        if mn == 'rst':
            return self.emit(0xC7 | self.ev(ops[0]))
        if mn == 'push': return self.emit(0xC5 | R16AF[a] << 4)
        if mn == 'pop': return self.emit(0xC1 | R16AF[a] << 4)
        if mn == 'ex':
            if a == 'de' and b == 'hl': return self.emit(0xEB)
            if a == 'af': return self.emit(0x08)
            if a == '(sp)' and b == 'hl': return self.emit(0xE3)
            raise AsmError('bad ex')
        if mn == 'in':
            if b == '(c)': return self.emit(0xED, 0x40 | R8[a] << 3)
            if a == 'a': return self.emit(0xDB, self.ev(ops[1][1:-1]))
            raise AsmError('bad in')
        if mn == 'out':
            if a == '(c)': return self.emit(0xED, 0x41 | R8[b] << 3)
            if b == 'a': return self.emit(0xD3, self.ev(ops[0][1:-1]))
            raise AsmError('bad out')
        if mn in ROT:
            return self.emit(0xCB, ROT[mn] << 3 | R8[a])
        if mn in ('bit', 'res', 'set'):
            base = {'bit': 0x40, 'res': 0x80, 'set': 0xC0}[mn]
            return self.emit(0xCB, base | self.ev(ops[0]) << 3 | R8[b])
        raise AsmError('unknown instruction %s' % mn)

    def lines(self, path):
        with open(path, encoding='utf-8') as f:
            for n, line in enumerate(f, 1):
                yield path, n, line

    def run_pass(self, path, final):
        self.final = final
        self.pc = 0
        if final:
            self.out = bytearray([0xFF] * self.size)
            self.used = bytearray(self.size)
        stack = [self.lines(path)]
        while stack:
            try:
                src, n, line = next(stack[-1])
            except StopIteration:
                stack.pop(); continue
            try:
                inc = self.line(line, src)
                if inc:
                    stack.append(self.lines(inc))
            except (AsmError, KeyError, IndexError, SyntaxError, TypeError) as e:
                raise AsmError('%s:%d: %s: %s' % (os.path.basename(src), n, type(e).__name__, e))

    def line(self, line, src):
        s = line
        # strip a comment that is not inside quotes
        q = None
        for i, ch in enumerate(s):
            if q:
                if ch == q: q = None
            elif ch == '"':
                q = ch
            elif ch == ';':
                s = s[:i]; break
        s = s.strip()
        if not s:
            return None
        m = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$', s)
        if m:
            self.syms[m.group(1)] = self.ev(m.group(2))
            return None
        m = re.match(r'^([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$', s)
        if m:
            name = m.group(1)
            if self.final and self.syms.get(name) != self.pc:
                raise AsmError('label %s moved between passes' % name)
            self.syms[name] = self.pc
            s = m.group(2).strip()
            if not s:
                return None
        parts = s.split(None, 1)
        mn = parts[0].lower()
        ops = split_ops(parts[1]) if len(parts) > 1 else []
        if mn == '.org':
            self.pc = self.ev(ops[0]); return None
        if mn == '.include':
            return os.path.join(os.path.dirname(src), ops[0].strip('"'))
        if mn == '.db':
            for o in ops:
                if o.startswith('"'):
                    for ch in o[1:-1]:
                        self.emit(ord(ch))
                else:
                    self.emit(self.ev(o))
            return None
        if mn == '.dw':
            for o in ops:
                self.w(self.ev(o))
            return None
        if mn == '.ds':
            fill = self.ev(ops[1]) if len(ops) > 1 else 0
            for _ in range(self.ev(ops[0])):
                self.emit(fill)
            return None
        self.ins(mn, ops)
        return None

    def assemble(self, path):
        self.run_pass(path, False)
        self.run_pass(path, False)
        self.run_pass(path, True)
        return self.out, self.used


def sms_header(img, product=0x0000, version=0):
    """TMR SEGA header for a 32 KB export cartridge: checksum over $0000-$7FEF
    (size code $C), region code 4 (Master System export)."""
    assert len(img) == 0x8000
    img[0x7FF0:0x7FF8] = b'TMR SEGA'
    img[0x7FF8] = 0x00
    img[0x7FF9] = 0x00
    s = sum(img[0:0x7FF0]) & 0xFFFF
    img[0x7FFA] = s & 0xFF
    img[0x7FFB] = s >> 8
    img[0x7FFC] = product & 0xFF
    img[0x7FFD] = (product >> 8) & 0xFF
    img[0x7FFE] = version & 0x0F
    img[0x7FFF] = 0x4C
    return img
